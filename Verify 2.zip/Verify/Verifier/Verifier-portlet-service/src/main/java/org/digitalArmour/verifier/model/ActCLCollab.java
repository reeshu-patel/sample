package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the ActCLCollab service. Represents a row in the &quot;Verifier_ActCLCollab&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ActCLCollabModel
 * @see org.digitalArmour.verifier.model.impl.ActCLCollabImpl
 * @see org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl
 * @generated
 */
public interface ActCLCollab extends ActCLCollabModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ActCLCollabImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
