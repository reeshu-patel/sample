package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ActCLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class ActCLCollabClp extends BaseModelImpl<ActCLCollab>
    implements ActCLCollab {
    private String _uuid;
    private long _actClCollabId;
    private String _actCollabType;
    private long _actPrManagerId;
    private long _userId;
    private String _userUuid;
    private long _actChecklistId;
    private BaseModel<?> _actCLCollabRemoteModel;

    public ActCLCollabClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ActCLCollab.class;
    }

    @Override
    public String getModelClassName() {
        return ActCLCollab.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _actClCollabId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setActClCollabId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _actClCollabId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("actClCollabId", getActClCollabId());
        attributes.put("actCollabType", getActCollabType());
        attributes.put("actPrManagerId", getActPrManagerId());
        attributes.put("userId", getUserId());
        attributes.put("actChecklistId", getActChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long actClCollabId = (Long) attributes.get("actClCollabId");

        if (actClCollabId != null) {
            setActClCollabId(actClCollabId);
        }

        String actCollabType = (String) attributes.get("actCollabType");

        if (actCollabType != null) {
            setActCollabType(actCollabType);
        }

        Long actPrManagerId = (Long) attributes.get("actPrManagerId");

        if (actPrManagerId != null) {
            setActPrManagerId(actPrManagerId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        Long actChecklistId = (Long) attributes.get("actChecklistId");

        if (actChecklistId != null) {
            setActChecklistId(actChecklistId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_actCLCollabRemoteModel != null) {
            try {
                Class<?> clazz = _actCLCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_actCLCollabRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActClCollabId() {
        return _actClCollabId;
    }

    @Override
    public void setActClCollabId(long actClCollabId) {
        _actClCollabId = actClCollabId;

        if (_actCLCollabRemoteModel != null) {
            try {
                Class<?> clazz = _actCLCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setActClCollabId", long.class);

                method.invoke(_actCLCollabRemoteModel, actClCollabId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getActCollabType() {
        return _actCollabType;
    }

    @Override
    public void setActCollabType(String actCollabType) {
        _actCollabType = actCollabType;

        if (_actCLCollabRemoteModel != null) {
            try {
                Class<?> clazz = _actCLCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setActCollabType", String.class);

                method.invoke(_actCLCollabRemoteModel, actCollabType);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActPrManagerId() {
        return _actPrManagerId;
    }

    @Override
    public void setActPrManagerId(long actPrManagerId) {
        _actPrManagerId = actPrManagerId;

        if (_actCLCollabRemoteModel != null) {
            try {
                Class<?> clazz = _actCLCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setActPrManagerId", long.class);

                method.invoke(_actCLCollabRemoteModel, actPrManagerId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_actCLCollabRemoteModel != null) {
            try {
                Class<?> clazz = _actCLCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_actCLCollabRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    @Override
    public long getActChecklistId() {
        return _actChecklistId;
    }

    @Override
    public void setActChecklistId(long actChecklistId) {
        _actChecklistId = actChecklistId;

        if (_actCLCollabRemoteModel != null) {
            try {
                Class<?> clazz = _actCLCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setActChecklistId", long.class);

                method.invoke(_actCLCollabRemoteModel, actChecklistId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> getActCLCollabRemoteModel() {
        return _actCLCollabRemoteModel;
    }

    public void setActCLCollabRemoteModel(BaseModel<?> actCLCollabRemoteModel) {
        _actCLCollabRemoteModel = actCLCollabRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _actCLCollabRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_actCLCollabRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ActCLCollabLocalServiceUtil.addActCLCollab(this);
        } else {
            ActCLCollabLocalServiceUtil.updateActCLCollab(this);
        }
    }

    @Override
    public ActCLCollab toEscapedModel() {
        return (ActCLCollab) ProxyUtil.newProxyInstance(ActCLCollab.class.getClassLoader(),
            new Class[] { ActCLCollab.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ActCLCollabClp clone = new ActCLCollabClp();

        clone.setUuid(getUuid());
        clone.setActClCollabId(getActClCollabId());
        clone.setActCollabType(getActCollabType());
        clone.setActPrManagerId(getActPrManagerId());
        clone.setUserId(getUserId());
        clone.setActChecklistId(getActChecklistId());

        return clone;
    }

    @Override
    public int compareTo(ActCLCollab actCLCollab) {
        int value = 0;

        if (getActClCollabId() < actCLCollab.getActClCollabId()) {
            value = -1;
        } else if (getActClCollabId() > actCLCollab.getActClCollabId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActCLCollabClp)) {
            return false;
        }

        ActCLCollabClp actCLCollab = (ActCLCollabClp) obj;

        long primaryKey = actCLCollab.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", actClCollabId=");
        sb.append(getActClCollabId());
        sb.append(", actCollabType=");
        sb.append(getActCollabType());
        sb.append(", actPrManagerId=");
        sb.append(getActPrManagerId());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append(", actChecklistId=");
        sb.append(getActChecklistId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(22);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ActCLCollab");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>actClCollabId</column-name><column-value><![CDATA[");
        sb.append(getActClCollabId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>actCollabType</column-name><column-value><![CDATA[");
        sb.append(getActCollabType());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>actPrManagerId</column-name><column-value><![CDATA[");
        sb.append(getActPrManagerId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>actChecklistId</column-name><column-value><![CDATA[");
        sb.append(getActChecklistId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
