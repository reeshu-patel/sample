package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ActCLCollabServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ActCLCollabServiceSoap
 * @generated
 */
public class ActCLCollabSoap implements Serializable {
    private String _uuid;
    private long _actClCollabId;
    private String _actCollabType;
    private long _actPrManagerId;
    private long _userId;
    private long _actChecklistId;

    public ActCLCollabSoap() {
    }

    public static ActCLCollabSoap toSoapModel(ActCLCollab model) {
        ActCLCollabSoap soapModel = new ActCLCollabSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setActClCollabId(model.getActClCollabId());
        soapModel.setActCollabType(model.getActCollabType());
        soapModel.setActPrManagerId(model.getActPrManagerId());
        soapModel.setUserId(model.getUserId());
        soapModel.setActChecklistId(model.getActChecklistId());

        return soapModel;
    }

    public static ActCLCollabSoap[] toSoapModels(ActCLCollab[] models) {
        ActCLCollabSoap[] soapModels = new ActCLCollabSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ActCLCollabSoap[][] toSoapModels(ActCLCollab[][] models) {
        ActCLCollabSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ActCLCollabSoap[models.length][models[0].length];
        } else {
            soapModels = new ActCLCollabSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ActCLCollabSoap[] toSoapModels(List<ActCLCollab> models) {
        List<ActCLCollabSoap> soapModels = new ArrayList<ActCLCollabSoap>(models.size());

        for (ActCLCollab model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ActCLCollabSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _actClCollabId;
    }

    public void setPrimaryKey(long pk) {
        setActClCollabId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getActClCollabId() {
        return _actClCollabId;
    }

    public void setActClCollabId(long actClCollabId) {
        _actClCollabId = actClCollabId;
    }

    public String getActCollabType() {
        return _actCollabType;
    }

    public void setActCollabType(String actCollabType) {
        _actCollabType = actCollabType;
    }

    public long getActPrManagerId() {
        return _actPrManagerId;
    }

    public void setActPrManagerId(long actPrManagerId) {
        _actPrManagerId = actPrManagerId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }

    public long getActChecklistId() {
        return _actChecklistId;
    }

    public void setActChecklistId(long actChecklistId) {
        _actChecklistId = actChecklistId;
    }
}
