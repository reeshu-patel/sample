package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActCLCollab}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActCLCollab
 * @generated
 */
public class ActCLCollabWrapper implements ActCLCollab,
    ModelWrapper<ActCLCollab> {
    private ActCLCollab _actCLCollab;

    public ActCLCollabWrapper(ActCLCollab actCLCollab) {
        _actCLCollab = actCLCollab;
    }

    @Override
    public Class<?> getModelClass() {
        return ActCLCollab.class;
    }

    @Override
    public String getModelClassName() {
        return ActCLCollab.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("actClCollabId", getActClCollabId());
        attributes.put("actCollabType", getActCollabType());
        attributes.put("actPrManagerId", getActPrManagerId());
        attributes.put("userId", getUserId());
        attributes.put("actChecklistId", getActChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long actClCollabId = (Long) attributes.get("actClCollabId");

        if (actClCollabId != null) {
            setActClCollabId(actClCollabId);
        }

        String actCollabType = (String) attributes.get("actCollabType");

        if (actCollabType != null) {
            setActCollabType(actCollabType);
        }

        Long actPrManagerId = (Long) attributes.get("actPrManagerId");

        if (actPrManagerId != null) {
            setActPrManagerId(actPrManagerId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        Long actChecklistId = (Long) attributes.get("actChecklistId");

        if (actChecklistId != null) {
            setActChecklistId(actChecklistId);
        }
    }

    /**
    * Returns the primary key of this act c l collab.
    *
    * @return the primary key of this act c l collab
    */
    @Override
    public long getPrimaryKey() {
        return _actCLCollab.getPrimaryKey();
    }

    /**
    * Sets the primary key of this act c l collab.
    *
    * @param primaryKey the primary key of this act c l collab
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _actCLCollab.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this act c l collab.
    *
    * @return the uuid of this act c l collab
    */
    @Override
    public java.lang.String getUuid() {
        return _actCLCollab.getUuid();
    }

    /**
    * Sets the uuid of this act c l collab.
    *
    * @param uuid the uuid of this act c l collab
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _actCLCollab.setUuid(uuid);
    }

    /**
    * Returns the act cl collab ID of this act c l collab.
    *
    * @return the act cl collab ID of this act c l collab
    */
    @Override
    public long getActClCollabId() {
        return _actCLCollab.getActClCollabId();
    }

    /**
    * Sets the act cl collab ID of this act c l collab.
    *
    * @param actClCollabId the act cl collab ID of this act c l collab
    */
    @Override
    public void setActClCollabId(long actClCollabId) {
        _actCLCollab.setActClCollabId(actClCollabId);
    }

    /**
    * Returns the act collab type of this act c l collab.
    *
    * @return the act collab type of this act c l collab
    */
    @Override
    public java.lang.String getActCollabType() {
        return _actCLCollab.getActCollabType();
    }

    /**
    * Sets the act collab type of this act c l collab.
    *
    * @param actCollabType the act collab type of this act c l collab
    */
    @Override
    public void setActCollabType(java.lang.String actCollabType) {
        _actCLCollab.setActCollabType(actCollabType);
    }

    /**
    * Returns the act pr manager ID of this act c l collab.
    *
    * @return the act pr manager ID of this act c l collab
    */
    @Override
    public long getActPrManagerId() {
        return _actCLCollab.getActPrManagerId();
    }

    /**
    * Sets the act pr manager ID of this act c l collab.
    *
    * @param actPrManagerId the act pr manager ID of this act c l collab
    */
    @Override
    public void setActPrManagerId(long actPrManagerId) {
        _actCLCollab.setActPrManagerId(actPrManagerId);
    }

    /**
    * Returns the user ID of this act c l collab.
    *
    * @return the user ID of this act c l collab
    */
    @Override
    public long getUserId() {
        return _actCLCollab.getUserId();
    }

    /**
    * Sets the user ID of this act c l collab.
    *
    * @param userId the user ID of this act c l collab
    */
    @Override
    public void setUserId(long userId) {
        _actCLCollab.setUserId(userId);
    }

    /**
    * Returns the user uuid of this act c l collab.
    *
    * @return the user uuid of this act c l collab
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollab.getUserUuid();
    }

    /**
    * Sets the user uuid of this act c l collab.
    *
    * @param userUuid the user uuid of this act c l collab
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _actCLCollab.setUserUuid(userUuid);
    }

    /**
    * Returns the act checklist ID of this act c l collab.
    *
    * @return the act checklist ID of this act c l collab
    */
    @Override
    public long getActChecklistId() {
        return _actCLCollab.getActChecklistId();
    }

    /**
    * Sets the act checklist ID of this act c l collab.
    *
    * @param actChecklistId the act checklist ID of this act c l collab
    */
    @Override
    public void setActChecklistId(long actChecklistId) {
        _actCLCollab.setActChecklistId(actChecklistId);
    }

    @Override
    public boolean isNew() {
        return _actCLCollab.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _actCLCollab.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _actCLCollab.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _actCLCollab.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _actCLCollab.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _actCLCollab.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _actCLCollab.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _actCLCollab.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _actCLCollab.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _actCLCollab.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _actCLCollab.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ActCLCollabWrapper((ActCLCollab) _actCLCollab.clone());
    }

    @Override
    public int compareTo(ActCLCollab actCLCollab) {
        return _actCLCollab.compareTo(actCLCollab);
    }

    @Override
    public int hashCode() {
        return _actCLCollab.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ActCLCollab> toCacheModel() {
        return _actCLCollab.toCacheModel();
    }

    @Override
    public ActCLCollab toEscapedModel() {
        return new ActCLCollabWrapper(_actCLCollab.toEscapedModel());
    }

    @Override
    public ActCLCollab toUnescapedModel() {
        return new ActCLCollabWrapper(_actCLCollab.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _actCLCollab.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _actCLCollab.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _actCLCollab.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActCLCollabWrapper)) {
            return false;
        }

        ActCLCollabWrapper actCLCollabWrapper = (ActCLCollabWrapper) obj;

        if (Validator.equals(_actCLCollab, actCLCollabWrapper._actCLCollab)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ActCLCollab getWrappedActCLCollab() {
        return _actCLCollab;
    }

    @Override
    public ActCLCollab getWrappedModel() {
        return _actCLCollab;
    }

    @Override
    public void resetOriginalValues() {
        _actCLCollab.resetOriginalValues();
    }
}
