package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the ActCategory service. Represents a row in the &quot;Verifier_ActCategory&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ActCategoryModel
 * @see org.digitalArmour.verifier.model.impl.ActCategoryImpl
 * @see org.digitalArmour.verifier.model.impl.ActCategoryModelImpl
 * @generated
 */
public interface ActCategory extends ActCategoryModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ActCategoryImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
