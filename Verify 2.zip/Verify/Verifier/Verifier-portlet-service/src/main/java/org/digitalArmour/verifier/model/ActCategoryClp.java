package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class ActCategoryClp extends BaseModelImpl<ActCategory>
    implements ActCategory {
    private String _uuid;
    private long _ActCategoryId;
    private long _ActiveCheckListID;
    private String _CategoryName;
    private long _SubCatogryId;
    private BaseModel<?> _actCategoryRemoteModel;

    public ActCategoryClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ActCategory.class;
    }

    @Override
    public String getModelClassName() {
        return ActCategory.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _ActCategoryId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setActCategoryId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _ActCategoryId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("ActCategoryId", getActCategoryId());
        attributes.put("ActiveCheckListID", getActiveCheckListID());
        attributes.put("CategoryName", getCategoryName());
        attributes.put("SubCatogryId", getSubCatogryId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long ActCategoryId = (Long) attributes.get("ActCategoryId");

        if (ActCategoryId != null) {
            setActCategoryId(ActCategoryId);
        }

        Long ActiveCheckListID = (Long) attributes.get("ActiveCheckListID");

        if (ActiveCheckListID != null) {
            setActiveCheckListID(ActiveCheckListID);
        }

        String CategoryName = (String) attributes.get("CategoryName");

        if (CategoryName != null) {
            setCategoryName(CategoryName);
        }

        Long SubCatogryId = (Long) attributes.get("SubCatogryId");

        if (SubCatogryId != null) {
            setSubCatogryId(SubCatogryId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_actCategoryRemoteModel != null) {
            try {
                Class<?> clazz = _actCategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_actCategoryRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActCategoryId() {
        return _ActCategoryId;
    }

    @Override
    public void setActCategoryId(long ActCategoryId) {
        _ActCategoryId = ActCategoryId;

        if (_actCategoryRemoteModel != null) {
            try {
                Class<?> clazz = _actCategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setActCategoryId", long.class);

                method.invoke(_actCategoryRemoteModel, ActCategoryId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActiveCheckListID() {
        return _ActiveCheckListID;
    }

    @Override
    public void setActiveCheckListID(long ActiveCheckListID) {
        _ActiveCheckListID = ActiveCheckListID;

        if (_actCategoryRemoteModel != null) {
            try {
                Class<?> clazz = _actCategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setActiveCheckListID",
                        long.class);

                method.invoke(_actCategoryRemoteModel, ActiveCheckListID);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getCategoryName() {
        return _CategoryName;
    }

    @Override
    public void setCategoryName(String CategoryName) {
        _CategoryName = CategoryName;

        if (_actCategoryRemoteModel != null) {
            try {
                Class<?> clazz = _actCategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setCategoryName", String.class);

                method.invoke(_actCategoryRemoteModel, CategoryName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getSubCatogryId() {
        return _SubCatogryId;
    }

    @Override
    public void setSubCatogryId(long SubCatogryId) {
        _SubCatogryId = SubCatogryId;

        if (_actCategoryRemoteModel != null) {
            try {
                Class<?> clazz = _actCategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setSubCatogryId", long.class);

                method.invoke(_actCategoryRemoteModel, SubCatogryId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> getActCategoryRemoteModel() {
        return _actCategoryRemoteModel;
    }

    public void setActCategoryRemoteModel(BaseModel<?> actCategoryRemoteModel) {
        _actCategoryRemoteModel = actCategoryRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _actCategoryRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_actCategoryRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ActCategoryLocalServiceUtil.addActCategory(this);
        } else {
            ActCategoryLocalServiceUtil.updateActCategory(this);
        }
    }

    @Override
    public ActCategory toEscapedModel() {
        return (ActCategory) ProxyUtil.newProxyInstance(ActCategory.class.getClassLoader(),
            new Class[] { ActCategory.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ActCategoryClp clone = new ActCategoryClp();

        clone.setUuid(getUuid());
        clone.setActCategoryId(getActCategoryId());
        clone.setActiveCheckListID(getActiveCheckListID());
        clone.setCategoryName(getCategoryName());
        clone.setSubCatogryId(getSubCatogryId());

        return clone;
    }

    @Override
    public int compareTo(ActCategory actCategory) {
        long primaryKey = actCategory.getPrimaryKey();

        if (getPrimaryKey() < primaryKey) {
            return -1;
        } else if (getPrimaryKey() > primaryKey) {
            return 1;
        } else {
            return 0;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActCategoryClp)) {
            return false;
        }

        ActCategoryClp actCategory = (ActCategoryClp) obj;

        long primaryKey = actCategory.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(11);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", ActCategoryId=");
        sb.append(getActCategoryId());
        sb.append(", ActiveCheckListID=");
        sb.append(getActiveCheckListID());
        sb.append(", CategoryName=");
        sb.append(getCategoryName());
        sb.append(", SubCatogryId=");
        sb.append(getSubCatogryId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(19);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ActCategory");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>ActCategoryId</column-name><column-value><![CDATA[");
        sb.append(getActCategoryId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>ActiveCheckListID</column-name><column-value><![CDATA[");
        sb.append(getActiveCheckListID());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>CategoryName</column-name><column-value><![CDATA[");
        sb.append(getCategoryName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>SubCatogryId</column-name><column-value><![CDATA[");
        sb.append(getSubCatogryId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
