package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ActCategoryServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ActCategoryServiceSoap
 * @generated
 */
public class ActCategorySoap implements Serializable {
    private String _uuid;
    private long _ActCategoryId;
    private long _ActiveCheckListID;
    private String _CategoryName;
    private long _SubCatogryId;

    public ActCategorySoap() {
    }

    public static ActCategorySoap toSoapModel(ActCategory model) {
        ActCategorySoap soapModel = new ActCategorySoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setActCategoryId(model.getActCategoryId());
        soapModel.setActiveCheckListID(model.getActiveCheckListID());
        soapModel.setCategoryName(model.getCategoryName());
        soapModel.setSubCatogryId(model.getSubCatogryId());

        return soapModel;
    }

    public static ActCategorySoap[] toSoapModels(ActCategory[] models) {
        ActCategorySoap[] soapModels = new ActCategorySoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ActCategorySoap[][] toSoapModels(ActCategory[][] models) {
        ActCategorySoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ActCategorySoap[models.length][models[0].length];
        } else {
            soapModels = new ActCategorySoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ActCategorySoap[] toSoapModels(List<ActCategory> models) {
        List<ActCategorySoap> soapModels = new ArrayList<ActCategorySoap>(models.size());

        for (ActCategory model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ActCategorySoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _ActCategoryId;
    }

    public void setPrimaryKey(long pk) {
        setActCategoryId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getActCategoryId() {
        return _ActCategoryId;
    }

    public void setActCategoryId(long ActCategoryId) {
        _ActCategoryId = ActCategoryId;
    }

    public long getActiveCheckListID() {
        return _ActiveCheckListID;
    }

    public void setActiveCheckListID(long ActiveCheckListID) {
        _ActiveCheckListID = ActiveCheckListID;
    }

    public String getCategoryName() {
        return _CategoryName;
    }

    public void setCategoryName(String CategoryName) {
        _CategoryName = CategoryName;
    }

    public long getSubCatogryId() {
        return _SubCatogryId;
    }

    public void setSubCatogryId(long SubCatogryId) {
        _SubCatogryId = SubCatogryId;
    }
}
