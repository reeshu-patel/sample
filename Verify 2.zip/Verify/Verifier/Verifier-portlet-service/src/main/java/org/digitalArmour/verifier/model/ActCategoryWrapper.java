package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActCategory}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActCategory
 * @generated
 */
public class ActCategoryWrapper implements ActCategory,
    ModelWrapper<ActCategory> {
    private ActCategory _actCategory;

    public ActCategoryWrapper(ActCategory actCategory) {
        _actCategory = actCategory;
    }

    @Override
    public Class<?> getModelClass() {
        return ActCategory.class;
    }

    @Override
    public String getModelClassName() {
        return ActCategory.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("ActCategoryId", getActCategoryId());
        attributes.put("ActiveCheckListID", getActiveCheckListID());
        attributes.put("CategoryName", getCategoryName());
        attributes.put("SubCatogryId", getSubCatogryId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long ActCategoryId = (Long) attributes.get("ActCategoryId");

        if (ActCategoryId != null) {
            setActCategoryId(ActCategoryId);
        }

        Long ActiveCheckListID = (Long) attributes.get("ActiveCheckListID");

        if (ActiveCheckListID != null) {
            setActiveCheckListID(ActiveCheckListID);
        }

        String CategoryName = (String) attributes.get("CategoryName");

        if (CategoryName != null) {
            setCategoryName(CategoryName);
        }

        Long SubCatogryId = (Long) attributes.get("SubCatogryId");

        if (SubCatogryId != null) {
            setSubCatogryId(SubCatogryId);
        }
    }

    /**
    * Returns the primary key of this act category.
    *
    * @return the primary key of this act category
    */
    @Override
    public long getPrimaryKey() {
        return _actCategory.getPrimaryKey();
    }

    /**
    * Sets the primary key of this act category.
    *
    * @param primaryKey the primary key of this act category
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _actCategory.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this act category.
    *
    * @return the uuid of this act category
    */
    @Override
    public java.lang.String getUuid() {
        return _actCategory.getUuid();
    }

    /**
    * Sets the uuid of this act category.
    *
    * @param uuid the uuid of this act category
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _actCategory.setUuid(uuid);
    }

    /**
    * Returns the act category ID of this act category.
    *
    * @return the act category ID of this act category
    */
    @Override
    public long getActCategoryId() {
        return _actCategory.getActCategoryId();
    }

    /**
    * Sets the act category ID of this act category.
    *
    * @param ActCategoryId the act category ID of this act category
    */
    @Override
    public void setActCategoryId(long ActCategoryId) {
        _actCategory.setActCategoryId(ActCategoryId);
    }

    /**
    * Returns the active check list i d of this act category.
    *
    * @return the active check list i d of this act category
    */
    @Override
    public long getActiveCheckListID() {
        return _actCategory.getActiveCheckListID();
    }

    /**
    * Sets the active check list i d of this act category.
    *
    * @param ActiveCheckListID the active check list i d of this act category
    */
    @Override
    public void setActiveCheckListID(long ActiveCheckListID) {
        _actCategory.setActiveCheckListID(ActiveCheckListID);
    }

    /**
    * Returns the category name of this act category.
    *
    * @return the category name of this act category
    */
    @Override
    public java.lang.String getCategoryName() {
        return _actCategory.getCategoryName();
    }

    /**
    * Sets the category name of this act category.
    *
    * @param CategoryName the category name of this act category
    */
    @Override
    public void setCategoryName(java.lang.String CategoryName) {
        _actCategory.setCategoryName(CategoryName);
    }

    /**
    * Returns the sub catogry ID of this act category.
    *
    * @return the sub catogry ID of this act category
    */
    @Override
    public long getSubCatogryId() {
        return _actCategory.getSubCatogryId();
    }

    /**
    * Sets the sub catogry ID of this act category.
    *
    * @param SubCatogryId the sub catogry ID of this act category
    */
    @Override
    public void setSubCatogryId(long SubCatogryId) {
        _actCategory.setSubCatogryId(SubCatogryId);
    }

    @Override
    public boolean isNew() {
        return _actCategory.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _actCategory.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _actCategory.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _actCategory.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _actCategory.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _actCategory.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _actCategory.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _actCategory.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _actCategory.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _actCategory.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _actCategory.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ActCategoryWrapper((ActCategory) _actCategory.clone());
    }

    @Override
    public int compareTo(ActCategory actCategory) {
        return _actCategory.compareTo(actCategory);
    }

    @Override
    public int hashCode() {
        return _actCategory.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ActCategory> toCacheModel() {
        return _actCategory.toCacheModel();
    }

    @Override
    public ActCategory toEscapedModel() {
        return new ActCategoryWrapper(_actCategory.toEscapedModel());
    }

    @Override
    public ActCategory toUnescapedModel() {
        return new ActCategoryWrapper(_actCategory.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _actCategory.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _actCategory.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _actCategory.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActCategoryWrapper)) {
            return false;
        }

        ActCategoryWrapper actCategoryWrapper = (ActCategoryWrapper) obj;

        if (Validator.equals(_actCategory, actCategoryWrapper._actCategory)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ActCategory getWrappedActCategory() {
        return _actCategory;
    }

    @Override
    public ActCategory getWrappedModel() {
        return _actCategory;
    }

    @Override
    public void resetOriginalValues() {
        _actCategory.resetOriginalValues();
    }
}
