package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the ActItem service. Represents a row in the &quot;Verifier_ActItem&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemModel
 * @see org.digitalArmour.verifier.model.impl.ActItemImpl
 * @see org.digitalArmour.verifier.model.impl.ActItemModelImpl
 * @generated
 */
public interface ActItem extends ActItemModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ActItemImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
