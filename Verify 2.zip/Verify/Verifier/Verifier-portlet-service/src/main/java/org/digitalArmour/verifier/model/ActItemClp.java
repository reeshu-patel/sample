package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ActItemLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ActItemClp extends BaseModelImpl<ActItem> implements ActItem {
    private String _uuid;
    private long _ItemId;
    private String _itemName;
    private String _itemDesc;
    private boolean _ignore;
    private boolean _isMajor;
    private long _percentage;
    private Date _completedDate;
    private boolean _completed;
    private long _ActivateClid;
    private long _usergroupId;
    private boolean _major;
    private long _major_percent;
    private long _catId;
    private long _userId;
    private String _userUuid;
    private BaseModel<?> _actItemRemoteModel;

    public ActItemClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ActItem.class;
    }

    @Override
    public String getModelClassName() {
        return ActItem.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _ItemId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setItemId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _ItemId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("ItemId", getItemId());
        attributes.put("itemName", getItemName());
        attributes.put("itemDesc", getItemDesc());
        attributes.put("ignore", getIgnore());
        attributes.put("isMajor", getIsMajor());
        attributes.put("percentage", getPercentage());
        attributes.put("completedDate", getCompletedDate());
        attributes.put("completed", getCompleted());
        attributes.put("ActivateClid", getActivateClid());
        attributes.put("usergroupId", getUsergroupId());
        attributes.put("major", getMajor());
        attributes.put("major_percent", getMajor_percent());
        attributes.put("catId", getCatId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long ItemId = (Long) attributes.get("ItemId");

        if (ItemId != null) {
            setItemId(ItemId);
        }

        String itemName = (String) attributes.get("itemName");

        if (itemName != null) {
            setItemName(itemName);
        }

        String itemDesc = (String) attributes.get("itemDesc");

        if (itemDesc != null) {
            setItemDesc(itemDesc);
        }

        Boolean ignore = (Boolean) attributes.get("ignore");

        if (ignore != null) {
            setIgnore(ignore);
        }

        Boolean isMajor = (Boolean) attributes.get("isMajor");

        if (isMajor != null) {
            setIsMajor(isMajor);
        }

        Long percentage = (Long) attributes.get("percentage");

        if (percentage != null) {
            setPercentage(percentage);
        }

        Date completedDate = (Date) attributes.get("completedDate");

        if (completedDate != null) {
            setCompletedDate(completedDate);
        }

        Boolean completed = (Boolean) attributes.get("completed");

        if (completed != null) {
            setCompleted(completed);
        }

        Long ActivateClid = (Long) attributes.get("ActivateClid");

        if (ActivateClid != null) {
            setActivateClid(ActivateClid);
        }

        Long usergroupId = (Long) attributes.get("usergroupId");

        if (usergroupId != null) {
            setUsergroupId(usergroupId);
        }

        Boolean major = (Boolean) attributes.get("major");

        if (major != null) {
            setMajor(major);
        }

        Long major_percent = (Long) attributes.get("major_percent");

        if (major_percent != null) {
            setMajor_percent(major_percent);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_actItemRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getItemId() {
        return _ItemId;
    }

    @Override
    public void setItemId(long ItemId) {
        _ItemId = ItemId;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setItemId", long.class);

                method.invoke(_actItemRemoteModel, ItemId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getItemName() {
        return _itemName;
    }

    @Override
    public void setItemName(String itemName) {
        _itemName = itemName;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setItemName", String.class);

                method.invoke(_actItemRemoteModel, itemName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getItemDesc() {
        return _itemDesc;
    }

    @Override
    public void setItemDesc(String itemDesc) {
        _itemDesc = itemDesc;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setItemDesc", String.class);

                method.invoke(_actItemRemoteModel, itemDesc);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getIgnore() {
        return _ignore;
    }

    @Override
    public boolean isIgnore() {
        return _ignore;
    }

    @Override
    public void setIgnore(boolean ignore) {
        _ignore = ignore;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setIgnore", boolean.class);

                method.invoke(_actItemRemoteModel, ignore);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getIsMajor() {
        return _isMajor;
    }

    @Override
    public boolean isIsMajor() {
        return _isMajor;
    }

    @Override
    public void setIsMajor(boolean isMajor) {
        _isMajor = isMajor;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setIsMajor", boolean.class);

                method.invoke(_actItemRemoteModel, isMajor);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getPercentage() {
        return _percentage;
    }

    @Override
    public void setPercentage(long percentage) {
        _percentage = percentage;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setPercentage", long.class);

                method.invoke(_actItemRemoteModel, percentage);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public Date getCompletedDate() {
        return _completedDate;
    }

    @Override
    public void setCompletedDate(Date completedDate) {
        _completedDate = completedDate;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setCompletedDate", Date.class);

                method.invoke(_actItemRemoteModel, completedDate);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getCompleted() {
        return _completed;
    }

    @Override
    public boolean isCompleted() {
        return _completed;
    }

    @Override
    public void setCompleted(boolean completed) {
        _completed = completed;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setCompleted", boolean.class);

                method.invoke(_actItemRemoteModel, completed);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActivateClid() {
        return _ActivateClid;
    }

    @Override
    public void setActivateClid(long ActivateClid) {
        _ActivateClid = ActivateClid;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setActivateClid", long.class);

                method.invoke(_actItemRemoteModel, ActivateClid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUsergroupId() {
        return _usergroupId;
    }

    @Override
    public void setUsergroupId(long usergroupId) {
        _usergroupId = usergroupId;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setUsergroupId", long.class);

                method.invoke(_actItemRemoteModel, usergroupId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getMajor() {
        return _major;
    }

    @Override
    public boolean isMajor() {
        return _major;
    }

    @Override
    public void setMajor(boolean major) {
        _major = major;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setMajor", boolean.class);

                method.invoke(_actItemRemoteModel, major);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getMajor_percent() {
        return _major_percent;
    }

    @Override
    public void setMajor_percent(long major_percent) {
        _major_percent = major_percent;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setMajor_percent", long.class);

                method.invoke(_actItemRemoteModel, major_percent);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getCatId() {
        return _catId;
    }

    @Override
    public void setCatId(long catId) {
        _catId = catId;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setCatId", long.class);

                method.invoke(_actItemRemoteModel, catId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_actItemRemoteModel != null) {
            try {
                Class<?> clazz = _actItemRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_actItemRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    public BaseModel<?> getActItemRemoteModel() {
        return _actItemRemoteModel;
    }

    public void setActItemRemoteModel(BaseModel<?> actItemRemoteModel) {
        _actItemRemoteModel = actItemRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _actItemRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_actItemRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ActItemLocalServiceUtil.addActItem(this);
        } else {
            ActItemLocalServiceUtil.updateActItem(this);
        }
    }

    @Override
    public ActItem toEscapedModel() {
        return (ActItem) ProxyUtil.newProxyInstance(ActItem.class.getClassLoader(),
            new Class[] { ActItem.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ActItemClp clone = new ActItemClp();

        clone.setUuid(getUuid());
        clone.setItemId(getItemId());
        clone.setItemName(getItemName());
        clone.setItemDesc(getItemDesc());
        clone.setIgnore(getIgnore());
        clone.setIsMajor(getIsMajor());
        clone.setPercentage(getPercentage());
        clone.setCompletedDate(getCompletedDate());
        clone.setCompleted(getCompleted());
        clone.setActivateClid(getActivateClid());
        clone.setUsergroupId(getUsergroupId());
        clone.setMajor(getMajor());
        clone.setMajor_percent(getMajor_percent());
        clone.setCatId(getCatId());
        clone.setUserId(getUserId());

        return clone;
    }

    @Override
    public int compareTo(ActItem actItem) {
        int value = 0;

        value = DateUtil.compareTo(getCompletedDate(),
                actItem.getCompletedDate());

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActItemClp)) {
            return false;
        }

        ActItemClp actItem = (ActItemClp) obj;

        long primaryKey = actItem.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(31);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", ItemId=");
        sb.append(getItemId());
        sb.append(", itemName=");
        sb.append(getItemName());
        sb.append(", itemDesc=");
        sb.append(getItemDesc());
        sb.append(", ignore=");
        sb.append(getIgnore());
        sb.append(", isMajor=");
        sb.append(getIsMajor());
        sb.append(", percentage=");
        sb.append(getPercentage());
        sb.append(", completedDate=");
        sb.append(getCompletedDate());
        sb.append(", completed=");
        sb.append(getCompleted());
        sb.append(", ActivateClid=");
        sb.append(getActivateClid());
        sb.append(", usergroupId=");
        sb.append(getUsergroupId());
        sb.append(", major=");
        sb.append(getMajor());
        sb.append(", major_percent=");
        sb.append(getMajor_percent());
        sb.append(", catId=");
        sb.append(getCatId());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(49);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ActItem");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>ItemId</column-name><column-value><![CDATA[");
        sb.append(getItemId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemName</column-name><column-value><![CDATA[");
        sb.append(getItemName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemDesc</column-name><column-value><![CDATA[");
        sb.append(getItemDesc());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>ignore</column-name><column-value><![CDATA[");
        sb.append(getIgnore());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>isMajor</column-name><column-value><![CDATA[");
        sb.append(getIsMajor());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>percentage</column-name><column-value><![CDATA[");
        sb.append(getPercentage());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>completedDate</column-name><column-value><![CDATA[");
        sb.append(getCompletedDate());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>completed</column-name><column-value><![CDATA[");
        sb.append(getCompleted());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>ActivateClid</column-name><column-value><![CDATA[");
        sb.append(getActivateClid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>usergroupId</column-name><column-value><![CDATA[");
        sb.append(getUsergroupId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>major</column-name><column-value><![CDATA[");
        sb.append(getMajor());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>major_percent</column-name><column-value><![CDATA[");
        sb.append(getMajor_percent());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>catId</column-name><column-value><![CDATA[");
        sb.append(getCatId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
