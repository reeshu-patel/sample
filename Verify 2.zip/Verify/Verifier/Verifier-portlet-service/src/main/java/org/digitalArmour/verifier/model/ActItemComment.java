package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the ActItemComment service. Represents a row in the &quot;Verifier_ActItemComment&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemCommentModel
 * @see org.digitalArmour.verifier.model.impl.ActItemCommentImpl
 * @see org.digitalArmour.verifier.model.impl.ActItemCommentModelImpl
 * @generated
 */
public interface ActItemComment extends ActItemCommentModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ActItemCommentImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
