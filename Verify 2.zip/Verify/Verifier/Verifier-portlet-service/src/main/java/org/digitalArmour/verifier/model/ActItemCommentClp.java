package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ActItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ActItemCommentClp extends BaseModelImpl<ActItemComment>
    implements ActItemComment {
    private String _uuid;
    private long _actCommId;
    private String _comment;
    private Date _createTime;
    private long _itemId;
    private long _userId;
    private String _userUuid;
    private BaseModel<?> _actItemCommentRemoteModel;

    public ActItemCommentClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ActItemComment.class;
    }

    @Override
    public String getModelClassName() {
        return ActItemComment.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _actCommId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setActCommId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _actCommId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("actCommId", getActCommId());
        attributes.put("comment", getComment());
        attributes.put("createTime", getCreateTime());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long actCommId = (Long) attributes.get("actCommId");

        if (actCommId != null) {
            setActCommId(actCommId);
        }

        String comment = (String) attributes.get("comment");

        if (comment != null) {
            setComment(comment);
        }

        Date createTime = (Date) attributes.get("createTime");

        if (createTime != null) {
            setCreateTime(createTime);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_actItemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _actItemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_actItemCommentRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActCommId() {
        return _actCommId;
    }

    @Override
    public void setActCommId(long actCommId) {
        _actCommId = actCommId;

        if (_actItemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _actItemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setActCommId", long.class);

                method.invoke(_actItemCommentRemoteModel, actCommId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getComment() {
        return _comment;
    }

    @Override
    public void setComment(String comment) {
        _comment = comment;

        if (_actItemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _actItemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setComment", String.class);

                method.invoke(_actItemCommentRemoteModel, comment);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public Date getCreateTime() {
        return _createTime;
    }

    @Override
    public void setCreateTime(Date createTime) {
        _createTime = createTime;

        if (_actItemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _actItemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setCreateTime", Date.class);

                method.invoke(_actItemCommentRemoteModel, createTime);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getItemId() {
        return _itemId;
    }

    @Override
    public void setItemId(long itemId) {
        _itemId = itemId;

        if (_actItemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _actItemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setItemId", long.class);

                method.invoke(_actItemCommentRemoteModel, itemId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_actItemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _actItemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_actItemCommentRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    public BaseModel<?> getActItemCommentRemoteModel() {
        return _actItemCommentRemoteModel;
    }

    public void setActItemCommentRemoteModel(
        BaseModel<?> actItemCommentRemoteModel) {
        _actItemCommentRemoteModel = actItemCommentRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _actItemCommentRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_actItemCommentRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ActItemCommentLocalServiceUtil.addActItemComment(this);
        } else {
            ActItemCommentLocalServiceUtil.updateActItemComment(this);
        }
    }

    @Override
    public ActItemComment toEscapedModel() {
        return (ActItemComment) ProxyUtil.newProxyInstance(ActItemComment.class.getClassLoader(),
            new Class[] { ActItemComment.class },
            new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ActItemCommentClp clone = new ActItemCommentClp();

        clone.setUuid(getUuid());
        clone.setActCommId(getActCommId());
        clone.setComment(getComment());
        clone.setCreateTime(getCreateTime());
        clone.setItemId(getItemId());
        clone.setUserId(getUserId());

        return clone;
    }

    @Override
    public int compareTo(ActItemComment actItemComment) {
        int value = 0;

        if (getActCommId() < actItemComment.getActCommId()) {
            value = -1;
        } else if (getActCommId() > actItemComment.getActCommId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActItemCommentClp)) {
            return false;
        }

        ActItemCommentClp actItemComment = (ActItemCommentClp) obj;

        long primaryKey = actItemComment.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", actCommId=");
        sb.append(getActCommId());
        sb.append(", comment=");
        sb.append(getComment());
        sb.append(", createTime=");
        sb.append(getCreateTime());
        sb.append(", itemId=");
        sb.append(getItemId());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(22);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ActItemComment");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>actCommId</column-name><column-value><![CDATA[");
        sb.append(getActCommId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>comment</column-name><column-value><![CDATA[");
        sb.append(getComment());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>createTime</column-name><column-value><![CDATA[");
        sb.append(getCreateTime());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemId</column-name><column-value><![CDATA[");
        sb.append(getItemId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
