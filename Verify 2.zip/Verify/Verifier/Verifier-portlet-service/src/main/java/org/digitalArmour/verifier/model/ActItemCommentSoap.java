package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ActItemCommentServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ActItemCommentServiceSoap
 * @generated
 */
public class ActItemCommentSoap implements Serializable {
    private String _uuid;
    private long _actCommId;
    private String _comment;
    private Date _createTime;
    private long _itemId;
    private long _userId;

    public ActItemCommentSoap() {
    }

    public static ActItemCommentSoap toSoapModel(ActItemComment model) {
        ActItemCommentSoap soapModel = new ActItemCommentSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setActCommId(model.getActCommId());
        soapModel.setComment(model.getComment());
        soapModel.setCreateTime(model.getCreateTime());
        soapModel.setItemId(model.getItemId());
        soapModel.setUserId(model.getUserId());

        return soapModel;
    }

    public static ActItemCommentSoap[] toSoapModels(ActItemComment[] models) {
        ActItemCommentSoap[] soapModels = new ActItemCommentSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ActItemCommentSoap[][] toSoapModels(ActItemComment[][] models) {
        ActItemCommentSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ActItemCommentSoap[models.length][models[0].length];
        } else {
            soapModels = new ActItemCommentSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ActItemCommentSoap[] toSoapModels(List<ActItemComment> models) {
        List<ActItemCommentSoap> soapModels = new ArrayList<ActItemCommentSoap>(models.size());

        for (ActItemComment model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ActItemCommentSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _actCommId;
    }

    public void setPrimaryKey(long pk) {
        setActCommId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getActCommId() {
        return _actCommId;
    }

    public void setActCommId(long actCommId) {
        _actCommId = actCommId;
    }

    public String getComment() {
        return _comment;
    }

    public void setComment(String comment) {
        _comment = comment;
    }

    public Date getCreateTime() {
        return _createTime;
    }

    public void setCreateTime(Date createTime) {
        _createTime = createTime;
    }

    public long getItemId() {
        return _itemId;
    }

    public void setItemId(long itemId) {
        _itemId = itemId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }
}
