package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActItemComment}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActItemComment
 * @generated
 */
public class ActItemCommentWrapper implements ActItemComment,
    ModelWrapper<ActItemComment> {
    private ActItemComment _actItemComment;

    public ActItemCommentWrapper(ActItemComment actItemComment) {
        _actItemComment = actItemComment;
    }

    @Override
    public Class<?> getModelClass() {
        return ActItemComment.class;
    }

    @Override
    public String getModelClassName() {
        return ActItemComment.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("actCommId", getActCommId());
        attributes.put("comment", getComment());
        attributes.put("createTime", getCreateTime());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long actCommId = (Long) attributes.get("actCommId");

        if (actCommId != null) {
            setActCommId(actCommId);
        }

        String comment = (String) attributes.get("comment");

        if (comment != null) {
            setComment(comment);
        }

        Date createTime = (Date) attributes.get("createTime");

        if (createTime != null) {
            setCreateTime(createTime);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    /**
    * Returns the primary key of this act item comment.
    *
    * @return the primary key of this act item comment
    */
    @Override
    public long getPrimaryKey() {
        return _actItemComment.getPrimaryKey();
    }

    /**
    * Sets the primary key of this act item comment.
    *
    * @param primaryKey the primary key of this act item comment
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _actItemComment.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this act item comment.
    *
    * @return the uuid of this act item comment
    */
    @Override
    public java.lang.String getUuid() {
        return _actItemComment.getUuid();
    }

    /**
    * Sets the uuid of this act item comment.
    *
    * @param uuid the uuid of this act item comment
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _actItemComment.setUuid(uuid);
    }

    /**
    * Returns the act comm ID of this act item comment.
    *
    * @return the act comm ID of this act item comment
    */
    @Override
    public long getActCommId() {
        return _actItemComment.getActCommId();
    }

    /**
    * Sets the act comm ID of this act item comment.
    *
    * @param actCommId the act comm ID of this act item comment
    */
    @Override
    public void setActCommId(long actCommId) {
        _actItemComment.setActCommId(actCommId);
    }

    /**
    * Returns the comment of this act item comment.
    *
    * @return the comment of this act item comment
    */
    @Override
    public java.lang.String getComment() {
        return _actItemComment.getComment();
    }

    /**
    * Sets the comment of this act item comment.
    *
    * @param comment the comment of this act item comment
    */
    @Override
    public void setComment(java.lang.String comment) {
        _actItemComment.setComment(comment);
    }

    /**
    * Returns the create time of this act item comment.
    *
    * @return the create time of this act item comment
    */
    @Override
    public java.util.Date getCreateTime() {
        return _actItemComment.getCreateTime();
    }

    /**
    * Sets the create time of this act item comment.
    *
    * @param createTime the create time of this act item comment
    */
    @Override
    public void setCreateTime(java.util.Date createTime) {
        _actItemComment.setCreateTime(createTime);
    }

    /**
    * Returns the item ID of this act item comment.
    *
    * @return the item ID of this act item comment
    */
    @Override
    public long getItemId() {
        return _actItemComment.getItemId();
    }

    /**
    * Sets the item ID of this act item comment.
    *
    * @param itemId the item ID of this act item comment
    */
    @Override
    public void setItemId(long itemId) {
        _actItemComment.setItemId(itemId);
    }

    /**
    * Returns the user ID of this act item comment.
    *
    * @return the user ID of this act item comment
    */
    @Override
    public long getUserId() {
        return _actItemComment.getUserId();
    }

    /**
    * Sets the user ID of this act item comment.
    *
    * @param userId the user ID of this act item comment
    */
    @Override
    public void setUserId(long userId) {
        _actItemComment.setUserId(userId);
    }

    /**
    * Returns the user uuid of this act item comment.
    *
    * @return the user uuid of this act item comment
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemComment.getUserUuid();
    }

    /**
    * Sets the user uuid of this act item comment.
    *
    * @param userUuid the user uuid of this act item comment
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _actItemComment.setUserUuid(userUuid);
    }

    @Override
    public boolean isNew() {
        return _actItemComment.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _actItemComment.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _actItemComment.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _actItemComment.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _actItemComment.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _actItemComment.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _actItemComment.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _actItemComment.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _actItemComment.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _actItemComment.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _actItemComment.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ActItemCommentWrapper((ActItemComment) _actItemComment.clone());
    }

    @Override
    public int compareTo(ActItemComment actItemComment) {
        return _actItemComment.compareTo(actItemComment);
    }

    @Override
    public int hashCode() {
        return _actItemComment.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ActItemComment> toCacheModel() {
        return _actItemComment.toCacheModel();
    }

    @Override
    public ActItemComment toEscapedModel() {
        return new ActItemCommentWrapper(_actItemComment.toEscapedModel());
    }

    @Override
    public ActItemComment toUnescapedModel() {
        return new ActItemCommentWrapper(_actItemComment.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _actItemComment.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _actItemComment.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _actItemComment.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActItemCommentWrapper)) {
            return false;
        }

        ActItemCommentWrapper actItemCommentWrapper = (ActItemCommentWrapper) obj;

        if (Validator.equals(_actItemComment,
                    actItemCommentWrapper._actItemComment)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ActItemComment getWrappedActItemComment() {
        return _actItemComment;
    }

    @Override
    public ActItemComment getWrappedModel() {
        return _actItemComment;
    }

    @Override
    public void resetOriginalValues() {
        _actItemComment.resetOriginalValues();
    }
}
