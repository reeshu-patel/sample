package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ActItemFileServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ActItemFileServiceSoap
 * @generated
 */
public class ActItemFileSoap implements Serializable {
    private String _uuid;
    private long _actItemFileId;
    private String _fileName;
    private String _filePath;
    private Date _createTime;
    private long _itemId;
    private long _userId;

    public ActItemFileSoap() {
    }

    public static ActItemFileSoap toSoapModel(ActItemFile model) {
        ActItemFileSoap soapModel = new ActItemFileSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setActItemFileId(model.getActItemFileId());
        soapModel.setFileName(model.getFileName());
        soapModel.setFilePath(model.getFilePath());
        soapModel.setCreateTime(model.getCreateTime());
        soapModel.setItemId(model.getItemId());
        soapModel.setUserId(model.getUserId());

        return soapModel;
    }

    public static ActItemFileSoap[] toSoapModels(ActItemFile[] models) {
        ActItemFileSoap[] soapModels = new ActItemFileSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ActItemFileSoap[][] toSoapModels(ActItemFile[][] models) {
        ActItemFileSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ActItemFileSoap[models.length][models[0].length];
        } else {
            soapModels = new ActItemFileSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ActItemFileSoap[] toSoapModels(List<ActItemFile> models) {
        List<ActItemFileSoap> soapModels = new ArrayList<ActItemFileSoap>(models.size());

        for (ActItemFile model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ActItemFileSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _actItemFileId;
    }

    public void setPrimaryKey(long pk) {
        setActItemFileId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getActItemFileId() {
        return _actItemFileId;
    }

    public void setActItemFileId(long actItemFileId) {
        _actItemFileId = actItemFileId;
    }

    public String getFileName() {
        return _fileName;
    }

    public void setFileName(String fileName) {
        _fileName = fileName;
    }

    public String getFilePath() {
        return _filePath;
    }

    public void setFilePath(String filePath) {
        _filePath = filePath;
    }

    public Date getCreateTime() {
        return _createTime;
    }

    public void setCreateTime(Date createTime) {
        _createTime = createTime;
    }

    public long getItemId() {
        return _itemId;
    }

    public void setItemId(long itemId) {
        _itemId = itemId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }
}
