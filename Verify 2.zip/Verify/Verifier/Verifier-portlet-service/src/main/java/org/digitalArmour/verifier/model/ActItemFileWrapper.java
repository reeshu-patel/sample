package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActItemFile}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActItemFile
 * @generated
 */
public class ActItemFileWrapper implements ActItemFile,
    ModelWrapper<ActItemFile> {
    private ActItemFile _actItemFile;

    public ActItemFileWrapper(ActItemFile actItemFile) {
        _actItemFile = actItemFile;
    }

    @Override
    public Class<?> getModelClass() {
        return ActItemFile.class;
    }

    @Override
    public String getModelClassName() {
        return ActItemFile.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("actItemFileId", getActItemFileId());
        attributes.put("fileName", getFileName());
        attributes.put("filePath", getFilePath());
        attributes.put("createTime", getCreateTime());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long actItemFileId = (Long) attributes.get("actItemFileId");

        if (actItemFileId != null) {
            setActItemFileId(actItemFileId);
        }

        String fileName = (String) attributes.get("fileName");

        if (fileName != null) {
            setFileName(fileName);
        }

        String filePath = (String) attributes.get("filePath");

        if (filePath != null) {
            setFilePath(filePath);
        }

        Date createTime = (Date) attributes.get("createTime");

        if (createTime != null) {
            setCreateTime(createTime);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    /**
    * Returns the primary key of this act item file.
    *
    * @return the primary key of this act item file
    */
    @Override
    public long getPrimaryKey() {
        return _actItemFile.getPrimaryKey();
    }

    /**
    * Sets the primary key of this act item file.
    *
    * @param primaryKey the primary key of this act item file
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _actItemFile.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this act item file.
    *
    * @return the uuid of this act item file
    */
    @Override
    public java.lang.String getUuid() {
        return _actItemFile.getUuid();
    }

    /**
    * Sets the uuid of this act item file.
    *
    * @param uuid the uuid of this act item file
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _actItemFile.setUuid(uuid);
    }

    /**
    * Returns the act item file ID of this act item file.
    *
    * @return the act item file ID of this act item file
    */
    @Override
    public long getActItemFileId() {
        return _actItemFile.getActItemFileId();
    }

    /**
    * Sets the act item file ID of this act item file.
    *
    * @param actItemFileId the act item file ID of this act item file
    */
    @Override
    public void setActItemFileId(long actItemFileId) {
        _actItemFile.setActItemFileId(actItemFileId);
    }

    /**
    * Returns the file name of this act item file.
    *
    * @return the file name of this act item file
    */
    @Override
    public java.lang.String getFileName() {
        return _actItemFile.getFileName();
    }

    /**
    * Sets the file name of this act item file.
    *
    * @param fileName the file name of this act item file
    */
    @Override
    public void setFileName(java.lang.String fileName) {
        _actItemFile.setFileName(fileName);
    }

    /**
    * Returns the file path of this act item file.
    *
    * @return the file path of this act item file
    */
    @Override
    public java.lang.String getFilePath() {
        return _actItemFile.getFilePath();
    }

    /**
    * Sets the file path of this act item file.
    *
    * @param filePath the file path of this act item file
    */
    @Override
    public void setFilePath(java.lang.String filePath) {
        _actItemFile.setFilePath(filePath);
    }

    /**
    * Returns the create time of this act item file.
    *
    * @return the create time of this act item file
    */
    @Override
    public java.util.Date getCreateTime() {
        return _actItemFile.getCreateTime();
    }

    /**
    * Sets the create time of this act item file.
    *
    * @param createTime the create time of this act item file
    */
    @Override
    public void setCreateTime(java.util.Date createTime) {
        _actItemFile.setCreateTime(createTime);
    }

    /**
    * Returns the item ID of this act item file.
    *
    * @return the item ID of this act item file
    */
    @Override
    public long getItemId() {
        return _actItemFile.getItemId();
    }

    /**
    * Sets the item ID of this act item file.
    *
    * @param itemId the item ID of this act item file
    */
    @Override
    public void setItemId(long itemId) {
        _actItemFile.setItemId(itemId);
    }

    /**
    * Returns the user ID of this act item file.
    *
    * @return the user ID of this act item file
    */
    @Override
    public long getUserId() {
        return _actItemFile.getUserId();
    }

    /**
    * Sets the user ID of this act item file.
    *
    * @param userId the user ID of this act item file
    */
    @Override
    public void setUserId(long userId) {
        _actItemFile.setUserId(userId);
    }

    /**
    * Returns the user uuid of this act item file.
    *
    * @return the user uuid of this act item file
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFile.getUserUuid();
    }

    /**
    * Sets the user uuid of this act item file.
    *
    * @param userUuid the user uuid of this act item file
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _actItemFile.setUserUuid(userUuid);
    }

    @Override
    public boolean isNew() {
        return _actItemFile.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _actItemFile.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _actItemFile.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _actItemFile.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _actItemFile.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _actItemFile.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _actItemFile.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _actItemFile.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _actItemFile.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _actItemFile.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _actItemFile.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ActItemFileWrapper((ActItemFile) _actItemFile.clone());
    }

    @Override
    public int compareTo(ActItemFile actItemFile) {
        return _actItemFile.compareTo(actItemFile);
    }

    @Override
    public int hashCode() {
        return _actItemFile.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ActItemFile> toCacheModel() {
        return _actItemFile.toCacheModel();
    }

    @Override
    public ActItemFile toEscapedModel() {
        return new ActItemFileWrapper(_actItemFile.toEscapedModel());
    }

    @Override
    public ActItemFile toUnescapedModel() {
        return new ActItemFileWrapper(_actItemFile.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _actItemFile.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _actItemFile.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _actItemFile.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActItemFileWrapper)) {
            return false;
        }

        ActItemFileWrapper actItemFileWrapper = (ActItemFileWrapper) obj;

        if (Validator.equals(_actItemFile, actItemFileWrapper._actItemFile)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ActItemFile getWrappedActItemFile() {
        return _actItemFile;
    }

    @Override
    public ActItemFile getWrappedModel() {
        return _actItemFile;
    }

    @Override
    public void resetOriginalValues() {
        _actItemFile.resetOriginalValues();
    }
}
