package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ActItemServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ActItemServiceSoap
 * @generated
 */
public class ActItemSoap implements Serializable {
    private String _uuid;
    private long _ItemId;
    private String _itemName;
    private String _itemDesc;
    private boolean _ignore;
    private boolean _isMajor;
    private long _percentage;
    private Date _completedDate;
    private boolean _completed;
    private long _ActivateClid;
    private long _usergroupId;
    private boolean _major;
    private long _major_percent;
    private long _catId;
    private long _userId;

    public ActItemSoap() {
    }

    public static ActItemSoap toSoapModel(ActItem model) {
        ActItemSoap soapModel = new ActItemSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setItemId(model.getItemId());
        soapModel.setItemName(model.getItemName());
        soapModel.setItemDesc(model.getItemDesc());
        soapModel.setIgnore(model.getIgnore());
        soapModel.setIsMajor(model.getIsMajor());
        soapModel.setPercentage(model.getPercentage());
        soapModel.setCompletedDate(model.getCompletedDate());
        soapModel.setCompleted(model.getCompleted());
        soapModel.setActivateClid(model.getActivateClid());
        soapModel.setUsergroupId(model.getUsergroupId());
        soapModel.setMajor(model.getMajor());
        soapModel.setMajor_percent(model.getMajor_percent());
        soapModel.setCatId(model.getCatId());
        soapModel.setUserId(model.getUserId());

        return soapModel;
    }

    public static ActItemSoap[] toSoapModels(ActItem[] models) {
        ActItemSoap[] soapModels = new ActItemSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ActItemSoap[][] toSoapModels(ActItem[][] models) {
        ActItemSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ActItemSoap[models.length][models[0].length];
        } else {
            soapModels = new ActItemSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ActItemSoap[] toSoapModels(List<ActItem> models) {
        List<ActItemSoap> soapModels = new ArrayList<ActItemSoap>(models.size());

        for (ActItem model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ActItemSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _ItemId;
    }

    public void setPrimaryKey(long pk) {
        setItemId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getItemId() {
        return _ItemId;
    }

    public void setItemId(long ItemId) {
        _ItemId = ItemId;
    }

    public String getItemName() {
        return _itemName;
    }

    public void setItemName(String itemName) {
        _itemName = itemName;
    }

    public String getItemDesc() {
        return _itemDesc;
    }

    public void setItemDesc(String itemDesc) {
        _itemDesc = itemDesc;
    }

    public boolean getIgnore() {
        return _ignore;
    }

    public boolean isIgnore() {
        return _ignore;
    }

    public void setIgnore(boolean ignore) {
        _ignore = ignore;
    }

    public boolean getIsMajor() {
        return _isMajor;
    }

    public boolean isIsMajor() {
        return _isMajor;
    }

    public void setIsMajor(boolean isMajor) {
        _isMajor = isMajor;
    }

    public long getPercentage() {
        return _percentage;
    }

    public void setPercentage(long percentage) {
        _percentage = percentage;
    }

    public Date getCompletedDate() {
        return _completedDate;
    }

    public void setCompletedDate(Date completedDate) {
        _completedDate = completedDate;
    }

    public boolean getCompleted() {
        return _completed;
    }

    public boolean isCompleted() {
        return _completed;
    }

    public void setCompleted(boolean completed) {
        _completed = completed;
    }

    public long getActivateClid() {
        return _ActivateClid;
    }

    public void setActivateClid(long ActivateClid) {
        _ActivateClid = ActivateClid;
    }

    public long getUsergroupId() {
        return _usergroupId;
    }

    public void setUsergroupId(long usergroupId) {
        _usergroupId = usergroupId;
    }

    public boolean getMajor() {
        return _major;
    }

    public boolean isMajor() {
        return _major;
    }

    public void setMajor(boolean major) {
        _major = major;
    }

    public long getMajor_percent() {
        return _major_percent;
    }

    public void setMajor_percent(long major_percent) {
        _major_percent = major_percent;
    }

    public long getCatId() {
        return _catId;
    }

    public void setCatId(long catId) {
        _catId = catId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }
}
