package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActItem}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActItem
 * @generated
 */
public class ActItemWrapper implements ActItem, ModelWrapper<ActItem> {
    private ActItem _actItem;

    public ActItemWrapper(ActItem actItem) {
        _actItem = actItem;
    }

    @Override
    public Class<?> getModelClass() {
        return ActItem.class;
    }

    @Override
    public String getModelClassName() {
        return ActItem.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("ItemId", getItemId());
        attributes.put("itemName", getItemName());
        attributes.put("itemDesc", getItemDesc());
        attributes.put("ignore", getIgnore());
        attributes.put("isMajor", getIsMajor());
        attributes.put("percentage", getPercentage());
        attributes.put("completedDate", getCompletedDate());
        attributes.put("completed", getCompleted());
        attributes.put("ActivateClid", getActivateClid());
        attributes.put("usergroupId", getUsergroupId());
        attributes.put("major", getMajor());
        attributes.put("major_percent", getMajor_percent());
        attributes.put("catId", getCatId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long ItemId = (Long) attributes.get("ItemId");

        if (ItemId != null) {
            setItemId(ItemId);
        }

        String itemName = (String) attributes.get("itemName");

        if (itemName != null) {
            setItemName(itemName);
        }

        String itemDesc = (String) attributes.get("itemDesc");

        if (itemDesc != null) {
            setItemDesc(itemDesc);
        }

        Boolean ignore = (Boolean) attributes.get("ignore");

        if (ignore != null) {
            setIgnore(ignore);
        }

        Boolean isMajor = (Boolean) attributes.get("isMajor");

        if (isMajor != null) {
            setIsMajor(isMajor);
        }

        Long percentage = (Long) attributes.get("percentage");

        if (percentage != null) {
            setPercentage(percentage);
        }

        Date completedDate = (Date) attributes.get("completedDate");

        if (completedDate != null) {
            setCompletedDate(completedDate);
        }

        Boolean completed = (Boolean) attributes.get("completed");

        if (completed != null) {
            setCompleted(completed);
        }

        Long ActivateClid = (Long) attributes.get("ActivateClid");

        if (ActivateClid != null) {
            setActivateClid(ActivateClid);
        }

        Long usergroupId = (Long) attributes.get("usergroupId");

        if (usergroupId != null) {
            setUsergroupId(usergroupId);
        }

        Boolean major = (Boolean) attributes.get("major");

        if (major != null) {
            setMajor(major);
        }

        Long major_percent = (Long) attributes.get("major_percent");

        if (major_percent != null) {
            setMajor_percent(major_percent);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    /**
    * Returns the primary key of this act item.
    *
    * @return the primary key of this act item
    */
    @Override
    public long getPrimaryKey() {
        return _actItem.getPrimaryKey();
    }

    /**
    * Sets the primary key of this act item.
    *
    * @param primaryKey the primary key of this act item
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _actItem.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this act item.
    *
    * @return the uuid of this act item
    */
    @Override
    public java.lang.String getUuid() {
        return _actItem.getUuid();
    }

    /**
    * Sets the uuid of this act item.
    *
    * @param uuid the uuid of this act item
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _actItem.setUuid(uuid);
    }

    /**
    * Returns the item ID of this act item.
    *
    * @return the item ID of this act item
    */
    @Override
    public long getItemId() {
        return _actItem.getItemId();
    }

    /**
    * Sets the item ID of this act item.
    *
    * @param ItemId the item ID of this act item
    */
    @Override
    public void setItemId(long ItemId) {
        _actItem.setItemId(ItemId);
    }

    /**
    * Returns the item name of this act item.
    *
    * @return the item name of this act item
    */
    @Override
    public java.lang.String getItemName() {
        return _actItem.getItemName();
    }

    /**
    * Sets the item name of this act item.
    *
    * @param itemName the item name of this act item
    */
    @Override
    public void setItemName(java.lang.String itemName) {
        _actItem.setItemName(itemName);
    }

    /**
    * Returns the item desc of this act item.
    *
    * @return the item desc of this act item
    */
    @Override
    public java.lang.String getItemDesc() {
        return _actItem.getItemDesc();
    }

    /**
    * Sets the item desc of this act item.
    *
    * @param itemDesc the item desc of this act item
    */
    @Override
    public void setItemDesc(java.lang.String itemDesc) {
        _actItem.setItemDesc(itemDesc);
    }

    /**
    * Returns the ignore of this act item.
    *
    * @return the ignore of this act item
    */
    @Override
    public boolean getIgnore() {
        return _actItem.getIgnore();
    }

    /**
    * Returns <code>true</code> if this act item is ignore.
    *
    * @return <code>true</code> if this act item is ignore; <code>false</code> otherwise
    */
    @Override
    public boolean isIgnore() {
        return _actItem.isIgnore();
    }

    /**
    * Sets whether this act item is ignore.
    *
    * @param ignore the ignore of this act item
    */
    @Override
    public void setIgnore(boolean ignore) {
        _actItem.setIgnore(ignore);
    }

    /**
    * Returns the is major of this act item.
    *
    * @return the is major of this act item
    */
    @Override
    public boolean getIsMajor() {
        return _actItem.getIsMajor();
    }

    /**
    * Returns <code>true</code> if this act item is is major.
    *
    * @return <code>true</code> if this act item is is major; <code>false</code> otherwise
    */
    @Override
    public boolean isIsMajor() {
        return _actItem.isIsMajor();
    }

    /**
    * Sets whether this act item is is major.
    *
    * @param isMajor the is major of this act item
    */
    @Override
    public void setIsMajor(boolean isMajor) {
        _actItem.setIsMajor(isMajor);
    }

    /**
    * Returns the percentage of this act item.
    *
    * @return the percentage of this act item
    */
    @Override
    public long getPercentage() {
        return _actItem.getPercentage();
    }

    /**
    * Sets the percentage of this act item.
    *
    * @param percentage the percentage of this act item
    */
    @Override
    public void setPercentage(long percentage) {
        _actItem.setPercentage(percentage);
    }

    /**
    * Returns the completed date of this act item.
    *
    * @return the completed date of this act item
    */
    @Override
    public java.util.Date getCompletedDate() {
        return _actItem.getCompletedDate();
    }

    /**
    * Sets the completed date of this act item.
    *
    * @param completedDate the completed date of this act item
    */
    @Override
    public void setCompletedDate(java.util.Date completedDate) {
        _actItem.setCompletedDate(completedDate);
    }

    /**
    * Returns the completed of this act item.
    *
    * @return the completed of this act item
    */
    @Override
    public boolean getCompleted() {
        return _actItem.getCompleted();
    }

    /**
    * Returns <code>true</code> if this act item is completed.
    *
    * @return <code>true</code> if this act item is completed; <code>false</code> otherwise
    */
    @Override
    public boolean isCompleted() {
        return _actItem.isCompleted();
    }

    /**
    * Sets whether this act item is completed.
    *
    * @param completed the completed of this act item
    */
    @Override
    public void setCompleted(boolean completed) {
        _actItem.setCompleted(completed);
    }

    /**
    * Returns the activate clid of this act item.
    *
    * @return the activate clid of this act item
    */
    @Override
    public long getActivateClid() {
        return _actItem.getActivateClid();
    }

    /**
    * Sets the activate clid of this act item.
    *
    * @param ActivateClid the activate clid of this act item
    */
    @Override
    public void setActivateClid(long ActivateClid) {
        _actItem.setActivateClid(ActivateClid);
    }

    /**
    * Returns the usergroup ID of this act item.
    *
    * @return the usergroup ID of this act item
    */
    @Override
    public long getUsergroupId() {
        return _actItem.getUsergroupId();
    }

    /**
    * Sets the usergroup ID of this act item.
    *
    * @param usergroupId the usergroup ID of this act item
    */
    @Override
    public void setUsergroupId(long usergroupId) {
        _actItem.setUsergroupId(usergroupId);
    }

    /**
    * Returns the major of this act item.
    *
    * @return the major of this act item
    */
    @Override
    public boolean getMajor() {
        return _actItem.getMajor();
    }

    /**
    * Returns <code>true</code> if this act item is major.
    *
    * @return <code>true</code> if this act item is major; <code>false</code> otherwise
    */
    @Override
    public boolean isMajor() {
        return _actItem.isMajor();
    }

    /**
    * Sets whether this act item is major.
    *
    * @param major the major of this act item
    */
    @Override
    public void setMajor(boolean major) {
        _actItem.setMajor(major);
    }

    /**
    * Returns the major_percent of this act item.
    *
    * @return the major_percent of this act item
    */
    @Override
    public long getMajor_percent() {
        return _actItem.getMajor_percent();
    }

    /**
    * Sets the major_percent of this act item.
    *
    * @param major_percent the major_percent of this act item
    */
    @Override
    public void setMajor_percent(long major_percent) {
        _actItem.setMajor_percent(major_percent);
    }

    /**
    * Returns the cat ID of this act item.
    *
    * @return the cat ID of this act item
    */
    @Override
    public long getCatId() {
        return _actItem.getCatId();
    }

    /**
    * Sets the cat ID of this act item.
    *
    * @param catId the cat ID of this act item
    */
    @Override
    public void setCatId(long catId) {
        _actItem.setCatId(catId);
    }

    /**
    * Returns the user ID of this act item.
    *
    * @return the user ID of this act item
    */
    @Override
    public long getUserId() {
        return _actItem.getUserId();
    }

    /**
    * Sets the user ID of this act item.
    *
    * @param userId the user ID of this act item
    */
    @Override
    public void setUserId(long userId) {
        _actItem.setUserId(userId);
    }

    /**
    * Returns the user uuid of this act item.
    *
    * @return the user uuid of this act item
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItem.getUserUuid();
    }

    /**
    * Sets the user uuid of this act item.
    *
    * @param userUuid the user uuid of this act item
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _actItem.setUserUuid(userUuid);
    }

    @Override
    public boolean isNew() {
        return _actItem.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _actItem.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _actItem.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _actItem.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _actItem.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _actItem.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _actItem.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _actItem.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _actItem.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _actItem.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _actItem.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ActItemWrapper((ActItem) _actItem.clone());
    }

    @Override
    public int compareTo(ActItem actItem) {
        return _actItem.compareTo(actItem);
    }

    @Override
    public int hashCode() {
        return _actItem.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ActItem> toCacheModel() {
        return _actItem.toCacheModel();
    }

    @Override
    public ActItem toEscapedModel() {
        return new ActItemWrapper(_actItem.toEscapedModel());
    }

    @Override
    public ActItem toUnescapedModel() {
        return new ActItemWrapper(_actItem.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _actItem.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _actItem.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _actItem.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActItemWrapper)) {
            return false;
        }

        ActItemWrapper actItemWrapper = (ActItemWrapper) obj;

        if (Validator.equals(_actItem, actItemWrapper._actItem)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ActItem getWrappedActItem() {
        return _actItem;
    }

    @Override
    public ActItem getWrappedModel() {
        return _actItem;
    }

    @Override
    public void resetOriginalValues() {
        _actItem.resetOriginalValues();
    }
}
