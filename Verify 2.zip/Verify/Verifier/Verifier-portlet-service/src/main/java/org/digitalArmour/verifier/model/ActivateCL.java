package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the ActivateCL service. Represents a row in the &quot;Verifier_ActivateCL&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLModel
 * @see org.digitalArmour.verifier.model.impl.ActivateCLImpl
 * @see org.digitalArmour.verifier.model.impl.ActivateCLModelImpl
 * @generated
 */
public interface ActivateCL extends ActivateCLModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ActivateCLImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
