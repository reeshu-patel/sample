package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ActivateCLClp extends BaseModelImpl<ActivateCL>
    implements ActivateCL {
    private String _uuid;
    private long _activateId;
    private long _checklistId;
    private String _clName;
    private String _clDescription;
    private String _organiztion;
    private boolean _isPublic;
    private boolean _isCompleted;
    private Date _completedDate;
    private long _actClUserId;
    private String _actClUserUuid;
    private BaseModel<?> _activateCLRemoteModel;

    public ActivateCLClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ActivateCL.class;
    }

    @Override
    public String getModelClassName() {
        return ActivateCL.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _activateId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setActivateId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _activateId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("activateId", getActivateId());
        attributes.put("checklistId", getChecklistId());
        attributes.put("clName", getClName());
        attributes.put("clDescription", getClDescription());
        attributes.put("organiztion", getOrganiztion());
        attributes.put("isPublic", getIsPublic());
        attributes.put("isCompleted", getIsCompleted());
        attributes.put("completedDate", getCompletedDate());
        attributes.put("actClUserId", getActClUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long activateId = (Long) attributes.get("activateId");

        if (activateId != null) {
            setActivateId(activateId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }

        String clName = (String) attributes.get("clName");

        if (clName != null) {
            setClName(clName);
        }

        String clDescription = (String) attributes.get("clDescription");

        if (clDescription != null) {
            setClDescription(clDescription);
        }

        String organiztion = (String) attributes.get("organiztion");

        if (organiztion != null) {
            setOrganiztion(organiztion);
        }

        Boolean isPublic = (Boolean) attributes.get("isPublic");

        if (isPublic != null) {
            setIsPublic(isPublic);
        }

        Boolean isCompleted = (Boolean) attributes.get("isCompleted");

        if (isCompleted != null) {
            setIsCompleted(isCompleted);
        }

        Date completedDate = (Date) attributes.get("completedDate");

        if (completedDate != null) {
            setCompletedDate(completedDate);
        }

        Long actClUserId = (Long) attributes.get("actClUserId");

        if (actClUserId != null) {
            setActClUserId(actClUserId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_activateCLRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActivateId() {
        return _activateId;
    }

    @Override
    public void setActivateId(long activateId) {
        _activateId = activateId;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setActivateId", long.class);

                method.invoke(_activateCLRemoteModel, activateId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getChecklistId() {
        return _checklistId;
    }

    @Override
    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setChecklistId", long.class);

                method.invoke(_activateCLRemoteModel, checklistId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getClName() {
        return _clName;
    }

    @Override
    public void setClName(String clName) {
        _clName = clName;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setClName", String.class);

                method.invoke(_activateCLRemoteModel, clName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getClDescription() {
        return _clDescription;
    }

    @Override
    public void setClDescription(String clDescription) {
        _clDescription = clDescription;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setClDescription", String.class);

                method.invoke(_activateCLRemoteModel, clDescription);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getOrganiztion() {
        return _organiztion;
    }

    @Override
    public void setOrganiztion(String organiztion) {
        _organiztion = organiztion;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setOrganiztion", String.class);

                method.invoke(_activateCLRemoteModel, organiztion);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getIsPublic() {
        return _isPublic;
    }

    @Override
    public boolean isIsPublic() {
        return _isPublic;
    }

    @Override
    public void setIsPublic(boolean isPublic) {
        _isPublic = isPublic;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setIsPublic", boolean.class);

                method.invoke(_activateCLRemoteModel, isPublic);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getIsCompleted() {
        return _isCompleted;
    }

    @Override
    public boolean isIsCompleted() {
        return _isCompleted;
    }

    @Override
    public void setIsCompleted(boolean isCompleted) {
        _isCompleted = isCompleted;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setIsCompleted", boolean.class);

                method.invoke(_activateCLRemoteModel, isCompleted);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public Date getCompletedDate() {
        return _completedDate;
    }

    @Override
    public void setCompletedDate(Date completedDate) {
        _completedDate = completedDate;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setCompletedDate", Date.class);

                method.invoke(_activateCLRemoteModel, completedDate);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getActClUserId() {
        return _actClUserId;
    }

    @Override
    public void setActClUserId(long actClUserId) {
        _actClUserId = actClUserId;

        if (_activateCLRemoteModel != null) {
            try {
                Class<?> clazz = _activateCLRemoteModel.getClass();

                Method method = clazz.getMethod("setActClUserId", long.class);

                method.invoke(_activateCLRemoteModel, actClUserId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getActClUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getActClUserId(), "uuid", _actClUserUuid);
    }

    @Override
    public void setActClUserUuid(String actClUserUuid) {
        _actClUserUuid = actClUserUuid;
    }

    public BaseModel<?> getActivateCLRemoteModel() {
        return _activateCLRemoteModel;
    }

    public void setActivateCLRemoteModel(BaseModel<?> activateCLRemoteModel) {
        _activateCLRemoteModel = activateCLRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _activateCLRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_activateCLRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ActivateCLLocalServiceUtil.addActivateCL(this);
        } else {
            ActivateCLLocalServiceUtil.updateActivateCL(this);
        }
    }

    @Override
    public ActivateCL toEscapedModel() {
        return (ActivateCL) ProxyUtil.newProxyInstance(ActivateCL.class.getClassLoader(),
            new Class[] { ActivateCL.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ActivateCLClp clone = new ActivateCLClp();

        clone.setUuid(getUuid());
        clone.setActivateId(getActivateId());
        clone.setChecklistId(getChecklistId());
        clone.setClName(getClName());
        clone.setClDescription(getClDescription());
        clone.setOrganiztion(getOrganiztion());
        clone.setIsPublic(getIsPublic());
        clone.setIsCompleted(getIsCompleted());
        clone.setCompletedDate(getCompletedDate());
        clone.setActClUserId(getActClUserId());

        return clone;
    }

    @Override
    public int compareTo(ActivateCL activateCL) {
        int value = 0;

        if (getActivateId() < activateCL.getActivateId()) {
            value = -1;
        } else if (getActivateId() > activateCL.getActivateId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActivateCLClp)) {
            return false;
        }

        ActivateCLClp activateCL = (ActivateCLClp) obj;

        long primaryKey = activateCL.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(21);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", activateId=");
        sb.append(getActivateId());
        sb.append(", checklistId=");
        sb.append(getChecklistId());
        sb.append(", clName=");
        sb.append(getClName());
        sb.append(", clDescription=");
        sb.append(getClDescription());
        sb.append(", organiztion=");
        sb.append(getOrganiztion());
        sb.append(", isPublic=");
        sb.append(getIsPublic());
        sb.append(", isCompleted=");
        sb.append(getIsCompleted());
        sb.append(", completedDate=");
        sb.append(getCompletedDate());
        sb.append(", actClUserId=");
        sb.append(getActClUserId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(34);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ActivateCL");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>activateId</column-name><column-value><![CDATA[");
        sb.append(getActivateId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>checklistId</column-name><column-value><![CDATA[");
        sb.append(getChecklistId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>clName</column-name><column-value><![CDATA[");
        sb.append(getClName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>clDescription</column-name><column-value><![CDATA[");
        sb.append(getClDescription());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>organiztion</column-name><column-value><![CDATA[");
        sb.append(getOrganiztion());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>isPublic</column-name><column-value><![CDATA[");
        sb.append(getIsPublic());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>isCompleted</column-name><column-value><![CDATA[");
        sb.append(getIsCompleted());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>completedDate</column-name><column-value><![CDATA[");
        sb.append(getCompletedDate());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>actClUserId</column-name><column-value><![CDATA[");
        sb.append(getActClUserId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
