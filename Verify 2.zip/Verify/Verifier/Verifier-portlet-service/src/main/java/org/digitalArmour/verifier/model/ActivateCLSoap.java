package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ActivateCLServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ActivateCLServiceSoap
 * @generated
 */
public class ActivateCLSoap implements Serializable {
    private String _uuid;
    private long _activateId;
    private long _checklistId;
    private String _clName;
    private String _clDescription;
    private String _organiztion;
    private boolean _isPublic;
    private boolean _isCompleted;
    private Date _completedDate;
    private long _actClUserId;

    public ActivateCLSoap() {
    }

    public static ActivateCLSoap toSoapModel(ActivateCL model) {
        ActivateCLSoap soapModel = new ActivateCLSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setActivateId(model.getActivateId());
        soapModel.setChecklistId(model.getChecklistId());
        soapModel.setClName(model.getClName());
        soapModel.setClDescription(model.getClDescription());
        soapModel.setOrganiztion(model.getOrganiztion());
        soapModel.setIsPublic(model.getIsPublic());
        soapModel.setIsCompleted(model.getIsCompleted());
        soapModel.setCompletedDate(model.getCompletedDate());
        soapModel.setActClUserId(model.getActClUserId());

        return soapModel;
    }

    public static ActivateCLSoap[] toSoapModels(ActivateCL[] models) {
        ActivateCLSoap[] soapModels = new ActivateCLSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ActivateCLSoap[][] toSoapModels(ActivateCL[][] models) {
        ActivateCLSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ActivateCLSoap[models.length][models[0].length];
        } else {
            soapModels = new ActivateCLSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ActivateCLSoap[] toSoapModels(List<ActivateCL> models) {
        List<ActivateCLSoap> soapModels = new ArrayList<ActivateCLSoap>(models.size());

        for (ActivateCL model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ActivateCLSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _activateId;
    }

    public void setPrimaryKey(long pk) {
        setActivateId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getActivateId() {
        return _activateId;
    }

    public void setActivateId(long activateId) {
        _activateId = activateId;
    }

    public long getChecklistId() {
        return _checklistId;
    }

    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;
    }

    public String getClName() {
        return _clName;
    }

    public void setClName(String clName) {
        _clName = clName;
    }

    public String getClDescription() {
        return _clDescription;
    }

    public void setClDescription(String clDescription) {
        _clDescription = clDescription;
    }

    public String getOrganiztion() {
        return _organiztion;
    }

    public void setOrganiztion(String organiztion) {
        _organiztion = organiztion;
    }

    public boolean getIsPublic() {
        return _isPublic;
    }

    public boolean isIsPublic() {
        return _isPublic;
    }

    public void setIsPublic(boolean isPublic) {
        _isPublic = isPublic;
    }

    public boolean getIsCompleted() {
        return _isCompleted;
    }

    public boolean isIsCompleted() {
        return _isCompleted;
    }

    public void setIsCompleted(boolean isCompleted) {
        _isCompleted = isCompleted;
    }

    public Date getCompletedDate() {
        return _completedDate;
    }

    public void setCompletedDate(Date completedDate) {
        _completedDate = completedDate;
    }

    public long getActClUserId() {
        return _actClUserId;
    }

    public void setActClUserId(long actClUserId) {
        _actClUserId = actClUserId;
    }
}
