package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ActivateCL}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCL
 * @generated
 */
public class ActivateCLWrapper implements ActivateCL, ModelWrapper<ActivateCL> {
    private ActivateCL _activateCL;

    public ActivateCLWrapper(ActivateCL activateCL) {
        _activateCL = activateCL;
    }

    @Override
    public Class<?> getModelClass() {
        return ActivateCL.class;
    }

    @Override
    public String getModelClassName() {
        return ActivateCL.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("activateId", getActivateId());
        attributes.put("checklistId", getChecklistId());
        attributes.put("clName", getClName());
        attributes.put("clDescription", getClDescription());
        attributes.put("organiztion", getOrganiztion());
        attributes.put("isPublic", getIsPublic());
        attributes.put("isCompleted", getIsCompleted());
        attributes.put("completedDate", getCompletedDate());
        attributes.put("actClUserId", getActClUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long activateId = (Long) attributes.get("activateId");

        if (activateId != null) {
            setActivateId(activateId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }

        String clName = (String) attributes.get("clName");

        if (clName != null) {
            setClName(clName);
        }

        String clDescription = (String) attributes.get("clDescription");

        if (clDescription != null) {
            setClDescription(clDescription);
        }

        String organiztion = (String) attributes.get("organiztion");

        if (organiztion != null) {
            setOrganiztion(organiztion);
        }

        Boolean isPublic = (Boolean) attributes.get("isPublic");

        if (isPublic != null) {
            setIsPublic(isPublic);
        }

        Boolean isCompleted = (Boolean) attributes.get("isCompleted");

        if (isCompleted != null) {
            setIsCompleted(isCompleted);
        }

        Date completedDate = (Date) attributes.get("completedDate");

        if (completedDate != null) {
            setCompletedDate(completedDate);
        }

        Long actClUserId = (Long) attributes.get("actClUserId");

        if (actClUserId != null) {
            setActClUserId(actClUserId);
        }
    }

    /**
    * Returns the primary key of this activate c l.
    *
    * @return the primary key of this activate c l
    */
    @Override
    public long getPrimaryKey() {
        return _activateCL.getPrimaryKey();
    }

    /**
    * Sets the primary key of this activate c l.
    *
    * @param primaryKey the primary key of this activate c l
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _activateCL.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this activate c l.
    *
    * @return the uuid of this activate c l
    */
    @Override
    public java.lang.String getUuid() {
        return _activateCL.getUuid();
    }

    /**
    * Sets the uuid of this activate c l.
    *
    * @param uuid the uuid of this activate c l
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _activateCL.setUuid(uuid);
    }

    /**
    * Returns the activate ID of this activate c l.
    *
    * @return the activate ID of this activate c l
    */
    @Override
    public long getActivateId() {
        return _activateCL.getActivateId();
    }

    /**
    * Sets the activate ID of this activate c l.
    *
    * @param activateId the activate ID of this activate c l
    */
    @Override
    public void setActivateId(long activateId) {
        _activateCL.setActivateId(activateId);
    }

    /**
    * Returns the checklist ID of this activate c l.
    *
    * @return the checklist ID of this activate c l
    */
    @Override
    public long getChecklistId() {
        return _activateCL.getChecklistId();
    }

    /**
    * Sets the checklist ID of this activate c l.
    *
    * @param checklistId the checklist ID of this activate c l
    */
    @Override
    public void setChecklistId(long checklistId) {
        _activateCL.setChecklistId(checklistId);
    }

    /**
    * Returns the cl name of this activate c l.
    *
    * @return the cl name of this activate c l
    */
    @Override
    public java.lang.String getClName() {
        return _activateCL.getClName();
    }

    /**
    * Sets the cl name of this activate c l.
    *
    * @param clName the cl name of this activate c l
    */
    @Override
    public void setClName(java.lang.String clName) {
        _activateCL.setClName(clName);
    }

    /**
    * Returns the cl description of this activate c l.
    *
    * @return the cl description of this activate c l
    */
    @Override
    public java.lang.String getClDescription() {
        return _activateCL.getClDescription();
    }

    /**
    * Sets the cl description of this activate c l.
    *
    * @param clDescription the cl description of this activate c l
    */
    @Override
    public void setClDescription(java.lang.String clDescription) {
        _activateCL.setClDescription(clDescription);
    }

    /**
    * Returns the organiztion of this activate c l.
    *
    * @return the organiztion of this activate c l
    */
    @Override
    public java.lang.String getOrganiztion() {
        return _activateCL.getOrganiztion();
    }

    /**
    * Sets the organiztion of this activate c l.
    *
    * @param organiztion the organiztion of this activate c l
    */
    @Override
    public void setOrganiztion(java.lang.String organiztion) {
        _activateCL.setOrganiztion(organiztion);
    }

    /**
    * Returns the is public of this activate c l.
    *
    * @return the is public of this activate c l
    */
    @Override
    public boolean getIsPublic() {
        return _activateCL.getIsPublic();
    }

    /**
    * Returns <code>true</code> if this activate c l is is public.
    *
    * @return <code>true</code> if this activate c l is is public; <code>false</code> otherwise
    */
    @Override
    public boolean isIsPublic() {
        return _activateCL.isIsPublic();
    }

    /**
    * Sets whether this activate c l is is public.
    *
    * @param isPublic the is public of this activate c l
    */
    @Override
    public void setIsPublic(boolean isPublic) {
        _activateCL.setIsPublic(isPublic);
    }

    /**
    * Returns the is completed of this activate c l.
    *
    * @return the is completed of this activate c l
    */
    @Override
    public boolean getIsCompleted() {
        return _activateCL.getIsCompleted();
    }

    /**
    * Returns <code>true</code> if this activate c l is is completed.
    *
    * @return <code>true</code> if this activate c l is is completed; <code>false</code> otherwise
    */
    @Override
    public boolean isIsCompleted() {
        return _activateCL.isIsCompleted();
    }

    /**
    * Sets whether this activate c l is is completed.
    *
    * @param isCompleted the is completed of this activate c l
    */
    @Override
    public void setIsCompleted(boolean isCompleted) {
        _activateCL.setIsCompleted(isCompleted);
    }

    /**
    * Returns the completed date of this activate c l.
    *
    * @return the completed date of this activate c l
    */
    @Override
    public java.util.Date getCompletedDate() {
        return _activateCL.getCompletedDate();
    }

    /**
    * Sets the completed date of this activate c l.
    *
    * @param completedDate the completed date of this activate c l
    */
    @Override
    public void setCompletedDate(java.util.Date completedDate) {
        _activateCL.setCompletedDate(completedDate);
    }

    /**
    * Returns the act cl user ID of this activate c l.
    *
    * @return the act cl user ID of this activate c l
    */
    @Override
    public long getActClUserId() {
        return _activateCL.getActClUserId();
    }

    /**
    * Sets the act cl user ID of this activate c l.
    *
    * @param actClUserId the act cl user ID of this activate c l
    */
    @Override
    public void setActClUserId(long actClUserId) {
        _activateCL.setActClUserId(actClUserId);
    }

    /**
    * Returns the act cl user uuid of this activate c l.
    *
    * @return the act cl user uuid of this activate c l
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getActClUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCL.getActClUserUuid();
    }

    /**
    * Sets the act cl user uuid of this activate c l.
    *
    * @param actClUserUuid the act cl user uuid of this activate c l
    */
    @Override
    public void setActClUserUuid(java.lang.String actClUserUuid) {
        _activateCL.setActClUserUuid(actClUserUuid);
    }

    @Override
    public boolean isNew() {
        return _activateCL.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _activateCL.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _activateCL.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _activateCL.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _activateCL.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _activateCL.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _activateCL.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _activateCL.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _activateCL.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _activateCL.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _activateCL.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ActivateCLWrapper((ActivateCL) _activateCL.clone());
    }

    @Override
    public int compareTo(ActivateCL activateCL) {
        return _activateCL.compareTo(activateCL);
    }

    @Override
    public int hashCode() {
        return _activateCL.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ActivateCL> toCacheModel() {
        return _activateCL.toCacheModel();
    }

    @Override
    public ActivateCL toEscapedModel() {
        return new ActivateCLWrapper(_activateCL.toEscapedModel());
    }

    @Override
    public ActivateCL toUnescapedModel() {
        return new ActivateCLWrapper(_activateCL.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _activateCL.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _activateCL.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _activateCL.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ActivateCLWrapper)) {
            return false;
        }

        ActivateCLWrapper activateCLWrapper = (ActivateCLWrapper) obj;

        if (Validator.equals(_activateCL, activateCLWrapper._activateCL)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ActivateCL getWrappedActivateCL() {
        return _activateCL;
    }

    @Override
    public ActivateCL getWrappedModel() {
        return _activateCL;
    }

    @Override
    public void resetOriginalValues() {
        _activateCL.resetOriginalValues();
    }
}
