package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.CLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class CLCollabClp extends BaseModelImpl<CLCollab> implements CLCollab {
    private String _uuid;
    private long _clCollabId;
    private String _collabType;
    private long _prManagerId;
    private long _userId;
    private String _userUuid;
    private long _checklistId;
    private BaseModel<?> _clCollabRemoteModel;

    public CLCollabClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return CLCollab.class;
    }

    @Override
    public String getModelClassName() {
        return CLCollab.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _clCollabId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setClCollabId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _clCollabId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("clCollabId", getClCollabId());
        attributes.put("collabType", getCollabType());
        attributes.put("prManagerId", getPrManagerId());
        attributes.put("userId", getUserId());
        attributes.put("checklistId", getChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long clCollabId = (Long) attributes.get("clCollabId");

        if (clCollabId != null) {
            setClCollabId(clCollabId);
        }

        String collabType = (String) attributes.get("collabType");

        if (collabType != null) {
            setCollabType(collabType);
        }

        Long prManagerId = (Long) attributes.get("prManagerId");

        if (prManagerId != null) {
            setPrManagerId(prManagerId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_clCollabRemoteModel != null) {
            try {
                Class<?> clazz = _clCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_clCollabRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getClCollabId() {
        return _clCollabId;
    }

    @Override
    public void setClCollabId(long clCollabId) {
        _clCollabId = clCollabId;

        if (_clCollabRemoteModel != null) {
            try {
                Class<?> clazz = _clCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setClCollabId", long.class);

                method.invoke(_clCollabRemoteModel, clCollabId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getCollabType() {
        return _collabType;
    }

    @Override
    public void setCollabType(String collabType) {
        _collabType = collabType;

        if (_clCollabRemoteModel != null) {
            try {
                Class<?> clazz = _clCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setCollabType", String.class);

                method.invoke(_clCollabRemoteModel, collabType);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getPrManagerId() {
        return _prManagerId;
    }

    @Override
    public void setPrManagerId(long prManagerId) {
        _prManagerId = prManagerId;

        if (_clCollabRemoteModel != null) {
            try {
                Class<?> clazz = _clCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setPrManagerId", long.class);

                method.invoke(_clCollabRemoteModel, prManagerId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_clCollabRemoteModel != null) {
            try {
                Class<?> clazz = _clCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_clCollabRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    @Override
    public long getChecklistId() {
        return _checklistId;
    }

    @Override
    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;

        if (_clCollabRemoteModel != null) {
            try {
                Class<?> clazz = _clCollabRemoteModel.getClass();

                Method method = clazz.getMethod("setChecklistId", long.class);

                method.invoke(_clCollabRemoteModel, checklistId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> getCLCollabRemoteModel() {
        return _clCollabRemoteModel;
    }

    public void setCLCollabRemoteModel(BaseModel<?> clCollabRemoteModel) {
        _clCollabRemoteModel = clCollabRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _clCollabRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_clCollabRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            CLCollabLocalServiceUtil.addCLCollab(this);
        } else {
            CLCollabLocalServiceUtil.updateCLCollab(this);
        }
    }

    @Override
    public CLCollab toEscapedModel() {
        return (CLCollab) ProxyUtil.newProxyInstance(CLCollab.class.getClassLoader(),
            new Class[] { CLCollab.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        CLCollabClp clone = new CLCollabClp();

        clone.setUuid(getUuid());
        clone.setClCollabId(getClCollabId());
        clone.setCollabType(getCollabType());
        clone.setPrManagerId(getPrManagerId());
        clone.setUserId(getUserId());
        clone.setChecklistId(getChecklistId());

        return clone;
    }

    @Override
    public int compareTo(CLCollab clCollab) {
        int value = 0;

        if (getClCollabId() < clCollab.getClCollabId()) {
            value = -1;
        } else if (getClCollabId() > clCollab.getClCollabId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof CLCollabClp)) {
            return false;
        }

        CLCollabClp clCollab = (CLCollabClp) obj;

        long primaryKey = clCollab.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", clCollabId=");
        sb.append(getClCollabId());
        sb.append(", collabType=");
        sb.append(getCollabType());
        sb.append(", prManagerId=");
        sb.append(getPrManagerId());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append(", checklistId=");
        sb.append(getChecklistId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(22);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.CLCollab");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>clCollabId</column-name><column-value><![CDATA[");
        sb.append(getClCollabId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>collabType</column-name><column-value><![CDATA[");
        sb.append(getCollabType());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>prManagerId</column-name><column-value><![CDATA[");
        sb.append(getPrManagerId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>checklistId</column-name><column-value><![CDATA[");
        sb.append(getChecklistId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
