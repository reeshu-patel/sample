package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.CLCollabServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.CLCollabServiceSoap
 * @generated
 */
public class CLCollabSoap implements Serializable {
    private String _uuid;
    private long _clCollabId;
    private String _collabType;
    private long _prManagerId;
    private long _userId;
    private long _checklistId;

    public CLCollabSoap() {
    }

    public static CLCollabSoap toSoapModel(CLCollab model) {
        CLCollabSoap soapModel = new CLCollabSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setClCollabId(model.getClCollabId());
        soapModel.setCollabType(model.getCollabType());
        soapModel.setPrManagerId(model.getPrManagerId());
        soapModel.setUserId(model.getUserId());
        soapModel.setChecklistId(model.getChecklistId());

        return soapModel;
    }

    public static CLCollabSoap[] toSoapModels(CLCollab[] models) {
        CLCollabSoap[] soapModels = new CLCollabSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static CLCollabSoap[][] toSoapModels(CLCollab[][] models) {
        CLCollabSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new CLCollabSoap[models.length][models[0].length];
        } else {
            soapModels = new CLCollabSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static CLCollabSoap[] toSoapModels(List<CLCollab> models) {
        List<CLCollabSoap> soapModels = new ArrayList<CLCollabSoap>(models.size());

        for (CLCollab model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new CLCollabSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _clCollabId;
    }

    public void setPrimaryKey(long pk) {
        setClCollabId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getClCollabId() {
        return _clCollabId;
    }

    public void setClCollabId(long clCollabId) {
        _clCollabId = clCollabId;
    }

    public String getCollabType() {
        return _collabType;
    }

    public void setCollabType(String collabType) {
        _collabType = collabType;
    }

    public long getPrManagerId() {
        return _prManagerId;
    }

    public void setPrManagerId(long prManagerId) {
        _prManagerId = prManagerId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }

    public long getChecklistId() {
        return _checklistId;
    }

    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;
    }
}
