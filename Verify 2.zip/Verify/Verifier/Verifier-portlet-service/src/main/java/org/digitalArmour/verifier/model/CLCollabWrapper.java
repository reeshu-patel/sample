package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link CLCollab}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CLCollab
 * @generated
 */
public class CLCollabWrapper implements CLCollab, ModelWrapper<CLCollab> {
    private CLCollab _clCollab;

    public CLCollabWrapper(CLCollab clCollab) {
        _clCollab = clCollab;
    }

    @Override
    public Class<?> getModelClass() {
        return CLCollab.class;
    }

    @Override
    public String getModelClassName() {
        return CLCollab.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("clCollabId", getClCollabId());
        attributes.put("collabType", getCollabType());
        attributes.put("prManagerId", getPrManagerId());
        attributes.put("userId", getUserId());
        attributes.put("checklistId", getChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long clCollabId = (Long) attributes.get("clCollabId");

        if (clCollabId != null) {
            setClCollabId(clCollabId);
        }

        String collabType = (String) attributes.get("collabType");

        if (collabType != null) {
            setCollabType(collabType);
        }

        Long prManagerId = (Long) attributes.get("prManagerId");

        if (prManagerId != null) {
            setPrManagerId(prManagerId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }
    }

    /**
    * Returns the primary key of this c l collab.
    *
    * @return the primary key of this c l collab
    */
    @Override
    public long getPrimaryKey() {
        return _clCollab.getPrimaryKey();
    }

    /**
    * Sets the primary key of this c l collab.
    *
    * @param primaryKey the primary key of this c l collab
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _clCollab.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this c l collab.
    *
    * @return the uuid of this c l collab
    */
    @Override
    public java.lang.String getUuid() {
        return _clCollab.getUuid();
    }

    /**
    * Sets the uuid of this c l collab.
    *
    * @param uuid the uuid of this c l collab
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _clCollab.setUuid(uuid);
    }

    /**
    * Returns the cl collab ID of this c l collab.
    *
    * @return the cl collab ID of this c l collab
    */
    @Override
    public long getClCollabId() {
        return _clCollab.getClCollabId();
    }

    /**
    * Sets the cl collab ID of this c l collab.
    *
    * @param clCollabId the cl collab ID of this c l collab
    */
    @Override
    public void setClCollabId(long clCollabId) {
        _clCollab.setClCollabId(clCollabId);
    }

    /**
    * Returns the collab type of this c l collab.
    *
    * @return the collab type of this c l collab
    */
    @Override
    public java.lang.String getCollabType() {
        return _clCollab.getCollabType();
    }

    /**
    * Sets the collab type of this c l collab.
    *
    * @param collabType the collab type of this c l collab
    */
    @Override
    public void setCollabType(java.lang.String collabType) {
        _clCollab.setCollabType(collabType);
    }

    /**
    * Returns the pr manager ID of this c l collab.
    *
    * @return the pr manager ID of this c l collab
    */
    @Override
    public long getPrManagerId() {
        return _clCollab.getPrManagerId();
    }

    /**
    * Sets the pr manager ID of this c l collab.
    *
    * @param prManagerId the pr manager ID of this c l collab
    */
    @Override
    public void setPrManagerId(long prManagerId) {
        _clCollab.setPrManagerId(prManagerId);
    }

    /**
    * Returns the user ID of this c l collab.
    *
    * @return the user ID of this c l collab
    */
    @Override
    public long getUserId() {
        return _clCollab.getUserId();
    }

    /**
    * Sets the user ID of this c l collab.
    *
    * @param userId the user ID of this c l collab
    */
    @Override
    public void setUserId(long userId) {
        _clCollab.setUserId(userId);
    }

    /**
    * Returns the user uuid of this c l collab.
    *
    * @return the user uuid of this c l collab
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clCollab.getUserUuid();
    }

    /**
    * Sets the user uuid of this c l collab.
    *
    * @param userUuid the user uuid of this c l collab
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _clCollab.setUserUuid(userUuid);
    }

    /**
    * Returns the checklist ID of this c l collab.
    *
    * @return the checklist ID of this c l collab
    */
    @Override
    public long getChecklistId() {
        return _clCollab.getChecklistId();
    }

    /**
    * Sets the checklist ID of this c l collab.
    *
    * @param checklistId the checklist ID of this c l collab
    */
    @Override
    public void setChecklistId(long checklistId) {
        _clCollab.setChecklistId(checklistId);
    }

    @Override
    public boolean isNew() {
        return _clCollab.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _clCollab.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _clCollab.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _clCollab.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _clCollab.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _clCollab.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _clCollab.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _clCollab.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _clCollab.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _clCollab.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _clCollab.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new CLCollabWrapper((CLCollab) _clCollab.clone());
    }

    @Override
    public int compareTo(CLCollab clCollab) {
        return _clCollab.compareTo(clCollab);
    }

    @Override
    public int hashCode() {
        return _clCollab.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<CLCollab> toCacheModel() {
        return _clCollab.toCacheModel();
    }

    @Override
    public CLCollab toEscapedModel() {
        return new CLCollabWrapper(_clCollab.toEscapedModel());
    }

    @Override
    public CLCollab toUnescapedModel() {
        return new CLCollabWrapper(_clCollab.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _clCollab.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _clCollab.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _clCollab.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof CLCollabWrapper)) {
            return false;
        }

        CLCollabWrapper clCollabWrapper = (CLCollabWrapper) obj;

        if (Validator.equals(_clCollab, clCollabWrapper._clCollab)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public CLCollab getWrappedCLCollab() {
        return _clCollab;
    }

    @Override
    public CLCollab getWrappedModel() {
        return _clCollab;
    }

    @Override
    public void resetOriginalValues() {
        _clCollab.resetOriginalValues();
    }
}
