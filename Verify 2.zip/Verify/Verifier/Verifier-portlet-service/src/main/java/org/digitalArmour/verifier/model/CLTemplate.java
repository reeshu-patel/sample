package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the CLTemplate service. Represents a row in the &quot;Verifier_CLTemplate&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplateModel
 * @see org.digitalArmour.verifier.model.impl.CLTemplateImpl
 * @see org.digitalArmour.verifier.model.impl.CLTemplateModelImpl
 * @generated
 */
public interface CLTemplate extends CLTemplateModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.CLTemplateImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
