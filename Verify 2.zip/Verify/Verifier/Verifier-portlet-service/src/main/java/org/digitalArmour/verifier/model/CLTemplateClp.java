package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class CLTemplateClp extends BaseModelImpl<CLTemplate>
    implements CLTemplate {
    private String _uuid;
    private long _checklistId;
    private String _clName;
    private String _clDescription;
    private String _clOrganiztion;
    private long _clUserId;
    private String _clUserUuid;
    private boolean _isPublic;
    private boolean _isPubliccat;
    private BaseModel<?> _clTemplateRemoteModel;

    public CLTemplateClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return CLTemplate.class;
    }

    @Override
    public String getModelClassName() {
        return CLTemplate.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _checklistId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setChecklistId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _checklistId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("checklistId", getChecklistId());
        attributes.put("clName", getClName());
        attributes.put("clDescription", getClDescription());
        attributes.put("clOrganiztion", getClOrganiztion());
        attributes.put("clUserId", getClUserId());
        attributes.put("isPublic", getIsPublic());
        attributes.put("isPubliccat", getIsPubliccat());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }

        String clName = (String) attributes.get("clName");

        if (clName != null) {
            setClName(clName);
        }

        String clDescription = (String) attributes.get("clDescription");

        if (clDescription != null) {
            setClDescription(clDescription);
        }

        String clOrganiztion = (String) attributes.get("clOrganiztion");

        if (clOrganiztion != null) {
            setClOrganiztion(clOrganiztion);
        }

        Long clUserId = (Long) attributes.get("clUserId");

        if (clUserId != null) {
            setClUserId(clUserId);
        }

        Boolean isPublic = (Boolean) attributes.get("isPublic");

        if (isPublic != null) {
            setIsPublic(isPublic);
        }

        Boolean isPubliccat = (Boolean) attributes.get("isPubliccat");

        if (isPubliccat != null) {
            setIsPubliccat(isPubliccat);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_clTemplateRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getChecklistId() {
        return _checklistId;
    }

    @Override
    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setChecklistId", long.class);

                method.invoke(_clTemplateRemoteModel, checklistId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getClName() {
        return _clName;
    }

    @Override
    public void setClName(String clName) {
        _clName = clName;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setClName", String.class);

                method.invoke(_clTemplateRemoteModel, clName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getClDescription() {
        return _clDescription;
    }

    @Override
    public void setClDescription(String clDescription) {
        _clDescription = clDescription;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setClDescription", String.class);

                method.invoke(_clTemplateRemoteModel, clDescription);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getClOrganiztion() {
        return _clOrganiztion;
    }

    @Override
    public void setClOrganiztion(String clOrganiztion) {
        _clOrganiztion = clOrganiztion;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setClOrganiztion", String.class);

                method.invoke(_clTemplateRemoteModel, clOrganiztion);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getClUserId() {
        return _clUserId;
    }

    @Override
    public void setClUserId(long clUserId) {
        _clUserId = clUserId;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setClUserId", long.class);

                method.invoke(_clTemplateRemoteModel, clUserId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getClUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getClUserId(), "uuid", _clUserUuid);
    }

    @Override
    public void setClUserUuid(String clUserUuid) {
        _clUserUuid = clUserUuid;
    }

    @Override
    public boolean getIsPublic() {
        return _isPublic;
    }

    @Override
    public boolean isIsPublic() {
        return _isPublic;
    }

    @Override
    public void setIsPublic(boolean isPublic) {
        _isPublic = isPublic;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setIsPublic", boolean.class);

                method.invoke(_clTemplateRemoteModel, isPublic);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getIsPubliccat() {
        return _isPubliccat;
    }

    @Override
    public boolean isIsPubliccat() {
        return _isPubliccat;
    }

    @Override
    public void setIsPubliccat(boolean isPubliccat) {
        _isPubliccat = isPubliccat;

        if (_clTemplateRemoteModel != null) {
            try {
                Class<?> clazz = _clTemplateRemoteModel.getClass();

                Method method = clazz.getMethod("setIsPubliccat", boolean.class);

                method.invoke(_clTemplateRemoteModel, isPubliccat);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> getCLTemplateRemoteModel() {
        return _clTemplateRemoteModel;
    }

    public void setCLTemplateRemoteModel(BaseModel<?> clTemplateRemoteModel) {
        _clTemplateRemoteModel = clTemplateRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _clTemplateRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_clTemplateRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            CLTemplateLocalServiceUtil.addCLTemplate(this);
        } else {
            CLTemplateLocalServiceUtil.updateCLTemplate(this);
        }
    }

    @Override
    public CLTemplate toEscapedModel() {
        return (CLTemplate) ProxyUtil.newProxyInstance(CLTemplate.class.getClassLoader(),
            new Class[] { CLTemplate.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        CLTemplateClp clone = new CLTemplateClp();

        clone.setUuid(getUuid());
        clone.setChecklistId(getChecklistId());
        clone.setClName(getClName());
        clone.setClDescription(getClDescription());
        clone.setClOrganiztion(getClOrganiztion());
        clone.setClUserId(getClUserId());
        clone.setIsPublic(getIsPublic());
        clone.setIsPubliccat(getIsPubliccat());

        return clone;
    }

    @Override
    public int compareTo(CLTemplate clTemplate) {
        int value = 0;

        if (getChecklistId() < clTemplate.getChecklistId()) {
            value = -1;
        } else if (getChecklistId() > clTemplate.getChecklistId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof CLTemplateClp)) {
            return false;
        }

        CLTemplateClp clTemplate = (CLTemplateClp) obj;

        long primaryKey = clTemplate.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(17);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", checklistId=");
        sb.append(getChecklistId());
        sb.append(", clName=");
        sb.append(getClName());
        sb.append(", clDescription=");
        sb.append(getClDescription());
        sb.append(", clOrganiztion=");
        sb.append(getClOrganiztion());
        sb.append(", clUserId=");
        sb.append(getClUserId());
        sb.append(", isPublic=");
        sb.append(getIsPublic());
        sb.append(", isPubliccat=");
        sb.append(getIsPubliccat());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(28);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.CLTemplate");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>checklistId</column-name><column-value><![CDATA[");
        sb.append(getChecklistId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>clName</column-name><column-value><![CDATA[");
        sb.append(getClName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>clDescription</column-name><column-value><![CDATA[");
        sb.append(getClDescription());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>clOrganiztion</column-name><column-value><![CDATA[");
        sb.append(getClOrganiztion());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>clUserId</column-name><column-value><![CDATA[");
        sb.append(getClUserId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>isPublic</column-name><column-value><![CDATA[");
        sb.append(getIsPublic());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>isPubliccat</column-name><column-value><![CDATA[");
        sb.append(getIsPubliccat());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
