package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.CLTemplateServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.CLTemplateServiceSoap
 * @generated
 */
public class CLTemplateSoap implements Serializable {
    private String _uuid;
    private long _checklistId;
    private String _clName;
    private String _clDescription;
    private String _clOrganiztion;
    private long _clUserId;
    private boolean _isPublic;
    private boolean _isPubliccat;

    public CLTemplateSoap() {
    }

    public static CLTemplateSoap toSoapModel(CLTemplate model) {
        CLTemplateSoap soapModel = new CLTemplateSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setChecklistId(model.getChecklistId());
        soapModel.setClName(model.getClName());
        soapModel.setClDescription(model.getClDescription());
        soapModel.setClOrganiztion(model.getClOrganiztion());
        soapModel.setClUserId(model.getClUserId());
        soapModel.setIsPublic(model.getIsPublic());
        soapModel.setIsPubliccat(model.getIsPubliccat());

        return soapModel;
    }

    public static CLTemplateSoap[] toSoapModels(CLTemplate[] models) {
        CLTemplateSoap[] soapModels = new CLTemplateSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static CLTemplateSoap[][] toSoapModels(CLTemplate[][] models) {
        CLTemplateSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new CLTemplateSoap[models.length][models[0].length];
        } else {
            soapModels = new CLTemplateSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static CLTemplateSoap[] toSoapModels(List<CLTemplate> models) {
        List<CLTemplateSoap> soapModels = new ArrayList<CLTemplateSoap>(models.size());

        for (CLTemplate model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new CLTemplateSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _checklistId;
    }

    public void setPrimaryKey(long pk) {
        setChecklistId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getChecklistId() {
        return _checklistId;
    }

    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;
    }

    public String getClName() {
        return _clName;
    }

    public void setClName(String clName) {
        _clName = clName;
    }

    public String getClDescription() {
        return _clDescription;
    }

    public void setClDescription(String clDescription) {
        _clDescription = clDescription;
    }

    public String getClOrganiztion() {
        return _clOrganiztion;
    }

    public void setClOrganiztion(String clOrganiztion) {
        _clOrganiztion = clOrganiztion;
    }

    public long getClUserId() {
        return _clUserId;
    }

    public void setClUserId(long clUserId) {
        _clUserId = clUserId;
    }

    public boolean getIsPublic() {
        return _isPublic;
    }

    public boolean isIsPublic() {
        return _isPublic;
    }

    public void setIsPublic(boolean isPublic) {
        _isPublic = isPublic;
    }

    public boolean getIsPubliccat() {
        return _isPubliccat;
    }

    public boolean isIsPubliccat() {
        return _isPubliccat;
    }

    public void setIsPubliccat(boolean isPubliccat) {
        _isPubliccat = isPubliccat;
    }
}
