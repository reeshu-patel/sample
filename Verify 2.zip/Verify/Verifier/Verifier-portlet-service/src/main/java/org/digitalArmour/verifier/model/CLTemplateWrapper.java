package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link CLTemplate}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplate
 * @generated
 */
public class CLTemplateWrapper implements CLTemplate, ModelWrapper<CLTemplate> {
    private CLTemplate _clTemplate;

    public CLTemplateWrapper(CLTemplate clTemplate) {
        _clTemplate = clTemplate;
    }

    @Override
    public Class<?> getModelClass() {
        return CLTemplate.class;
    }

    @Override
    public String getModelClassName() {
        return CLTemplate.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("checklistId", getChecklistId());
        attributes.put("clName", getClName());
        attributes.put("clDescription", getClDescription());
        attributes.put("clOrganiztion", getClOrganiztion());
        attributes.put("clUserId", getClUserId());
        attributes.put("isPublic", getIsPublic());
        attributes.put("isPubliccat", getIsPubliccat());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }

        String clName = (String) attributes.get("clName");

        if (clName != null) {
            setClName(clName);
        }

        String clDescription = (String) attributes.get("clDescription");

        if (clDescription != null) {
            setClDescription(clDescription);
        }

        String clOrganiztion = (String) attributes.get("clOrganiztion");

        if (clOrganiztion != null) {
            setClOrganiztion(clOrganiztion);
        }

        Long clUserId = (Long) attributes.get("clUserId");

        if (clUserId != null) {
            setClUserId(clUserId);
        }

        Boolean isPublic = (Boolean) attributes.get("isPublic");

        if (isPublic != null) {
            setIsPublic(isPublic);
        }

        Boolean isPubliccat = (Boolean) attributes.get("isPubliccat");

        if (isPubliccat != null) {
            setIsPubliccat(isPubliccat);
        }
    }

    /**
    * Returns the primary key of this c l template.
    *
    * @return the primary key of this c l template
    */
    @Override
    public long getPrimaryKey() {
        return _clTemplate.getPrimaryKey();
    }

    /**
    * Sets the primary key of this c l template.
    *
    * @param primaryKey the primary key of this c l template
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _clTemplate.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this c l template.
    *
    * @return the uuid of this c l template
    */
    @Override
    public java.lang.String getUuid() {
        return _clTemplate.getUuid();
    }

    /**
    * Sets the uuid of this c l template.
    *
    * @param uuid the uuid of this c l template
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _clTemplate.setUuid(uuid);
    }

    /**
    * Returns the checklist ID of this c l template.
    *
    * @return the checklist ID of this c l template
    */
    @Override
    public long getChecklistId() {
        return _clTemplate.getChecklistId();
    }

    /**
    * Sets the checklist ID of this c l template.
    *
    * @param checklistId the checklist ID of this c l template
    */
    @Override
    public void setChecklistId(long checklistId) {
        _clTemplate.setChecklistId(checklistId);
    }

    /**
    * Returns the cl name of this c l template.
    *
    * @return the cl name of this c l template
    */
    @Override
    public java.lang.String getClName() {
        return _clTemplate.getClName();
    }

    /**
    * Sets the cl name of this c l template.
    *
    * @param clName the cl name of this c l template
    */
    @Override
    public void setClName(java.lang.String clName) {
        _clTemplate.setClName(clName);
    }

    /**
    * Returns the cl description of this c l template.
    *
    * @return the cl description of this c l template
    */
    @Override
    public java.lang.String getClDescription() {
        return _clTemplate.getClDescription();
    }

    /**
    * Sets the cl description of this c l template.
    *
    * @param clDescription the cl description of this c l template
    */
    @Override
    public void setClDescription(java.lang.String clDescription) {
        _clTemplate.setClDescription(clDescription);
    }

    /**
    * Returns the cl organiztion of this c l template.
    *
    * @return the cl organiztion of this c l template
    */
    @Override
    public java.lang.String getClOrganiztion() {
        return _clTemplate.getClOrganiztion();
    }

    /**
    * Sets the cl organiztion of this c l template.
    *
    * @param clOrganiztion the cl organiztion of this c l template
    */
    @Override
    public void setClOrganiztion(java.lang.String clOrganiztion) {
        _clTemplate.setClOrganiztion(clOrganiztion);
    }

    /**
    * Returns the cl user ID of this c l template.
    *
    * @return the cl user ID of this c l template
    */
    @Override
    public long getClUserId() {
        return _clTemplate.getClUserId();
    }

    /**
    * Sets the cl user ID of this c l template.
    *
    * @param clUserId the cl user ID of this c l template
    */
    @Override
    public void setClUserId(long clUserId) {
        _clTemplate.setClUserId(clUserId);
    }

    /**
    * Returns the cl user uuid of this c l template.
    *
    * @return the cl user uuid of this c l template
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getClUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplate.getClUserUuid();
    }

    /**
    * Sets the cl user uuid of this c l template.
    *
    * @param clUserUuid the cl user uuid of this c l template
    */
    @Override
    public void setClUserUuid(java.lang.String clUserUuid) {
        _clTemplate.setClUserUuid(clUserUuid);
    }

    /**
    * Returns the is public of this c l template.
    *
    * @return the is public of this c l template
    */
    @Override
    public boolean getIsPublic() {
        return _clTemplate.getIsPublic();
    }

    /**
    * Returns <code>true</code> if this c l template is is public.
    *
    * @return <code>true</code> if this c l template is is public; <code>false</code> otherwise
    */
    @Override
    public boolean isIsPublic() {
        return _clTemplate.isIsPublic();
    }

    /**
    * Sets whether this c l template is is public.
    *
    * @param isPublic the is public of this c l template
    */
    @Override
    public void setIsPublic(boolean isPublic) {
        _clTemplate.setIsPublic(isPublic);
    }

    /**
    * Returns the is publiccat of this c l template.
    *
    * @return the is publiccat of this c l template
    */
    @Override
    public boolean getIsPubliccat() {
        return _clTemplate.getIsPubliccat();
    }

    /**
    * Returns <code>true</code> if this c l template is is publiccat.
    *
    * @return <code>true</code> if this c l template is is publiccat; <code>false</code> otherwise
    */
    @Override
    public boolean isIsPubliccat() {
        return _clTemplate.isIsPubliccat();
    }

    /**
    * Sets whether this c l template is is publiccat.
    *
    * @param isPubliccat the is publiccat of this c l template
    */
    @Override
    public void setIsPubliccat(boolean isPubliccat) {
        _clTemplate.setIsPubliccat(isPubliccat);
    }

    @Override
    public boolean isNew() {
        return _clTemplate.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _clTemplate.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _clTemplate.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _clTemplate.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _clTemplate.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _clTemplate.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _clTemplate.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _clTemplate.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _clTemplate.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _clTemplate.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _clTemplate.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new CLTemplateWrapper((CLTemplate) _clTemplate.clone());
    }

    @Override
    public int compareTo(CLTemplate clTemplate) {
        return _clTemplate.compareTo(clTemplate);
    }

    @Override
    public int hashCode() {
        return _clTemplate.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<CLTemplate> toCacheModel() {
        return _clTemplate.toCacheModel();
    }

    @Override
    public CLTemplate toEscapedModel() {
        return new CLTemplateWrapper(_clTemplate.toEscapedModel());
    }

    @Override
    public CLTemplate toUnescapedModel() {
        return new CLTemplateWrapper(_clTemplate.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _clTemplate.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _clTemplate.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _clTemplate.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof CLTemplateWrapper)) {
            return false;
        }

        CLTemplateWrapper clTemplateWrapper = (CLTemplateWrapper) obj;

        if (Validator.equals(_clTemplate, clTemplateWrapper._clTemplate)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public CLTemplate getWrappedCLTemplate() {
        return _clTemplate;
    }

    @Override
    public CLTemplate getWrappedModel() {
        return _clTemplate;
    }

    @Override
    public void resetOriginalValues() {
        _clTemplate.resetOriginalValues();
    }
}
