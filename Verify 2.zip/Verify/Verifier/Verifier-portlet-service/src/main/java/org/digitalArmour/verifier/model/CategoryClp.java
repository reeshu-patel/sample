package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import org.digitalArmour.verifier.service.CategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class CategoryClp extends BaseModelImpl<Category> implements Category {
    private String _uuid;
    private long _catId;
    private String _catName;
    private long _subcategoryId;
    private long _checklistId;
    private BaseModel<?> _categoryRemoteModel;

    public CategoryClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return Category.class;
    }

    @Override
    public String getModelClassName() {
        return Category.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _catId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setCatId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _catId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("catId", getCatId());
        attributes.put("catName", getCatName());
        attributes.put("subcategoryId", getSubcategoryId());
        attributes.put("checklistId", getChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }

        String catName = (String) attributes.get("catName");

        if (catName != null) {
            setCatName(catName);
        }

        Long subcategoryId = (Long) attributes.get("subcategoryId");

        if (subcategoryId != null) {
            setSubcategoryId(subcategoryId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_categoryRemoteModel != null) {
            try {
                Class<?> clazz = _categoryRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_categoryRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getCatId() {
        return _catId;
    }

    @Override
    public void setCatId(long catId) {
        _catId = catId;

        if (_categoryRemoteModel != null) {
            try {
                Class<?> clazz = _categoryRemoteModel.getClass();

                Method method = clazz.getMethod("setCatId", long.class);

                method.invoke(_categoryRemoteModel, catId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getCatName() {
        return _catName;
    }

    @Override
    public void setCatName(String catName) {
        _catName = catName;

        if (_categoryRemoteModel != null) {
            try {
                Class<?> clazz = _categoryRemoteModel.getClass();

                Method method = clazz.getMethod("setCatName", String.class);

                method.invoke(_categoryRemoteModel, catName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getSubcategoryId() {
        return _subcategoryId;
    }

    @Override
    public void setSubcategoryId(long subcategoryId) {
        _subcategoryId = subcategoryId;

        if (_categoryRemoteModel != null) {
            try {
                Class<?> clazz = _categoryRemoteModel.getClass();

                Method method = clazz.getMethod("setSubcategoryId", long.class);

                method.invoke(_categoryRemoteModel, subcategoryId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getChecklistId() {
        return _checklistId;
    }

    @Override
    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;

        if (_categoryRemoteModel != null) {
            try {
                Class<?> clazz = _categoryRemoteModel.getClass();

                Method method = clazz.getMethod("setChecklistId", long.class);

                method.invoke(_categoryRemoteModel, checklistId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> getCategoryRemoteModel() {
        return _categoryRemoteModel;
    }

    public void setCategoryRemoteModel(BaseModel<?> categoryRemoteModel) {
        _categoryRemoteModel = categoryRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _categoryRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_categoryRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            CategoryLocalServiceUtil.addCategory(this);
        } else {
            CategoryLocalServiceUtil.updateCategory(this);
        }
    }

    @Override
    public Category toEscapedModel() {
        return (Category) ProxyUtil.newProxyInstance(Category.class.getClassLoader(),
            new Class[] { Category.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        CategoryClp clone = new CategoryClp();

        clone.setUuid(getUuid());
        clone.setCatId(getCatId());
        clone.setCatName(getCatName());
        clone.setSubcategoryId(getSubcategoryId());
        clone.setChecklistId(getChecklistId());

        return clone;
    }

    @Override
    public int compareTo(Category category) {
        int value = 0;

        if (getCatId() < category.getCatId()) {
            value = -1;
        } else if (getCatId() > category.getCatId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof CategoryClp)) {
            return false;
        }

        CategoryClp category = (CategoryClp) obj;

        long primaryKey = category.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(11);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", catId=");
        sb.append(getCatId());
        sb.append(", catName=");
        sb.append(getCatName());
        sb.append(", subcategoryId=");
        sb.append(getSubcategoryId());
        sb.append(", checklistId=");
        sb.append(getChecklistId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(19);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.Category");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>catId</column-name><column-value><![CDATA[");
        sb.append(getCatId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>catName</column-name><column-value><![CDATA[");
        sb.append(getCatName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>subcategoryId</column-name><column-value><![CDATA[");
        sb.append(getSubcategoryId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>checklistId</column-name><column-value><![CDATA[");
        sb.append(getChecklistId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
