package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.CategoryServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.CategoryServiceSoap
 * @generated
 */
public class CategorySoap implements Serializable {
    private String _uuid;
    private long _catId;
    private String _catName;
    private long _subcategoryId;
    private long _checklistId;

    public CategorySoap() {
    }

    public static CategorySoap toSoapModel(Category model) {
        CategorySoap soapModel = new CategorySoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setCatId(model.getCatId());
        soapModel.setCatName(model.getCatName());
        soapModel.setSubcategoryId(model.getSubcategoryId());
        soapModel.setChecklistId(model.getChecklistId());

        return soapModel;
    }

    public static CategorySoap[] toSoapModels(Category[] models) {
        CategorySoap[] soapModels = new CategorySoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static CategorySoap[][] toSoapModels(Category[][] models) {
        CategorySoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new CategorySoap[models.length][models[0].length];
        } else {
            soapModels = new CategorySoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static CategorySoap[] toSoapModels(List<Category> models) {
        List<CategorySoap> soapModels = new ArrayList<CategorySoap>(models.size());

        for (Category model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new CategorySoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _catId;
    }

    public void setPrimaryKey(long pk) {
        setCatId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getCatId() {
        return _catId;
    }

    public void setCatId(long catId) {
        _catId = catId;
    }

    public String getCatName() {
        return _catName;
    }

    public void setCatName(String catName) {
        _catName = catName;
    }

    public long getSubcategoryId() {
        return _subcategoryId;
    }

    public void setSubcategoryId(long subcategoryId) {
        _subcategoryId = subcategoryId;
    }

    public long getChecklistId() {
        return _checklistId;
    }

    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;
    }
}
