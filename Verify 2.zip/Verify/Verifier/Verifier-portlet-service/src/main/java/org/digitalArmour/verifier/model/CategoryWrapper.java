package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Category}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Category
 * @generated
 */
public class CategoryWrapper implements Category, ModelWrapper<Category> {
    private Category _category;

    public CategoryWrapper(Category category) {
        _category = category;
    }

    @Override
    public Class<?> getModelClass() {
        return Category.class;
    }

    @Override
    public String getModelClassName() {
        return Category.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("catId", getCatId());
        attributes.put("catName", getCatName());
        attributes.put("subcategoryId", getSubcategoryId());
        attributes.put("checklistId", getChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }

        String catName = (String) attributes.get("catName");

        if (catName != null) {
            setCatName(catName);
        }

        Long subcategoryId = (Long) attributes.get("subcategoryId");

        if (subcategoryId != null) {
            setSubcategoryId(subcategoryId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }
    }

    /**
    * Returns the primary key of this category.
    *
    * @return the primary key of this category
    */
    @Override
    public long getPrimaryKey() {
        return _category.getPrimaryKey();
    }

    /**
    * Sets the primary key of this category.
    *
    * @param primaryKey the primary key of this category
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _category.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this category.
    *
    * @return the uuid of this category
    */
    @Override
    public java.lang.String getUuid() {
        return _category.getUuid();
    }

    /**
    * Sets the uuid of this category.
    *
    * @param uuid the uuid of this category
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _category.setUuid(uuid);
    }

    /**
    * Returns the cat ID of this category.
    *
    * @return the cat ID of this category
    */
    @Override
    public long getCatId() {
        return _category.getCatId();
    }

    /**
    * Sets the cat ID of this category.
    *
    * @param catId the cat ID of this category
    */
    @Override
    public void setCatId(long catId) {
        _category.setCatId(catId);
    }

    /**
    * Returns the cat name of this category.
    *
    * @return the cat name of this category
    */
    @Override
    public java.lang.String getCatName() {
        return _category.getCatName();
    }

    /**
    * Sets the cat name of this category.
    *
    * @param catName the cat name of this category
    */
    @Override
    public void setCatName(java.lang.String catName) {
        _category.setCatName(catName);
    }

    /**
    * Returns the subcategory ID of this category.
    *
    * @return the subcategory ID of this category
    */
    @Override
    public long getSubcategoryId() {
        return _category.getSubcategoryId();
    }

    /**
    * Sets the subcategory ID of this category.
    *
    * @param subcategoryId the subcategory ID of this category
    */
    @Override
    public void setSubcategoryId(long subcategoryId) {
        _category.setSubcategoryId(subcategoryId);
    }

    /**
    * Returns the checklist ID of this category.
    *
    * @return the checklist ID of this category
    */
    @Override
    public long getChecklistId() {
        return _category.getChecklistId();
    }

    /**
    * Sets the checklist ID of this category.
    *
    * @param checklistId the checklist ID of this category
    */
    @Override
    public void setChecklistId(long checklistId) {
        _category.setChecklistId(checklistId);
    }

    @Override
    public boolean isNew() {
        return _category.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _category.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _category.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _category.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _category.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _category.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _category.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _category.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _category.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _category.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _category.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new CategoryWrapper((Category) _category.clone());
    }

    @Override
    public int compareTo(Category category) {
        return _category.compareTo(category);
    }

    @Override
    public int hashCode() {
        return _category.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<Category> toCacheModel() {
        return _category.toCacheModel();
    }

    @Override
    public Category toEscapedModel() {
        return new CategoryWrapper(_category.toEscapedModel());
    }

    @Override
    public Category toUnescapedModel() {
        return new CategoryWrapper(_category.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _category.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _category.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _category.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof CategoryWrapper)) {
            return false;
        }

        CategoryWrapper categoryWrapper = (CategoryWrapper) obj;

        if (Validator.equals(_category, categoryWrapper._category)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Category getWrappedCategory() {
        return _category;
    }

    @Override
    public Category getWrappedModel() {
        return _category;
    }

    @Override
    public void resetOriginalValues() {
        _category.resetOriginalValues();
    }
}
