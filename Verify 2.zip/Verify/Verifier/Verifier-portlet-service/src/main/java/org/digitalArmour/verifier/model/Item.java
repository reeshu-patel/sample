package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the Item service. Represents a row in the &quot;Verifier_Item&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ItemModel
 * @see org.digitalArmour.verifier.model.impl.ItemImpl
 * @see org.digitalArmour.verifier.model.impl.ItemModelImpl
 * @generated
 */
public interface Item extends ItemModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ItemImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
