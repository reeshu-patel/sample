package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class ItemClp extends BaseModelImpl<Item> implements Item {
    private String _uuid;
    private long _itemId;
    private String _itemName;
    private String _itemDesc;
    private boolean _minor;
    private long _minor_percent;
    private boolean _major;
    private long _major_percent;
    private long _userGroupId;
    private long _catId;
    private long _checklistId;
    private BaseModel<?> _itemRemoteModel;

    public ItemClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return Item.class;
    }

    @Override
    public String getModelClassName() {
        return Item.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _itemId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setItemId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _itemId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("itemId", getItemId());
        attributes.put("itemName", getItemName());
        attributes.put("itemDesc", getItemDesc());
        attributes.put("minor", getMinor());
        attributes.put("minor_percent", getMinor_percent());
        attributes.put("major", getMajor());
        attributes.put("major_percent", getMajor_percent());
        attributes.put("userGroupId", getUserGroupId());
        attributes.put("catId", getCatId());
        attributes.put("checklistId", getChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        String itemName = (String) attributes.get("itemName");

        if (itemName != null) {
            setItemName(itemName);
        }

        String itemDesc = (String) attributes.get("itemDesc");

        if (itemDesc != null) {
            setItemDesc(itemDesc);
        }

        Boolean minor = (Boolean) attributes.get("minor");

        if (minor != null) {
            setMinor(minor);
        }

        Long minor_percent = (Long) attributes.get("minor_percent");

        if (minor_percent != null) {
            setMinor_percent(minor_percent);
        }

        Boolean major = (Boolean) attributes.get("major");

        if (major != null) {
            setMajor(major);
        }

        Long major_percent = (Long) attributes.get("major_percent");

        if (major_percent != null) {
            setMajor_percent(major_percent);
        }

        Long userGroupId = (Long) attributes.get("userGroupId");

        if (userGroupId != null) {
            setUserGroupId(userGroupId);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_itemRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getItemId() {
        return _itemId;
    }

    @Override
    public void setItemId(long itemId) {
        _itemId = itemId;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setItemId", long.class);

                method.invoke(_itemRemoteModel, itemId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getItemName() {
        return _itemName;
    }

    @Override
    public void setItemName(String itemName) {
        _itemName = itemName;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setItemName", String.class);

                method.invoke(_itemRemoteModel, itemName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getItemDesc() {
        return _itemDesc;
    }

    @Override
    public void setItemDesc(String itemDesc) {
        _itemDesc = itemDesc;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setItemDesc", String.class);

                method.invoke(_itemRemoteModel, itemDesc);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getMinor() {
        return _minor;
    }

    @Override
    public boolean isMinor() {
        return _minor;
    }

    @Override
    public void setMinor(boolean minor) {
        _minor = minor;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setMinor", boolean.class);

                method.invoke(_itemRemoteModel, minor);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getMinor_percent() {
        return _minor_percent;
    }

    @Override
    public void setMinor_percent(long minor_percent) {
        _minor_percent = minor_percent;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setMinor_percent", long.class);

                method.invoke(_itemRemoteModel, minor_percent);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getMajor() {
        return _major;
    }

    @Override
    public boolean isMajor() {
        return _major;
    }

    @Override
    public void setMajor(boolean major) {
        _major = major;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setMajor", boolean.class);

                method.invoke(_itemRemoteModel, major);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getMajor_percent() {
        return _major_percent;
    }

    @Override
    public void setMajor_percent(long major_percent) {
        _major_percent = major_percent;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setMajor_percent", long.class);

                method.invoke(_itemRemoteModel, major_percent);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserGroupId() {
        return _userGroupId;
    }

    @Override
    public void setUserGroupId(long userGroupId) {
        _userGroupId = userGroupId;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setUserGroupId", long.class);

                method.invoke(_itemRemoteModel, userGroupId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getCatId() {
        return _catId;
    }

    @Override
    public void setCatId(long catId) {
        _catId = catId;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setCatId", long.class);

                method.invoke(_itemRemoteModel, catId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getChecklistId() {
        return _checklistId;
    }

    @Override
    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;

        if (_itemRemoteModel != null) {
            try {
                Class<?> clazz = _itemRemoteModel.getClass();

                Method method = clazz.getMethod("setChecklistId", long.class);

                method.invoke(_itemRemoteModel, checklistId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> getItemRemoteModel() {
        return _itemRemoteModel;
    }

    public void setItemRemoteModel(BaseModel<?> itemRemoteModel) {
        _itemRemoteModel = itemRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _itemRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_itemRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ItemLocalServiceUtil.addItem(this);
        } else {
            ItemLocalServiceUtil.updateItem(this);
        }
    }

    @Override
    public Item toEscapedModel() {
        return (Item) ProxyUtil.newProxyInstance(Item.class.getClassLoader(),
            new Class[] { Item.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ItemClp clone = new ItemClp();

        clone.setUuid(getUuid());
        clone.setItemId(getItemId());
        clone.setItemName(getItemName());
        clone.setItemDesc(getItemDesc());
        clone.setMinor(getMinor());
        clone.setMinor_percent(getMinor_percent());
        clone.setMajor(getMajor());
        clone.setMajor_percent(getMajor_percent());
        clone.setUserGroupId(getUserGroupId());
        clone.setCatId(getCatId());
        clone.setChecklistId(getChecklistId());

        return clone;
    }

    @Override
    public int compareTo(Item item) {
        int value = 0;

        if (getItemId() < item.getItemId()) {
            value = -1;
        } else if (getItemId() > item.getItemId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemClp)) {
            return false;
        }

        ItemClp item = (ItemClp) obj;

        long primaryKey = item.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(23);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", itemId=");
        sb.append(getItemId());
        sb.append(", itemName=");
        sb.append(getItemName());
        sb.append(", itemDesc=");
        sb.append(getItemDesc());
        sb.append(", minor=");
        sb.append(getMinor());
        sb.append(", minor_percent=");
        sb.append(getMinor_percent());
        sb.append(", major=");
        sb.append(getMajor());
        sb.append(", major_percent=");
        sb.append(getMajor_percent());
        sb.append(", userGroupId=");
        sb.append(getUserGroupId());
        sb.append(", catId=");
        sb.append(getCatId());
        sb.append(", checklistId=");
        sb.append(getChecklistId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(37);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.Item");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemId</column-name><column-value><![CDATA[");
        sb.append(getItemId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemName</column-name><column-value><![CDATA[");
        sb.append(getItemName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemDesc</column-name><column-value><![CDATA[");
        sb.append(getItemDesc());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>minor</column-name><column-value><![CDATA[");
        sb.append(getMinor());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>minor_percent</column-name><column-value><![CDATA[");
        sb.append(getMinor_percent());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>major</column-name><column-value><![CDATA[");
        sb.append(getMajor());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>major_percent</column-name><column-value><![CDATA[");
        sb.append(getMajor_percent());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userGroupId</column-name><column-value><![CDATA[");
        sb.append(getUserGroupId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>catId</column-name><column-value><![CDATA[");
        sb.append(getCatId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>checklistId</column-name><column-value><![CDATA[");
        sb.append(getChecklistId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
