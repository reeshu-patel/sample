package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the ItemComment service. Represents a row in the &quot;Verifier_ItemComment&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ItemCommentModel
 * @see org.digitalArmour.verifier.model.impl.ItemCommentImpl
 * @see org.digitalArmour.verifier.model.impl.ItemCommentModelImpl
 * @generated
 */
public interface ItemComment extends ItemCommentModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ItemCommentImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
