package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ItemCommentClp extends BaseModelImpl<ItemComment>
    implements ItemComment {
    private String _uuid;
    private long _commId;
    private String _comment;
    private Date _createTime;
    private long _itemId;
    private long _userId;
    private String _userUuid;
    private BaseModel<?> _itemCommentRemoteModel;

    public ItemCommentClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ItemComment.class;
    }

    @Override
    public String getModelClassName() {
        return ItemComment.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _commId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setCommId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _commId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("commId", getCommId());
        attributes.put("comment", getComment());
        attributes.put("createTime", getCreateTime());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long commId = (Long) attributes.get("commId");

        if (commId != null) {
            setCommId(commId);
        }

        String comment = (String) attributes.get("comment");

        if (comment != null) {
            setComment(comment);
        }

        Date createTime = (Date) attributes.get("createTime");

        if (createTime != null) {
            setCreateTime(createTime);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_itemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _itemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_itemCommentRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getCommId() {
        return _commId;
    }

    @Override
    public void setCommId(long commId) {
        _commId = commId;

        if (_itemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _itemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setCommId", long.class);

                method.invoke(_itemCommentRemoteModel, commId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getComment() {
        return _comment;
    }

    @Override
    public void setComment(String comment) {
        _comment = comment;

        if (_itemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _itemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setComment", String.class);

                method.invoke(_itemCommentRemoteModel, comment);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public Date getCreateTime() {
        return _createTime;
    }

    @Override
    public void setCreateTime(Date createTime) {
        _createTime = createTime;

        if (_itemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _itemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setCreateTime", Date.class);

                method.invoke(_itemCommentRemoteModel, createTime);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getItemId() {
        return _itemId;
    }

    @Override
    public void setItemId(long itemId) {
        _itemId = itemId;

        if (_itemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _itemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setItemId", long.class);

                method.invoke(_itemCommentRemoteModel, itemId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_itemCommentRemoteModel != null) {
            try {
                Class<?> clazz = _itemCommentRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_itemCommentRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    public BaseModel<?> getItemCommentRemoteModel() {
        return _itemCommentRemoteModel;
    }

    public void setItemCommentRemoteModel(BaseModel<?> itemCommentRemoteModel) {
        _itemCommentRemoteModel = itemCommentRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _itemCommentRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_itemCommentRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ItemCommentLocalServiceUtil.addItemComment(this);
        } else {
            ItemCommentLocalServiceUtil.updateItemComment(this);
        }
    }

    @Override
    public ItemComment toEscapedModel() {
        return (ItemComment) ProxyUtil.newProxyInstance(ItemComment.class.getClassLoader(),
            new Class[] { ItemComment.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ItemCommentClp clone = new ItemCommentClp();

        clone.setUuid(getUuid());
        clone.setCommId(getCommId());
        clone.setComment(getComment());
        clone.setCreateTime(getCreateTime());
        clone.setItemId(getItemId());
        clone.setUserId(getUserId());

        return clone;
    }

    @Override
    public int compareTo(ItemComment itemComment) {
        int value = 0;

        if (getCommId() < itemComment.getCommId()) {
            value = -1;
        } else if (getCommId() > itemComment.getCommId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemCommentClp)) {
            return false;
        }

        ItemCommentClp itemComment = (ItemCommentClp) obj;

        long primaryKey = itemComment.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", commId=");
        sb.append(getCommId());
        sb.append(", comment=");
        sb.append(getComment());
        sb.append(", createTime=");
        sb.append(getCreateTime());
        sb.append(", itemId=");
        sb.append(getItemId());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(22);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ItemComment");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>commId</column-name><column-value><![CDATA[");
        sb.append(getCommId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>comment</column-name><column-value><![CDATA[");
        sb.append(getComment());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>createTime</column-name><column-value><![CDATA[");
        sb.append(getCreateTime());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemId</column-name><column-value><![CDATA[");
        sb.append(getItemId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
