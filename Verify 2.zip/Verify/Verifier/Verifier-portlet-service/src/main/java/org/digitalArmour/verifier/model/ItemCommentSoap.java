package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ItemCommentServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ItemCommentServiceSoap
 * @generated
 */
public class ItemCommentSoap implements Serializable {
    private String _uuid;
    private long _commId;
    private String _comment;
    private Date _createTime;
    private long _itemId;
    private long _userId;

    public ItemCommentSoap() {
    }

    public static ItemCommentSoap toSoapModel(ItemComment model) {
        ItemCommentSoap soapModel = new ItemCommentSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setCommId(model.getCommId());
        soapModel.setComment(model.getComment());
        soapModel.setCreateTime(model.getCreateTime());
        soapModel.setItemId(model.getItemId());
        soapModel.setUserId(model.getUserId());

        return soapModel;
    }

    public static ItemCommentSoap[] toSoapModels(ItemComment[] models) {
        ItemCommentSoap[] soapModels = new ItemCommentSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ItemCommentSoap[][] toSoapModels(ItemComment[][] models) {
        ItemCommentSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ItemCommentSoap[models.length][models[0].length];
        } else {
            soapModels = new ItemCommentSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ItemCommentSoap[] toSoapModels(List<ItemComment> models) {
        List<ItemCommentSoap> soapModels = new ArrayList<ItemCommentSoap>(models.size());

        for (ItemComment model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ItemCommentSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _commId;
    }

    public void setPrimaryKey(long pk) {
        setCommId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getCommId() {
        return _commId;
    }

    public void setCommId(long commId) {
        _commId = commId;
    }

    public String getComment() {
        return _comment;
    }

    public void setComment(String comment) {
        _comment = comment;
    }

    public Date getCreateTime() {
        return _createTime;
    }

    public void setCreateTime(Date createTime) {
        _createTime = createTime;
    }

    public long getItemId() {
        return _itemId;
    }

    public void setItemId(long itemId) {
        _itemId = itemId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }
}
