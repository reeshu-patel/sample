package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ItemComment}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ItemComment
 * @generated
 */
public class ItemCommentWrapper implements ItemComment,
    ModelWrapper<ItemComment> {
    private ItemComment _itemComment;

    public ItemCommentWrapper(ItemComment itemComment) {
        _itemComment = itemComment;
    }

    @Override
    public Class<?> getModelClass() {
        return ItemComment.class;
    }

    @Override
    public String getModelClassName() {
        return ItemComment.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("commId", getCommId());
        attributes.put("comment", getComment());
        attributes.put("createTime", getCreateTime());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long commId = (Long) attributes.get("commId");

        if (commId != null) {
            setCommId(commId);
        }

        String comment = (String) attributes.get("comment");

        if (comment != null) {
            setComment(comment);
        }

        Date createTime = (Date) attributes.get("createTime");

        if (createTime != null) {
            setCreateTime(createTime);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    /**
    * Returns the primary key of this item comment.
    *
    * @return the primary key of this item comment
    */
    @Override
    public long getPrimaryKey() {
        return _itemComment.getPrimaryKey();
    }

    /**
    * Sets the primary key of this item comment.
    *
    * @param primaryKey the primary key of this item comment
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _itemComment.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this item comment.
    *
    * @return the uuid of this item comment
    */
    @Override
    public java.lang.String getUuid() {
        return _itemComment.getUuid();
    }

    /**
    * Sets the uuid of this item comment.
    *
    * @param uuid the uuid of this item comment
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _itemComment.setUuid(uuid);
    }

    /**
    * Returns the comm ID of this item comment.
    *
    * @return the comm ID of this item comment
    */
    @Override
    public long getCommId() {
        return _itemComment.getCommId();
    }

    /**
    * Sets the comm ID of this item comment.
    *
    * @param commId the comm ID of this item comment
    */
    @Override
    public void setCommId(long commId) {
        _itemComment.setCommId(commId);
    }

    /**
    * Returns the comment of this item comment.
    *
    * @return the comment of this item comment
    */
    @Override
    public java.lang.String getComment() {
        return _itemComment.getComment();
    }

    /**
    * Sets the comment of this item comment.
    *
    * @param comment the comment of this item comment
    */
    @Override
    public void setComment(java.lang.String comment) {
        _itemComment.setComment(comment);
    }

    /**
    * Returns the create time of this item comment.
    *
    * @return the create time of this item comment
    */
    @Override
    public java.util.Date getCreateTime() {
        return _itemComment.getCreateTime();
    }

    /**
    * Sets the create time of this item comment.
    *
    * @param createTime the create time of this item comment
    */
    @Override
    public void setCreateTime(java.util.Date createTime) {
        _itemComment.setCreateTime(createTime);
    }

    /**
    * Returns the item ID of this item comment.
    *
    * @return the item ID of this item comment
    */
    @Override
    public long getItemId() {
        return _itemComment.getItemId();
    }

    /**
    * Sets the item ID of this item comment.
    *
    * @param itemId the item ID of this item comment
    */
    @Override
    public void setItemId(long itemId) {
        _itemComment.setItemId(itemId);
    }

    /**
    * Returns the user ID of this item comment.
    *
    * @return the user ID of this item comment
    */
    @Override
    public long getUserId() {
        return _itemComment.getUserId();
    }

    /**
    * Sets the user ID of this item comment.
    *
    * @param userId the user ID of this item comment
    */
    @Override
    public void setUserId(long userId) {
        _itemComment.setUserId(userId);
    }

    /**
    * Returns the user uuid of this item comment.
    *
    * @return the user uuid of this item comment
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _itemComment.getUserUuid();
    }

    /**
    * Sets the user uuid of this item comment.
    *
    * @param userUuid the user uuid of this item comment
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _itemComment.setUserUuid(userUuid);
    }

    @Override
    public boolean isNew() {
        return _itemComment.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _itemComment.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _itemComment.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _itemComment.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _itemComment.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _itemComment.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _itemComment.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _itemComment.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _itemComment.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _itemComment.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _itemComment.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ItemCommentWrapper((ItemComment) _itemComment.clone());
    }

    @Override
    public int compareTo(ItemComment itemComment) {
        return _itemComment.compareTo(itemComment);
    }

    @Override
    public int hashCode() {
        return _itemComment.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ItemComment> toCacheModel() {
        return _itemComment.toCacheModel();
    }

    @Override
    public ItemComment toEscapedModel() {
        return new ItemCommentWrapper(_itemComment.toEscapedModel());
    }

    @Override
    public ItemComment toUnescapedModel() {
        return new ItemCommentWrapper(_itemComment.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _itemComment.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _itemComment.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _itemComment.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemCommentWrapper)) {
            return false;
        }

        ItemCommentWrapper itemCommentWrapper = (ItemCommentWrapper) obj;

        if (Validator.equals(_itemComment, itemCommentWrapper._itemComment)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ItemComment getWrappedItemComment() {
        return _itemComment;
    }

    @Override
    public ItemComment getWrappedModel() {
        return _itemComment;
    }

    @Override
    public void resetOriginalValues() {
        _itemComment.resetOriginalValues();
    }
}
