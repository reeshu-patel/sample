package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.ItemFileLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ItemFileClp extends BaseModelImpl<ItemFile> implements ItemFile {
    private String _uuid;
    private long _fileId;
    private String _fileName;
    private String _filePath;
    private Date _createTime;
    private long _itemId;
    private long _userId;
    private String _userUuid;
    private BaseModel<?> _itemFileRemoteModel;

    public ItemFileClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ItemFile.class;
    }

    @Override
    public String getModelClassName() {
        return ItemFile.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _fileId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setFileId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _fileId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("fileId", getFileId());
        attributes.put("fileName", getFileName());
        attributes.put("filePath", getFilePath());
        attributes.put("createTime", getCreateTime());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long fileId = (Long) attributes.get("fileId");

        if (fileId != null) {
            setFileId(fileId);
        }

        String fileName = (String) attributes.get("fileName");

        if (fileName != null) {
            setFileName(fileName);
        }

        String filePath = (String) attributes.get("filePath");

        if (filePath != null) {
            setFilePath(filePath);
        }

        Date createTime = (Date) attributes.get("createTime");

        if (createTime != null) {
            setCreateTime(createTime);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_itemFileRemoteModel != null) {
            try {
                Class<?> clazz = _itemFileRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_itemFileRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getFileId() {
        return _fileId;
    }

    @Override
    public void setFileId(long fileId) {
        _fileId = fileId;

        if (_itemFileRemoteModel != null) {
            try {
                Class<?> clazz = _itemFileRemoteModel.getClass();

                Method method = clazz.getMethod("setFileId", long.class);

                method.invoke(_itemFileRemoteModel, fileId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getFileName() {
        return _fileName;
    }

    @Override
    public void setFileName(String fileName) {
        _fileName = fileName;

        if (_itemFileRemoteModel != null) {
            try {
                Class<?> clazz = _itemFileRemoteModel.getClass();

                Method method = clazz.getMethod("setFileName", String.class);

                method.invoke(_itemFileRemoteModel, fileName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getFilePath() {
        return _filePath;
    }

    @Override
    public void setFilePath(String filePath) {
        _filePath = filePath;

        if (_itemFileRemoteModel != null) {
            try {
                Class<?> clazz = _itemFileRemoteModel.getClass();

                Method method = clazz.getMethod("setFilePath", String.class);

                method.invoke(_itemFileRemoteModel, filePath);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public Date getCreateTime() {
        return _createTime;
    }

    @Override
    public void setCreateTime(Date createTime) {
        _createTime = createTime;

        if (_itemFileRemoteModel != null) {
            try {
                Class<?> clazz = _itemFileRemoteModel.getClass();

                Method method = clazz.getMethod("setCreateTime", Date.class);

                method.invoke(_itemFileRemoteModel, createTime);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getItemId() {
        return _itemId;
    }

    @Override
    public void setItemId(long itemId) {
        _itemId = itemId;

        if (_itemFileRemoteModel != null) {
            try {
                Class<?> clazz = _itemFileRemoteModel.getClass();

                Method method = clazz.getMethod("setItemId", long.class);

                method.invoke(_itemFileRemoteModel, itemId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_itemFileRemoteModel != null) {
            try {
                Class<?> clazz = _itemFileRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_itemFileRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    public BaseModel<?> getItemFileRemoteModel() {
        return _itemFileRemoteModel;
    }

    public void setItemFileRemoteModel(BaseModel<?> itemFileRemoteModel) {
        _itemFileRemoteModel = itemFileRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _itemFileRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_itemFileRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ItemFileLocalServiceUtil.addItemFile(this);
        } else {
            ItemFileLocalServiceUtil.updateItemFile(this);
        }
    }

    @Override
    public ItemFile toEscapedModel() {
        return (ItemFile) ProxyUtil.newProxyInstance(ItemFile.class.getClassLoader(),
            new Class[] { ItemFile.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ItemFileClp clone = new ItemFileClp();

        clone.setUuid(getUuid());
        clone.setFileId(getFileId());
        clone.setFileName(getFileName());
        clone.setFilePath(getFilePath());
        clone.setCreateTime(getCreateTime());
        clone.setItemId(getItemId());
        clone.setUserId(getUserId());

        return clone;
    }

    @Override
    public int compareTo(ItemFile itemFile) {
        int value = 0;

        if (getFileId() < itemFile.getFileId()) {
            value = -1;
        } else if (getFileId() > itemFile.getFileId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemFileClp)) {
            return false;
        }

        ItemFileClp itemFile = (ItemFileClp) obj;

        long primaryKey = itemFile.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(15);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", fileId=");
        sb.append(getFileId());
        sb.append(", fileName=");
        sb.append(getFileName());
        sb.append(", filePath=");
        sb.append(getFilePath());
        sb.append(", createTime=");
        sb.append(getCreateTime());
        sb.append(", itemId=");
        sb.append(getItemId());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(25);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ItemFile");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>fileId</column-name><column-value><![CDATA[");
        sb.append(getFileId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>fileName</column-name><column-value><![CDATA[");
        sb.append(getFileName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>filePath</column-name><column-value><![CDATA[");
        sb.append(getFilePath());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>createTime</column-name><column-value><![CDATA[");
        sb.append(getCreateTime());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemId</column-name><column-value><![CDATA[");
        sb.append(getItemId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
