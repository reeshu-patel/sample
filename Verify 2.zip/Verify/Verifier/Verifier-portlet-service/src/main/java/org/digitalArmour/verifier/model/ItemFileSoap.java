package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ItemFileServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ItemFileServiceSoap
 * @generated
 */
public class ItemFileSoap implements Serializable {
    private String _uuid;
    private long _fileId;
    private String _fileName;
    private String _filePath;
    private Date _createTime;
    private long _itemId;
    private long _userId;

    public ItemFileSoap() {
    }

    public static ItemFileSoap toSoapModel(ItemFile model) {
        ItemFileSoap soapModel = new ItemFileSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setFileId(model.getFileId());
        soapModel.setFileName(model.getFileName());
        soapModel.setFilePath(model.getFilePath());
        soapModel.setCreateTime(model.getCreateTime());
        soapModel.setItemId(model.getItemId());
        soapModel.setUserId(model.getUserId());

        return soapModel;
    }

    public static ItemFileSoap[] toSoapModels(ItemFile[] models) {
        ItemFileSoap[] soapModels = new ItemFileSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ItemFileSoap[][] toSoapModels(ItemFile[][] models) {
        ItemFileSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ItemFileSoap[models.length][models[0].length];
        } else {
            soapModels = new ItemFileSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ItemFileSoap[] toSoapModels(List<ItemFile> models) {
        List<ItemFileSoap> soapModels = new ArrayList<ItemFileSoap>(models.size());

        for (ItemFile model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ItemFileSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _fileId;
    }

    public void setPrimaryKey(long pk) {
        setFileId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getFileId() {
        return _fileId;
    }

    public void setFileId(long fileId) {
        _fileId = fileId;
    }

    public String getFileName() {
        return _fileName;
    }

    public void setFileName(String fileName) {
        _fileName = fileName;
    }

    public String getFilePath() {
        return _filePath;
    }

    public void setFilePath(String filePath) {
        _filePath = filePath;
    }

    public Date getCreateTime() {
        return _createTime;
    }

    public void setCreateTime(Date createTime) {
        _createTime = createTime;
    }

    public long getItemId() {
        return _itemId;
    }

    public void setItemId(long itemId) {
        _itemId = itemId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }
}
