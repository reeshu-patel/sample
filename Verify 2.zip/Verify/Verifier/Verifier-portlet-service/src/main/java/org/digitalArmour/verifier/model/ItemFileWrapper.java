package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ItemFile}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ItemFile
 * @generated
 */
public class ItemFileWrapper implements ItemFile, ModelWrapper<ItemFile> {
    private ItemFile _itemFile;

    public ItemFileWrapper(ItemFile itemFile) {
        _itemFile = itemFile;
    }

    @Override
    public Class<?> getModelClass() {
        return ItemFile.class;
    }

    @Override
    public String getModelClassName() {
        return ItemFile.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("fileId", getFileId());
        attributes.put("fileName", getFileName());
        attributes.put("filePath", getFilePath());
        attributes.put("createTime", getCreateTime());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long fileId = (Long) attributes.get("fileId");

        if (fileId != null) {
            setFileId(fileId);
        }

        String fileName = (String) attributes.get("fileName");

        if (fileName != null) {
            setFileName(fileName);
        }

        String filePath = (String) attributes.get("filePath");

        if (filePath != null) {
            setFilePath(filePath);
        }

        Date createTime = (Date) attributes.get("createTime");

        if (createTime != null) {
            setCreateTime(createTime);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    /**
    * Returns the primary key of this item file.
    *
    * @return the primary key of this item file
    */
    @Override
    public long getPrimaryKey() {
        return _itemFile.getPrimaryKey();
    }

    /**
    * Sets the primary key of this item file.
    *
    * @param primaryKey the primary key of this item file
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _itemFile.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this item file.
    *
    * @return the uuid of this item file
    */
    @Override
    public java.lang.String getUuid() {
        return _itemFile.getUuid();
    }

    /**
    * Sets the uuid of this item file.
    *
    * @param uuid the uuid of this item file
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _itemFile.setUuid(uuid);
    }

    /**
    * Returns the file ID of this item file.
    *
    * @return the file ID of this item file
    */
    @Override
    public long getFileId() {
        return _itemFile.getFileId();
    }

    /**
    * Sets the file ID of this item file.
    *
    * @param fileId the file ID of this item file
    */
    @Override
    public void setFileId(long fileId) {
        _itemFile.setFileId(fileId);
    }

    /**
    * Returns the file name of this item file.
    *
    * @return the file name of this item file
    */
    @Override
    public java.lang.String getFileName() {
        return _itemFile.getFileName();
    }

    /**
    * Sets the file name of this item file.
    *
    * @param fileName the file name of this item file
    */
    @Override
    public void setFileName(java.lang.String fileName) {
        _itemFile.setFileName(fileName);
    }

    /**
    * Returns the file path of this item file.
    *
    * @return the file path of this item file
    */
    @Override
    public java.lang.String getFilePath() {
        return _itemFile.getFilePath();
    }

    /**
    * Sets the file path of this item file.
    *
    * @param filePath the file path of this item file
    */
    @Override
    public void setFilePath(java.lang.String filePath) {
        _itemFile.setFilePath(filePath);
    }

    /**
    * Returns the create time of this item file.
    *
    * @return the create time of this item file
    */
    @Override
    public java.util.Date getCreateTime() {
        return _itemFile.getCreateTime();
    }

    /**
    * Sets the create time of this item file.
    *
    * @param createTime the create time of this item file
    */
    @Override
    public void setCreateTime(java.util.Date createTime) {
        _itemFile.setCreateTime(createTime);
    }

    /**
    * Returns the item ID of this item file.
    *
    * @return the item ID of this item file
    */
    @Override
    public long getItemId() {
        return _itemFile.getItemId();
    }

    /**
    * Sets the item ID of this item file.
    *
    * @param itemId the item ID of this item file
    */
    @Override
    public void setItemId(long itemId) {
        _itemFile.setItemId(itemId);
    }

    /**
    * Returns the user ID of this item file.
    *
    * @return the user ID of this item file
    */
    @Override
    public long getUserId() {
        return _itemFile.getUserId();
    }

    /**
    * Sets the user ID of this item file.
    *
    * @param userId the user ID of this item file
    */
    @Override
    public void setUserId(long userId) {
        _itemFile.setUserId(userId);
    }

    /**
    * Returns the user uuid of this item file.
    *
    * @return the user uuid of this item file
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _itemFile.getUserUuid();
    }

    /**
    * Sets the user uuid of this item file.
    *
    * @param userUuid the user uuid of this item file
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _itemFile.setUserUuid(userUuid);
    }

    @Override
    public boolean isNew() {
        return _itemFile.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _itemFile.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _itemFile.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _itemFile.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _itemFile.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _itemFile.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _itemFile.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _itemFile.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _itemFile.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _itemFile.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _itemFile.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ItemFileWrapper((ItemFile) _itemFile.clone());
    }

    @Override
    public int compareTo(ItemFile itemFile) {
        return _itemFile.compareTo(itemFile);
    }

    @Override
    public int hashCode() {
        return _itemFile.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ItemFile> toCacheModel() {
        return _itemFile.toCacheModel();
    }

    @Override
    public ItemFile toEscapedModel() {
        return new ItemFileWrapper(_itemFile.toEscapedModel());
    }

    @Override
    public ItemFile toUnescapedModel() {
        return new ItemFileWrapper(_itemFile.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _itemFile.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _itemFile.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _itemFile.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemFileWrapper)) {
            return false;
        }

        ItemFileWrapper itemFileWrapper = (ItemFileWrapper) obj;

        if (Validator.equals(_itemFile, itemFileWrapper._itemFile)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ItemFile getWrappedItemFile() {
        return _itemFile;
    }

    @Override
    public ItemFile getWrappedModel() {
        return _itemFile;
    }

    @Override
    public void resetOriginalValues() {
        _itemFile.resetOriginalValues();
    }
}
