package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.ItemServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.ItemServiceSoap
 * @generated
 */
public class ItemSoap implements Serializable {
    private String _uuid;
    private long _itemId;
    private String _itemName;
    private String _itemDesc;
    private boolean _minor;
    private long _minor_percent;
    private boolean _major;
    private long _major_percent;
    private long _userGroupId;
    private long _catId;
    private long _checklistId;

    public ItemSoap() {
    }

    public static ItemSoap toSoapModel(Item model) {
        ItemSoap soapModel = new ItemSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setItemId(model.getItemId());
        soapModel.setItemName(model.getItemName());
        soapModel.setItemDesc(model.getItemDesc());
        soapModel.setMinor(model.getMinor());
        soapModel.setMinor_percent(model.getMinor_percent());
        soapModel.setMajor(model.getMajor());
        soapModel.setMajor_percent(model.getMajor_percent());
        soapModel.setUserGroupId(model.getUserGroupId());
        soapModel.setCatId(model.getCatId());
        soapModel.setChecklistId(model.getChecklistId());

        return soapModel;
    }

    public static ItemSoap[] toSoapModels(Item[] models) {
        ItemSoap[] soapModels = new ItemSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static ItemSoap[][] toSoapModels(Item[][] models) {
        ItemSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new ItemSoap[models.length][models[0].length];
        } else {
            soapModels = new ItemSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static ItemSoap[] toSoapModels(List<Item> models) {
        List<ItemSoap> soapModels = new ArrayList<ItemSoap>(models.size());

        for (Item model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new ItemSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _itemId;
    }

    public void setPrimaryKey(long pk) {
        setItemId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getItemId() {
        return _itemId;
    }

    public void setItemId(long itemId) {
        _itemId = itemId;
    }

    public String getItemName() {
        return _itemName;
    }

    public void setItemName(String itemName) {
        _itemName = itemName;
    }

    public String getItemDesc() {
        return _itemDesc;
    }

    public void setItemDesc(String itemDesc) {
        _itemDesc = itemDesc;
    }

    public boolean getMinor() {
        return _minor;
    }

    public boolean isMinor() {
        return _minor;
    }

    public void setMinor(boolean minor) {
        _minor = minor;
    }

    public long getMinor_percent() {
        return _minor_percent;
    }

    public void setMinor_percent(long minor_percent) {
        _minor_percent = minor_percent;
    }

    public boolean getMajor() {
        return _major;
    }

    public boolean isMajor() {
        return _major;
    }

    public void setMajor(boolean major) {
        _major = major;
    }

    public long getMajor_percent() {
        return _major_percent;
    }

    public void setMajor_percent(long major_percent) {
        _major_percent = major_percent;
    }

    public long getUserGroupId() {
        return _userGroupId;
    }

    public void setUserGroupId(long userGroupId) {
        _userGroupId = userGroupId;
    }

    public long getCatId() {
        return _catId;
    }

    public void setCatId(long catId) {
        _catId = catId;
    }

    public long getChecklistId() {
        return _checklistId;
    }

    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;
    }
}
