package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the ItemUser service. Represents a row in the &quot;Verifier_ItemUser&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see ItemUserModel
 * @see org.digitalArmour.verifier.model.impl.ItemUserImpl
 * @see org.digitalArmour.verifier.model.impl.ItemUserModelImpl
 * @generated
 */
public interface ItemUser extends ItemUserModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.ItemUserImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
