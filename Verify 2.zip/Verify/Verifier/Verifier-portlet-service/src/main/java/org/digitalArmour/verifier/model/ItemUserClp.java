package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.ItemUserLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ItemUserClp extends BaseModelImpl<ItemUser> implements ItemUser {
    private String _uuid;
    private long _itemUserId;
    private String _itemUserUuid;
    private Date _createDate;
    private Date _dueDate;
    private long _itemId;
    private long _userId;
    private String _userUuid;
    private BaseModel<?> _itemUserRemoteModel;

    public ItemUserClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return ItemUser.class;
    }

    @Override
    public String getModelClassName() {
        return ItemUser.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _itemUserId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setItemUserId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _itemUserId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("itemUserId", getItemUserId());
        attributes.put("createDate", getCreateDate());
        attributes.put("dueDate", getDueDate());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long itemUserId = (Long) attributes.get("itemUserId");

        if (itemUserId != null) {
            setItemUserId(itemUserId);
        }

        Date createDate = (Date) attributes.get("createDate");

        if (createDate != null) {
            setCreateDate(createDate);
        }

        Date dueDate = (Date) attributes.get("dueDate");

        if (dueDate != null) {
            setDueDate(dueDate);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_itemUserRemoteModel != null) {
            try {
                Class<?> clazz = _itemUserRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_itemUserRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getItemUserId() {
        return _itemUserId;
    }

    @Override
    public void setItemUserId(long itemUserId) {
        _itemUserId = itemUserId;

        if (_itemUserRemoteModel != null) {
            try {
                Class<?> clazz = _itemUserRemoteModel.getClass();

                Method method = clazz.getMethod("setItemUserId", long.class);

                method.invoke(_itemUserRemoteModel, itemUserId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getItemUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getItemUserId(), "uuid", _itemUserUuid);
    }

    @Override
    public void setItemUserUuid(String itemUserUuid) {
        _itemUserUuid = itemUserUuid;
    }

    @Override
    public Date getCreateDate() {
        return _createDate;
    }

    @Override
    public void setCreateDate(Date createDate) {
        _createDate = createDate;

        if (_itemUserRemoteModel != null) {
            try {
                Class<?> clazz = _itemUserRemoteModel.getClass();

                Method method = clazz.getMethod("setCreateDate", Date.class);

                method.invoke(_itemUserRemoteModel, createDate);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public Date getDueDate() {
        return _dueDate;
    }

    @Override
    public void setDueDate(Date dueDate) {
        _dueDate = dueDate;

        if (_itemUserRemoteModel != null) {
            try {
                Class<?> clazz = _itemUserRemoteModel.getClass();

                Method method = clazz.getMethod("setDueDate", Date.class);

                method.invoke(_itemUserRemoteModel, dueDate);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getItemId() {
        return _itemId;
    }

    @Override
    public void setItemId(long itemId) {
        _itemId = itemId;

        if (_itemUserRemoteModel != null) {
            try {
                Class<?> clazz = _itemUserRemoteModel.getClass();

                Method method = clazz.getMethod("setItemId", long.class);

                method.invoke(_itemUserRemoteModel, itemId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_itemUserRemoteModel != null) {
            try {
                Class<?> clazz = _itemUserRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_itemUserRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    public BaseModel<?> getItemUserRemoteModel() {
        return _itemUserRemoteModel;
    }

    public void setItemUserRemoteModel(BaseModel<?> itemUserRemoteModel) {
        _itemUserRemoteModel = itemUserRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _itemUserRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_itemUserRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            ItemUserLocalServiceUtil.addItemUser(this);
        } else {
            ItemUserLocalServiceUtil.updateItemUser(this);
        }
    }

    @Override
    public ItemUser toEscapedModel() {
        return (ItemUser) ProxyUtil.newProxyInstance(ItemUser.class.getClassLoader(),
            new Class[] { ItemUser.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        ItemUserClp clone = new ItemUserClp();

        clone.setUuid(getUuid());
        clone.setItemUserId(getItemUserId());
        clone.setCreateDate(getCreateDate());
        clone.setDueDate(getDueDate());
        clone.setItemId(getItemId());
        clone.setUserId(getUserId());

        return clone;
    }

    @Override
    public int compareTo(ItemUser itemUser) {
        int value = 0;

        if (getItemUserId() < itemUser.getItemUserId()) {
            value = -1;
        } else if (getItemUserId() > itemUser.getItemUserId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemUserClp)) {
            return false;
        }

        ItemUserClp itemUser = (ItemUserClp) obj;

        long primaryKey = itemUser.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", itemUserId=");
        sb.append(getItemUserId());
        sb.append(", createDate=");
        sb.append(getCreateDate());
        sb.append(", dueDate=");
        sb.append(getDueDate());
        sb.append(", itemId=");
        sb.append(getItemId());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(22);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.ItemUser");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemUserId</column-name><column-value><![CDATA[");
        sb.append(getItemUserId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>createDate</column-name><column-value><![CDATA[");
        sb.append(getCreateDate());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>dueDate</column-name><column-value><![CDATA[");
        sb.append(getDueDate());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>itemId</column-name><column-value><![CDATA[");
        sb.append(getItemId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
