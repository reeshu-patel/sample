package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ItemUser}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ItemUser
 * @generated
 */
public class ItemUserWrapper implements ItemUser, ModelWrapper<ItemUser> {
    private ItemUser _itemUser;

    public ItemUserWrapper(ItemUser itemUser) {
        _itemUser = itemUser;
    }

    @Override
    public Class<?> getModelClass() {
        return ItemUser.class;
    }

    @Override
    public String getModelClassName() {
        return ItemUser.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("itemUserId", getItemUserId());
        attributes.put("createDate", getCreateDate());
        attributes.put("dueDate", getDueDate());
        attributes.put("itemId", getItemId());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long itemUserId = (Long) attributes.get("itemUserId");

        if (itemUserId != null) {
            setItemUserId(itemUserId);
        }

        Date createDate = (Date) attributes.get("createDate");

        if (createDate != null) {
            setCreateDate(createDate);
        }

        Date dueDate = (Date) attributes.get("dueDate");

        if (dueDate != null) {
            setDueDate(dueDate);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    /**
    * Returns the primary key of this item user.
    *
    * @return the primary key of this item user
    */
    @Override
    public long getPrimaryKey() {
        return _itemUser.getPrimaryKey();
    }

    /**
    * Sets the primary key of this item user.
    *
    * @param primaryKey the primary key of this item user
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _itemUser.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this item user.
    *
    * @return the uuid of this item user
    */
    @Override
    public java.lang.String getUuid() {
        return _itemUser.getUuid();
    }

    /**
    * Sets the uuid of this item user.
    *
    * @param uuid the uuid of this item user
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _itemUser.setUuid(uuid);
    }

    /**
    * Returns the item user ID of this item user.
    *
    * @return the item user ID of this item user
    */
    @Override
    public long getItemUserId() {
        return _itemUser.getItemUserId();
    }

    /**
    * Sets the item user ID of this item user.
    *
    * @param itemUserId the item user ID of this item user
    */
    @Override
    public void setItemUserId(long itemUserId) {
        _itemUser.setItemUserId(itemUserId);
    }

    /**
    * Returns the item user uuid of this item user.
    *
    * @return the item user uuid of this item user
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getItemUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _itemUser.getItemUserUuid();
    }

    /**
    * Sets the item user uuid of this item user.
    *
    * @param itemUserUuid the item user uuid of this item user
    */
    @Override
    public void setItemUserUuid(java.lang.String itemUserUuid) {
        _itemUser.setItemUserUuid(itemUserUuid);
    }

    /**
    * Returns the create date of this item user.
    *
    * @return the create date of this item user
    */
    @Override
    public java.util.Date getCreateDate() {
        return _itemUser.getCreateDate();
    }

    /**
    * Sets the create date of this item user.
    *
    * @param createDate the create date of this item user
    */
    @Override
    public void setCreateDate(java.util.Date createDate) {
        _itemUser.setCreateDate(createDate);
    }

    /**
    * Returns the due date of this item user.
    *
    * @return the due date of this item user
    */
    @Override
    public java.util.Date getDueDate() {
        return _itemUser.getDueDate();
    }

    /**
    * Sets the due date of this item user.
    *
    * @param dueDate the due date of this item user
    */
    @Override
    public void setDueDate(java.util.Date dueDate) {
        _itemUser.setDueDate(dueDate);
    }

    /**
    * Returns the item ID of this item user.
    *
    * @return the item ID of this item user
    */
    @Override
    public long getItemId() {
        return _itemUser.getItemId();
    }

    /**
    * Sets the item ID of this item user.
    *
    * @param itemId the item ID of this item user
    */
    @Override
    public void setItemId(long itemId) {
        _itemUser.setItemId(itemId);
    }

    /**
    * Returns the user ID of this item user.
    *
    * @return the user ID of this item user
    */
    @Override
    public long getUserId() {
        return _itemUser.getUserId();
    }

    /**
    * Sets the user ID of this item user.
    *
    * @param userId the user ID of this item user
    */
    @Override
    public void setUserId(long userId) {
        _itemUser.setUserId(userId);
    }

    /**
    * Returns the user uuid of this item user.
    *
    * @return the user uuid of this item user
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _itemUser.getUserUuid();
    }

    /**
    * Sets the user uuid of this item user.
    *
    * @param userUuid the user uuid of this item user
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _itemUser.setUserUuid(userUuid);
    }

    @Override
    public boolean isNew() {
        return _itemUser.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _itemUser.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _itemUser.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _itemUser.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _itemUser.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _itemUser.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _itemUser.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _itemUser.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _itemUser.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _itemUser.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _itemUser.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ItemUserWrapper((ItemUser) _itemUser.clone());
    }

    @Override
    public int compareTo(ItemUser itemUser) {
        return _itemUser.compareTo(itemUser);
    }

    @Override
    public int hashCode() {
        return _itemUser.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<ItemUser> toCacheModel() {
        return _itemUser.toCacheModel();
    }

    @Override
    public ItemUser toEscapedModel() {
        return new ItemUserWrapper(_itemUser.toEscapedModel());
    }

    @Override
    public ItemUser toUnescapedModel() {
        return new ItemUserWrapper(_itemUser.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _itemUser.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _itemUser.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _itemUser.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemUserWrapper)) {
            return false;
        }

        ItemUserWrapper itemUserWrapper = (ItemUserWrapper) obj;

        if (Validator.equals(_itemUser, itemUserWrapper._itemUser)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public ItemUser getWrappedItemUser() {
        return _itemUser;
    }

    @Override
    public ItemUser getWrappedModel() {
        return _itemUser;
    }

    @Override
    public void resetOriginalValues() {
        _itemUser.resetOriginalValues();
    }
}
