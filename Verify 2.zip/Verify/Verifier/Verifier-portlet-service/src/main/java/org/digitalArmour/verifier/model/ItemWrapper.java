package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Item}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Item
 * @generated
 */
public class ItemWrapper implements Item, ModelWrapper<Item> {
    private Item _item;

    public ItemWrapper(Item item) {
        _item = item;
    }

    @Override
    public Class<?> getModelClass() {
        return Item.class;
    }

    @Override
    public String getModelClassName() {
        return Item.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("itemId", getItemId());
        attributes.put("itemName", getItemName());
        attributes.put("itemDesc", getItemDesc());
        attributes.put("minor", getMinor());
        attributes.put("minor_percent", getMinor_percent());
        attributes.put("major", getMajor());
        attributes.put("major_percent", getMajor_percent());
        attributes.put("userGroupId", getUserGroupId());
        attributes.put("catId", getCatId());
        attributes.put("checklistId", getChecklistId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long itemId = (Long) attributes.get("itemId");

        if (itemId != null) {
            setItemId(itemId);
        }

        String itemName = (String) attributes.get("itemName");

        if (itemName != null) {
            setItemName(itemName);
        }

        String itemDesc = (String) attributes.get("itemDesc");

        if (itemDesc != null) {
            setItemDesc(itemDesc);
        }

        Boolean minor = (Boolean) attributes.get("minor");

        if (minor != null) {
            setMinor(minor);
        }

        Long minor_percent = (Long) attributes.get("minor_percent");

        if (minor_percent != null) {
            setMinor_percent(minor_percent);
        }

        Boolean major = (Boolean) attributes.get("major");

        if (major != null) {
            setMajor(major);
        }

        Long major_percent = (Long) attributes.get("major_percent");

        if (major_percent != null) {
            setMajor_percent(major_percent);
        }

        Long userGroupId = (Long) attributes.get("userGroupId");

        if (userGroupId != null) {
            setUserGroupId(userGroupId);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }
    }

    /**
    * Returns the primary key of this item.
    *
    * @return the primary key of this item
    */
    @Override
    public long getPrimaryKey() {
        return _item.getPrimaryKey();
    }

    /**
    * Sets the primary key of this item.
    *
    * @param primaryKey the primary key of this item
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _item.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this item.
    *
    * @return the uuid of this item
    */
    @Override
    public java.lang.String getUuid() {
        return _item.getUuid();
    }

    /**
    * Sets the uuid of this item.
    *
    * @param uuid the uuid of this item
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _item.setUuid(uuid);
    }

    /**
    * Returns the item ID of this item.
    *
    * @return the item ID of this item
    */
    @Override
    public long getItemId() {
        return _item.getItemId();
    }

    /**
    * Sets the item ID of this item.
    *
    * @param itemId the item ID of this item
    */
    @Override
    public void setItemId(long itemId) {
        _item.setItemId(itemId);
    }

    /**
    * Returns the item name of this item.
    *
    * @return the item name of this item
    */
    @Override
    public java.lang.String getItemName() {
        return _item.getItemName();
    }

    /**
    * Sets the item name of this item.
    *
    * @param itemName the item name of this item
    */
    @Override
    public void setItemName(java.lang.String itemName) {
        _item.setItemName(itemName);
    }

    /**
    * Returns the item desc of this item.
    *
    * @return the item desc of this item
    */
    @Override
    public java.lang.String getItemDesc() {
        return _item.getItemDesc();
    }

    /**
    * Sets the item desc of this item.
    *
    * @param itemDesc the item desc of this item
    */
    @Override
    public void setItemDesc(java.lang.String itemDesc) {
        _item.setItemDesc(itemDesc);
    }

    /**
    * Returns the minor of this item.
    *
    * @return the minor of this item
    */
    @Override
    public boolean getMinor() {
        return _item.getMinor();
    }

    /**
    * Returns <code>true</code> if this item is minor.
    *
    * @return <code>true</code> if this item is minor; <code>false</code> otherwise
    */
    @Override
    public boolean isMinor() {
        return _item.isMinor();
    }

    /**
    * Sets whether this item is minor.
    *
    * @param minor the minor of this item
    */
    @Override
    public void setMinor(boolean minor) {
        _item.setMinor(minor);
    }

    /**
    * Returns the minor_percent of this item.
    *
    * @return the minor_percent of this item
    */
    @Override
    public long getMinor_percent() {
        return _item.getMinor_percent();
    }

    /**
    * Sets the minor_percent of this item.
    *
    * @param minor_percent the minor_percent of this item
    */
    @Override
    public void setMinor_percent(long minor_percent) {
        _item.setMinor_percent(minor_percent);
    }

    /**
    * Returns the major of this item.
    *
    * @return the major of this item
    */
    @Override
    public boolean getMajor() {
        return _item.getMajor();
    }

    /**
    * Returns <code>true</code> if this item is major.
    *
    * @return <code>true</code> if this item is major; <code>false</code> otherwise
    */
    @Override
    public boolean isMajor() {
        return _item.isMajor();
    }

    /**
    * Sets whether this item is major.
    *
    * @param major the major of this item
    */
    @Override
    public void setMajor(boolean major) {
        _item.setMajor(major);
    }

    /**
    * Returns the major_percent of this item.
    *
    * @return the major_percent of this item
    */
    @Override
    public long getMajor_percent() {
        return _item.getMajor_percent();
    }

    /**
    * Sets the major_percent of this item.
    *
    * @param major_percent the major_percent of this item
    */
    @Override
    public void setMajor_percent(long major_percent) {
        _item.setMajor_percent(major_percent);
    }

    /**
    * Returns the user group ID of this item.
    *
    * @return the user group ID of this item
    */
    @Override
    public long getUserGroupId() {
        return _item.getUserGroupId();
    }

    /**
    * Sets the user group ID of this item.
    *
    * @param userGroupId the user group ID of this item
    */
    @Override
    public void setUserGroupId(long userGroupId) {
        _item.setUserGroupId(userGroupId);
    }

    /**
    * Returns the cat ID of this item.
    *
    * @return the cat ID of this item
    */
    @Override
    public long getCatId() {
        return _item.getCatId();
    }

    /**
    * Sets the cat ID of this item.
    *
    * @param catId the cat ID of this item
    */
    @Override
    public void setCatId(long catId) {
        _item.setCatId(catId);
    }

    /**
    * Returns the checklist ID of this item.
    *
    * @return the checklist ID of this item
    */
    @Override
    public long getChecklistId() {
        return _item.getChecklistId();
    }

    /**
    * Sets the checklist ID of this item.
    *
    * @param checklistId the checklist ID of this item
    */
    @Override
    public void setChecklistId(long checklistId) {
        _item.setChecklistId(checklistId);
    }

    @Override
    public boolean isNew() {
        return _item.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _item.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _item.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _item.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _item.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _item.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _item.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _item.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _item.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _item.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _item.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ItemWrapper((Item) _item.clone());
    }

    @Override
    public int compareTo(Item item) {
        return _item.compareTo(item);
    }

    @Override
    public int hashCode() {
        return _item.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<Item> toCacheModel() {
        return _item.toCacheModel();
    }

    @Override
    public Item toEscapedModel() {
        return new ItemWrapper(_item.toEscapedModel());
    }

    @Override
    public Item toUnescapedModel() {
        return new ItemWrapper(_item.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _item.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _item.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _item.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ItemWrapper)) {
            return false;
        }

        ItemWrapper itemWrapper = (ItemWrapper) obj;

        if (Validator.equals(_item, itemWrapper._item)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Item getWrappedItem() {
        return _item;
    }

    @Override
    public Item getWrappedModel() {
        return _item;
    }

    @Override
    public void resetOriginalValues() {
        _item.resetOriginalValues();
    }
}
