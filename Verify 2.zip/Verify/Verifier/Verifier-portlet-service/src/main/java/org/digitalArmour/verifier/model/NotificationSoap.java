package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.NotificationServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.NotificationServiceSoap
 * @generated
 */
public class NotificationSoap implements Serializable {
    private String _uuid;
    private long _noteId;
    private String _noteName;
    private boolean _isMail;
    private boolean _isNewsFeed;

    public NotificationSoap() {
    }

    public static NotificationSoap toSoapModel(Notification model) {
        NotificationSoap soapModel = new NotificationSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setNoteId(model.getNoteId());
        soapModel.setNoteName(model.getNoteName());
        soapModel.setIsMail(model.getIsMail());
        soapModel.setIsNewsFeed(model.getIsNewsFeed());

        return soapModel;
    }

    public static NotificationSoap[] toSoapModels(Notification[] models) {
        NotificationSoap[] soapModels = new NotificationSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static NotificationSoap[][] toSoapModels(Notification[][] models) {
        NotificationSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new NotificationSoap[models.length][models[0].length];
        } else {
            soapModels = new NotificationSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static NotificationSoap[] toSoapModels(List<Notification> models) {
        List<NotificationSoap> soapModels = new ArrayList<NotificationSoap>(models.size());

        for (Notification model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new NotificationSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _noteId;
    }

    public void setPrimaryKey(long pk) {
        setNoteId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getNoteId() {
        return _noteId;
    }

    public void setNoteId(long noteId) {
        _noteId = noteId;
    }

    public String getNoteName() {
        return _noteName;
    }

    public void setNoteName(String noteName) {
        _noteName = noteName;
    }

    public boolean getIsMail() {
        return _isMail;
    }

    public boolean isIsMail() {
        return _isMail;
    }

    public void setIsMail(boolean isMail) {
        _isMail = isMail;
    }

    public boolean getIsNewsFeed() {
        return _isNewsFeed;
    }

    public boolean isIsNewsFeed() {
        return _isNewsFeed;
    }

    public void setIsNewsFeed(boolean isNewsFeed) {
        _isNewsFeed = isNewsFeed;
    }
}
