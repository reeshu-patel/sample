package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Notification}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Notification
 * @generated
 */
public class NotificationWrapper implements Notification,
    ModelWrapper<Notification> {
    private Notification _notification;

    public NotificationWrapper(Notification notification) {
        _notification = notification;
    }

    @Override
    public Class<?> getModelClass() {
        return Notification.class;
    }

    @Override
    public String getModelClassName() {
        return Notification.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("noteId", getNoteId());
        attributes.put("noteName", getNoteName());
        attributes.put("isMail", getIsMail());
        attributes.put("isNewsFeed", getIsNewsFeed());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long noteId = (Long) attributes.get("noteId");

        if (noteId != null) {
            setNoteId(noteId);
        }

        String noteName = (String) attributes.get("noteName");

        if (noteName != null) {
            setNoteName(noteName);
        }

        Boolean isMail = (Boolean) attributes.get("isMail");

        if (isMail != null) {
            setIsMail(isMail);
        }

        Boolean isNewsFeed = (Boolean) attributes.get("isNewsFeed");

        if (isNewsFeed != null) {
            setIsNewsFeed(isNewsFeed);
        }
    }

    /**
    * Returns the primary key of this notification.
    *
    * @return the primary key of this notification
    */
    @Override
    public long getPrimaryKey() {
        return _notification.getPrimaryKey();
    }

    /**
    * Sets the primary key of this notification.
    *
    * @param primaryKey the primary key of this notification
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _notification.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this notification.
    *
    * @return the uuid of this notification
    */
    @Override
    public java.lang.String getUuid() {
        return _notification.getUuid();
    }

    /**
    * Sets the uuid of this notification.
    *
    * @param uuid the uuid of this notification
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _notification.setUuid(uuid);
    }

    /**
    * Returns the note ID of this notification.
    *
    * @return the note ID of this notification
    */
    @Override
    public long getNoteId() {
        return _notification.getNoteId();
    }

    /**
    * Sets the note ID of this notification.
    *
    * @param noteId the note ID of this notification
    */
    @Override
    public void setNoteId(long noteId) {
        _notification.setNoteId(noteId);
    }

    /**
    * Returns the note name of this notification.
    *
    * @return the note name of this notification
    */
    @Override
    public java.lang.String getNoteName() {
        return _notification.getNoteName();
    }

    /**
    * Sets the note name of this notification.
    *
    * @param noteName the note name of this notification
    */
    @Override
    public void setNoteName(java.lang.String noteName) {
        _notification.setNoteName(noteName);
    }

    /**
    * Returns the is mail of this notification.
    *
    * @return the is mail of this notification
    */
    @Override
    public boolean getIsMail() {
        return _notification.getIsMail();
    }

    /**
    * Returns <code>true</code> if this notification is is mail.
    *
    * @return <code>true</code> if this notification is is mail; <code>false</code> otherwise
    */
    @Override
    public boolean isIsMail() {
        return _notification.isIsMail();
    }

    /**
    * Sets whether this notification is is mail.
    *
    * @param isMail the is mail of this notification
    */
    @Override
    public void setIsMail(boolean isMail) {
        _notification.setIsMail(isMail);
    }

    /**
    * Returns the is news feed of this notification.
    *
    * @return the is news feed of this notification
    */
    @Override
    public boolean getIsNewsFeed() {
        return _notification.getIsNewsFeed();
    }

    /**
    * Returns <code>true</code> if this notification is is news feed.
    *
    * @return <code>true</code> if this notification is is news feed; <code>false</code> otherwise
    */
    @Override
    public boolean isIsNewsFeed() {
        return _notification.isIsNewsFeed();
    }

    /**
    * Sets whether this notification is is news feed.
    *
    * @param isNewsFeed the is news feed of this notification
    */
    @Override
    public void setIsNewsFeed(boolean isNewsFeed) {
        _notification.setIsNewsFeed(isNewsFeed);
    }

    @Override
    public boolean isNew() {
        return _notification.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _notification.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _notification.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _notification.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _notification.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _notification.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _notification.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _notification.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _notification.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _notification.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _notification.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new NotificationWrapper((Notification) _notification.clone());
    }

    @Override
    public int compareTo(Notification notification) {
        return _notification.compareTo(notification);
    }

    @Override
    public int hashCode() {
        return _notification.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<Notification> toCacheModel() {
        return _notification.toCacheModel();
    }

    @Override
    public Notification toEscapedModel() {
        return new NotificationWrapper(_notification.toEscapedModel());
    }

    @Override
    public Notification toUnescapedModel() {
        return new NotificationWrapper(_notification.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _notification.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _notification.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _notification.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof NotificationWrapper)) {
            return false;
        }

        NotificationWrapper notificationWrapper = (NotificationWrapper) obj;

        if (Validator.equals(_notification, notificationWrapper._notification)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Notification getWrappedNotification() {
        return _notification;
    }

    @Override
    public Notification getWrappedModel() {
        return _notification;
    }

    @Override
    public void resetOriginalValues() {
        _notification.resetOriginalValues();
    }
}
