package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.OrganizationLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class OrganizationClp extends BaseModelImpl<Organization>
    implements Organization {
    private String _uuid;
    private long _orgId;
    private String _orgName;
    private boolean _type;
    private long _userId;
    private String _userUuid;
    private BaseModel<?> _organizationRemoteModel;

    public OrganizationClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return Organization.class;
    }

    @Override
    public String getModelClassName() {
        return Organization.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _orgId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setOrgId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _orgId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("orgId", getOrgId());
        attributes.put("orgName", getOrgName());
        attributes.put("type", getType());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long orgId = (Long) attributes.get("orgId");

        if (orgId != null) {
            setOrgId(orgId);
        }

        String orgName = (String) attributes.get("orgName");

        if (orgName != null) {
            setOrgName(orgName);
        }

        Boolean type = (Boolean) attributes.get("type");

        if (type != null) {
            setType(type);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_organizationRemoteModel != null) {
            try {
                Class<?> clazz = _organizationRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_organizationRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getOrgId() {
        return _orgId;
    }

    @Override
    public void setOrgId(long orgId) {
        _orgId = orgId;

        if (_organizationRemoteModel != null) {
            try {
                Class<?> clazz = _organizationRemoteModel.getClass();

                Method method = clazz.getMethod("setOrgId", long.class);

                method.invoke(_organizationRemoteModel, orgId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getOrgName() {
        return _orgName;
    }

    @Override
    public void setOrgName(String orgName) {
        _orgName = orgName;

        if (_organizationRemoteModel != null) {
            try {
                Class<?> clazz = _organizationRemoteModel.getClass();

                Method method = clazz.getMethod("setOrgName", String.class);

                method.invoke(_organizationRemoteModel, orgName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public boolean getType() {
        return _type;
    }

    @Override
    public boolean isType() {
        return _type;
    }

    @Override
    public void setType(boolean type) {
        _type = type;

        if (_organizationRemoteModel != null) {
            try {
                Class<?> clazz = _organizationRemoteModel.getClass();

                Method method = clazz.getMethod("setType", boolean.class);

                method.invoke(_organizationRemoteModel, type);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getUserId() {
        return _userId;
    }

    @Override
    public void setUserId(long userId) {
        _userId = userId;

        if (_organizationRemoteModel != null) {
            try {
                Class<?> clazz = _organizationRemoteModel.getClass();

                Method method = clazz.getMethod("setUserId", long.class);

                method.invoke(_organizationRemoteModel, userId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getUserUuid() throws SystemException {
        return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
    }

    @Override
    public void setUserUuid(String userUuid) {
        _userUuid = userUuid;
    }

    public BaseModel<?> getOrganizationRemoteModel() {
        return _organizationRemoteModel;
    }

    public void setOrganizationRemoteModel(BaseModel<?> organizationRemoteModel) {
        _organizationRemoteModel = organizationRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _organizationRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_organizationRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            OrganizationLocalServiceUtil.addOrganization(this);
        } else {
            OrganizationLocalServiceUtil.updateOrganization(this);
        }
    }

    @Override
    public Organization toEscapedModel() {
        return (Organization) ProxyUtil.newProxyInstance(Organization.class.getClassLoader(),
            new Class[] { Organization.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        OrganizationClp clone = new OrganizationClp();

        clone.setUuid(getUuid());
        clone.setOrgId(getOrgId());
        clone.setOrgName(getOrgName());
        clone.setType(getType());
        clone.setUserId(getUserId());

        return clone;
    }

    @Override
    public int compareTo(Organization organization) {
        int value = 0;

        if (getOrgId() < organization.getOrgId()) {
            value = -1;
        } else if (getOrgId() > organization.getOrgId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof OrganizationClp)) {
            return false;
        }

        OrganizationClp organization = (OrganizationClp) obj;

        long primaryKey = organization.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(11);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", orgId=");
        sb.append(getOrgId());
        sb.append(", orgName=");
        sb.append(getOrgName());
        sb.append(", type=");
        sb.append(getType());
        sb.append(", userId=");
        sb.append(getUserId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(19);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.Organization");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>orgId</column-name><column-value><![CDATA[");
        sb.append(getOrgId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>orgName</column-name><column-value><![CDATA[");
        sb.append(getOrgName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>type</column-name><column-value><![CDATA[");
        sb.append(getType());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>userId</column-name><column-value><![CDATA[");
        sb.append(getUserId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
