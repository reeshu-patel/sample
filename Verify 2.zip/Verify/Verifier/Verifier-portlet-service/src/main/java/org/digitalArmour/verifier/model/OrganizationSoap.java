package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.OrganizationServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.OrganizationServiceSoap
 * @generated
 */
public class OrganizationSoap implements Serializable {
    private String _uuid;
    private long _orgId;
    private String _orgName;
    private boolean _type;
    private long _userId;

    public OrganizationSoap() {
    }

    public static OrganizationSoap toSoapModel(Organization model) {
        OrganizationSoap soapModel = new OrganizationSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setOrgId(model.getOrgId());
        soapModel.setOrgName(model.getOrgName());
        soapModel.setType(model.getType());
        soapModel.setUserId(model.getUserId());

        return soapModel;
    }

    public static OrganizationSoap[] toSoapModels(Organization[] models) {
        OrganizationSoap[] soapModels = new OrganizationSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static OrganizationSoap[][] toSoapModels(Organization[][] models) {
        OrganizationSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new OrganizationSoap[models.length][models[0].length];
        } else {
            soapModels = new OrganizationSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static OrganizationSoap[] toSoapModels(List<Organization> models) {
        List<OrganizationSoap> soapModels = new ArrayList<OrganizationSoap>(models.size());

        for (Organization model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new OrganizationSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _orgId;
    }

    public void setPrimaryKey(long pk) {
        setOrgId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getOrgId() {
        return _orgId;
    }

    public void setOrgId(long orgId) {
        _orgId = orgId;
    }

    public String getOrgName() {
        return _orgName;
    }

    public void setOrgName(String orgName) {
        _orgName = orgName;
    }

    public boolean getType() {
        return _type;
    }

    public boolean isType() {
        return _type;
    }

    public void setType(boolean type) {
        _type = type;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }
}
