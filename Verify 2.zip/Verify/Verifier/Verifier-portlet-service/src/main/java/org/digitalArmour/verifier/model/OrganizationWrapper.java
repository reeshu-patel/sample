package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Organization}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Organization
 * @generated
 */
public class OrganizationWrapper implements Organization,
    ModelWrapper<Organization> {
    private Organization _organization;

    public OrganizationWrapper(Organization organization) {
        _organization = organization;
    }

    @Override
    public Class<?> getModelClass() {
        return Organization.class;
    }

    @Override
    public String getModelClassName() {
        return Organization.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("orgId", getOrgId());
        attributes.put("orgName", getOrgName());
        attributes.put("type", getType());
        attributes.put("userId", getUserId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long orgId = (Long) attributes.get("orgId");

        if (orgId != null) {
            setOrgId(orgId);
        }

        String orgName = (String) attributes.get("orgName");

        if (orgName != null) {
            setOrgName(orgName);
        }

        Boolean type = (Boolean) attributes.get("type");

        if (type != null) {
            setType(type);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }
    }

    /**
    * Returns the primary key of this organization.
    *
    * @return the primary key of this organization
    */
    @Override
    public long getPrimaryKey() {
        return _organization.getPrimaryKey();
    }

    /**
    * Sets the primary key of this organization.
    *
    * @param primaryKey the primary key of this organization
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _organization.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this organization.
    *
    * @return the uuid of this organization
    */
    @Override
    public java.lang.String getUuid() {
        return _organization.getUuid();
    }

    /**
    * Sets the uuid of this organization.
    *
    * @param uuid the uuid of this organization
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _organization.setUuid(uuid);
    }

    /**
    * Returns the org ID of this organization.
    *
    * @return the org ID of this organization
    */
    @Override
    public long getOrgId() {
        return _organization.getOrgId();
    }

    /**
    * Sets the org ID of this organization.
    *
    * @param orgId the org ID of this organization
    */
    @Override
    public void setOrgId(long orgId) {
        _organization.setOrgId(orgId);
    }

    /**
    * Returns the org name of this organization.
    *
    * @return the org name of this organization
    */
    @Override
    public java.lang.String getOrgName() {
        return _organization.getOrgName();
    }

    /**
    * Sets the org name of this organization.
    *
    * @param orgName the org name of this organization
    */
    @Override
    public void setOrgName(java.lang.String orgName) {
        _organization.setOrgName(orgName);
    }

    /**
    * Returns the type of this organization.
    *
    * @return the type of this organization
    */
    @Override
    public boolean getType() {
        return _organization.getType();
    }

    /**
    * Returns <code>true</code> if this organization is type.
    *
    * @return <code>true</code> if this organization is type; <code>false</code> otherwise
    */
    @Override
    public boolean isType() {
        return _organization.isType();
    }

    /**
    * Sets whether this organization is type.
    *
    * @param type the type of this organization
    */
    @Override
    public void setType(boolean type) {
        _organization.setType(type);
    }

    /**
    * Returns the user ID of this organization.
    *
    * @return the user ID of this organization
    */
    @Override
    public long getUserId() {
        return _organization.getUserId();
    }

    /**
    * Sets the user ID of this organization.
    *
    * @param userId the user ID of this organization
    */
    @Override
    public void setUserId(long userId) {
        _organization.setUserId(userId);
    }

    /**
    * Returns the user uuid of this organization.
    *
    * @return the user uuid of this organization
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _organization.getUserUuid();
    }

    /**
    * Sets the user uuid of this organization.
    *
    * @param userUuid the user uuid of this organization
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _organization.setUserUuid(userUuid);
    }

    @Override
    public boolean isNew() {
        return _organization.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _organization.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _organization.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _organization.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _organization.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _organization.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _organization.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _organization.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _organization.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _organization.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _organization.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new OrganizationWrapper((Organization) _organization.clone());
    }

    @Override
    public int compareTo(Organization organization) {
        return _organization.compareTo(organization);
    }

    @Override
    public int hashCode() {
        return _organization.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<Organization> toCacheModel() {
        return _organization.toCacheModel();
    }

    @Override
    public Organization toEscapedModel() {
        return new OrganizationWrapper(_organization.toEscapedModel());
    }

    @Override
    public Organization toUnescapedModel() {
        return new OrganizationWrapper(_organization.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _organization.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _organization.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _organization.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof OrganizationWrapper)) {
            return false;
        }

        OrganizationWrapper organizationWrapper = (OrganizationWrapper) obj;

        if (Validator.equals(_organization, organizationWrapper._organization)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Organization getWrappedOrganization() {
        return _organization;
    }

    @Override
    public Organization getWrappedModel() {
        return _organization;
    }

    @Override
    public void resetOriginalValues() {
        _organization.resetOriginalValues();
    }
}
