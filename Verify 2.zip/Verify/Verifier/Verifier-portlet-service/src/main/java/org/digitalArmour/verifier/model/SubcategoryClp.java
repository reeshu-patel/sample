package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.SubcategoryLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class SubcategoryClp extends BaseModelImpl<Subcategory>
    implements Subcategory {
    private String _uuid;
    private long _subcatId;
    private String _subcatName;
    private long _catId;
    private BaseModel<?> _subcategoryRemoteModel;

    public SubcategoryClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return Subcategory.class;
    }

    @Override
    public String getModelClassName() {
        return Subcategory.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _subcatId;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setSubcatId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _subcatId;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("subcatId", getSubcatId());
        attributes.put("subcatName", getSubcatName());
        attributes.put("catId", getCatId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long subcatId = (Long) attributes.get("subcatId");

        if (subcatId != null) {
            setSubcatId(subcatId);
        }

        String subcatName = (String) attributes.get("subcatName");

        if (subcatName != null) {
            setSubcatName(subcatName);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }
    }

    @Override
    public String getUuid() {
        return _uuid;
    }

    @Override
    public void setUuid(String uuid) {
        _uuid = uuid;

        if (_subcategoryRemoteModel != null) {
            try {
                Class<?> clazz = _subcategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setUuid", String.class);

                method.invoke(_subcategoryRemoteModel, uuid);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getSubcatId() {
        return _subcatId;
    }

    @Override
    public void setSubcatId(long subcatId) {
        _subcatId = subcatId;

        if (_subcategoryRemoteModel != null) {
            try {
                Class<?> clazz = _subcategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setSubcatId", long.class);

                method.invoke(_subcategoryRemoteModel, subcatId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getSubcatName() {
        return _subcatName;
    }

    @Override
    public void setSubcatName(String subcatName) {
        _subcatName = subcatName;

        if (_subcategoryRemoteModel != null) {
            try {
                Class<?> clazz = _subcategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setSubcatName", String.class);

                method.invoke(_subcategoryRemoteModel, subcatName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getCatId() {
        return _catId;
    }

    @Override
    public void setCatId(long catId) {
        _catId = catId;

        if (_subcategoryRemoteModel != null) {
            try {
                Class<?> clazz = _subcategoryRemoteModel.getClass();

                Method method = clazz.getMethod("setCatId", long.class);

                method.invoke(_subcategoryRemoteModel, catId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> getSubcategoryRemoteModel() {
        return _subcategoryRemoteModel;
    }

    public void setSubcategoryRemoteModel(BaseModel<?> subcategoryRemoteModel) {
        _subcategoryRemoteModel = subcategoryRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _subcategoryRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_subcategoryRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            SubcategoryLocalServiceUtil.addSubcategory(this);
        } else {
            SubcategoryLocalServiceUtil.updateSubcategory(this);
        }
    }

    @Override
    public Subcategory toEscapedModel() {
        return (Subcategory) ProxyUtil.newProxyInstance(Subcategory.class.getClassLoader(),
            new Class[] { Subcategory.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        SubcategoryClp clone = new SubcategoryClp();

        clone.setUuid(getUuid());
        clone.setSubcatId(getSubcatId());
        clone.setSubcatName(getSubcatName());
        clone.setCatId(getCatId());

        return clone;
    }

    @Override
    public int compareTo(Subcategory subcategory) {
        int value = 0;

        if (getSubcatId() < subcategory.getSubcatId()) {
            value = -1;
        } else if (getSubcatId() > subcategory.getSubcatId()) {
            value = 1;
        } else {
            value = 0;
        }

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof SubcategoryClp)) {
            return false;
        }

        SubcategoryClp subcategory = (SubcategoryClp) obj;

        long primaryKey = subcategory.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(9);

        sb.append("{uuid=");
        sb.append(getUuid());
        sb.append(", subcatId=");
        sb.append(getSubcatId());
        sb.append(", subcatName=");
        sb.append(getSubcatName());
        sb.append(", catId=");
        sb.append(getCatId());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(16);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.Subcategory");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>uuid</column-name><column-value><![CDATA[");
        sb.append(getUuid());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>subcatId</column-name><column-value><![CDATA[");
        sb.append(getSubcatId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>subcatName</column-name><column-value><![CDATA[");
        sb.append(getSubcatName());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>catId</column-name><column-value><![CDATA[");
        sb.append(getCatId());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
