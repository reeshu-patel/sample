package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.SubcategoryServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.SubcategoryServiceSoap
 * @generated
 */
public class SubcategorySoap implements Serializable {
    private String _uuid;
    private long _subcatId;
    private String _subcatName;
    private long _catId;

    public SubcategorySoap() {
    }

    public static SubcategorySoap toSoapModel(Subcategory model) {
        SubcategorySoap soapModel = new SubcategorySoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setSubcatId(model.getSubcatId());
        soapModel.setSubcatName(model.getSubcatName());
        soapModel.setCatId(model.getCatId());

        return soapModel;
    }

    public static SubcategorySoap[] toSoapModels(Subcategory[] models) {
        SubcategorySoap[] soapModels = new SubcategorySoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static SubcategorySoap[][] toSoapModels(Subcategory[][] models) {
        SubcategorySoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new SubcategorySoap[models.length][models[0].length];
        } else {
            soapModels = new SubcategorySoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static SubcategorySoap[] toSoapModels(List<Subcategory> models) {
        List<SubcategorySoap> soapModels = new ArrayList<SubcategorySoap>(models.size());

        for (Subcategory model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new SubcategorySoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _subcatId;
    }

    public void setPrimaryKey(long pk) {
        setSubcatId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getSubcatId() {
        return _subcatId;
    }

    public void setSubcatId(long subcatId) {
        _subcatId = subcatId;
    }

    public String getSubcatName() {
        return _subcatName;
    }

    public void setSubcatName(String subcatName) {
        _subcatName = subcatName;
    }

    public long getCatId() {
        return _catId;
    }

    public void setCatId(long catId) {
        _catId = catId;
    }
}
