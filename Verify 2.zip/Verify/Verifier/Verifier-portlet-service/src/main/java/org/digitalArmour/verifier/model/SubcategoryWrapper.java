package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Subcategory}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Subcategory
 * @generated
 */
public class SubcategoryWrapper implements Subcategory,
    ModelWrapper<Subcategory> {
    private Subcategory _subcategory;

    public SubcategoryWrapper(Subcategory subcategory) {
        _subcategory = subcategory;
    }

    @Override
    public Class<?> getModelClass() {
        return Subcategory.class;
    }

    @Override
    public String getModelClassName() {
        return Subcategory.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("subcatId", getSubcatId());
        attributes.put("subcatName", getSubcatName());
        attributes.put("catId", getCatId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long subcatId = (Long) attributes.get("subcatId");

        if (subcatId != null) {
            setSubcatId(subcatId);
        }

        String subcatName = (String) attributes.get("subcatName");

        if (subcatName != null) {
            setSubcatName(subcatName);
        }

        Long catId = (Long) attributes.get("catId");

        if (catId != null) {
            setCatId(catId);
        }
    }

    /**
    * Returns the primary key of this subcategory.
    *
    * @return the primary key of this subcategory
    */
    @Override
    public long getPrimaryKey() {
        return _subcategory.getPrimaryKey();
    }

    /**
    * Sets the primary key of this subcategory.
    *
    * @param primaryKey the primary key of this subcategory
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _subcategory.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this subcategory.
    *
    * @return the uuid of this subcategory
    */
    @Override
    public java.lang.String getUuid() {
        return _subcategory.getUuid();
    }

    /**
    * Sets the uuid of this subcategory.
    *
    * @param uuid the uuid of this subcategory
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _subcategory.setUuid(uuid);
    }

    /**
    * Returns the subcat ID of this subcategory.
    *
    * @return the subcat ID of this subcategory
    */
    @Override
    public long getSubcatId() {
        return _subcategory.getSubcatId();
    }

    /**
    * Sets the subcat ID of this subcategory.
    *
    * @param subcatId the subcat ID of this subcategory
    */
    @Override
    public void setSubcatId(long subcatId) {
        _subcategory.setSubcatId(subcatId);
    }

    /**
    * Returns the subcat name of this subcategory.
    *
    * @return the subcat name of this subcategory
    */
    @Override
    public java.lang.String getSubcatName() {
        return _subcategory.getSubcatName();
    }

    /**
    * Sets the subcat name of this subcategory.
    *
    * @param subcatName the subcat name of this subcategory
    */
    @Override
    public void setSubcatName(java.lang.String subcatName) {
        _subcategory.setSubcatName(subcatName);
    }

    /**
    * Returns the cat ID of this subcategory.
    *
    * @return the cat ID of this subcategory
    */
    @Override
    public long getCatId() {
        return _subcategory.getCatId();
    }

    /**
    * Sets the cat ID of this subcategory.
    *
    * @param catId the cat ID of this subcategory
    */
    @Override
    public void setCatId(long catId) {
        _subcategory.setCatId(catId);
    }

    @Override
    public boolean isNew() {
        return _subcategory.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _subcategory.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _subcategory.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _subcategory.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _subcategory.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _subcategory.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _subcategory.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _subcategory.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _subcategory.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _subcategory.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _subcategory.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new SubcategoryWrapper((Subcategory) _subcategory.clone());
    }

    @Override
    public int compareTo(Subcategory subcategory) {
        return _subcategory.compareTo(subcategory);
    }

    @Override
    public int hashCode() {
        return _subcategory.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<Subcategory> toCacheModel() {
        return _subcategory.toCacheModel();
    }

    @Override
    public Subcategory toEscapedModel() {
        return new SubcategoryWrapper(_subcategory.toEscapedModel());
    }

    @Override
    public Subcategory toUnescapedModel() {
        return new SubcategoryWrapper(_subcategory.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _subcategory.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _subcategory.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _subcategory.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof SubcategoryWrapper)) {
            return false;
        }

        SubcategoryWrapper subcategoryWrapper = (SubcategoryWrapper) obj;

        if (Validator.equals(_subcategory, subcategoryWrapper._subcategory)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Subcategory getWrappedSubcategory() {
        return _subcategory;
    }

    @Override
    public Subcategory getWrappedModel() {
        return _subcategory;
    }

    @Override
    public void resetOriginalValues() {
        _subcategory.resetOriginalValues();
    }
}
