package org.digitalArmour.verifier.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the tag service. Represents a row in the &quot;Verifier_tag&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see tagModel
 * @see org.digitalArmour.verifier.model.impl.tagImpl
 * @see org.digitalArmour.verifier.model.impl.tagModelImpl
 * @generated
 */
public interface tag extends tagModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link org.digitalArmour.verifier.model.impl.tagImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
