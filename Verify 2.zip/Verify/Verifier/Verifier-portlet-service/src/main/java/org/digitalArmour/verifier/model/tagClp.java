package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.tagLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;


public class tagClp extends BaseModelImpl<tag> implements tag {
    private long _Id;
    private long _checklistId;
    private String _tagName;
    private BaseModel<?> _tagRemoteModel;

    public tagClp() {
    }

    @Override
    public Class<?> getModelClass() {
        return tag.class;
    }

    @Override
    public String getModelClassName() {
        return tag.class.getName();
    }

    @Override
    public long getPrimaryKey() {
        return _Id;
    }

    @Override
    public void setPrimaryKey(long primaryKey) {
        setId(primaryKey);
    }

    @Override
    public Serializable getPrimaryKeyObj() {
        return _Id;
    }

    @Override
    public void setPrimaryKeyObj(Serializable primaryKeyObj) {
        setPrimaryKey(((Long) primaryKeyObj).longValue());
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("Id", getId());
        attributes.put("checklistId", getChecklistId());
        attributes.put("tagName", getTagName());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        Long Id = (Long) attributes.get("Id");

        if (Id != null) {
            setId(Id);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }

        String tagName = (String) attributes.get("tagName");

        if (tagName != null) {
            setTagName(tagName);
        }
    }

    @Override
    public long getId() {
        return _Id;
    }

    @Override
    public void setId(long Id) {
        _Id = Id;

        if (_tagRemoteModel != null) {
            try {
                Class<?> clazz = _tagRemoteModel.getClass();

                Method method = clazz.getMethod("setId", long.class);

                method.invoke(_tagRemoteModel, Id);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public long getChecklistId() {
        return _checklistId;
    }

    @Override
    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;

        if (_tagRemoteModel != null) {
            try {
                Class<?> clazz = _tagRemoteModel.getClass();

                Method method = clazz.getMethod("setChecklistId", long.class);

                method.invoke(_tagRemoteModel, checklistId);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    @Override
    public String getTagName() {
        return _tagName;
    }

    @Override
    public void setTagName(String tagName) {
        _tagName = tagName;

        if (_tagRemoteModel != null) {
            try {
                Class<?> clazz = _tagRemoteModel.getClass();

                Method method = clazz.getMethod("setTagName", String.class);

                method.invoke(_tagRemoteModel, tagName);
            } catch (Exception e) {
                throw new UnsupportedOperationException(e);
            }
        }
    }

    public BaseModel<?> gettagRemoteModel() {
        return _tagRemoteModel;
    }

    public void settagRemoteModel(BaseModel<?> tagRemoteModel) {
        _tagRemoteModel = tagRemoteModel;
    }

    public Object invokeOnRemoteModel(String methodName,
        Class<?>[] parameterTypes, Object[] parameterValues)
        throws Exception {
        Object[] remoteParameterValues = new Object[parameterValues.length];

        for (int i = 0; i < parameterValues.length; i++) {
            if (parameterValues[i] != null) {
                remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
            }
        }

        Class<?> remoteModelClass = _tagRemoteModel.getClass();

        ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

        Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i].isPrimitive()) {
                remoteParameterTypes[i] = parameterTypes[i];
            } else {
                String parameterTypeName = parameterTypes[i].getName();

                remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
            }
        }

        Method method = remoteModelClass.getMethod(methodName,
                remoteParameterTypes);

        Object returnValue = method.invoke(_tagRemoteModel,
                remoteParameterValues);

        if (returnValue != null) {
            returnValue = ClpSerializer.translateOutput(returnValue);
        }

        return returnValue;
    }

    @Override
    public void persist() throws SystemException {
        if (this.isNew()) {
            tagLocalServiceUtil.addtag(this);
        } else {
            tagLocalServiceUtil.updatetag(this);
        }
    }

    @Override
    public tag toEscapedModel() {
        return (tag) ProxyUtil.newProxyInstance(tag.class.getClassLoader(),
            new Class[] { tag.class }, new AutoEscapeBeanHandler(this));
    }

    @Override
    public Object clone() {
        tagClp clone = new tagClp();

        clone.setId(getId());
        clone.setChecklistId(getChecklistId());
        clone.setTagName(getTagName());

        return clone;
    }

    @Override
    public int compareTo(tag tag) {
        int value = 0;

        value = getTagName().compareTo(tag.getTagName());

        if (value != 0) {
            return value;
        }

        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof tagClp)) {
            return false;
        }

        tagClp tag = (tagClp) obj;

        long primaryKey = tag.getPrimaryKey();

        if (getPrimaryKey() == primaryKey) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (int) getPrimaryKey();
    }

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(7);

        sb.append("{Id=");
        sb.append(getId());
        sb.append(", checklistId=");
        sb.append(getChecklistId());
        sb.append(", tagName=");
        sb.append(getTagName());
        sb.append("}");

        return sb.toString();
    }

    @Override
    public String toXmlString() {
        StringBundler sb = new StringBundler(13);

        sb.append("<model><model-name>");
        sb.append("org.digitalArmour.verifier.model.tag");
        sb.append("</model-name>");

        sb.append(
            "<column><column-name>Id</column-name><column-value><![CDATA[");
        sb.append(getId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>checklistId</column-name><column-value><![CDATA[");
        sb.append(getChecklistId());
        sb.append("]]></column-value></column>");
        sb.append(
            "<column><column-name>tagName</column-name><column-value><![CDATA[");
        sb.append(getTagName());
        sb.append("]]></column-value></column>");

        sb.append("</model>");

        return sb.toString();
    }
}
