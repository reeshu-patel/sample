package org.digitalArmour.verifier.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link org.digitalArmour.verifier.service.http.tagServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.http.tagServiceSoap
 * @generated
 */
public class tagSoap implements Serializable {
    private long _Id;
    private long _checklistId;
    private String _tagName;

    public tagSoap() {
    }

    public static tagSoap toSoapModel(tag model) {
        tagSoap soapModel = new tagSoap();

        soapModel.setId(model.getId());
        soapModel.setChecklistId(model.getChecklistId());
        soapModel.setTagName(model.getTagName());

        return soapModel;
    }

    public static tagSoap[] toSoapModels(tag[] models) {
        tagSoap[] soapModels = new tagSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static tagSoap[][] toSoapModels(tag[][] models) {
        tagSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new tagSoap[models.length][models[0].length];
        } else {
            soapModels = new tagSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static tagSoap[] toSoapModels(List<tag> models) {
        List<tagSoap> soapModels = new ArrayList<tagSoap>(models.size());

        for (tag model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new tagSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _Id;
    }

    public void setPrimaryKey(long pk) {
        setId(pk);
    }

    public long getId() {
        return _Id;
    }

    public void setId(long Id) {
        _Id = Id;
    }

    public long getChecklistId() {
        return _checklistId;
    }

    public void setChecklistId(long checklistId) {
        _checklistId = checklistId;
    }

    public String getTagName() {
        return _tagName;
    }

    public void setTagName(String tagName) {
        _tagName = tagName;
    }
}
