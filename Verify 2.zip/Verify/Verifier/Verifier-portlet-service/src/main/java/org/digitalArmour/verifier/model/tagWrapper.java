package org.digitalArmour.verifier.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link tag}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see tag
 * @generated
 */
public class tagWrapper implements tag, ModelWrapper<tag> {
    private tag _tag;

    public tagWrapper(tag tag) {
        _tag = tag;
    }

    @Override
    public Class<?> getModelClass() {
        return tag.class;
    }

    @Override
    public String getModelClassName() {
        return tag.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("Id", getId());
        attributes.put("checklistId", getChecklistId());
        attributes.put("tagName", getTagName());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        Long Id = (Long) attributes.get("Id");

        if (Id != null) {
            setId(Id);
        }

        Long checklistId = (Long) attributes.get("checklistId");

        if (checklistId != null) {
            setChecklistId(checklistId);
        }

        String tagName = (String) attributes.get("tagName");

        if (tagName != null) {
            setTagName(tagName);
        }
    }

    /**
    * Returns the primary key of this tag.
    *
    * @return the primary key of this tag
    */
    @Override
    public long getPrimaryKey() {
        return _tag.getPrimaryKey();
    }

    /**
    * Sets the primary key of this tag.
    *
    * @param primaryKey the primary key of this tag
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _tag.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the ID of this tag.
    *
    * @return the ID of this tag
    */
    @Override
    public long getId() {
        return _tag.getId();
    }

    /**
    * Sets the ID of this tag.
    *
    * @param Id the ID of this tag
    */
    @Override
    public void setId(long Id) {
        _tag.setId(Id);
    }

    /**
    * Returns the checklist ID of this tag.
    *
    * @return the checklist ID of this tag
    */
    @Override
    public long getChecklistId() {
        return _tag.getChecklistId();
    }

    /**
    * Sets the checklist ID of this tag.
    *
    * @param checklistId the checklist ID of this tag
    */
    @Override
    public void setChecklistId(long checklistId) {
        _tag.setChecklistId(checklistId);
    }

    /**
    * Returns the tag name of this tag.
    *
    * @return the tag name of this tag
    */
    @Override
    public java.lang.String getTagName() {
        return _tag.getTagName();
    }

    /**
    * Sets the tag name of this tag.
    *
    * @param tagName the tag name of this tag
    */
    @Override
    public void setTagName(java.lang.String tagName) {
        _tag.setTagName(tagName);
    }

    @Override
    public boolean isNew() {
        return _tag.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _tag.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _tag.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _tag.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _tag.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _tag.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _tag.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _tag.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _tag.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _tag.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _tag.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new tagWrapper((tag) _tag.clone());
    }

    @Override
    public int compareTo(tag tag) {
        return _tag.compareTo(tag);
    }

    @Override
    public int hashCode() {
        return _tag.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<tag> toCacheModel() {
        return _tag.toCacheModel();
    }

    @Override
    public tag toEscapedModel() {
        return new tagWrapper(_tag.toEscapedModel());
    }

    @Override
    public tag toUnescapedModel() {
        return new tagWrapper(_tag.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _tag.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _tag.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _tag.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof tagWrapper)) {
            return false;
        }

        tagWrapper tagWrapper = (tagWrapper) obj;

        if (Validator.equals(_tag, tagWrapper._tag)) {
            return true;
        }

        return false;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public tag getWrappedtag() {
        return _tag;
    }

    @Override
    public tag getWrappedModel() {
        return _tag;
    }

    @Override
    public void resetOriginalValues() {
        _tag.resetOriginalValues();
    }
}
