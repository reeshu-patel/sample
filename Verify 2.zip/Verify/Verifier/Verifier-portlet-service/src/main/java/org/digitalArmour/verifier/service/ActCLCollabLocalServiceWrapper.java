package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActCLCollabLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActCLCollabLocalService
 * @generated
 */
public class ActCLCollabLocalServiceWrapper implements ActCLCollabLocalService,
    ServiceWrapper<ActCLCollabLocalService> {
    private ActCLCollabLocalService _actCLCollabLocalService;

    public ActCLCollabLocalServiceWrapper(
        ActCLCollabLocalService actCLCollabLocalService) {
        _actCLCollabLocalService = actCLCollabLocalService;
    }

    /**
    * Adds the act c l collab to the database. Also notifies the appropriate model listeners.
    *
    * @param actCLCollab the act c l collab
    * @return the act c l collab that was added
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCLCollab addActCLCollab(
        org.digitalArmour.verifier.model.ActCLCollab actCLCollab)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.addActCLCollab(actCLCollab);
    }

    /**
    * Creates a new act c l collab with the primary key. Does not add the act c l collab to the database.
    *
    * @param actClCollabId the primary key for the new act c l collab
    * @return the new act c l collab
    */
    @Override
    public org.digitalArmour.verifier.model.ActCLCollab createActCLCollab(
        long actClCollabId) {
        return _actCLCollabLocalService.createActCLCollab(actClCollabId);
    }

    /**
    * Deletes the act c l collab with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param actClCollabId the primary key of the act c l collab
    * @return the act c l collab that was removed
    * @throws PortalException if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCLCollab deleteActCLCollab(
        long actClCollabId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.deleteActCLCollab(actClCollabId);
    }

    /**
    * Deletes the act c l collab from the database. Also notifies the appropriate model listeners.
    *
    * @param actCLCollab the act c l collab
    * @return the act c l collab that was removed
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCLCollab deleteActCLCollab(
        org.digitalArmour.verifier.model.ActCLCollab actCLCollab)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.deleteActCLCollab(actCLCollab);
    }

    @Override
    public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return _actCLCollabLocalService.dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.dynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.dynamicQueryCount(dynamicQuery,
            projection);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCLCollab fetchActCLCollab(
        long actClCollabId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.fetchActCLCollab(actClCollabId);
    }

    /**
    * Returns the act c l collab with the primary key.
    *
    * @param actClCollabId the primary key of the act c l collab
    * @return the act c l collab
    * @throws PortalException if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCLCollab getActCLCollab(
        long actClCollabId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.getActCLCollab(actClCollabId);
    }

    @Override
    public com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the act c l collabs.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @return the range of act c l collabs
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> getActCLCollabs(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.getActCLCollabs(start, end);
    }

    /**
    * Returns the number of act c l collabs.
    *
    * @return the number of act c l collabs
    * @throws SystemException if a system exception occurred
    */
    @Override
    public int getActCLCollabsCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.getActCLCollabsCount();
    }

    /**
    * Updates the act c l collab in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param actCLCollab the act c l collab
    * @return the act c l collab that was updated
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCLCollab updateActCLCollab(
        org.digitalArmour.verifier.model.ActCLCollab actCLCollab)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.updateActCLCollab(actCLCollab);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actCLCollabLocalService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actCLCollabLocalService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actCLCollabLocalService.invokeMethod(name, parameterTypes,
            arguments);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> getCollabByActiveCL(
        java.lang.Long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.getCollabByActiveCL(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> searchByuserId(
        long userId) throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabLocalService.searchByuserId(userId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActCLCollabLocalService getWrappedActCLCollabLocalService() {
        return _actCLCollabLocalService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActCLCollabLocalService(
        ActCLCollabLocalService actCLCollabLocalService) {
        _actCLCollabLocalService = actCLCollabLocalService;
    }

    @Override
    public ActCLCollabLocalService getWrappedService() {
        return _actCLCollabLocalService;
    }

    @Override
    public void setWrappedService(
        ActCLCollabLocalService actCLCollabLocalService) {
        _actCLCollabLocalService = actCLCollabLocalService;
    }
}
