package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service utility for ActCLCollab. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.ActCLCollabServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on a remote server. Methods of this service are expected to have security
 * checks based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author Brian Wing Shun Chan
 * @see ActCLCollabService
 * @see org.digitalArmour.verifier.service.base.ActCLCollabServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.ActCLCollabServiceImpl
 * @generated
 */
public class ActCLCollabServiceUtil {
    private static ActCLCollabService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.ActCLCollabServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static org.digitalArmour.verifier.model.ActCLCollab AddActClCollab(
        long checklistId, long userid, java.lang.String collabtype)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().AddActClCollab(checklistId, userid, collabtype);
    }

    public static org.digitalArmour.verifier.model.ActCLCollab DeleteActClCollab(
        long collabId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().DeleteActClCollab(collabId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActCLCollab> getCollabByActiveCL(
        java.lang.Long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getCollabByActiveCL(id);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActCLCollab> searchByuserId(
        long userId) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().searchByuserId(userId);
    }

    public static void clearService() {
        _service = null;
    }

    public static ActCLCollabService getService() {
        if (_service == null) {
            InvokableService invokableService = (InvokableService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    ActCLCollabService.class.getName());

            if (invokableService instanceof ActCLCollabService) {
                _service = (ActCLCollabService) invokableService;
            } else {
                _service = new ActCLCollabServiceClp(invokableService);
            }

            ReferenceRegistry.registerReference(ActCLCollabServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(ActCLCollabService service) {
    }
}
