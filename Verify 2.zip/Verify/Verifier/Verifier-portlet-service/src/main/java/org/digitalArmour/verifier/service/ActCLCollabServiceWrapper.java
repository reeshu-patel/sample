package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActCLCollabService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActCLCollabService
 * @generated
 */
public class ActCLCollabServiceWrapper implements ActCLCollabService,
    ServiceWrapper<ActCLCollabService> {
    private ActCLCollabService _actCLCollabService;

    public ActCLCollabServiceWrapper(ActCLCollabService actCLCollabService) {
        _actCLCollabService = actCLCollabService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actCLCollabService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actCLCollabService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actCLCollabService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCLCollab AddActClCollab(
        long checklistId, long userid, java.lang.String collabtype)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabService.AddActClCollab(checklistId, userid,
            collabtype);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCLCollab DeleteActClCollab(
        long collabId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabService.DeleteActClCollab(collabId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> getCollabByActiveCL(
        java.lang.Long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabService.getCollabByActiveCL(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> searchByuserId(
        long userId) throws com.liferay.portal.kernel.exception.SystemException {
        return _actCLCollabService.searchByuserId(userId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActCLCollabService getWrappedActCLCollabService() {
        return _actCLCollabService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActCLCollabService(
        ActCLCollabService actCLCollabService) {
        _actCLCollabService = actCLCollabService;
    }

    @Override
    public ActCLCollabService getWrappedService() {
        return _actCLCollabService;
    }

    @Override
    public void setWrappedService(ActCLCollabService actCLCollabService) {
        _actCLCollabService = actCLCollabService;
    }
}
