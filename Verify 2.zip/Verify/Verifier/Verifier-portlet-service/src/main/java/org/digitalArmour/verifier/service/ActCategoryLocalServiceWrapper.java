package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActCategoryLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActCategoryLocalService
 * @generated
 */
public class ActCategoryLocalServiceWrapper implements ActCategoryLocalService,
    ServiceWrapper<ActCategoryLocalService> {
    private ActCategoryLocalService _actCategoryLocalService;

    public ActCategoryLocalServiceWrapper(
        ActCategoryLocalService actCategoryLocalService) {
        _actCategoryLocalService = actCategoryLocalService;
    }

    /**
    * Adds the act category to the database. Also notifies the appropriate model listeners.
    *
    * @param actCategory the act category
    * @return the act category that was added
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCategory addActCategory(
        org.digitalArmour.verifier.model.ActCategory actCategory)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.addActCategory(actCategory);
    }

    /**
    * Creates a new act category with the primary key. Does not add the act category to the database.
    *
    * @param ActCategoryId the primary key for the new act category
    * @return the new act category
    */
    @Override
    public org.digitalArmour.verifier.model.ActCategory createActCategory(
        long ActCategoryId) {
        return _actCategoryLocalService.createActCategory(ActCategoryId);
    }

    /**
    * Deletes the act category with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category that was removed
    * @throws PortalException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCategory deleteActCategory(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.deleteActCategory(ActCategoryId);
    }

    /**
    * Deletes the act category from the database. Also notifies the appropriate model listeners.
    *
    * @param actCategory the act category
    * @return the act category that was removed
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCategory deleteActCategory(
        org.digitalArmour.verifier.model.ActCategory actCategory)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.deleteActCategory(actCategory);
    }

    @Override
    public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return _actCategoryLocalService.dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.dynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.dynamicQueryCount(dynamicQuery,
            projection);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCategory fetchActCategory(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.fetchActCategory(ActCategoryId);
    }

    /**
    * Returns the act category with the primary key.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category
    * @throws PortalException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCategory getActCategory(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.getActCategory(ActCategoryId);
    }

    @Override
    public com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the act categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of act categories
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> getActCategories(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.getActCategories(start, end);
    }

    /**
    * Returns the number of act categories.
    *
    * @return the number of act categories
    * @throws SystemException if a system exception occurred
    */
    @Override
    public int getActCategoriesCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.getActCategoriesCount();
    }

    /**
    * Updates the act category in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param actCategory the act category
    * @return the act category that was updated
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActCategory updateActCategory(
        org.digitalArmour.verifier.model.ActCategory actCategory)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.updateActCategory(actCategory);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actCategoryLocalService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actCategoryLocalService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actCategoryLocalService.invokeMethod(name, parameterTypes,
            arguments);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> searchbyActiveClId(
        long ActiveClId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.searchbyActiveClId(ActiveClId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Item> searchbyActiveCatId(
        long ActiveCatId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.searchbyActiveCatId(ActiveCatId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> getByActClSubID(
        long clid, long sid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryLocalService.getByActClSubID(clid, sid);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActCategoryLocalService getWrappedActCategoryLocalService() {
        return _actCategoryLocalService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActCategoryLocalService(
        ActCategoryLocalService actCategoryLocalService) {
        _actCategoryLocalService = actCategoryLocalService;
    }

    @Override
    public ActCategoryLocalService getWrappedService() {
        return _actCategoryLocalService;
    }

    @Override
    public void setWrappedService(
        ActCategoryLocalService actCategoryLocalService) {
        _actCategoryLocalService = actCategoryLocalService;
    }
}
