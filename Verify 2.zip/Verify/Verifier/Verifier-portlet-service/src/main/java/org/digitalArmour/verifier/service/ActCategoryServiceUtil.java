package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service utility for ActCategory. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.ActCategoryServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on a remote server. Methods of this service are expected to have security
 * checks based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author Brian Wing Shun Chan
 * @see ActCategoryService
 * @see org.digitalArmour.verifier.service.base.ActCategoryServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.ActCategoryServiceImpl
 * @generated
 */
public class ActCategoryServiceUtil {
    private static ActCategoryService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.ActCategoryServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static org.digitalArmour.verifier.model.ActCategory AddActivatecategory(
        java.lang.String categotyName, long activeChecklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().AddActivatecategory(categotyName, activeChecklistId);
    }

    public static org.digitalArmour.verifier.model.ActCategory updateActCategory(
        java.lang.String categoryName, long catid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().updateActCategory(categoryName, catid);
    }

    public static org.digitalArmour.verifier.model.ActCategory DeleteActCategory(
        long ActchecklistId, long catid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().DeleteActCategory(ActchecklistId, catid);
    }

    public static org.digitalArmour.verifier.model.ActCategory AddSubcategory(
        java.lang.String subCategoryName, long categoryId,
        long activeChecklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService()
                   .AddSubcategory(subCategoryName, categoryId,
            activeChecklistId);
    }

    public static org.digitalArmour.verifier.model.ActCategory UpdateSubcategory(
        java.lang.String subCategoryName, long categoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().UpdateSubcategory(subCategoryName, categoryId);
    }

    public static org.digitalArmour.verifier.model.ActCategory DeleteSubcategory(
        long SubcategoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().DeleteSubcategory(SubcategoryId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> searchbyActiveClId(
        long ActiveClId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyActiveClId(ActiveClId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> getByActClSubID(
        long clid, long sid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getByActClSubID(clid, sid);
    }

    public static void clearService() {
        _service = null;
    }

    public static ActCategoryService getService() {
        if (_service == null) {
            InvokableService invokableService = (InvokableService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    ActCategoryService.class.getName());

            if (invokableService instanceof ActCategoryService) {
                _service = (ActCategoryService) invokableService;
            } else {
                _service = new ActCategoryServiceClp(invokableService);
            }

            ReferenceRegistry.registerReference(ActCategoryServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(ActCategoryService service) {
    }
}
