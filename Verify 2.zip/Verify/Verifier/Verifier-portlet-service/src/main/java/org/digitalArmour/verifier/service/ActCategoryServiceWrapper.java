package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActCategoryService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActCategoryService
 * @generated
 */
public class ActCategoryServiceWrapper implements ActCategoryService,
    ServiceWrapper<ActCategoryService> {
    private ActCategoryService _actCategoryService;

    public ActCategoryServiceWrapper(ActCategoryService actCategoryService) {
        _actCategoryService = actCategoryService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actCategoryService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actCategoryService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actCategoryService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCategory AddActivatecategory(
        java.lang.String categotyName, long activeChecklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.AddActivatecategory(categotyName,
            activeChecklistId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCategory updateActCategory(
        java.lang.String categoryName, long catid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.updateActCategory(categoryName, catid);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCategory DeleteActCategory(
        long ActchecklistId, long catid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.DeleteActCategory(ActchecklistId, catid);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCategory AddSubcategory(
        java.lang.String subCategoryName, long categoryId,
        long activeChecklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.AddSubcategory(subCategoryName, categoryId,
            activeChecklistId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCategory UpdateSubcategory(
        java.lang.String subCategoryName, long categoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.UpdateSubcategory(subCategoryName, categoryId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActCategory DeleteSubcategory(
        long SubcategoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.DeleteSubcategory(SubcategoryId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> searchbyActiveClId(
        long ActiveClId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.searchbyActiveClId(ActiveClId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> getByActClSubID(
        long clid, long sid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actCategoryService.getByActClSubID(clid, sid);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActCategoryService getWrappedActCategoryService() {
        return _actCategoryService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActCategoryService(
        ActCategoryService actCategoryService) {
        _actCategoryService = actCategoryService;
    }

    @Override
    public ActCategoryService getWrappedService() {
        return _actCategoryService;
    }

    @Override
    public void setWrappedService(ActCategoryService actCategoryService) {
        _actCategoryService = actCategoryService;
    }
}
