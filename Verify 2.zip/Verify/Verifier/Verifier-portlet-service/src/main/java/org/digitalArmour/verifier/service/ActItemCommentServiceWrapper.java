package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActItemCommentService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemCommentService
 * @generated
 */
public class ActItemCommentServiceWrapper implements ActItemCommentService,
    ServiceWrapper<ActItemCommentService> {
    private ActItemCommentService _actItemCommentService;

    public ActItemCommentServiceWrapper(
        ActItemCommentService actItemCommentService) {
        _actItemCommentService = actItemCommentService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actItemCommentService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actItemCommentService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actItemCommentService.invokeMethod(name, parameterTypes,
            arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItemComment AddActTaskComment(
        long taskId, java.lang.String commentMassage, long userId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemCommentService.AddActTaskComment(taskId, commentMassage,
            userId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItemComment updateActTaskComment(
        long commentId, java.lang.String commentMassage)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemCommentService.updateActTaskComment(commentId,
            commentMassage);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItemComment DeleteActTaskComment(
        long commentId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemCommentService.DeleteActTaskComment(commentId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItemComment> getAllComments(
        long itemId) throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemCommentService.getAllComments(itemId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItemComment> searchbyItemId(
        long ItemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemCommentService.searchbyItemId(ItemId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActItemCommentService getWrappedActItemCommentService() {
        return _actItemCommentService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActItemCommentService(
        ActItemCommentService actItemCommentService) {
        _actItemCommentService = actItemCommentService;
    }

    @Override
    public ActItemCommentService getWrappedService() {
        return _actItemCommentService;
    }

    @Override
    public void setWrappedService(ActItemCommentService actItemCommentService) {
        _actItemCommentService = actItemCommentService;
    }
}
