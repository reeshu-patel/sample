package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActItemFileLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemFileLocalService
 * @generated
 */
public class ActItemFileLocalServiceWrapper implements ActItemFileLocalService,
    ServiceWrapper<ActItemFileLocalService> {
    private ActItemFileLocalService _actItemFileLocalService;

    public ActItemFileLocalServiceWrapper(
        ActItemFileLocalService actItemFileLocalService) {
        _actItemFileLocalService = actItemFileLocalService;
    }

    /**
    * Adds the act item file to the database. Also notifies the appropriate model listeners.
    *
    * @param actItemFile the act item file
    * @return the act item file that was added
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItemFile addActItemFile(
        org.digitalArmour.verifier.model.ActItemFile actItemFile)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.addActItemFile(actItemFile);
    }

    /**
    * Creates a new act item file with the primary key. Does not add the act item file to the database.
    *
    * @param actItemFileId the primary key for the new act item file
    * @return the new act item file
    */
    @Override
    public org.digitalArmour.verifier.model.ActItemFile createActItemFile(
        long actItemFileId) {
        return _actItemFileLocalService.createActItemFile(actItemFileId);
    }

    /**
    * Deletes the act item file with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param actItemFileId the primary key of the act item file
    * @return the act item file that was removed
    * @throws PortalException if a act item file with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItemFile deleteActItemFile(
        long actItemFileId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.deleteActItemFile(actItemFileId);
    }

    /**
    * Deletes the act item file from the database. Also notifies the appropriate model listeners.
    *
    * @param actItemFile the act item file
    * @return the act item file that was removed
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItemFile deleteActItemFile(
        org.digitalArmour.verifier.model.ActItemFile actItemFile)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.deleteActItemFile(actItemFile);
    }

    @Override
    public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return _actItemFileLocalService.dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.dynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.dynamicQueryCount(dynamicQuery,
            projection);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItemFile fetchActItemFile(
        long actItemFileId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.fetchActItemFile(actItemFileId);
    }

    /**
    * Returns the act item file with the primary key.
    *
    * @param actItemFileId the primary key of the act item file
    * @return the act item file
    * @throws PortalException if a act item file with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItemFile getActItemFile(
        long actItemFileId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.getActItemFile(actItemFileId);
    }

    @Override
    public com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the act item files.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act item files
    * @param end the upper bound of the range of act item files (not inclusive)
    * @return the range of act item files
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItemFile> getActItemFiles(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.getActItemFiles(start, end);
    }

    /**
    * Returns the number of act item files.
    *
    * @return the number of act item files
    * @throws SystemException if a system exception occurred
    */
    @Override
    public int getActItemFilesCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.getActItemFilesCount();
    }

    /**
    * Updates the act item file in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param actItemFile the act item file
    * @return the act item file that was updated
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItemFile updateActItemFile(
        org.digitalArmour.verifier.model.ActItemFile actItemFile)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.updateActItemFile(actItemFile);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actItemFileLocalService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actItemFileLocalService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actItemFileLocalService.invokeMethod(name, parameterTypes,
            arguments);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItemFile> getAllFiles(
        long itemId) throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.getAllFiles(itemId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItemFile> searchbyItemId(
        long ItemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileLocalService.searchbyItemId(ItemId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActItemFileLocalService getWrappedActItemFileLocalService() {
        return _actItemFileLocalService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActItemFileLocalService(
        ActItemFileLocalService actItemFileLocalService) {
        _actItemFileLocalService = actItemFileLocalService;
    }

    @Override
    public ActItemFileLocalService getWrappedService() {
        return _actItemFileLocalService;
    }

    @Override
    public void setWrappedService(
        ActItemFileLocalService actItemFileLocalService) {
        _actItemFileLocalService = actItemFileLocalService;
    }
}
