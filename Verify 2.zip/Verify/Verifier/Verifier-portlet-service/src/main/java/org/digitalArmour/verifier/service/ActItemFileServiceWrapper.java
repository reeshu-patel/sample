package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActItemFileService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemFileService
 * @generated
 */
public class ActItemFileServiceWrapper implements ActItemFileService,
    ServiceWrapper<ActItemFileService> {
    private ActItemFileService _actItemFileService;

    public ActItemFileServiceWrapper(ActItemFileService actItemFileService) {
        _actItemFileService = actItemFileService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actItemFileService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actItemFileService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actItemFileService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItemFile AddTaskFile(
        long taskId, java.lang.String sourceFileName, long userId,
        java.lang.String file)
        throws com.liferay.portal.kernel.exception.SystemException,
            java.io.IOException {
        return _actItemFileService.AddTaskFile(taskId, sourceFileName, userId,
            file);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItemFile DeleteFile(long fileId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemFileService.DeleteFile(fileId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActItemFileService getWrappedActItemFileService() {
        return _actItemFileService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActItemFileService(
        ActItemFileService actItemFileService) {
        _actItemFileService = actItemFileService;
    }

    @Override
    public ActItemFileService getWrappedService() {
        return _actItemFileService;
    }

    @Override
    public void setWrappedService(ActItemFileService actItemFileService) {
        _actItemFileService = actItemFileService;
    }
}
