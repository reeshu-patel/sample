package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for ActItem. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.ActItemLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemLocalService
 * @see org.digitalArmour.verifier.service.base.ActItemLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.ActItemLocalServiceImpl
 * @generated
 */
public class ActItemLocalServiceUtil {
    private static ActItemLocalService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.ActItemLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Adds the act item to the database. Also notifies the appropriate model listeners.
    *
    * @param actItem the act item
    * @return the act item that was added
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem addActItem(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().addActItem(actItem);
    }

    /**
    * Creates a new act item with the primary key. Does not add the act item to the database.
    *
    * @param ItemId the primary key for the new act item
    * @return the new act item
    */
    public static org.digitalArmour.verifier.model.ActItem createActItem(
        long ItemId) {
        return getService().createActItem(ItemId);
    }

    /**
    * Deletes the act item with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param ItemId the primary key of the act item
    * @return the act item that was removed
    * @throws PortalException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem deleteActItem(
        long ItemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().deleteActItem(ItemId);
    }

    /**
    * Deletes the act item from the database. Also notifies the appropriate model listeners.
    *
    * @param actItem the act item
    * @return the act item that was removed
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem deleteActItem(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().deleteActItem(actItem);
    }

    public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return getService().dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService()
                   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    public static long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    public static long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQueryCount(dynamicQuery, projection);
    }

    public static org.digitalArmour.verifier.model.ActItem fetchActItem(
        long ItemId) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().fetchActItem(ItemId);
    }

    /**
    * Returns the act item with the primary key.
    *
    * @param ItemId the primary key of the act item
    * @return the act item
    * @throws PortalException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem getActItem(
        long ItemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().getActItem(ItemId);
    }

    public static com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the act items.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> getActItems(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getActItems(start, end);
    }

    /**
    * Returns the number of act items.
    *
    * @return the number of act items
    * @throws SystemException if a system exception occurred
    */
    public static int getActItemsCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getActItemsCount();
    }

    /**
    * Updates the act item in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param actItem the act item
    * @return the act item that was updated
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem updateActItem(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().updateActItem(actItem);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycatId(
        long catId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbycatId(catId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycompletedDate(
        java.sql.Date completedDate)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbycompletedDate(completedDate);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActivateClid(
        long ActivateClid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyActivateClid(ActivateClid);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActidcompleted(
        long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyActidcompleted(ActivateClid, completed);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchUnActItem(
        long aclid) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().searchUnActItem(aclid);
    }

    public static void clearService() {
        _service = null;
    }

    public static ActItemLocalService getService() {
        if (_service == null) {
            InvokableLocalService invokableLocalService = (InvokableLocalService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    ActItemLocalService.class.getName());

            if (invokableLocalService instanceof ActItemLocalService) {
                _service = (ActItemLocalService) invokableLocalService;
            } else {
                _service = new ActItemLocalServiceClp(invokableLocalService);
            }

            ReferenceRegistry.registerReference(ActItemLocalServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(ActItemLocalService service) {
    }
}
