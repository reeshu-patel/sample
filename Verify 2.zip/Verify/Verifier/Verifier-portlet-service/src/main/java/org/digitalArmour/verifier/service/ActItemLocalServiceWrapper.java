package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActItemLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemLocalService
 * @generated
 */
public class ActItemLocalServiceWrapper implements ActItemLocalService,
    ServiceWrapper<ActItemLocalService> {
    private ActItemLocalService _actItemLocalService;

    public ActItemLocalServiceWrapper(ActItemLocalService actItemLocalService) {
        _actItemLocalService = actItemLocalService;
    }

    /**
    * Adds the act item to the database. Also notifies the appropriate model listeners.
    *
    * @param actItem the act item
    * @return the act item that was added
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItem addActItem(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.addActItem(actItem);
    }

    /**
    * Creates a new act item with the primary key. Does not add the act item to the database.
    *
    * @param ItemId the primary key for the new act item
    * @return the new act item
    */
    @Override
    public org.digitalArmour.verifier.model.ActItem createActItem(long ItemId) {
        return _actItemLocalService.createActItem(ItemId);
    }

    /**
    * Deletes the act item with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param ItemId the primary key of the act item
    * @return the act item that was removed
    * @throws PortalException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItem deleteActItem(long ItemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.deleteActItem(ItemId);
    }

    /**
    * Deletes the act item from the database. Also notifies the appropriate model listeners.
    *
    * @param actItem the act item
    * @return the act item that was removed
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItem deleteActItem(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.deleteActItem(actItem);
    }

    @Override
    public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return _actItemLocalService.dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.dynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.dynamicQueryCount(dynamicQuery, projection);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem fetchActItem(long ItemId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.fetchActItem(ItemId);
    }

    /**
    * Returns the act item with the primary key.
    *
    * @param ItemId the primary key of the act item
    * @return the act item
    * @throws PortalException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItem getActItem(long ItemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.getActItem(ItemId);
    }

    @Override
    public com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the act items.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of act items
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> getActItems(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.getActItems(start, end);
    }

    /**
    * Returns the number of act items.
    *
    * @return the number of act items
    * @throws SystemException if a system exception occurred
    */
    @Override
    public int getActItemsCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.getActItemsCount();
    }

    /**
    * Updates the act item in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param actItem the act item
    * @return the act item that was updated
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActItem updateActItem(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.updateActItem(actItem);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actItemLocalService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actItemLocalService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actItemLocalService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycatId(
        long catId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.searchbycatId(catId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycompletedDate(
        java.sql.Date completedDate)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.searchbycompletedDate(completedDate);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActivateClid(
        long ActivateClid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.searchbyActivateClid(ActivateClid);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActidcompleted(
        long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.searchbyActidcompleted(ActivateClid,
            completed);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchUnActItem(
        long aclid) throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemLocalService.searchUnActItem(aclid);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActItemLocalService getWrappedActItemLocalService() {
        return _actItemLocalService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActItemLocalService(
        ActItemLocalService actItemLocalService) {
        _actItemLocalService = actItemLocalService;
    }

    @Override
    public ActItemLocalService getWrappedService() {
        return _actItemLocalService;
    }

    @Override
    public void setWrappedService(ActItemLocalService actItemLocalService) {
        _actItemLocalService = actItemLocalService;
    }
}
