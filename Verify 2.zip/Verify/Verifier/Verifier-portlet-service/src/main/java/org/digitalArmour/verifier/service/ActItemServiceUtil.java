package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service utility for ActItem. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.ActItemServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on a remote server. Methods of this service are expected to have security
 * checks based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemService
 * @see org.digitalArmour.verifier.service.base.ActItemServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.ActItemServiceImpl
 * @generated
 */
public class ActItemServiceUtil {
    private static ActItemService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.ActItemServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static org.digitalArmour.verifier.model.ActItem AddActiveTask(
        java.lang.String taskName, long catId, long checklistId,
        long userGroupId, long majorPer, boolean major)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService()
                   .AddActiveTask(taskName, catId, checklistId, userGroupId,
            majorPer, major);
    }

    public static org.digitalArmour.verifier.model.ActItem UpdateActiveTask(
        java.lang.String taskName, long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().UpdateActiveTask(taskName, taskId);
    }

    public static org.digitalArmour.verifier.model.ActItem UpdateTaskdetailDescription(
        java.lang.String description, long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().UpdateTaskdetailDescription(description, taskId);
    }

    public static org.digitalArmour.verifier.model.ActItem IgnoreTask(
        long IgnoreItem, long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().IgnoreTask(IgnoreItem, taskId);
    }

    public static org.digitalArmour.verifier.model.ActItem UnIgnoreTask(
        long IgnoreItem)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().UnIgnoreTask(IgnoreItem);
    }

    public static org.digitalArmour.verifier.model.ActItem ActivatetaskTask(
        long taskId, long userId, java.sql.Date date)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().ActivatetaskTask(taskId, userId, date);
    }

    public static org.digitalArmour.verifier.model.ActItem DeActivateTask(
        long taskId, long userId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().DeActivateTask(taskId, userId);
    }

    public static org.digitalArmour.verifier.model.ActItem DeleteActiveTask(
        long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().DeleteActiveTask(taskId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycatId(
        long catId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbycatId(catId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycompletedDate(
        java.sql.Date completedDate)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbycompletedDate(completedDate);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActivateClid(
        long ActivateClid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyActivateClid(ActivateClid);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActidcompleted(
        long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyActidcompleted(ActivateClid, completed);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActItem> searchUnActItem(
        long aclid) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().searchUnActItem(aclid);
    }

    public static void clearService() {
        _service = null;
    }

    public static ActItemService getService() {
        if (_service == null) {
            InvokableService invokableService = (InvokableService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    ActItemService.class.getName());

            if (invokableService instanceof ActItemService) {
                _service = (ActItemService) invokableService;
            } else {
                _service = new ActItemServiceClp(invokableService);
            }

            ReferenceRegistry.registerReference(ActItemServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(ActItemService service) {
    }
}
