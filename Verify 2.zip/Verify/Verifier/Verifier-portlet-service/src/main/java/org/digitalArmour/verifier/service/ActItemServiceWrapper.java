package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActItemService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemService
 * @generated
 */
public class ActItemServiceWrapper implements ActItemService,
    ServiceWrapper<ActItemService> {
    private ActItemService _actItemService;

    public ActItemServiceWrapper(ActItemService actItemService) {
        _actItemService = actItemService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _actItemService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _actItemService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _actItemService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem AddActiveTask(
        java.lang.String taskName, long catId, long checklistId,
        long userGroupId, long majorPer, boolean major)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.AddActiveTask(taskName, catId, checklistId,
            userGroupId, majorPer, major);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem UpdateActiveTask(
        java.lang.String taskName, long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.UpdateActiveTask(taskName, taskId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem UpdateTaskdetailDescription(
        java.lang.String description, long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.UpdateTaskdetailDescription(description, taskId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem IgnoreTask(
        long IgnoreItem, long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.IgnoreTask(IgnoreItem, taskId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem UnIgnoreTask(
        long IgnoreItem)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.UnIgnoreTask(IgnoreItem);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem ActivatetaskTask(
        long taskId, long userId, java.sql.Date date)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.ActivatetaskTask(taskId, userId, date);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem DeActivateTask(
        long taskId, long userId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.DeActivateTask(taskId, userId);
    }

    @Override
    public org.digitalArmour.verifier.model.ActItem DeleteActiveTask(
        long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.DeleteActiveTask(taskId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycatId(
        long catId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.searchbycatId(catId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbycompletedDate(
        java.sql.Date completedDate)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.searchbycompletedDate(completedDate);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActivateClid(
        long ActivateClid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.searchbyActivateClid(ActivateClid);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchbyActidcompleted(
        long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.searchbyActidcompleted(ActivateClid, completed);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActItem> searchUnActItem(
        long aclid) throws com.liferay.portal.kernel.exception.SystemException {
        return _actItemService.searchUnActItem(aclid);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActItemService getWrappedActItemService() {
        return _actItemService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActItemService(ActItemService actItemService) {
        _actItemService = actItemService;
    }

    @Override
    public ActItemService getWrappedService() {
        return _actItemService;
    }

    @Override
    public void setWrappedService(ActItemService actItemService) {
        _actItemService = actItemService;
    }
}
