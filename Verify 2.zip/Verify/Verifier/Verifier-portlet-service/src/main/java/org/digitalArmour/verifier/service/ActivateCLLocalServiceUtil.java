package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for ActivateCL. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.ActivateCLLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLLocalService
 * @see org.digitalArmour.verifier.service.base.ActivateCLLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.ActivateCLLocalServiceImpl
 * @generated
 */
public class ActivateCLLocalServiceUtil {
    private static ActivateCLLocalService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.ActivateCLLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Adds the activate c l to the database. Also notifies the appropriate model listeners.
    *
    * @param activateCL the activate c l
    * @return the activate c l that was added
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL addActivateCL(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().addActivateCL(activateCL);
    }

    /**
    * Creates a new activate c l with the primary key. Does not add the activate c l to the database.
    *
    * @param activateId the primary key for the new activate c l
    * @return the new activate c l
    */
    public static org.digitalArmour.verifier.model.ActivateCL createActivateCL(
        long activateId) {
        return getService().createActivateCL(activateId);
    }

    /**
    * Deletes the activate c l with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l that was removed
    * @throws PortalException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL deleteActivateCL(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().deleteActivateCL(activateId);
    }

    /**
    * Deletes the activate c l from the database. Also notifies the appropriate model listeners.
    *
    * @param activateCL the activate c l
    * @return the activate c l that was removed
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL deleteActivateCL(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().deleteActivateCL(activateCL);
    }

    public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return getService().dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService()
                   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    public static long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    public static long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQueryCount(dynamicQuery, projection);
    }

    public static org.digitalArmour.verifier.model.ActivateCL fetchActivateCL(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().fetchActivateCL(activateId);
    }

    /**
    * Returns the activate c l with the primary key.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l
    * @throws PortalException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL getActivateCL(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().getActivateCL(activateId);
    }

    public static com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the activate c ls.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> getActivateCLs(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getActivateCLs(start, end);
    }

    /**
    * Returns the number of activate c ls.
    *
    * @return the number of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int getActivateCLsCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getActivateCLsCount();
    }

    /**
    * Updates the activate c l in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param activateCL the activate c l
    * @return the activate c l that was updated
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL updateActivateCL(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().updateActivateCL(activateCL);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbychecklistId(
        java.lang.String checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbychecklistId(checklistId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyisCompleted(
        boolean isCompleted)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyisCompleted(isCompleted);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyactivateId(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyactivateId(activateId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> getActCLByCL(
        long id) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getActCLByCL(id);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> getByCompCL(
        boolean bol, long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getByCompCL(bol, id);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchByCompUserId(
        boolean iscompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().searchByCompUserId(iscompleted, actClUserId);
    }

    public static void clearService() {
        _service = null;
    }

    public static ActivateCLLocalService getService() {
        if (_service == null) {
            InvokableLocalService invokableLocalService = (InvokableLocalService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    ActivateCLLocalService.class.getName());

            if (invokableLocalService instanceof ActivateCLLocalService) {
                _service = (ActivateCLLocalService) invokableLocalService;
            } else {
                _service = new ActivateCLLocalServiceClp(invokableLocalService);
            }

            ReferenceRegistry.registerReference(ActivateCLLocalServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(ActivateCLLocalService service) {
    }
}
