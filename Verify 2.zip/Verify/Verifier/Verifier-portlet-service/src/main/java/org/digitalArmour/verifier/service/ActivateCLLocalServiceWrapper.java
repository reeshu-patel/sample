package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActivateCLLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLLocalService
 * @generated
 */
public class ActivateCLLocalServiceWrapper implements ActivateCLLocalService,
    ServiceWrapper<ActivateCLLocalService> {
    private ActivateCLLocalService _activateCLLocalService;

    public ActivateCLLocalServiceWrapper(
        ActivateCLLocalService activateCLLocalService) {
        _activateCLLocalService = activateCLLocalService;
    }

    /**
    * Adds the activate c l to the database. Also notifies the appropriate model listeners.
    *
    * @param activateCL the activate c l
    * @return the activate c l that was added
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActivateCL addActivateCL(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.addActivateCL(activateCL);
    }

    /**
    * Creates a new activate c l with the primary key. Does not add the activate c l to the database.
    *
    * @param activateId the primary key for the new activate c l
    * @return the new activate c l
    */
    @Override
    public org.digitalArmour.verifier.model.ActivateCL createActivateCL(
        long activateId) {
        return _activateCLLocalService.createActivateCL(activateId);
    }

    /**
    * Deletes the activate c l with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l that was removed
    * @throws PortalException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActivateCL deleteActivateCL(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.deleteActivateCL(activateId);
    }

    /**
    * Deletes the activate c l from the database. Also notifies the appropriate model listeners.
    *
    * @param activateCL the activate c l
    * @return the activate c l that was removed
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActivateCL deleteActivateCL(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.deleteActivateCL(activateCL);
    }

    @Override
    public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return _activateCLLocalService.dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.dynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.dynamicQueryCount(dynamicQuery,
            projection);
    }

    @Override
    public org.digitalArmour.verifier.model.ActivateCL fetchActivateCL(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.fetchActivateCL(activateId);
    }

    /**
    * Returns the activate c l with the primary key.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l
    * @throws PortalException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActivateCL getActivateCL(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.getActivateCL(activateId);
    }

    @Override
    public com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the activate c ls.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of activate c ls
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> getActivateCLs(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.getActivateCLs(start, end);
    }

    /**
    * Returns the number of activate c ls.
    *
    * @return the number of activate c ls
    * @throws SystemException if a system exception occurred
    */
    @Override
    public int getActivateCLsCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.getActivateCLsCount();
    }

    /**
    * Updates the activate c l in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param activateCL the activate c l
    * @return the activate c l that was updated
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.ActivateCL updateActivateCL(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.updateActivateCL(activateCL);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _activateCLLocalService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _activateCLLocalService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _activateCLLocalService.invokeMethod(name, parameterTypes,
            arguments);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbychecklistId(
        java.lang.String checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.searchbychecklistId(checklistId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyisCompleted(
        boolean isCompleted)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.searchbyisCompleted(isCompleted);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyactivateId(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.searchbyactivateId(activateId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> getActCLByCL(
        long id) throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.getActCLByCL(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> getByCompCL(
        boolean bol, long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.getByCompCL(bol, id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchByCompUserId(
        boolean iscompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLLocalService.searchByCompUserId(iscompleted,
            actClUserId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActivateCLLocalService getWrappedActivateCLLocalService() {
        return _activateCLLocalService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActivateCLLocalService(
        ActivateCLLocalService activateCLLocalService) {
        _activateCLLocalService = activateCLLocalService;
    }

    @Override
    public ActivateCLLocalService getWrappedService() {
        return _activateCLLocalService;
    }

    @Override
    public void setWrappedService(ActivateCLLocalService activateCLLocalService) {
        _activateCLLocalService = activateCLLocalService;
    }
}
