package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service utility for ActivateCL. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.ActivateCLServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on a remote server. Methods of this service are expected to have security
 * checks based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLService
 * @see org.digitalArmour.verifier.service.base.ActivateCLServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.ActivateCLServiceImpl
 * @generated
 */
public class ActivateCLServiceUtil {
    private static ActivateCLService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.ActivateCLServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static org.digitalArmour.verifier.model.ActivateCL UpdateActivatechecklist(
        long checklistId, java.lang.String checklistName)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().UpdateActivatechecklist(checklistId, checklistName);
    }

    public static org.digitalArmour.verifier.model.ActivateCL UpdateDescription(
        long checklistId, java.lang.String description)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().UpdateDescription(checklistId, description);
    }

    public static org.digitalArmour.verifier.model.ActivateCL DeletActivateCl(
        long activechecklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().DeletActivateCl(activechecklistId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbychecklistId(
        java.lang.String checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbychecklistId(checklistId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyisCompleted(
        boolean isCompleted)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyisCompleted(isCompleted);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyactivateId(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyactivateId(activateId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> getActCLByCL(
        long id) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getActCLByCL(id);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> getByCompCL(
        boolean bol, long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getByCompCL(bol, id);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchByCompUserId(
        boolean iscompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().searchByCompUserId(iscompleted, actClUserId);
    }

    public static void clearService() {
        _service = null;
    }

    public static ActivateCLService getService() {
        if (_service == null) {
            InvokableService invokableService = (InvokableService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    ActivateCLService.class.getName());

            if (invokableService instanceof ActivateCLService) {
                _service = (ActivateCLService) invokableService;
            } else {
                _service = new ActivateCLServiceClp(invokableService);
            }

            ReferenceRegistry.registerReference(ActivateCLServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(ActivateCLService service) {
    }
}
