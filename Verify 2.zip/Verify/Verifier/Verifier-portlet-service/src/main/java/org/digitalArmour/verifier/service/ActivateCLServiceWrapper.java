package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ActivateCLService}.
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLService
 * @generated
 */
public class ActivateCLServiceWrapper implements ActivateCLService,
    ServiceWrapper<ActivateCLService> {
    private ActivateCLService _activateCLService;

    public ActivateCLServiceWrapper(ActivateCLService activateCLService) {
        _activateCLService = activateCLService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _activateCLService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _activateCLService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _activateCLService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ActivateCL UpdateActivatechecklist(
        long checklistId, java.lang.String checklistName)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.UpdateActivatechecklist(checklistId,
            checklistName);
    }

    @Override
    public org.digitalArmour.verifier.model.ActivateCL UpdateDescription(
        long checklistId, java.lang.String description)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.UpdateDescription(checklistId, description);
    }

    @Override
    public org.digitalArmour.verifier.model.ActivateCL DeletActivateCl(
        long activechecklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.DeletActivateCl(activechecklistId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbychecklistId(
        java.lang.String checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.searchbychecklistId(checklistId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyisCompleted(
        boolean isCompleted)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.searchbyisCompleted(isCompleted);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchbyactivateId(
        long activateId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.searchbyactivateId(activateId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> getActCLByCL(
        long id) throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.getActCLByCL(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> getByCompCL(
        boolean bol, long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.getByCompCL(bol, id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> searchByCompUserId(
        boolean iscompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _activateCLService.searchByCompUserId(iscompleted, actClUserId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ActivateCLService getWrappedActivateCLService() {
        return _activateCLService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedActivateCLService(ActivateCLService activateCLService) {
        _activateCLService = activateCLService;
    }

    @Override
    public ActivateCLService getWrappedService() {
        return _activateCLService;
    }

    @Override
    public void setWrappedService(ActivateCLService activateCLService) {
        _activateCLService = activateCLService;
    }
}
