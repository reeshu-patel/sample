package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CLCollabService}.
 *
 * @author Brian Wing Shun Chan
 * @see CLCollabService
 * @generated
 */
public class CLCollabServiceWrapper implements CLCollabService,
    ServiceWrapper<CLCollabService> {
    private CLCollabService _clCollabService;

    public CLCollabServiceWrapper(CLCollabService clCollabService) {
        _clCollabService = clCollabService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _clCollabService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _clCollabService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _clCollabService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.CLCollab AddCollaboratorUser(
        java.lang.String collaboratorType, long userId, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clCollabService.AddCollaboratorUser(collaboratorType, userId,
            checklistId);
    }

    @Override
    public org.digitalArmour.verifier.model.CLCollab DeleteCollaboratorUser(
        long collaboratorId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clCollabService.DeleteCollaboratorUser(collaboratorId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLCollab> getCollabByCL(
        java.lang.Long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clCollabService.getCollabByCL(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLCollab> searchbyuserId(
        long userId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clCollabService.searchbyuserId(userId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public CLCollabService getWrappedCLCollabService() {
        return _clCollabService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedCLCollabService(CLCollabService clCollabService) {
        _clCollabService = clCollabService;
    }

    @Override
    public CLCollabService getWrappedService() {
        return _clCollabService;
    }

    @Override
    public void setWrappedService(CLCollabService clCollabService) {
        _clCollabService = clCollabService;
    }
}
