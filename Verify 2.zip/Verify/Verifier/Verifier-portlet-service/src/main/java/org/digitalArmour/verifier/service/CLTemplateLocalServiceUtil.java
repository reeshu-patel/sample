package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for CLTemplate. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.CLTemplateLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplateLocalService
 * @see org.digitalArmour.verifier.service.base.CLTemplateLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.CLTemplateLocalServiceImpl
 * @generated
 */
public class CLTemplateLocalServiceUtil {
    private static CLTemplateLocalService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.CLTemplateLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Adds the c l template to the database. Also notifies the appropriate model listeners.
    *
    * @param clTemplate the c l template
    * @return the c l template that was added
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLTemplate addCLTemplate(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().addCLTemplate(clTemplate);
    }

    /**
    * Creates a new c l template with the primary key. Does not add the c l template to the database.
    *
    * @param checklistId the primary key for the new c l template
    * @return the new c l template
    */
    public static org.digitalArmour.verifier.model.CLTemplate createCLTemplate(
        long checklistId) {
        return getService().createCLTemplate(checklistId);
    }

    /**
    * Deletes the c l template with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param checklistId the primary key of the c l template
    * @return the c l template that was removed
    * @throws PortalException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLTemplate deleteCLTemplate(
        long checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().deleteCLTemplate(checklistId);
    }

    /**
    * Deletes the c l template from the database. Also notifies the appropriate model listeners.
    *
    * @param clTemplate the c l template
    * @return the c l template that was removed
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLTemplate deleteCLTemplate(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().deleteCLTemplate(clTemplate);
    }

    public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return getService().dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @SuppressWarnings("rawtypes")
    public static java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService()
                   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    public static long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    public static long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().dynamicQueryCount(dynamicQuery, projection);
    }

    public static org.digitalArmour.verifier.model.CLTemplate fetchCLTemplate(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().fetchCLTemplate(checklistId);
    }

    /**
    * Returns the c l template with the primary key.
    *
    * @param checklistId the primary key of the c l template
    * @return the c l template
    * @throws PortalException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLTemplate getCLTemplate(
        long checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().getCLTemplate(checklistId);
    }

    public static com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the c l templates.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of c l templates
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLTemplate> getCLTemplates(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getCLTemplates(start, end);
    }

    /**
    * Returns the number of c l templates.
    *
    * @return the number of c l templates
    * @throws SystemException if a system exception occurred
    */
    public static int getCLTemplatesCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getCLTemplatesCount();
    }

    /**
    * Updates the c l template in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param clTemplate the c l template
    * @return the c l template that was updated
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLTemplate updateCLTemplate(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().updateCLTemplate(clTemplate);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbychecklistId(
        java.lang.String checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbychecklistId(checklistId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.CLTemplate> getallCLs()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getallCLs();
    }

    public static java.util.List<org.digitalArmour.verifier.model.CLTemplate> getallUser(
        long id) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getallUser(id);
    }

    public static java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbyisPublic(
        boolean isPublic)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyisPublic(isPublic);
    }

    public static java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbyisPubliccat(
        boolean isPubliccat)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyisPubliccat(isPubliccat);
    }

    public static void clearService() {
        _service = null;
    }

    public static CLTemplateLocalService getService() {
        if (_service == null) {
            InvokableLocalService invokableLocalService = (InvokableLocalService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    CLTemplateLocalService.class.getName());

            if (invokableLocalService instanceof CLTemplateLocalService) {
                _service = (CLTemplateLocalService) invokableLocalService;
            } else {
                _service = new CLTemplateLocalServiceClp(invokableLocalService);
            }

            ReferenceRegistry.registerReference(CLTemplateLocalServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(CLTemplateLocalService service) {
    }
}
