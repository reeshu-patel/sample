package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CLTemplateLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplateLocalService
 * @generated
 */
public class CLTemplateLocalServiceWrapper implements CLTemplateLocalService,
    ServiceWrapper<CLTemplateLocalService> {
    private CLTemplateLocalService _clTemplateLocalService;

    public CLTemplateLocalServiceWrapper(
        CLTemplateLocalService clTemplateLocalService) {
        _clTemplateLocalService = clTemplateLocalService;
    }

    /**
    * Adds the c l template to the database. Also notifies the appropriate model listeners.
    *
    * @param clTemplate the c l template
    * @return the c l template that was added
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.CLTemplate addCLTemplate(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.addCLTemplate(clTemplate);
    }

    /**
    * Creates a new c l template with the primary key. Does not add the c l template to the database.
    *
    * @param checklistId the primary key for the new c l template
    * @return the new c l template
    */
    @Override
    public org.digitalArmour.verifier.model.CLTemplate createCLTemplate(
        long checklistId) {
        return _clTemplateLocalService.createCLTemplate(checklistId);
    }

    /**
    * Deletes the c l template with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param checklistId the primary key of the c l template
    * @return the c l template that was removed
    * @throws PortalException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.CLTemplate deleteCLTemplate(
        long checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.deleteCLTemplate(checklistId);
    }

    /**
    * Deletes the c l template from the database. Also notifies the appropriate model listeners.
    *
    * @param clTemplate the c l template
    * @return the c l template that was removed
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.CLTemplate deleteCLTemplate(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.deleteCLTemplate(clTemplate);
    }

    @Override
    public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return _clTemplateLocalService.dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.dynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.dynamicQueryCount(dynamicQuery,
            projection);
    }

    @Override
    public org.digitalArmour.verifier.model.CLTemplate fetchCLTemplate(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.fetchCLTemplate(checklistId);
    }

    /**
    * Returns the c l template with the primary key.
    *
    * @param checklistId the primary key of the c l template
    * @return the c l template
    * @throws PortalException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.CLTemplate getCLTemplate(
        long checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.getCLTemplate(checklistId);
    }

    @Override
    public com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns a range of all the c l templates.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of c l templates
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> getCLTemplates(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.getCLTemplates(start, end);
    }

    /**
    * Returns the number of c l templates.
    *
    * @return the number of c l templates
    * @throws SystemException if a system exception occurred
    */
    @Override
    public int getCLTemplatesCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.getCLTemplatesCount();
    }

    /**
    * Updates the c l template in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param clTemplate the c l template
    * @return the c l template that was updated
    * @throws SystemException if a system exception occurred
    */
    @Override
    public org.digitalArmour.verifier.model.CLTemplate updateCLTemplate(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.updateCLTemplate(clTemplate);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _clTemplateLocalService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _clTemplateLocalService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _clTemplateLocalService.invokeMethod(name, parameterTypes,
            arguments);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbychecklistId(
        java.lang.String checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.searchbychecklistId(checklistId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> getallCLs()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.getallCLs();
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> getallUser(
        long id) throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.getallUser(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbyisPublic(
        boolean isPublic)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.searchbyisPublic(isPublic);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbyisPubliccat(
        boolean isPubliccat)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateLocalService.searchbyisPubliccat(isPubliccat);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public CLTemplateLocalService getWrappedCLTemplateLocalService() {
        return _clTemplateLocalService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedCLTemplateLocalService(
        CLTemplateLocalService clTemplateLocalService) {
        _clTemplateLocalService = clTemplateLocalService;
    }

    @Override
    public CLTemplateLocalService getWrappedService() {
        return _clTemplateLocalService;
    }

    @Override
    public void setWrappedService(CLTemplateLocalService clTemplateLocalService) {
        _clTemplateLocalService = clTemplateLocalService;
    }
}
