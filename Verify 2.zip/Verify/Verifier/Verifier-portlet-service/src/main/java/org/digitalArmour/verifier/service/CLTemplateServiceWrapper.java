package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CLTemplateService}.
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplateService
 * @generated
 */
public class CLTemplateServiceWrapper implements CLTemplateService,
    ServiceWrapper<CLTemplateService> {
    private CLTemplateService _clTemplateService;

    public CLTemplateServiceWrapper(CLTemplateService clTemplateService) {
        _clTemplateService = clTemplateService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _clTemplateService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _clTemplateService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _clTemplateService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.CLTemplate AddchecklistTemplate(
        long userId, java.lang.String ttile, java.lang.String description)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.AddchecklistTemplate(userId, ttile,
            description);
    }

    @Override
    public org.digitalArmour.verifier.model.CLTemplate updateChecklistTemplate(
        long checkId, java.lang.String ttile, java.lang.String description)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.updateChecklistTemplate(checkId, ttile,
            description);
    }

    @Override
    public org.digitalArmour.verifier.model.CLTemplate deletChecklistTemplate(
        long id1)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.deletChecklistTemplate(id1);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbychecklistId(
        java.lang.String checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.searchbychecklistId(checklistId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> getallCLs()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.getallCLs();
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> getallUser(
        long id) throws com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.getallUser(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbyisPublic(
        boolean isPublic)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.searchbyisPublic(isPublic);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> searchbyisPubliccat(
        boolean isPubliccat)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _clTemplateService.searchbyisPubliccat(isPubliccat);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public CLTemplateService getWrappedCLTemplateService() {
        return _clTemplateService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedCLTemplateService(CLTemplateService clTemplateService) {
        _clTemplateService = clTemplateService;
    }

    @Override
    public CLTemplateService getWrappedService() {
        return _clTemplateService;
    }

    @Override
    public void setWrappedService(CLTemplateService clTemplateService) {
        _clTemplateService = clTemplateService;
    }
}
