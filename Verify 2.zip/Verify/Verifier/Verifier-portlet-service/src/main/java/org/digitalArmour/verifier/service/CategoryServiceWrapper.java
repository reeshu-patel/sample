package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CategoryService}.
 *
 * @author Brian Wing Shun Chan
 * @see CategoryService
 * @generated
 */
public class CategoryServiceWrapper implements CategoryService,
    ServiceWrapper<CategoryService> {
    private CategoryService _categoryService;

    public CategoryServiceWrapper(CategoryService categoryService) {
        _categoryService = categoryService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _categoryService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _categoryService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _categoryService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.Category AddCategory(
        java.lang.String categoryName, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.AddCategory(categoryName, checklistId);
    }

    @Override
    public org.digitalArmour.verifier.model.Category UpdateCategory(
        java.lang.String categoryName, long categoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.UpdateCategory(categoryName, categoryId);
    }

    @Override
    public org.digitalArmour.verifier.model.Category DeleteCategory(
        long checklistId, long categoryId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.DeleteCategory(checklistId, categoryId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Category> getAllCategories()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.getAllCategories();
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Category> getCatBysubcategoryId(
        java.lang.Long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.getCatBysubcategoryId(subcategoryId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Category> getCatByChecklistId(
        java.lang.Long id)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.getCatByChecklistId(id);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Category> getBySubClID(
        java.lang.Long clid, long sid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.getBySubClID(clid, sid);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Category> getBycatId(
        long catId) throws com.liferay.portal.kernel.exception.SystemException {
        return _categoryService.getBycatId(catId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public CategoryService getWrappedCategoryService() {
        return _categoryService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedCategoryService(CategoryService categoryService) {
        _categoryService = categoryService;
    }

    @Override
    public CategoryService getWrappedService() {
        return _categoryService;
    }

    @Override
    public void setWrappedService(CategoryService categoryService) {
        _categoryService = categoryService;
    }
}
