package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayInputStream;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayOutputStream;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ClassLoaderObjectInputStream;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.BaseModel;

import org.digitalArmour.verifier.model.ActCLCollabClp;
import org.digitalArmour.verifier.model.ActCategoryClp;
import org.digitalArmour.verifier.model.ActItemClp;
import org.digitalArmour.verifier.model.ActItemCommentClp;
import org.digitalArmour.verifier.model.ActItemFileClp;
import org.digitalArmour.verifier.model.ActivateCLClp;
import org.digitalArmour.verifier.model.CLCollabClp;
import org.digitalArmour.verifier.model.CLTemplateClp;
import org.digitalArmour.verifier.model.CategoryClp;
import org.digitalArmour.verifier.model.ItemClp;
import org.digitalArmour.verifier.model.ItemCommentClp;
import org.digitalArmour.verifier.model.ItemFileClp;
import org.digitalArmour.verifier.model.ItemUserClp;
import org.digitalArmour.verifier.model.NotificationClp;
import org.digitalArmour.verifier.model.OrganizationClp;
import org.digitalArmour.verifier.model.SubcategoryClp;
import org.digitalArmour.verifier.model.tagClp;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.List;


public class ClpSerializer {
    private static Log _log = LogFactoryUtil.getLog(ClpSerializer.class);
    private static String _servletContextName;
    private static boolean _useReflectionToTranslateThrowable = true;

    public static String getServletContextName() {
        if (Validator.isNotNull(_servletContextName)) {
            return _servletContextName;
        }

        synchronized (ClpSerializer.class) {
            if (Validator.isNotNull(_servletContextName)) {
                return _servletContextName;
            }

            try {
                ClassLoader classLoader = ClpSerializer.class.getClassLoader();

                Class<?> portletPropsClass = classLoader.loadClass(
                        "com.liferay.util.portlet.PortletProps");

                Method getMethod = portletPropsClass.getMethod("get",
                        new Class<?>[] { String.class });

                String portletPropsServletContextName = (String) getMethod.invoke(null,
                        "Verifier-portlet-deployment-context");

                if (Validator.isNotNull(portletPropsServletContextName)) {
                    _servletContextName = portletPropsServletContextName;
                }
            } catch (Throwable t) {
                if (_log.isInfoEnabled()) {
                    _log.info(
                        "Unable to locate deployment context from portlet properties");
                }
            }

            if (Validator.isNull(_servletContextName)) {
                try {
                    String propsUtilServletContextName = PropsUtil.get(
                            "Verifier-portlet-deployment-context");

                    if (Validator.isNotNull(propsUtilServletContextName)) {
                        _servletContextName = propsUtilServletContextName;
                    }
                } catch (Throwable t) {
                    if (_log.isInfoEnabled()) {
                        _log.info(
                            "Unable to locate deployment context from portal properties");
                    }
                }
            }

            if (Validator.isNull(_servletContextName)) {
                _servletContextName = "Verifier-portlet";
            }

            return _servletContextName;
        }
    }

    public static Object translateInput(BaseModel<?> oldModel) {
        Class<?> oldModelClass = oldModel.getClass();

        String oldModelClassName = oldModelClass.getName();

        if (oldModelClassName.equals(ActCategoryClp.class.getName())) {
            return translateInputActCategory(oldModel);
        }

        if (oldModelClassName.equals(ActCLCollabClp.class.getName())) {
            return translateInputActCLCollab(oldModel);
        }

        if (oldModelClassName.equals(ActItemClp.class.getName())) {
            return translateInputActItem(oldModel);
        }

        if (oldModelClassName.equals(ActItemCommentClp.class.getName())) {
            return translateInputActItemComment(oldModel);
        }

        if (oldModelClassName.equals(ActItemFileClp.class.getName())) {
            return translateInputActItemFile(oldModel);
        }

        if (oldModelClassName.equals(ActivateCLClp.class.getName())) {
            return translateInputActivateCL(oldModel);
        }

        if (oldModelClassName.equals(CategoryClp.class.getName())) {
            return translateInputCategory(oldModel);
        }

        if (oldModelClassName.equals(CLCollabClp.class.getName())) {
            return translateInputCLCollab(oldModel);
        }

        if (oldModelClassName.equals(CLTemplateClp.class.getName())) {
            return translateInputCLTemplate(oldModel);
        }

        if (oldModelClassName.equals(ItemClp.class.getName())) {
            return translateInputItem(oldModel);
        }

        if (oldModelClassName.equals(ItemCommentClp.class.getName())) {
            return translateInputItemComment(oldModel);
        }

        if (oldModelClassName.equals(ItemFileClp.class.getName())) {
            return translateInputItemFile(oldModel);
        }

        if (oldModelClassName.equals(ItemUserClp.class.getName())) {
            return translateInputItemUser(oldModel);
        }

        if (oldModelClassName.equals(NotificationClp.class.getName())) {
            return translateInputNotification(oldModel);
        }

        if (oldModelClassName.equals(OrganizationClp.class.getName())) {
            return translateInputOrganization(oldModel);
        }

        if (oldModelClassName.equals(SubcategoryClp.class.getName())) {
            return translateInputSubcategory(oldModel);
        }

        if (oldModelClassName.equals(tagClp.class.getName())) {
            return translateInputtag(oldModel);
        }

        return oldModel;
    }

    public static Object translateInput(List<Object> oldList) {
        List<Object> newList = new ArrayList<Object>(oldList.size());

        for (int i = 0; i < oldList.size(); i++) {
            Object curObj = oldList.get(i);

            newList.add(translateInput(curObj));
        }

        return newList;
    }

    public static Object translateInputActCategory(BaseModel<?> oldModel) {
        ActCategoryClp oldClpModel = (ActCategoryClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getActCategoryRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputActCLCollab(BaseModel<?> oldModel) {
        ActCLCollabClp oldClpModel = (ActCLCollabClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getActCLCollabRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputActItem(BaseModel<?> oldModel) {
        ActItemClp oldClpModel = (ActItemClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getActItemRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputActItemComment(BaseModel<?> oldModel) {
        ActItemCommentClp oldClpModel = (ActItemCommentClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getActItemCommentRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputActItemFile(BaseModel<?> oldModel) {
        ActItemFileClp oldClpModel = (ActItemFileClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getActItemFileRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputActivateCL(BaseModel<?> oldModel) {
        ActivateCLClp oldClpModel = (ActivateCLClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getActivateCLRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputCategory(BaseModel<?> oldModel) {
        CategoryClp oldClpModel = (CategoryClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getCategoryRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputCLCollab(BaseModel<?> oldModel) {
        CLCollabClp oldClpModel = (CLCollabClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getCLCollabRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputCLTemplate(BaseModel<?> oldModel) {
        CLTemplateClp oldClpModel = (CLTemplateClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getCLTemplateRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputItem(BaseModel<?> oldModel) {
        ItemClp oldClpModel = (ItemClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getItemRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputItemComment(BaseModel<?> oldModel) {
        ItemCommentClp oldClpModel = (ItemCommentClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getItemCommentRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputItemFile(BaseModel<?> oldModel) {
        ItemFileClp oldClpModel = (ItemFileClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getItemFileRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputItemUser(BaseModel<?> oldModel) {
        ItemUserClp oldClpModel = (ItemUserClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getItemUserRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputNotification(BaseModel<?> oldModel) {
        NotificationClp oldClpModel = (NotificationClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getNotificationRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputOrganization(BaseModel<?> oldModel) {
        OrganizationClp oldClpModel = (OrganizationClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getOrganizationRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputSubcategory(BaseModel<?> oldModel) {
        SubcategoryClp oldClpModel = (SubcategoryClp) oldModel;

        BaseModel<?> newModel = oldClpModel.getSubcategoryRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInputtag(BaseModel<?> oldModel) {
        tagClp oldClpModel = (tagClp) oldModel;

        BaseModel<?> newModel = oldClpModel.gettagRemoteModel();

        newModel.setModelAttributes(oldClpModel.getModelAttributes());

        return newModel;
    }

    public static Object translateInput(Object obj) {
        if (obj instanceof BaseModel<?>) {
            return translateInput((BaseModel<?>) obj);
        } else if (obj instanceof List<?>) {
            return translateInput((List<Object>) obj);
        } else {
            return obj;
        }
    }

    public static Object translateOutput(BaseModel<?> oldModel) {
        Class<?> oldModelClass = oldModel.getClass();

        String oldModelClassName = oldModelClass.getName();

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ActCategoryImpl")) {
            return translateOutputActCategory(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ActCLCollabImpl")) {
            return translateOutputActCLCollab(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ActItemImpl")) {
            return translateOutputActItem(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ActItemCommentImpl")) {
            return translateOutputActItemComment(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ActItemFileImpl")) {
            return translateOutputActItemFile(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ActivateCLImpl")) {
            return translateOutputActivateCL(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.CategoryImpl")) {
            return translateOutputCategory(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.CLCollabImpl")) {
            return translateOutputCLCollab(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.CLTemplateImpl")) {
            return translateOutputCLTemplate(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ItemImpl")) {
            return translateOutputItem(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ItemCommentImpl")) {
            return translateOutputItemComment(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ItemFileImpl")) {
            return translateOutputItemFile(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.ItemUserImpl")) {
            return translateOutputItemUser(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.NotificationImpl")) {
            return translateOutputNotification(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.OrganizationImpl")) {
            return translateOutputOrganization(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.SubcategoryImpl")) {
            return translateOutputSubcategory(oldModel);
        }

        if (oldModelClassName.equals(
                    "org.digitalArmour.verifier.model.impl.tagImpl")) {
            return translateOutputtag(oldModel);
        }

        return oldModel;
    }

    public static Object translateOutput(List<Object> oldList) {
        List<Object> newList = new ArrayList<Object>(oldList.size());

        for (int i = 0; i < oldList.size(); i++) {
            Object curObj = oldList.get(i);

            newList.add(translateOutput(curObj));
        }

        return newList;
    }

    public static Object translateOutput(Object obj) {
        if (obj instanceof BaseModel<?>) {
            return translateOutput((BaseModel<?>) obj);
        } else if (obj instanceof List<?>) {
            return translateOutput((List<Object>) obj);
        } else {
            return obj;
        }
    }

    public static Throwable translateThrowable(Throwable throwable) {
        if (_useReflectionToTranslateThrowable) {
            try {
                UnsyncByteArrayOutputStream unsyncByteArrayOutputStream = new UnsyncByteArrayOutputStream();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(unsyncByteArrayOutputStream);

                objectOutputStream.writeObject(throwable);

                objectOutputStream.flush();
                objectOutputStream.close();

                UnsyncByteArrayInputStream unsyncByteArrayInputStream = new UnsyncByteArrayInputStream(unsyncByteArrayOutputStream.unsafeGetByteArray(),
                        0, unsyncByteArrayOutputStream.size());

                Thread currentThread = Thread.currentThread();

                ClassLoader contextClassLoader = currentThread.getContextClassLoader();

                ObjectInputStream objectInputStream = new ClassLoaderObjectInputStream(unsyncByteArrayInputStream,
                        contextClassLoader);

                throwable = (Throwable) objectInputStream.readObject();

                objectInputStream.close();

                return throwable;
            } catch (SecurityException se) {
                if (_log.isInfoEnabled()) {
                    _log.info("Do not use reflection to translate throwable");
                }

                _useReflectionToTranslateThrowable = false;
            } catch (Throwable throwable2) {
                _log.error(throwable2, throwable2);

                return throwable2;
            }
        }

        Class<?> clazz = throwable.getClass();

        String className = clazz.getName();

        if (className.equals(PortalException.class.getName())) {
            return new PortalException();
        }

        if (className.equals(SystemException.class.getName())) {
            return new SystemException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchActCategoryException")) {
            return new org.digitalArmour.verifier.NoSuchActCategoryException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchActCLCollabException")) {
            return new org.digitalArmour.verifier.NoSuchActCLCollabException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchActItemException")) {
            return new org.digitalArmour.verifier.NoSuchActItemException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchActItemCommentException")) {
            return new org.digitalArmour.verifier.NoSuchActItemCommentException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchActItemFileException")) {
            return new org.digitalArmour.verifier.NoSuchActItemFileException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchActivateCLException")) {
            return new org.digitalArmour.verifier.NoSuchActivateCLException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchCategoryException")) {
            return new org.digitalArmour.verifier.NoSuchCategoryException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchCLCollabException")) {
            return new org.digitalArmour.verifier.NoSuchCLCollabException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchCLTemplateException")) {
            return new org.digitalArmour.verifier.NoSuchCLTemplateException();
        }

        if (className.equals("org.digitalArmour.verifier.NoSuchItemException")) {
            return new org.digitalArmour.verifier.NoSuchItemException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchItemCommentException")) {
            return new org.digitalArmour.verifier.NoSuchItemCommentException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchItemFileException")) {
            return new org.digitalArmour.verifier.NoSuchItemFileException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchItemUserException")) {
            return new org.digitalArmour.verifier.NoSuchItemUserException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchNotificationException")) {
            return new org.digitalArmour.verifier.NoSuchNotificationException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchOrganizationException")) {
            return new org.digitalArmour.verifier.NoSuchOrganizationException();
        }

        if (className.equals(
                    "org.digitalArmour.verifier.NoSuchSubcategoryException")) {
            return new org.digitalArmour.verifier.NoSuchSubcategoryException();
        }

        if (className.equals("org.digitalArmour.verifier.NoSuchtagException")) {
            return new org.digitalArmour.verifier.NoSuchtagException();
        }

        return throwable;
    }

    public static Object translateOutputActCategory(BaseModel<?> oldModel) {
        ActCategoryClp newModel = new ActCategoryClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setActCategoryRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputActCLCollab(BaseModel<?> oldModel) {
        ActCLCollabClp newModel = new ActCLCollabClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setActCLCollabRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputActItem(BaseModel<?> oldModel) {
        ActItemClp newModel = new ActItemClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setActItemRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputActItemComment(BaseModel<?> oldModel) {
        ActItemCommentClp newModel = new ActItemCommentClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setActItemCommentRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputActItemFile(BaseModel<?> oldModel) {
        ActItemFileClp newModel = new ActItemFileClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setActItemFileRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputActivateCL(BaseModel<?> oldModel) {
        ActivateCLClp newModel = new ActivateCLClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setActivateCLRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputCategory(BaseModel<?> oldModel) {
        CategoryClp newModel = new CategoryClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setCategoryRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputCLCollab(BaseModel<?> oldModel) {
        CLCollabClp newModel = new CLCollabClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setCLCollabRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputCLTemplate(BaseModel<?> oldModel) {
        CLTemplateClp newModel = new CLTemplateClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setCLTemplateRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputItem(BaseModel<?> oldModel) {
        ItemClp newModel = new ItemClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setItemRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputItemComment(BaseModel<?> oldModel) {
        ItemCommentClp newModel = new ItemCommentClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setItemCommentRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputItemFile(BaseModel<?> oldModel) {
        ItemFileClp newModel = new ItemFileClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setItemFileRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputItemUser(BaseModel<?> oldModel) {
        ItemUserClp newModel = new ItemUserClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setItemUserRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputNotification(BaseModel<?> oldModel) {
        NotificationClp newModel = new NotificationClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setNotificationRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputOrganization(BaseModel<?> oldModel) {
        OrganizationClp newModel = new OrganizationClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setOrganizationRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputSubcategory(BaseModel<?> oldModel) {
        SubcategoryClp newModel = new SubcategoryClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.setSubcategoryRemoteModel(oldModel);

        return newModel;
    }

    public static Object translateOutputtag(BaseModel<?> oldModel) {
        tagClp newModel = new tagClp();

        newModel.setModelAttributes(oldModel.getModelAttributes());

        newModel.settagRemoteModel(oldModel);

        return newModel;
    }
}
