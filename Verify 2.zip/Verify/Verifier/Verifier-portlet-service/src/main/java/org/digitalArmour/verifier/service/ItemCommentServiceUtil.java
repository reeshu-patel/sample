package org.digitalArmour.verifier.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableService;

/**
 * Provides the remote service utility for ItemComment. This utility wraps
 * {@link org.digitalArmour.verifier.service.impl.ItemCommentServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on a remote server. Methods of this service are expected to have security
 * checks based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author Brian Wing Shun Chan
 * @see ItemCommentService
 * @see org.digitalArmour.verifier.service.base.ItemCommentServiceBaseImpl
 * @see org.digitalArmour.verifier.service.impl.ItemCommentServiceImpl
 * @generated
 */
public class ItemCommentServiceUtil {
    private static ItemCommentService _service;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Add custom service methods to {@link org.digitalArmour.verifier.service.impl.ItemCommentServiceImpl} and rerun ServiceBuilder to regenerate this class.
     */

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    public static java.lang.String getBeanIdentifier() {
        return getService().getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    public static void setBeanIdentifier(java.lang.String beanIdentifier) {
        getService().setBeanIdentifier(beanIdentifier);
    }

    public static java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return getService().invokeMethod(name, parameterTypes, arguments);
    }

    public static org.digitalArmour.verifier.model.ItemComment AddComment(
        long userId, long taskId, java.lang.String commMassage)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().AddComment(userId, taskId, commMassage);
    }

    public static org.digitalArmour.verifier.model.ItemComment UpdateComment(
        long commentId, java.lang.String commMassage)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().UpdateComment(commentId, commMassage);
    }

    public static org.digitalArmour.verifier.model.ItemComment DeleteComment(
        long commentId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().DeleteComment(commentId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ItemComment> getAllComments(
        long itemId) throws com.liferay.portal.kernel.exception.SystemException {
        return getService().getAllComments(itemId);
    }

    public static java.util.List<org.digitalArmour.verifier.model.ItemComment> searchbyitemId(
        long itemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return getService().searchbyitemId(itemId);
    }

    public static void clearService() {
        _service = null;
    }

    public static ItemCommentService getService() {
        if (_service == null) {
            InvokableService invokableService = (InvokableService) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
                    ItemCommentService.class.getName());

            if (invokableService instanceof ItemCommentService) {
                _service = (ItemCommentService) invokableService;
            } else {
                _service = new ItemCommentServiceClp(invokableService);
            }

            ReferenceRegistry.registerReference(ItemCommentServiceUtil.class,
                "_service");
        }

        return _service;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setService(ItemCommentService service) {
    }
}
