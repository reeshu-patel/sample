package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ItemCommentService}.
 *
 * @author Brian Wing Shun Chan
 * @see ItemCommentService
 * @generated
 */
public class ItemCommentServiceWrapper implements ItemCommentService,
    ServiceWrapper<ItemCommentService> {
    private ItemCommentService _itemCommentService;

    public ItemCommentServiceWrapper(ItemCommentService itemCommentService) {
        _itemCommentService = itemCommentService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _itemCommentService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _itemCommentService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _itemCommentService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ItemComment AddComment(
        long userId, long taskId, java.lang.String commMassage)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemCommentService.AddComment(userId, taskId, commMassage);
    }

    @Override
    public org.digitalArmour.verifier.model.ItemComment UpdateComment(
        long commentId, java.lang.String commMassage)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemCommentService.UpdateComment(commentId, commMassage);
    }

    @Override
    public org.digitalArmour.verifier.model.ItemComment DeleteComment(
        long commentId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemCommentService.DeleteComment(commentId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ItemComment> getAllComments(
        long itemId) throws com.liferay.portal.kernel.exception.SystemException {
        return _itemCommentService.getAllComments(itemId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ItemComment> searchbyitemId(
        long itemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemCommentService.searchbyitemId(itemId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ItemCommentService getWrappedItemCommentService() {
        return _itemCommentService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedItemCommentService(
        ItemCommentService itemCommentService) {
        _itemCommentService = itemCommentService;
    }

    @Override
    public ItemCommentService getWrappedService() {
        return _itemCommentService;
    }

    @Override
    public void setWrappedService(ItemCommentService itemCommentService) {
        _itemCommentService = itemCommentService;
    }
}
