package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ItemFileService}.
 *
 * @author Brian Wing Shun Chan
 * @see ItemFileService
 * @generated
 */
public class ItemFileServiceWrapper implements ItemFileService,
    ServiceWrapper<ItemFileService> {
    private ItemFileService _itemFileService;

    public ItemFileServiceWrapper(ItemFileService itemFileService) {
        _itemFileService = itemFileService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _itemFileService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _itemFileService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _itemFileService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.ItemFile AddTaskFile(long taskId,
        java.lang.String sourceFileName, long userId, java.lang.String file)
        throws com.liferay.portal.kernel.exception.SystemException,
            java.io.IOException {
        return _itemFileService.AddTaskFile(taskId, sourceFileName, userId, file);
    }

    @Override
    public org.digitalArmour.verifier.model.ItemFile DeleteTaskFile(long fileId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemFileService.DeleteTaskFile(fileId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> getAllFiles(
        long itemId) throws com.liferay.portal.kernel.exception.SystemException {
        return _itemFileService.getAllFiles(itemId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> searchbyItemId(
        long ItemId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemFileService.searchbyItemId(ItemId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ItemFileService getWrappedItemFileService() {
        return _itemFileService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedItemFileService(ItemFileService itemFileService) {
        _itemFileService = itemFileService;
    }

    @Override
    public ItemFileService getWrappedService() {
        return _itemFileService;
    }

    @Override
    public void setWrappedService(ItemFileService itemFileService) {
        _itemFileService = itemFileService;
    }
}
