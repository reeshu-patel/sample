package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ItemService}.
 *
 * @author Brian Wing Shun Chan
 * @see ItemService
 * @generated
 */
public class ItemServiceWrapper implements ItemService,
    ServiceWrapper<ItemService> {
    private ItemService _itemService;

    public ItemServiceWrapper(ItemService itemService) {
        _itemService = itemService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _itemService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _itemService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _itemService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.Item AddTask(long checklistId,
        java.lang.String taskName, long catId, long userGoupid,
        java.lang.String major, long majorweight)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _itemService.AddTask(checklistId, taskName, catId, userGoupid,
            major, majorweight);
    }

    @Override
    public org.digitalArmour.verifier.model.Item UpdateTask(long taskId,
        java.lang.String taskName)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemService.UpdateTask(taskId, taskName);
    }

    @Override
    public org.digitalArmour.verifier.model.Item DeleteTask(long taskId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemService.DeleteTask(taskId);
    }

    @Override
    public org.digitalArmour.verifier.model.Item UpdateDiscriptionTask(
        long taskId, java.lang.String taskDescription)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemService.UpdateDiscriptionTask(taskId, taskDescription);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Item> searchbycatId(
        long catId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _itemService.searchbycatId(catId);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Item> getAllitems()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _itemService.getAllitems();
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.Item> searchByCheckId(
        long ckid) throws com.liferay.portal.kernel.exception.SystemException {
        return _itemService.searchByCheckId(ckid);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ItemService getWrappedItemService() {
        return _itemService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedItemService(ItemService itemService) {
        _itemService = itemService;
    }

    @Override
    public ItemService getWrappedService() {
        return _itemService;
    }

    @Override
    public void setWrappedService(ItemService itemService) {
        _itemService = itemService;
    }
}
