package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link SubcategoryService}.
 *
 * @author Brian Wing Shun Chan
 * @see SubcategoryService
 * @generated
 */
public class SubcategoryServiceWrapper implements SubcategoryService,
    ServiceWrapper<SubcategoryService> {
    private SubcategoryService _subcategoryService;

    public SubcategoryServiceWrapper(SubcategoryService subcategoryService) {
        _subcategoryService = subcategoryService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _subcategoryService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _subcategoryService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _subcategoryService.invokeMethod(name, parameterTypes, arguments);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public SubcategoryService getWrappedSubcategoryService() {
        return _subcategoryService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedSubcategoryService(
        SubcategoryService subcategoryService) {
        _subcategoryService = subcategoryService;
    }

    @Override
    public SubcategoryService getWrappedService() {
        return _subcategoryService;
    }

    @Override
    public void setWrappedService(SubcategoryService subcategoryService) {
        _subcategoryService = subcategoryService;
    }
}
