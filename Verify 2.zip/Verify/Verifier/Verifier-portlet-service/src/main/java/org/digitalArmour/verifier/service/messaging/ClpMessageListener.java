package org.digitalArmour.verifier.service.messaging;

import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.Message;

import org.digitalArmour.verifier.service.ActCLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.ActCLCollabServiceUtil;
import org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ActCategoryServiceUtil;
import org.digitalArmour.verifier.service.ActItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemCommentServiceUtil;
import org.digitalArmour.verifier.service.ActItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemFileServiceUtil;
import org.digitalArmour.verifier.service.ActItemLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemServiceUtil;
import org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil;
import org.digitalArmour.verifier.service.ActivateCLServiceUtil;
import org.digitalArmour.verifier.service.CLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.CLCollabServiceUtil;
import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;
import org.digitalArmour.verifier.service.CLTemplateServiceUtil;
import org.digitalArmour.verifier.service.CategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.CategoryServiceUtil;
import org.digitalArmour.verifier.service.ClpSerializer;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemCommentServiceUtil;
import org.digitalArmour.verifier.service.ItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemFileServiceUtil;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemServiceUtil;
import org.digitalArmour.verifier.service.ItemUserLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemUserServiceUtil;
import org.digitalArmour.verifier.service.NotificationLocalServiceUtil;
import org.digitalArmour.verifier.service.NotificationServiceUtil;
import org.digitalArmour.verifier.service.OrganizationLocalServiceUtil;
import org.digitalArmour.verifier.service.OrganizationServiceUtil;
import org.digitalArmour.verifier.service.SubcategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.SubcategoryServiceUtil;
import org.digitalArmour.verifier.service.tagLocalServiceUtil;
import org.digitalArmour.verifier.service.tagServiceUtil;


public class ClpMessageListener extends BaseMessageListener {
    public static String getServletContextName() {
        return ClpSerializer.getServletContextName();
    }

    @Override
    protected void doReceive(Message message) throws Exception {
        String command = message.getString("command");
        String servletContextName = message.getString("servletContextName");

        if (command.equals("undeploy") &&
                servletContextName.equals(getServletContextName())) {
            ActCategoryLocalServiceUtil.clearService();

            ActCategoryServiceUtil.clearService();
            ActCLCollabLocalServiceUtil.clearService();

            ActCLCollabServiceUtil.clearService();
            ActItemLocalServiceUtil.clearService();

            ActItemServiceUtil.clearService();
            ActItemCommentLocalServiceUtil.clearService();

            ActItemCommentServiceUtil.clearService();
            ActItemFileLocalServiceUtil.clearService();

            ActItemFileServiceUtil.clearService();
            ActivateCLLocalServiceUtil.clearService();

            ActivateCLServiceUtil.clearService();
            CategoryLocalServiceUtil.clearService();

            CategoryServiceUtil.clearService();
            CLCollabLocalServiceUtil.clearService();

            CLCollabServiceUtil.clearService();
            CLTemplateLocalServiceUtil.clearService();

            CLTemplateServiceUtil.clearService();
            ItemLocalServiceUtil.clearService();

            ItemServiceUtil.clearService();
            ItemCommentLocalServiceUtil.clearService();

            ItemCommentServiceUtil.clearService();
            ItemFileLocalServiceUtil.clearService();

            ItemFileServiceUtil.clearService();
            ItemUserLocalServiceUtil.clearService();

            ItemUserServiceUtil.clearService();
            NotificationLocalServiceUtil.clearService();

            NotificationServiceUtil.clearService();
            OrganizationLocalServiceUtil.clearService();

            OrganizationServiceUtil.clearService();
            SubcategoryLocalServiceUtil.clearService();

            SubcategoryServiceUtil.clearService();
            tagLocalServiceUtil.clearService();

            tagServiceUtil.clearService();
        }
    }
}
