package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.ActCLCollab;
import org.digitalArmour.verifier.service.ActCLCollabLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ActCLCollabActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ActCLCollabActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ActCLCollabLocalServiceUtil.getService());
        setClass(ActCLCollab.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("actClCollabId");
    }
}
