package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.ActCLCollab;

/**
 * The persistence interface for the act c l collab service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActCLCollabPersistenceImpl
 * @see ActCLCollabUtil
 * @generated
 */
public interface ActCLCollabPersistence extends BasePersistence<ActCLCollab> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link ActCLCollabUtil} to access the act c l collab persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the act c l collabs where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act c l collabs where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @return the range of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act c l collabs where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Returns the first act c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act c l collab, or <code>null</code> if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Returns the last act c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act c l collab, or <code>null</code> if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act c l collabs before and after the current act c l collab in the ordered set where uuid = &#63;.
    *
    * @param actClCollabId the primary key of the current act c l collab
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab[] findByUuid_PrevAndNext(
        long actClCollabId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Removes all the act c l collabs where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act c l collabs where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act c l collabs where actChecklistId = &#63;.
    *
    * @param actChecklistId the act checklist ID
    * @return the matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByCollab_ActCL(
        long actChecklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act c l collabs where actChecklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param actChecklistId the act checklist ID
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @return the range of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByCollab_ActCL(
        long actChecklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act c l collabs where actChecklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param actChecklistId the act checklist ID
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByCollab_ActCL(
        long actChecklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act c l collab in the ordered set where actChecklistId = &#63;.
    *
    * @param actChecklistId the act checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab findByCollab_ActCL_First(
        long actChecklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Returns the first act c l collab in the ordered set where actChecklistId = &#63;.
    *
    * @param actChecklistId the act checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act c l collab, or <code>null</code> if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab fetchByCollab_ActCL_First(
        long actChecklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act c l collab in the ordered set where actChecklistId = &#63;.
    *
    * @param actChecklistId the act checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab findByCollab_ActCL_Last(
        long actChecklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Returns the last act c l collab in the ordered set where actChecklistId = &#63;.
    *
    * @param actChecklistId the act checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act c l collab, or <code>null</code> if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab fetchByCollab_ActCL_Last(
        long actChecklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act c l collabs before and after the current act c l collab in the ordered set where actChecklistId = &#63;.
    *
    * @param actClCollabId the primary key of the current act c l collab
    * @param actChecklistId the act checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab[] findByCollab_ActCL_PrevAndNext(
        long actClCollabId, long actChecklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Removes all the act c l collabs where actChecklistId = &#63; from the database.
    *
    * @param actChecklistId the act checklist ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByCollab_ActCL(long actChecklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act c l collabs where actChecklistId = &#63;.
    *
    * @param actChecklistId the act checklist ID
    * @return the number of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public int countByCollab_ActCL(long actChecklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act c l collabs where userId = &#63;.
    *
    * @param userId the user ID
    * @return the matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByuserId(
        long userId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act c l collabs where userId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param userId the user ID
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @return the range of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByuserId(
        long userId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act c l collabs where userId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param userId the user ID
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findByuserId(
        long userId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab findByuserId_First(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Returns the first act c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act c l collab, or <code>null</code> if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab fetchByuserId_First(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab findByuserId_Last(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Returns the last act c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act c l collab, or <code>null</code> if a matching act c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab fetchByuserId_Last(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act c l collabs before and after the current act c l collab in the ordered set where userId = &#63;.
    *
    * @param actClCollabId the primary key of the current act c l collab
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab[] findByuserId_PrevAndNext(
        long actClCollabId, long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Removes all the act c l collabs where userId = &#63; from the database.
    *
    * @param userId the user ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByuserId(long userId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act c l collabs where userId = &#63;.
    *
    * @param userId the user ID
    * @return the number of matching act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public int countByuserId(long userId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the act c l collab in the entity cache if it is enabled.
    *
    * @param actCLCollab the act c l collab
    */
    public void cacheResult(
        org.digitalArmour.verifier.model.ActCLCollab actCLCollab);

    /**
    * Caches the act c l collabs in the entity cache if it is enabled.
    *
    * @param actCLCollabs the act c l collabs
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ActCLCollab> actCLCollabs);

    /**
    * Creates a new act c l collab with the primary key. Does not add the act c l collab to the database.
    *
    * @param actClCollabId the primary key for the new act c l collab
    * @return the new act c l collab
    */
    public org.digitalArmour.verifier.model.ActCLCollab create(
        long actClCollabId);

    /**
    * Removes the act c l collab with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param actClCollabId the primary key of the act c l collab
    * @return the act c l collab that was removed
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab remove(
        long actClCollabId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    public org.digitalArmour.verifier.model.ActCLCollab updateImpl(
        org.digitalArmour.verifier.model.ActCLCollab actCLCollab)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act c l collab with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActCLCollabException} if it could not be found.
    *
    * @param actClCollabId the primary key of the act c l collab
    * @return the act c l collab
    * @throws org.digitalArmour.verifier.NoSuchActCLCollabException if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab findByPrimaryKey(
        long actClCollabId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCLCollabException;

    /**
    * Returns the act c l collab with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param actClCollabId the primary key of the act c l collab
    * @return the act c l collab, or <code>null</code> if a act c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCLCollab fetchByPrimaryKey(
        long actClCollabId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act c l collabs.
    *
    * @return the act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act c l collabs.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @return the range of act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act c l collabs.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act c l collabs
    * @param end the upper bound of the range of act c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCLCollab> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the act c l collabs from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act c l collabs.
    *
    * @return the number of act c l collabs
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
