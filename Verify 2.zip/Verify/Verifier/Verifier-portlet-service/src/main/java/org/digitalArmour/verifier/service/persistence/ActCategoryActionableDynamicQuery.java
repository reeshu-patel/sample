package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ActCategoryActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ActCategoryActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ActCategoryLocalServiceUtil.getService());
        setClass(ActCategory.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("ActCategoryId");
    }
}
