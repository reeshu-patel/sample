package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.ActCategory;

/**
 * The persistence interface for the act category service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActCategoryPersistenceImpl
 * @see ActCategoryUtil
 * @generated
 */
public interface ActCategoryPersistence extends BasePersistence<ActCategory> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link ActCategoryUtil} to access the act category persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the act categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the first act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the last act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act categories before and after the current act category in the ordered set where uuid = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory[] findByUuid_PrevAndNext(
        long ActCategoryId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Removes all the act categories where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act categories where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClId(
        long ActiveCheckListID)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act categories where ActiveCheckListID = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClId(
        long ActiveCheckListID, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act categories where ActiveCheckListID = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClId(
        long ActiveCheckListID, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByActiveClId_First(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByActiveClId_First(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByActiveClId_Last(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByActiveClId_Last(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act categories before and after the current act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory[] findByActiveClId_PrevAndNext(
        long ActCategoryId, long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Removes all the act categories where ActiveCheckListID = &#63; from the database.
    *
    * @param ActiveCheckListID the active check list i d
    * @throws SystemException if a system exception occurred
    */
    public void removeByActiveClId(long ActiveCheckListID)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act categories where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public int countByActiveClId(long ActiveCheckListID)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act categories where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveCatId(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act categories where ActCategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActCategoryId the act category ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveCatId(
        long ActCategoryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act categories where ActCategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActCategoryId the act category ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveCatId(
        long ActCategoryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByActiveCatId_First(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the first act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByActiveCatId_First(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByActiveCatId_Last(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the last act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByActiveCatId_Last(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the act categories where ActCategoryId = &#63; from the database.
    *
    * @param ActCategoryId the act category ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByActiveCatId(long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act categories where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public int countByActiveCatId(long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClSubId(
        long ActiveCheckListID, long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClSubId(
        long ActiveCheckListID, long SubCatogryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClSubId(
        long ActiveCheckListID, long SubCatogryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByActiveClSubId_First(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByActiveClSubId_First(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByActiveClSubId_Last(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByActiveClSubId_Last(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act categories before and after the current act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory[] findByActiveClSubId_PrevAndNext(
        long ActCategoryId, long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Removes all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63; from the database.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByActiveClSubId(long ActiveCheckListID, long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public int countByActiveClSubId(long ActiveCheckListID, long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act categories where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findBySubCatogryId(
        long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act categories where SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findBySubCatogryId(
        long SubCatogryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act categories where SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findBySubCatogryId(
        long SubCatogryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findBySubCatogryId_First(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the first act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchBySubCatogryId_First(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findBySubCatogryId_Last(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the last act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchBySubCatogryId_Last(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act categories before and after the current act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory[] findBySubCatogryId_PrevAndNext(
        long ActCategoryId, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Removes all the act categories where SubCatogryId = &#63; from the database.
    *
    * @param SubCatogryId the sub catogry ID
    * @throws SystemException if a system exception occurred
    */
    public void removeBySubCatogryId(long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act categories where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public int countBySubCatogryId(long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the act category in the entity cache if it is enabled.
    *
    * @param actCategory the act category
    */
    public void cacheResult(
        org.digitalArmour.verifier.model.ActCategory actCategory);

    /**
    * Caches the act categories in the entity cache if it is enabled.
    *
    * @param actCategories the act categories
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ActCategory> actCategories);

    /**
    * Creates a new act category with the primary key. Does not add the act category to the database.
    *
    * @param ActCategoryId the primary key for the new act category
    * @return the new act category
    */
    public org.digitalArmour.verifier.model.ActCategory create(
        long ActCategoryId);

    /**
    * Removes the act category with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category that was removed
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory remove(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    public org.digitalArmour.verifier.model.ActCategory updateImpl(
        org.digitalArmour.verifier.model.ActCategory actCategory)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act category with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActCategoryException} if it could not be found.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory findByPrimaryKey(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException;

    /**
    * Returns the act category with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category, or <code>null</code> if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActCategory fetchByPrimaryKey(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act categories.
    *
    * @return the act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of act categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActCategory> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the act categories from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act categories.
    *
    * @return the number of act categories
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
