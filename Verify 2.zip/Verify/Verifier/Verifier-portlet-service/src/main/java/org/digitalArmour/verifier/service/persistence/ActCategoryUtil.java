package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import org.digitalArmour.verifier.model.ActCategory;

import java.util.List;

/**
 * The persistence utility for the act category service. This utility wraps {@link ActCategoryPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActCategoryPersistence
 * @see ActCategoryPersistenceImpl
 * @generated
 */
public class ActCategoryUtil {
    private static ActCategoryPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(ActCategory actCategory) {
        getPersistence().clearCache(actCategory);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<ActCategory> findWithDynamicQuery(
        DynamicQuery dynamicQuery) throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<ActCategory> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<ActCategory> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static ActCategory update(ActCategory actCategory)
        throws SystemException {
        return getPersistence().update(actCategory);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static ActCategory update(ActCategory actCategory,
        ServiceContext serviceContext) throws SystemException {
        return getPersistence().update(actCategory, serviceContext);
    }

    /**
    * Returns all the act categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the act categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the act categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the act categories before and after the current act category in the ordered set where uuid = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory[] findByUuid_PrevAndNext(
        long ActCategoryId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByUuid_PrevAndNext(ActCategoryId, uuid,
            orderByComparator);
    }

    /**
    * Removes all the act categories where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of act categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Returns all the act categories where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClId(
        long ActiveCheckListID)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByActiveClId(ActiveCheckListID);
    }

    /**
    * Returns a range of all the act categories where ActiveCheckListID = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClId(
        long ActiveCheckListID, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByActiveClId(ActiveCheckListID, start, end);
    }

    /**
    * Returns an ordered range of all the act categories where ActiveCheckListID = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClId(
        long ActiveCheckListID, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActiveClId(ActiveCheckListID, start, end,
            orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByActiveClId_First(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveClId_First(ActiveCheckListID, orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByActiveClId_First(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActiveClId_First(ActiveCheckListID, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByActiveClId_Last(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveClId_Last(ActiveCheckListID, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByActiveClId_Last(
        long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActiveClId_Last(ActiveCheckListID, orderByComparator);
    }

    /**
    * Returns the act categories before and after the current act category in the ordered set where ActiveCheckListID = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param ActiveCheckListID the active check list i d
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory[] findByActiveClId_PrevAndNext(
        long ActCategoryId, long ActiveCheckListID,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveClId_PrevAndNext(ActCategoryId,
            ActiveCheckListID, orderByComparator);
    }

    /**
    * Removes all the act categories where ActiveCheckListID = &#63; from the database.
    *
    * @param ActiveCheckListID the active check list i d
    * @throws SystemException if a system exception occurred
    */
    public static void removeByActiveClId(long ActiveCheckListID)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByActiveClId(ActiveCheckListID);
    }

    /**
    * Returns the number of act categories where ActiveCheckListID = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static int countByActiveClId(long ActiveCheckListID)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByActiveClId(ActiveCheckListID);
    }

    /**
    * Returns all the act categories where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveCatId(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByActiveCatId(ActCategoryId);
    }

    /**
    * Returns a range of all the act categories where ActCategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActCategoryId the act category ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveCatId(
        long ActCategoryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByActiveCatId(ActCategoryId, start, end);
    }

    /**
    * Returns an ordered range of all the act categories where ActCategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActCategoryId the act category ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveCatId(
        long ActCategoryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActiveCatId(ActCategoryId, start, end,
            orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByActiveCatId_First(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveCatId_First(ActCategoryId, orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByActiveCatId_First(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActiveCatId_First(ActCategoryId, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByActiveCatId_Last(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveCatId_Last(ActCategoryId, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByActiveCatId_Last(
        long ActCategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActiveCatId_Last(ActCategoryId, orderByComparator);
    }

    /**
    * Removes all the act categories where ActCategoryId = &#63; from the database.
    *
    * @param ActCategoryId the act category ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByActiveCatId(long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByActiveCatId(ActCategoryId);
    }

    /**
    * Returns the number of act categories where ActCategoryId = &#63;.
    *
    * @param ActCategoryId the act category ID
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static int countByActiveCatId(long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByActiveCatId(ActCategoryId);
    }

    /**
    * Returns all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClSubId(
        long ActiveCheckListID, long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActiveClSubId(ActiveCheckListID, SubCatogryId);
    }

    /**
    * Returns a range of all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClSubId(
        long ActiveCheckListID, long SubCatogryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActiveClSubId(ActiveCheckListID, SubCatogryId, start,
            end);
    }

    /**
    * Returns an ordered range of all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findByActiveClSubId(
        long ActiveCheckListID, long SubCatogryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActiveClSubId(ActiveCheckListID, SubCatogryId, start,
            end, orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByActiveClSubId_First(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveClSubId_First(ActiveCheckListID, SubCatogryId,
            orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByActiveClSubId_First(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActiveClSubId_First(ActiveCheckListID, SubCatogryId,
            orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByActiveClSubId_Last(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveClSubId_Last(ActiveCheckListID, SubCatogryId,
            orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByActiveClSubId_Last(
        long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActiveClSubId_Last(ActiveCheckListID, SubCatogryId,
            orderByComparator);
    }

    /**
    * Returns the act categories before and after the current act category in the ordered set where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory[] findByActiveClSubId_PrevAndNext(
        long ActCategoryId, long ActiveCheckListID, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findByActiveClSubId_PrevAndNext(ActCategoryId,
            ActiveCheckListID, SubCatogryId, orderByComparator);
    }

    /**
    * Removes all the act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63; from the database.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByActiveClSubId(long ActiveCheckListID,
        long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByActiveClSubId(ActiveCheckListID, SubCatogryId);
    }

    /**
    * Returns the number of act categories where ActiveCheckListID = &#63; and SubCatogryId = &#63;.
    *
    * @param ActiveCheckListID the active check list i d
    * @param SubCatogryId the sub catogry ID
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static int countByActiveClSubId(long ActiveCheckListID,
        long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .countByActiveClSubId(ActiveCheckListID, SubCatogryId);
    }

    /**
    * Returns all the act categories where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @return the matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findBySubCatogryId(
        long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBySubCatogryId(SubCatogryId);
    }

    /**
    * Returns a range of all the act categories where SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findBySubCatogryId(
        long SubCatogryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBySubCatogryId(SubCatogryId, start, end);
    }

    /**
    * Returns an ordered range of all the act categories where SubCatogryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param SubCatogryId the sub catogry ID
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findBySubCatogryId(
        long SubCatogryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findBySubCatogryId(SubCatogryId, start, end,
            orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findBySubCatogryId_First(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findBySubCatogryId_First(SubCatogryId, orderByComparator);
    }

    /**
    * Returns the first act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchBySubCatogryId_First(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBySubCatogryId_First(SubCatogryId, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findBySubCatogryId_Last(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findBySubCatogryId_Last(SubCatogryId, orderByComparator);
    }

    /**
    * Returns the last act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act category, or <code>null</code> if a matching act category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchBySubCatogryId_Last(
        long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBySubCatogryId_Last(SubCatogryId, orderByComparator);
    }

    /**
    * Returns the act categories before and after the current act category in the ordered set where SubCatogryId = &#63;.
    *
    * @param ActCategoryId the primary key of the current act category
    * @param SubCatogryId the sub catogry ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory[] findBySubCatogryId_PrevAndNext(
        long ActCategoryId, long SubCatogryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence()
                   .findBySubCatogryId_PrevAndNext(ActCategoryId, SubCatogryId,
            orderByComparator);
    }

    /**
    * Removes all the act categories where SubCatogryId = &#63; from the database.
    *
    * @param SubCatogryId the sub catogry ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeBySubCatogryId(long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeBySubCatogryId(SubCatogryId);
    }

    /**
    * Returns the number of act categories where SubCatogryId = &#63;.
    *
    * @param SubCatogryId the sub catogry ID
    * @return the number of matching act categories
    * @throws SystemException if a system exception occurred
    */
    public static int countBySubCatogryId(long SubCatogryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countBySubCatogryId(SubCatogryId);
    }

    /**
    * Caches the act category in the entity cache if it is enabled.
    *
    * @param actCategory the act category
    */
    public static void cacheResult(
        org.digitalArmour.verifier.model.ActCategory actCategory) {
        getPersistence().cacheResult(actCategory);
    }

    /**
    * Caches the act categories in the entity cache if it is enabled.
    *
    * @param actCategories the act categories
    */
    public static void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ActCategory> actCategories) {
        getPersistence().cacheResult(actCategories);
    }

    /**
    * Creates a new act category with the primary key. Does not add the act category to the database.
    *
    * @param ActCategoryId the primary key for the new act category
    * @return the new act category
    */
    public static org.digitalArmour.verifier.model.ActCategory create(
        long ActCategoryId) {
        return getPersistence().create(ActCategoryId);
    }

    /**
    * Removes the act category with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category that was removed
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory remove(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence().remove(ActCategoryId);
    }

    public static org.digitalArmour.verifier.model.ActCategory updateImpl(
        org.digitalArmour.verifier.model.ActCategory actCategory)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(actCategory);
    }

    /**
    * Returns the act category with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActCategoryException} if it could not be found.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category
    * @throws org.digitalArmour.verifier.NoSuchActCategoryException if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory findByPrimaryKey(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActCategoryException {
        return getPersistence().findByPrimaryKey(ActCategoryId);
    }

    /**
    * Returns the act category with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param ActCategoryId the primary key of the act category
    * @return the act category, or <code>null</code> if a act category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActCategory fetchByPrimaryKey(
        long ActCategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(ActCategoryId);
    }

    /**
    * Returns all the act categories.
    *
    * @return the act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the act categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @return the range of act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the act categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActCategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act categories
    * @param end the upper bound of the range of act categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of act categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActCategory> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the act categories from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of act categories.
    *
    * @return the number of act categories
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static ActCategoryPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (ActCategoryPersistence) PortletBeanLocatorUtil.locate(org.digitalArmour.verifier.service.ClpSerializer.getServletContextName(),
                    ActCategoryPersistence.class.getName());

            ReferenceRegistry.registerReference(ActCategoryUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(ActCategoryPersistence persistence) {
    }
}
