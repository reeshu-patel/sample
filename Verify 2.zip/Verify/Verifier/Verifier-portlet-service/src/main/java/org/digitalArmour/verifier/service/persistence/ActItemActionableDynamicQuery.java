package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.ActItem;
import org.digitalArmour.verifier.service.ActItemLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ActItemActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ActItemActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ActItemLocalServiceUtil.getService());
        setClass(ActItem.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("ItemId");
    }
}
