package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.ActItemComment;
import org.digitalArmour.verifier.service.ActItemCommentLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ActItemCommentActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ActItemCommentActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ActItemCommentLocalServiceUtil.getService());
        setClass(ActItemComment.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("actCommId");
    }
}
