package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.ActItemFile;
import org.digitalArmour.verifier.service.ActItemFileLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ActItemFileActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ActItemFileActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ActItemFileLocalServiceUtil.getService());
        setClass(ActItemFile.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("actItemFileId");
    }
}
