package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.ActItem;

/**
 * The persistence interface for the act item service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActItemPersistenceImpl
 * @see ActItemUtil
 * @generated
 */
public interface ActItemPersistence extends BasePersistence<ActItem> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link ActItemUtil} to access the act item persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the act items where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act items where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act items where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the first act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the last act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act items before and after the current act item in the ordered set where uuid = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem[] findByUuid_PrevAndNext(
        long ItemId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Removes all the act items where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act items where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act items where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findBycompletedDate(
        java.util.Date completedDate)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act items where completedDate = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param completedDate the completed date
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findBycompletedDate(
        java.util.Date completedDate, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act items where completedDate = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param completedDate the completed date
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findBycompletedDate(
        java.util.Date completedDate, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findBycompletedDate_First(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the first act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchBycompletedDate_First(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findBycompletedDate_Last(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the last act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchBycompletedDate_Last(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act items before and after the current act item in the ordered set where completedDate = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem[] findBycompletedDate_PrevAndNext(
        long ItemId, java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Removes all the act items where completedDate = &#63; from the database.
    *
    * @param completedDate the completed date
    * @throws SystemException if a system exception occurred
    */
    public void removeBycompletedDate(java.util.Date completedDate)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act items where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public int countBycompletedDate(java.util.Date completedDate)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act items where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByActivateClid(
        long ActivateClid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act items where ActivateClid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByActivateClid(
        long ActivateClid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act items where ActivateClid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByActivateClid(
        long ActivateClid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByActivateClid_First(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByActivateClid_First(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByActivateClid_Last(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByActivateClid_Last(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem[] findByActivateClid_PrevAndNext(
        long ItemId, long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Removes all the act items where ActivateClid = &#63; from the database.
    *
    * @param ActivateClid the activate clid
    * @throws SystemException if a system exception occurred
    */
    public void removeByActivateClid(long ActivateClid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act items where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public int countByActivateClid(long ActivateClid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act items where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findBycatId(
        long catId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act items where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findBycatId(
        long catId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act items where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findBycatId(
        long catId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the first act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the last act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act items before and after the current act item in the ordered set where catId = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem[] findBycatId_PrevAndNext(
        long ItemId, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Removes all the act items where catId = &#63; from the database.
    *
    * @param catId the cat ID
    * @throws SystemException if a system exception occurred
    */
    public void removeBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act items where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public int countBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act items where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByActidcompleted(
        long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act items where ActivateClid = &#63; and completed = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByActidcompleted(
        long ActivateClid, boolean completed, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act items where ActivateClid = &#63; and completed = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByActidcompleted(
        long ActivateClid, boolean completed, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByActidcompleted_First(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByActidcompleted_First(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByActidcompleted_Last(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByActidcompleted_Last(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem[] findByActidcompleted_PrevAndNext(
        long ItemId, long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Removes all the act items where ActivateClid = &#63; and completed = &#63; from the database.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @throws SystemException if a system exception occurred
    */
    public void removeByActidcompleted(long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act items where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public int countByActidcompleted(long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act items where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByactCLUncat(
        long ActivateClid, long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act items where ActivateClid = &#63; and catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByactCLUncat(
        long ActivateClid, long catId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act items where ActivateClid = &#63; and catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findByactCLUncat(
        long ActivateClid, long catId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByactCLUncat_First(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByactCLUncat_First(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByactCLUncat_Last(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByactCLUncat_Last(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem[] findByactCLUncat_PrevAndNext(
        long ItemId, long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Removes all the act items where ActivateClid = &#63; and catId = &#63; from the database.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByactCLUncat(long ActivateClid, long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act items where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public int countByactCLUncat(long ActivateClid, long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the act item in the entity cache if it is enabled.
    *
    * @param actItem the act item
    */
    public void cacheResult(org.digitalArmour.verifier.model.ActItem actItem);

    /**
    * Caches the act items in the entity cache if it is enabled.
    *
    * @param actItems the act items
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ActItem> actItems);

    /**
    * Creates a new act item with the primary key. Does not add the act item to the database.
    *
    * @param ItemId the primary key for the new act item
    * @return the new act item
    */
    public org.digitalArmour.verifier.model.ActItem create(long ItemId);

    /**
    * Removes the act item with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param ItemId the primary key of the act item
    * @return the act item that was removed
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem remove(long ItemId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    public org.digitalArmour.verifier.model.ActItem updateImpl(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the act item with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActItemException} if it could not be found.
    *
    * @param ItemId the primary key of the act item
    * @return the act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem findByPrimaryKey(
        long ItemId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException;

    /**
    * Returns the act item with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param ItemId the primary key of the act item
    * @return the act item, or <code>null</code> if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActItem fetchByPrimaryKey(
        long ItemId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the act items.
    *
    * @return the act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the act items.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the act items.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of act items
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActItem> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the act items from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of act items.
    *
    * @return the number of act items
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
