package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import org.digitalArmour.verifier.model.ActItem;

import java.util.List;

/**
 * The persistence utility for the act item service. This utility wraps {@link ActItemPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActItemPersistence
 * @see ActItemPersistenceImpl
 * @generated
 */
public class ActItemUtil {
    private static ActItemPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(ActItem actItem) {
        getPersistence().clearCache(actItem);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<ActItem> findWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<ActItem> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<ActItem> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static ActItem update(ActItem actItem) throws SystemException {
        return getPersistence().update(actItem);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static ActItem update(ActItem actItem, ServiceContext serviceContext)
        throws SystemException {
        return getPersistence().update(actItem, serviceContext);
    }

    /**
    * Returns all the act items where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the act items where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the act items where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the act items before and after the current act item in the ordered set where uuid = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem[] findByUuid_PrevAndNext(
        long ItemId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByUuid_PrevAndNext(ItemId, uuid, orderByComparator);
    }

    /**
    * Removes all the act items where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of act items where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Returns all the act items where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findBycompletedDate(
        java.util.Date completedDate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycompletedDate(completedDate);
    }

    /**
    * Returns a range of all the act items where completedDate = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param completedDate the completed date
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findBycompletedDate(
        java.util.Date completedDate, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycompletedDate(completedDate, start, end);
    }

    /**
    * Returns an ordered range of all the act items where completedDate = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param completedDate the completed date
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findBycompletedDate(
        java.util.Date completedDate, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findBycompletedDate(completedDate, start, end,
            orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findBycompletedDate_First(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findBycompletedDate_First(completedDate, orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchBycompletedDate_First(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBycompletedDate_First(completedDate, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findBycompletedDate_Last(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findBycompletedDate_Last(completedDate, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchBycompletedDate_Last(
        java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBycompletedDate_Last(completedDate, orderByComparator);
    }

    /**
    * Returns the act items before and after the current act item in the ordered set where completedDate = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param completedDate the completed date
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem[] findBycompletedDate_PrevAndNext(
        long ItemId, java.util.Date completedDate,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findBycompletedDate_PrevAndNext(ItemId, completedDate,
            orderByComparator);
    }

    /**
    * Removes all the act items where completedDate = &#63; from the database.
    *
    * @param completedDate the completed date
    * @throws SystemException if a system exception occurred
    */
    public static void removeBycompletedDate(java.util.Date completedDate)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeBycompletedDate(completedDate);
    }

    /**
    * Returns the number of act items where completedDate = &#63;.
    *
    * @param completedDate the completed date
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static int countBycompletedDate(java.util.Date completedDate)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countBycompletedDate(completedDate);
    }

    /**
    * Returns all the act items where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByActivateClid(
        long ActivateClid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByActivateClid(ActivateClid);
    }

    /**
    * Returns a range of all the act items where ActivateClid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByActivateClid(
        long ActivateClid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByActivateClid(ActivateClid, start, end);
    }

    /**
    * Returns an ordered range of all the act items where ActivateClid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByActivateClid(
        long ActivateClid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActivateClid(ActivateClid, start, end,
            orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByActivateClid_First(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByActivateClid_First(ActivateClid, orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByActivateClid_First(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActivateClid_First(ActivateClid, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByActivateClid_Last(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByActivateClid_Last(ActivateClid, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByActivateClid_Last(
        long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActivateClid_Last(ActivateClid, orderByComparator);
    }

    /**
    * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param ActivateClid the activate clid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem[] findByActivateClid_PrevAndNext(
        long ItemId, long ActivateClid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByActivateClid_PrevAndNext(ItemId, ActivateClid,
            orderByComparator);
    }

    /**
    * Removes all the act items where ActivateClid = &#63; from the database.
    *
    * @param ActivateClid the activate clid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByActivateClid(long ActivateClid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByActivateClid(ActivateClid);
    }

    /**
    * Returns the number of act items where ActivateClid = &#63;.
    *
    * @param ActivateClid the activate clid
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static int countByActivateClid(long ActivateClid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByActivateClid(ActivateClid);
    }

    /**
    * Returns all the act items where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findBycatId(
        long catId) throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycatId(catId);
    }

    /**
    * Returns a range of all the act items where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findBycatId(
        long catId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycatId(catId, start, end);
    }

    /**
    * Returns an ordered range of all the act items where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findBycatId(
        long catId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycatId(catId, start, end, orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence().findBycatId_First(catId, orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchBycatId_First(catId, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence().findBycatId_Last(catId, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchBycatId_Last(catId, orderByComparator);
    }

    /**
    * Returns the act items before and after the current act item in the ordered set where catId = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem[] findBycatId_PrevAndNext(
        long ItemId, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findBycatId_PrevAndNext(ItemId, catId, orderByComparator);
    }

    /**
    * Removes all the act items where catId = &#63; from the database.
    *
    * @param catId the cat ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeBycatId(catId);
    }

    /**
    * Returns the number of act items where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static int countBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countBycatId(catId);
    }

    /**
    * Returns all the act items where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByActidcompleted(
        long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByActidcompleted(ActivateClid, completed);
    }

    /**
    * Returns a range of all the act items where ActivateClid = &#63; and completed = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByActidcompleted(
        long ActivateClid, boolean completed, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActidcompleted(ActivateClid, completed, start, end);
    }

    /**
    * Returns an ordered range of all the act items where ActivateClid = &#63; and completed = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByActidcompleted(
        long ActivateClid, boolean completed, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByActidcompleted(ActivateClid, completed, start, end,
            orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByActidcompleted_First(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByActidcompleted_First(ActivateClid, completed,
            orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByActidcompleted_First(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActidcompleted_First(ActivateClid, completed,
            orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByActidcompleted_Last(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByActidcompleted_Last(ActivateClid, completed,
            orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByActidcompleted_Last(
        long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByActidcompleted_Last(ActivateClid, completed,
            orderByComparator);
    }

    /**
    * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem[] findByActidcompleted_PrevAndNext(
        long ItemId, long ActivateClid, boolean completed,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByActidcompleted_PrevAndNext(ItemId, ActivateClid,
            completed, orderByComparator);
    }

    /**
    * Removes all the act items where ActivateClid = &#63; and completed = &#63; from the database.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @throws SystemException if a system exception occurred
    */
    public static void removeByActidcompleted(long ActivateClid,
        boolean completed)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByActidcompleted(ActivateClid, completed);
    }

    /**
    * Returns the number of act items where ActivateClid = &#63; and completed = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param completed the completed
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static int countByActidcompleted(long ActivateClid, boolean completed)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByActidcompleted(ActivateClid, completed);
    }

    /**
    * Returns all the act items where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @return the matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByactCLUncat(
        long ActivateClid, long catId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByactCLUncat(ActivateClid, catId);
    }

    /**
    * Returns a range of all the act items where ActivateClid = &#63; and catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByactCLUncat(
        long ActivateClid, long catId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByactCLUncat(ActivateClid, catId, start, end);
    }

    /**
    * Returns an ordered range of all the act items where ActivateClid = &#63; and catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findByactCLUncat(
        long ActivateClid, long catId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByactCLUncat(ActivateClid, catId, start, end,
            orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByactCLUncat_First(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByactCLUncat_First(ActivateClid, catId,
            orderByComparator);
    }

    /**
    * Returns the first act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByactCLUncat_First(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByactCLUncat_First(ActivateClid, catId,
            orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByactCLUncat_Last(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByactCLUncat_Last(ActivateClid, catId, orderByComparator);
    }

    /**
    * Returns the last act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching act item, or <code>null</code> if a matching act item could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByactCLUncat_Last(
        long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByactCLUncat_Last(ActivateClid, catId,
            orderByComparator);
    }

    /**
    * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ItemId the primary key of the current act item
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem[] findByactCLUncat_PrevAndNext(
        long ItemId, long ActivateClid, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence()
                   .findByactCLUncat_PrevAndNext(ItemId, ActivateClid, catId,
            orderByComparator);
    }

    /**
    * Removes all the act items where ActivateClid = &#63; and catId = &#63; from the database.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByactCLUncat(long ActivateClid, long catId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByactCLUncat(ActivateClid, catId);
    }

    /**
    * Returns the number of act items where ActivateClid = &#63; and catId = &#63;.
    *
    * @param ActivateClid the activate clid
    * @param catId the cat ID
    * @return the number of matching act items
    * @throws SystemException if a system exception occurred
    */
    public static int countByactCLUncat(long ActivateClid, long catId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByactCLUncat(ActivateClid, catId);
    }

    /**
    * Caches the act item in the entity cache if it is enabled.
    *
    * @param actItem the act item
    */
    public static void cacheResult(
        org.digitalArmour.verifier.model.ActItem actItem) {
        getPersistence().cacheResult(actItem);
    }

    /**
    * Caches the act items in the entity cache if it is enabled.
    *
    * @param actItems the act items
    */
    public static void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ActItem> actItems) {
        getPersistence().cacheResult(actItems);
    }

    /**
    * Creates a new act item with the primary key. Does not add the act item to the database.
    *
    * @param ItemId the primary key for the new act item
    * @return the new act item
    */
    public static org.digitalArmour.verifier.model.ActItem create(long ItemId) {
        return getPersistence().create(ItemId);
    }

    /**
    * Removes the act item with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param ItemId the primary key of the act item
    * @return the act item that was removed
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem remove(long ItemId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence().remove(ItemId);
    }

    public static org.digitalArmour.verifier.model.ActItem updateImpl(
        org.digitalArmour.verifier.model.ActItem actItem)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(actItem);
    }

    /**
    * Returns the act item with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActItemException} if it could not be found.
    *
    * @param ItemId the primary key of the act item
    * @return the act item
    * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem findByPrimaryKey(
        long ItemId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActItemException {
        return getPersistence().findByPrimaryKey(ItemId);
    }

    /**
    * Returns the act item with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param ItemId the primary key of the act item
    * @return the act item, or <code>null</code> if a act item with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActItem fetchByPrimaryKey(
        long ItemId) throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(ItemId);
    }

    /**
    * Returns all the act items.
    *
    * @return the act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the act items.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @return the range of act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the act items.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of act items
    * @param end the upper bound of the range of act items (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of act items
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActItem> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the act items from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of act items.
    *
    * @return the number of act items
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static ActItemPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (ActItemPersistence) PortletBeanLocatorUtil.locate(org.digitalArmour.verifier.service.ClpSerializer.getServletContextName(),
                    ActItemPersistence.class.getName());

            ReferenceRegistry.registerReference(ActItemUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(ActItemPersistence persistence) {
    }
}
