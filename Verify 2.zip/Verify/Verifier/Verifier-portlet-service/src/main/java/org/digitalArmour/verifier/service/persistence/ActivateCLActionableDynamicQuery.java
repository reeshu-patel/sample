package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.ActivateCL;
import org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ActivateCLActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ActivateCLActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ActivateCLLocalServiceUtil.getService());
        setClass(ActivateCL.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("activateId");
    }
}
