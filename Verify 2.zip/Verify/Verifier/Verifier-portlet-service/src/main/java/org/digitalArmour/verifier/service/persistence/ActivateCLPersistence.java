package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.ActivateCL;

/**
 * The persistence interface for the activate c l service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLPersistenceImpl
 * @see ActivateCLUtil
 * @generated
 */
public interface ActivateCLPersistence extends BasePersistence<ActivateCL> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link ActivateCLUtil} to access the activate c l persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the activate c ls where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the first activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the last activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where uuid = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL[] findByUuid_PrevAndNext(
        long activateId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Removes all the activate c ls where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the activate c ls where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findBycheckListId(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findBycheckListId(
        long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findBycheckListId(
        long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findBycheckListId_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the first activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchBycheckListId_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findBycheckListId_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the last activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchBycheckListId_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where checklistId = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL[] findBycheckListId_PrevAndNext(
        long activateId, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Removes all the activate c ls where checklistId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public void removeBycheckListId(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countBycheckListId(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the activate c ls where clName = &#63;.
    *
    * @param clName the cl name
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByclName(
        java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls where clName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clName the cl name
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByclName(
        java.lang.String clName, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls where clName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clName the cl name
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByclName(
        java.lang.String clName, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByclName_First(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the first activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByclName_First(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByclName_Last(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the last activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByclName_Last(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where clName = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL[] findByclName_PrevAndNext(
        long activateId, java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Removes all the activate c ls where clName = &#63; from the database.
    *
    * @param clName the cl name
    * @throws SystemException if a system exception occurred
    */
    public void removeByclName(java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls where clName = &#63;.
    *
    * @param clName the cl name
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countByclName(java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the activate c ls where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompleted(
        boolean isCompleted)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls where isCompleted = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompleted(
        boolean isCompleted, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls where isCompleted = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompleted(
        boolean isCompleted, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByisCompleted_First(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByisCompleted_First(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByisCompleted_Last(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByisCompleted_Last(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL[] findByisCompleted_PrevAndNext(
        long activateId, boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Removes all the activate c ls where isCompleted = &#63; from the database.
    *
    * @param isCompleted the is completed
    * @throws SystemException if a system exception occurred
    */
    public void removeByisCompleted(boolean isCompleted)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countByisCompleted(boolean isCompleted)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the activate c ls where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByactivateId(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls where activateId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param activateId the activate ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByactivateId(
        long activateId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls where activateId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param activateId the activate ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByactivateId(
        long activateId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByactivateId_First(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the first activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByactivateId_First(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByactivateId_Last(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the last activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByactivateId_Last(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the activate c ls where activateId = &#63; from the database.
    *
    * @param activateId the activate ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByactivateId(long activateId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countByactivateId(long activateId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompCheck(
        boolean isCompleted, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompCheck(
        boolean isCompleted, long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompCheck(
        boolean isCompleted, long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByisCompCheck_First(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByisCompCheck_First(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByisCompCheck_Last(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByisCompCheck_Last(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL[] findByisCompCheck_PrevAndNext(
        long activateId, boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Removes all the activate c ls where isCompleted = &#63; and checklistId = &#63; from the database.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByisCompCheck(boolean isCompleted, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countByisCompCheck(boolean isCompleted, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompUser(
        boolean isCompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompUser(
        boolean isCompleted, long actClUserId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompUser(
        boolean isCompleted, long actClUserId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByisCompUser_First(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByisCompUser_First(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByisCompUser_Last(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByisCompUser_Last(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL[] findByisCompUser_PrevAndNext(
        long activateId, boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Removes all the activate c ls where isCompleted = &#63; and actClUserId = &#63; from the database.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByisCompUser(boolean isCompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countByisCompUser(boolean isCompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the activate c l in the entity cache if it is enabled.
    *
    * @param activateCL the activate c l
    */
    public void cacheResult(
        org.digitalArmour.verifier.model.ActivateCL activateCL);

    /**
    * Caches the activate c ls in the entity cache if it is enabled.
    *
    * @param activateCLs the activate c ls
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ActivateCL> activateCLs);

    /**
    * Creates a new activate c l with the primary key. Does not add the activate c l to the database.
    *
    * @param activateId the primary key for the new activate c l
    * @return the new activate c l
    */
    public org.digitalArmour.verifier.model.ActivateCL create(long activateId);

    /**
    * Removes the activate c l with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l that was removed
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL remove(long activateId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    public org.digitalArmour.verifier.model.ActivateCL updateImpl(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the activate c l with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActivateCLException} if it could not be found.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL findByPrimaryKey(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException;

    /**
    * Returns the activate c l with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l, or <code>null</code> if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ActivateCL fetchByPrimaryKey(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the activate c ls.
    *
    * @return the activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the activate c ls.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the activate c ls.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ActivateCL> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the activate c ls from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of activate c ls.
    *
    * @return the number of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
