package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import org.digitalArmour.verifier.model.ActivateCL;

import java.util.List;

/**
 * The persistence utility for the activate c l service. This utility wraps {@link ActivateCLPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLPersistence
 * @see ActivateCLPersistenceImpl
 * @generated
 */
public class ActivateCLUtil {
    private static ActivateCLPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(ActivateCL activateCL) {
        getPersistence().clearCache(activateCL);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<ActivateCL> findWithDynamicQuery(
        DynamicQuery dynamicQuery) throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<ActivateCL> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<ActivateCL> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static ActivateCL update(ActivateCL activateCL)
        throws SystemException {
        return getPersistence().update(activateCL);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static ActivateCL update(ActivateCL activateCL,
        ServiceContext serviceContext) throws SystemException {
        return getPersistence().update(activateCL, serviceContext);
    }

    /**
    * Returns all the activate c ls where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the activate c ls where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where uuid = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL[] findByUuid_PrevAndNext(
        long activateId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByUuid_PrevAndNext(activateId, uuid, orderByComparator);
    }

    /**
    * Removes all the activate c ls where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of activate c ls where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Returns all the activate c ls where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findBycheckListId(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycheckListId(checklistId);
    }

    /**
    * Returns a range of all the activate c ls where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findBycheckListId(
        long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycheckListId(checklistId, start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findBycheckListId(
        long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findBycheckListId(checklistId, start, end, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findBycheckListId_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findBycheckListId_First(checklistId, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchBycheckListId_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBycheckListId_First(checklistId, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findBycheckListId_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findBycheckListId_Last(checklistId, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchBycheckListId_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBycheckListId_Last(checklistId, orderByComparator);
    }

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where checklistId = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL[] findBycheckListId_PrevAndNext(
        long activateId, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findBycheckListId_PrevAndNext(activateId, checklistId,
            orderByComparator);
    }

    /**
    * Removes all the activate c ls where checklistId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeBycheckListId(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeBycheckListId(checklistId);
    }

    /**
    * Returns the number of activate c ls where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countBycheckListId(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countBycheckListId(checklistId);
    }

    /**
    * Returns all the activate c ls where clName = &#63;.
    *
    * @param clName the cl name
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByclName(
        java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByclName(clName);
    }

    /**
    * Returns a range of all the activate c ls where clName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clName the cl name
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByclName(
        java.lang.String clName, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByclName(clName, start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls where clName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clName the cl name
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByclName(
        java.lang.String clName, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByclName(clName, start, end, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByclName_First(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence().findByclName_First(clName, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByclName_First(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByclName_First(clName, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByclName_Last(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence().findByclName_Last(clName, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByclName_Last(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByclName_Last(clName, orderByComparator);
    }

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where clName = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL[] findByclName_PrevAndNext(
        long activateId, java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByclName_PrevAndNext(activateId, clName,
            orderByComparator);
    }

    /**
    * Removes all the activate c ls where clName = &#63; from the database.
    *
    * @param clName the cl name
    * @throws SystemException if a system exception occurred
    */
    public static void removeByclName(java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByclName(clName);
    }

    /**
    * Returns the number of activate c ls where clName = &#63;.
    *
    * @param clName the cl name
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countByclName(java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByclName(clName);
    }

    /**
    * Returns all the activate c ls where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompleted(
        boolean isCompleted)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByisCompleted(isCompleted);
    }

    /**
    * Returns a range of all the activate c ls where isCompleted = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompleted(
        boolean isCompleted, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByisCompleted(isCompleted, start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls where isCompleted = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompleted(
        boolean isCompleted, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByisCompleted(isCompleted, start, end, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByisCompleted_First(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompleted_First(isCompleted, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByisCompleted_First(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByisCompleted_First(isCompleted, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByisCompleted_Last(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompleted_Last(isCompleted, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByisCompleted_Last(
        boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByisCompleted_Last(isCompleted, orderByComparator);
    }

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param isCompleted the is completed
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL[] findByisCompleted_PrevAndNext(
        long activateId, boolean isCompleted,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompleted_PrevAndNext(activateId, isCompleted,
            orderByComparator);
    }

    /**
    * Removes all the activate c ls where isCompleted = &#63; from the database.
    *
    * @param isCompleted the is completed
    * @throws SystemException if a system exception occurred
    */
    public static void removeByisCompleted(boolean isCompleted)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByisCompleted(isCompleted);
    }

    /**
    * Returns the number of activate c ls where isCompleted = &#63;.
    *
    * @param isCompleted the is completed
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countByisCompleted(boolean isCompleted)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByisCompleted(isCompleted);
    }

    /**
    * Returns all the activate c ls where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByactivateId(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByactivateId(activateId);
    }

    /**
    * Returns a range of all the activate c ls where activateId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param activateId the activate ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByactivateId(
        long activateId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByactivateId(activateId, start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls where activateId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param activateId the activate ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByactivateId(
        long activateId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByactivateId(activateId, start, end, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByactivateId_First(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByactivateId_First(activateId, orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByactivateId_First(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByactivateId_First(activateId, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByactivateId_Last(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByactivateId_Last(activateId, orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByactivateId_Last(
        long activateId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByactivateId_Last(activateId, orderByComparator);
    }

    /**
    * Removes all the activate c ls where activateId = &#63; from the database.
    *
    * @param activateId the activate ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByactivateId(long activateId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByactivateId(activateId);
    }

    /**
    * Returns the number of activate c ls where activateId = &#63;.
    *
    * @param activateId the activate ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countByactivateId(long activateId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByactivateId(activateId);
    }

    /**
    * Returns all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompCheck(
        boolean isCompleted, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByisCompCheck(isCompleted, checklistId);
    }

    /**
    * Returns a range of all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompCheck(
        boolean isCompleted, long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByisCompCheck(isCompleted, checklistId, start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompCheck(
        boolean isCompleted, long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByisCompCheck(isCompleted, checklistId, start, end,
            orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByisCompCheck_First(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompCheck_First(isCompleted, checklistId,
            orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByisCompCheck_First(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByisCompCheck_First(isCompleted, checklistId,
            orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByisCompCheck_Last(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompCheck_Last(isCompleted, checklistId,
            orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByisCompCheck_Last(
        boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByisCompCheck_Last(isCompleted, checklistId,
            orderByComparator);
    }

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL[] findByisCompCheck_PrevAndNext(
        long activateId, boolean isCompleted, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompCheck_PrevAndNext(activateId, isCompleted,
            checklistId, orderByComparator);
    }

    /**
    * Removes all the activate c ls where isCompleted = &#63; and checklistId = &#63; from the database.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByisCompCheck(boolean isCompleted, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByisCompCheck(isCompleted, checklistId);
    }

    /**
    * Returns the number of activate c ls where isCompleted = &#63; and checklistId = &#63;.
    *
    * @param isCompleted the is completed
    * @param checklistId the checklist ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countByisCompCheck(boolean isCompleted, long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByisCompCheck(isCompleted, checklistId);
    }

    /**
    * Returns all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @return the matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompUser(
        boolean isCompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByisCompUser(isCompleted, actClUserId);
    }

    /**
    * Returns a range of all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompUser(
        boolean isCompleted, long actClUserId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByisCompUser(isCompleted, actClUserId, start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findByisCompUser(
        boolean isCompleted, long actClUserId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByisCompUser(isCompleted, actClUserId, start, end,
            orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByisCompUser_First(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompUser_First(isCompleted, actClUserId,
            orderByComparator);
    }

    /**
    * Returns the first activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByisCompUser_First(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByisCompUser_First(isCompleted, actClUserId,
            orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByisCompUser_Last(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompUser_Last(isCompleted, actClUserId,
            orderByComparator);
    }

    /**
    * Returns the last activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByisCompUser_Last(
        boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByisCompUser_Last(isCompleted, actClUserId,
            orderByComparator);
    }

    /**
    * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param activateId the primary key of the current activate c l
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL[] findByisCompUser_PrevAndNext(
        long activateId, boolean isCompleted, long actClUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence()
                   .findByisCompUser_PrevAndNext(activateId, isCompleted,
            actClUserId, orderByComparator);
    }

    /**
    * Removes all the activate c ls where isCompleted = &#63; and actClUserId = &#63; from the database.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByisCompUser(boolean isCompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByisCompUser(isCompleted, actClUserId);
    }

    /**
    * Returns the number of activate c ls where isCompleted = &#63; and actClUserId = &#63;.
    *
    * @param isCompleted the is completed
    * @param actClUserId the act cl user ID
    * @return the number of matching activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countByisCompUser(boolean isCompleted, long actClUserId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByisCompUser(isCompleted, actClUserId);
    }

    /**
    * Caches the activate c l in the entity cache if it is enabled.
    *
    * @param activateCL the activate c l
    */
    public static void cacheResult(
        org.digitalArmour.verifier.model.ActivateCL activateCL) {
        getPersistence().cacheResult(activateCL);
    }

    /**
    * Caches the activate c ls in the entity cache if it is enabled.
    *
    * @param activateCLs the activate c ls
    */
    public static void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ActivateCL> activateCLs) {
        getPersistence().cacheResult(activateCLs);
    }

    /**
    * Creates a new activate c l with the primary key. Does not add the activate c l to the database.
    *
    * @param activateId the primary key for the new activate c l
    * @return the new activate c l
    */
    public static org.digitalArmour.verifier.model.ActivateCL create(
        long activateId) {
        return getPersistence().create(activateId);
    }

    /**
    * Removes the activate c l with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l that was removed
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL remove(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence().remove(activateId);
    }

    public static org.digitalArmour.verifier.model.ActivateCL updateImpl(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(activateCL);
    }

    /**
    * Returns the activate c l with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActivateCLException} if it could not be found.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l
    * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL findByPrimaryKey(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchActivateCLException {
        return getPersistence().findByPrimaryKey(activateId);
    }

    /**
    * Returns the activate c l with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param activateId the primary key of the activate c l
    * @return the activate c l, or <code>null</code> if a activate c l with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.ActivateCL fetchByPrimaryKey(
        long activateId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(activateId);
    }

    /**
    * Returns all the activate c ls.
    *
    * @return the activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the activate c ls.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @return the range of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the activate c ls.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of activate c ls
    * @param end the upper bound of the range of activate c ls (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.ActivateCL> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the activate c ls from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of activate c ls.
    *
    * @return the number of activate c ls
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static ActivateCLPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (ActivateCLPersistence) PortletBeanLocatorUtil.locate(org.digitalArmour.verifier.service.ClpSerializer.getServletContextName(),
                    ActivateCLPersistence.class.getName());

            ReferenceRegistry.registerReference(ActivateCLUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(ActivateCLPersistence persistence) {
    }
}
