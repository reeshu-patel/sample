package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.CLCollab;
import org.digitalArmour.verifier.service.CLCollabLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class CLCollabActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public CLCollabActionableDynamicQuery() throws SystemException {
        setBaseLocalService(CLCollabLocalServiceUtil.getService());
        setClass(CLCollab.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("clCollabId");
    }
}
