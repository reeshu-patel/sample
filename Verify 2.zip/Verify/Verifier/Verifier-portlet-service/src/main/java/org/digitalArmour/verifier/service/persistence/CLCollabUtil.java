package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import org.digitalArmour.verifier.model.CLCollab;

import java.util.List;

/**
 * The persistence utility for the c l collab service. This utility wraps {@link CLCollabPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CLCollabPersistence
 * @see CLCollabPersistenceImpl
 * @generated
 */
public class CLCollabUtil {
    private static CLCollabPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(CLCollab clCollab) {
        getPersistence().clearCache(clCollab);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<CLCollab> findWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<CLCollab> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<CLCollab> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static CLCollab update(CLCollab clCollab) throws SystemException {
        return getPersistence().update(clCollab);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static CLCollab update(CLCollab clCollab,
        ServiceContext serviceContext) throws SystemException {
        return getPersistence().update(clCollab, serviceContext);
    }

    /**
    * Returns all the c l collabs where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the c l collabs where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @return the range of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the c l collabs where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l collab, or <code>null</code> if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last c l collab in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l collab, or <code>null</code> if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the c l collabs before and after the current c l collab in the ordered set where uuid = &#63;.
    *
    * @param clCollabId the primary key of the current c l collab
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab[] findByUuid_PrevAndNext(
        long clCollabId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence()
                   .findByUuid_PrevAndNext(clCollabId, uuid, orderByComparator);
    }

    /**
    * Removes all the c l collabs where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of c l collabs where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Returns all the c l collabs where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByCollab_CL(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByCollab_CL(checklistId);
    }

    /**
    * Returns a range of all the c l collabs where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @return the range of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByCollab_CL(
        long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByCollab_CL(checklistId, start, end);
    }

    /**
    * Returns an ordered range of all the c l collabs where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByCollab_CL(
        long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByCollab_CL(checklistId, start, end, orderByComparator);
    }

    /**
    * Returns the first c l collab in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab findByCollab_CL_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence()
                   .findByCollab_CL_First(checklistId, orderByComparator);
    }

    /**
    * Returns the first c l collab in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l collab, or <code>null</code> if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab fetchByCollab_CL_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByCollab_CL_First(checklistId, orderByComparator);
    }

    /**
    * Returns the last c l collab in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab findByCollab_CL_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence()
                   .findByCollab_CL_Last(checklistId, orderByComparator);
    }

    /**
    * Returns the last c l collab in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l collab, or <code>null</code> if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab fetchByCollab_CL_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByCollab_CL_Last(checklistId, orderByComparator);
    }

    /**
    * Returns the c l collabs before and after the current c l collab in the ordered set where checklistId = &#63;.
    *
    * @param clCollabId the primary key of the current c l collab
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab[] findByCollab_CL_PrevAndNext(
        long clCollabId, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence()
                   .findByCollab_CL_PrevAndNext(clCollabId, checklistId,
            orderByComparator);
    }

    /**
    * Removes all the c l collabs where checklistId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByCollab_CL(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByCollab_CL(checklistId);
    }

    /**
    * Returns the number of c l collabs where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the number of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static int countByCollab_CL(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByCollab_CL(checklistId);
    }

    /**
    * Returns all the c l collabs where userId = &#63;.
    *
    * @param userId the user ID
    * @return the matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByuserId(
        long userId) throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByuserId(userId);
    }

    /**
    * Returns a range of all the c l collabs where userId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param userId the user ID
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @return the range of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByuserId(
        long userId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByuserId(userId, start, end);
    }

    /**
    * Returns an ordered range of all the c l collabs where userId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param userId the user ID
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findByuserId(
        long userId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByuserId(userId, start, end, orderByComparator);
    }

    /**
    * Returns the first c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab findByuserId_First(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence().findByuserId_First(userId, orderByComparator);
    }

    /**
    * Returns the first c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l collab, or <code>null</code> if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab fetchByuserId_First(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByuserId_First(userId, orderByComparator);
    }

    /**
    * Returns the last c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab findByuserId_Last(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence().findByuserId_Last(userId, orderByComparator);
    }

    /**
    * Returns the last c l collab in the ordered set where userId = &#63;.
    *
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l collab, or <code>null</code> if a matching c l collab could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab fetchByuserId_Last(
        long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByuserId_Last(userId, orderByComparator);
    }

    /**
    * Returns the c l collabs before and after the current c l collab in the ordered set where userId = &#63;.
    *
    * @param clCollabId the primary key of the current c l collab
    * @param userId the user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab[] findByuserId_PrevAndNext(
        long clCollabId, long userId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence()
                   .findByuserId_PrevAndNext(clCollabId, userId,
            orderByComparator);
    }

    /**
    * Removes all the c l collabs where userId = &#63; from the database.
    *
    * @param userId the user ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByuserId(long userId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByuserId(userId);
    }

    /**
    * Returns the number of c l collabs where userId = &#63;.
    *
    * @param userId the user ID
    * @return the number of matching c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static int countByuserId(long userId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByuserId(userId);
    }

    /**
    * Caches the c l collab in the entity cache if it is enabled.
    *
    * @param clCollab the c l collab
    */
    public static void cacheResult(
        org.digitalArmour.verifier.model.CLCollab clCollab) {
        getPersistence().cacheResult(clCollab);
    }

    /**
    * Caches the c l collabs in the entity cache if it is enabled.
    *
    * @param clCollabs the c l collabs
    */
    public static void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.CLCollab> clCollabs) {
        getPersistence().cacheResult(clCollabs);
    }

    /**
    * Creates a new c l collab with the primary key. Does not add the c l collab to the database.
    *
    * @param clCollabId the primary key for the new c l collab
    * @return the new c l collab
    */
    public static org.digitalArmour.verifier.model.CLCollab create(
        long clCollabId) {
        return getPersistence().create(clCollabId);
    }

    /**
    * Removes the c l collab with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param clCollabId the primary key of the c l collab
    * @return the c l collab that was removed
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab remove(
        long clCollabId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence().remove(clCollabId);
    }

    public static org.digitalArmour.verifier.model.CLCollab updateImpl(
        org.digitalArmour.verifier.model.CLCollab clCollab)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(clCollab);
    }

    /**
    * Returns the c l collab with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchCLCollabException} if it could not be found.
    *
    * @param clCollabId the primary key of the c l collab
    * @return the c l collab
    * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab findByPrimaryKey(
        long clCollabId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLCollabException {
        return getPersistence().findByPrimaryKey(clCollabId);
    }

    /**
    * Returns the c l collab with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param clCollabId the primary key of the c l collab
    * @return the c l collab, or <code>null</code> if a c l collab with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.CLCollab fetchByPrimaryKey(
        long clCollabId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(clCollabId);
    }

    /**
    * Returns all the c l collabs.
    *
    * @return the c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the c l collabs.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @return the range of c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the c l collabs.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of c l collabs
    * @param end the upper bound of the range of c l collabs (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.CLCollab> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the c l collabs from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of c l collabs.
    *
    * @return the number of c l collabs
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static CLCollabPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (CLCollabPersistence) PortletBeanLocatorUtil.locate(org.digitalArmour.verifier.service.ClpSerializer.getServletContextName(),
                    CLCollabPersistence.class.getName());

            ReferenceRegistry.registerReference(CLCollabUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(CLCollabPersistence persistence) {
    }
}
