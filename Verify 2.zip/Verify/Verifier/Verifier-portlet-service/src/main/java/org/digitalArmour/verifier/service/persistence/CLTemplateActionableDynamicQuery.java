package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class CLTemplateActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public CLTemplateActionableDynamicQuery() throws SystemException {
        setBaseLocalService(CLTemplateLocalServiceUtil.getService());
        setClass(CLTemplate.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("checklistId");
    }
}
