package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.CLTemplate;

/**
 * The persistence interface for the c l template service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplatePersistenceImpl
 * @see CLTemplateUtil
 * @generated
 */
public interface CLTemplatePersistence extends BasePersistence<CLTemplate> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link CLTemplateUtil} to access the c l template persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the c l templates where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the c l templates where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the c l templates where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first c l template in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the first c l template in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last c l template in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the last c l template in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l templates before and after the current c l template in the ordered set where uuid = &#63;.
    *
    * @param checklistId the primary key of the current c l template
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate[] findByUuid_PrevAndNext(
        long checklistId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Removes all the c l templates where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of c l templates where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l template where checklistId = &#63; or throws a {@link org.digitalArmour.verifier.NoSuchCLTemplateException} if it could not be found.
    *
    * @param checklistId the checklist ID
    * @return the matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findBychecklistId(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the c l template where checklistId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
    *
    * @param checklistId the checklist ID
    * @return the matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchBychecklistId(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l template where checklistId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
    *
    * @param checklistId the checklist ID
    * @param retrieveFromCache whether to use the finder cache
    * @return the matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchBychecklistId(
        long checklistId, boolean retrieveFromCache)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes the c l template where checklistId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @return the c l template that was removed
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate removeBychecklistId(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the number of c l templates where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the number of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public int countBychecklistId(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the c l templates where clName = &#63;.
    *
    * @param clName the cl name
    * @return the matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByclName(
        java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the c l templates where clName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clName the cl name
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByclName(
        java.lang.String clName, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the c l templates where clName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clName the cl name
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByclName(
        java.lang.String clName, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first c l template in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByclName_First(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the first c l template in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByclName_First(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last c l template in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByclName_Last(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the last c l template in the ordered set where clName = &#63;.
    *
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByclName_Last(
        java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l templates before and after the current c l template in the ordered set where clName = &#63;.
    *
    * @param checklistId the primary key of the current c l template
    * @param clName the cl name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate[] findByclName_PrevAndNext(
        long checklistId, java.lang.String clName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Removes all the c l templates where clName = &#63; from the database.
    *
    * @param clName the cl name
    * @throws SystemException if a system exception occurred
    */
    public void removeByclName(java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of c l templates where clName = &#63;.
    *
    * @param clName the cl name
    * @return the number of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public int countByclName(java.lang.String clName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the c l templates where clUserId = &#63;.
    *
    * @param clUserId the cl user ID
    * @return the matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByclUserId(
        long clUserId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the c l templates where clUserId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clUserId the cl user ID
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByclUserId(
        long clUserId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the c l templates where clUserId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param clUserId the cl user ID
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByclUserId(
        long clUserId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first c l template in the ordered set where clUserId = &#63;.
    *
    * @param clUserId the cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByclUserId_First(
        long clUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the first c l template in the ordered set where clUserId = &#63;.
    *
    * @param clUserId the cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByclUserId_First(
        long clUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last c l template in the ordered set where clUserId = &#63;.
    *
    * @param clUserId the cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByclUserId_Last(
        long clUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the last c l template in the ordered set where clUserId = &#63;.
    *
    * @param clUserId the cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByclUserId_Last(
        long clUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l templates before and after the current c l template in the ordered set where clUserId = &#63;.
    *
    * @param checklistId the primary key of the current c l template
    * @param clUserId the cl user ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate[] findByclUserId_PrevAndNext(
        long checklistId, long clUserId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Removes all the c l templates where clUserId = &#63; from the database.
    *
    * @param clUserId the cl user ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByclUserId(long clUserId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of c l templates where clUserId = &#63;.
    *
    * @param clUserId the cl user ID
    * @return the number of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public int countByclUserId(long clUserId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the c l templates where isPublic = &#63;.
    *
    * @param isPublic the is public
    * @return the matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByisPublic(
        boolean isPublic)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the c l templates where isPublic = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isPublic the is public
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByisPublic(
        boolean isPublic, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the c l templates where isPublic = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isPublic the is public
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByisPublic(
        boolean isPublic, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first c l template in the ordered set where isPublic = &#63;.
    *
    * @param isPublic the is public
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByisPublic_First(
        boolean isPublic,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the first c l template in the ordered set where isPublic = &#63;.
    *
    * @param isPublic the is public
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByisPublic_First(
        boolean isPublic,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last c l template in the ordered set where isPublic = &#63;.
    *
    * @param isPublic the is public
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByisPublic_Last(
        boolean isPublic,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the last c l template in the ordered set where isPublic = &#63;.
    *
    * @param isPublic the is public
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByisPublic_Last(
        boolean isPublic,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l templates before and after the current c l template in the ordered set where isPublic = &#63;.
    *
    * @param checklistId the primary key of the current c l template
    * @param isPublic the is public
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate[] findByisPublic_PrevAndNext(
        long checklistId, boolean isPublic,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Removes all the c l templates where isPublic = &#63; from the database.
    *
    * @param isPublic the is public
    * @throws SystemException if a system exception occurred
    */
    public void removeByisPublic(boolean isPublic)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of c l templates where isPublic = &#63;.
    *
    * @param isPublic the is public
    * @return the number of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public int countByisPublic(boolean isPublic)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the c l templates where isPubliccat = &#63;.
    *
    * @param isPubliccat the is publiccat
    * @return the matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByisPubliccat(
        boolean isPubliccat)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the c l templates where isPubliccat = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isPubliccat the is publiccat
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByisPubliccat(
        boolean isPubliccat, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the c l templates where isPubliccat = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param isPubliccat the is publiccat
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findByisPubliccat(
        boolean isPubliccat, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first c l template in the ordered set where isPubliccat = &#63;.
    *
    * @param isPubliccat the is publiccat
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByisPubliccat_First(
        boolean isPubliccat,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the first c l template in the ordered set where isPubliccat = &#63;.
    *
    * @param isPubliccat the is publiccat
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByisPubliccat_First(
        boolean isPubliccat,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last c l template in the ordered set where isPubliccat = &#63;.
    *
    * @param isPubliccat the is publiccat
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByisPubliccat_Last(
        boolean isPubliccat,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the last c l template in the ordered set where isPubliccat = &#63;.
    *
    * @param isPubliccat the is publiccat
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByisPubliccat_Last(
        boolean isPubliccat,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l templates before and after the current c l template in the ordered set where isPubliccat = &#63;.
    *
    * @param checklistId the primary key of the current c l template
    * @param isPubliccat the is publiccat
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate[] findByisPubliccat_PrevAndNext(
        long checklistId, boolean isPubliccat,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Removes all the c l templates where isPubliccat = &#63; from the database.
    *
    * @param isPubliccat the is publiccat
    * @throws SystemException if a system exception occurred
    */
    public void removeByisPubliccat(boolean isPubliccat)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of c l templates where isPubliccat = &#63;.
    *
    * @param isPubliccat the is publiccat
    * @return the number of matching c l templates
    * @throws SystemException if a system exception occurred
    */
    public int countByisPubliccat(boolean isPubliccat)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the c l template in the entity cache if it is enabled.
    *
    * @param clTemplate the c l template
    */
    public void cacheResult(
        org.digitalArmour.verifier.model.CLTemplate clTemplate);

    /**
    * Caches the c l templates in the entity cache if it is enabled.
    *
    * @param clTemplates the c l templates
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.CLTemplate> clTemplates);

    /**
    * Creates a new c l template with the primary key. Does not add the c l template to the database.
    *
    * @param checklistId the primary key for the new c l template
    * @return the new c l template
    */
    public org.digitalArmour.verifier.model.CLTemplate create(long checklistId);

    /**
    * Removes the c l template with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param checklistId the primary key of the c l template
    * @return the c l template that was removed
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate remove(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    public org.digitalArmour.verifier.model.CLTemplate updateImpl(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the c l template with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchCLTemplateException} if it could not be found.
    *
    * @param checklistId the primary key of the c l template
    * @return the c l template
    * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate findByPrimaryKey(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCLTemplateException;

    /**
    * Returns the c l template with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param checklistId the primary key of the c l template
    * @return the c l template, or <code>null</code> if a c l template with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.CLTemplate fetchByPrimaryKey(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the c l templates.
    *
    * @return the c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the c l templates.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @return the range of c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the c l templates.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of c l templates
    * @param end the upper bound of the range of c l templates (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of c l templates
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.CLTemplate> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the c l templates from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of c l templates.
    *
    * @return the number of c l templates
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
