package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.service.CategoryLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class CategoryActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public CategoryActionableDynamicQuery() throws SystemException {
        setBaseLocalService(CategoryLocalServiceUtil.getService());
        setClass(Category.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("catId");
    }
}
