package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.Category;

/**
 * The persistence interface for the category service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CategoryPersistenceImpl
 * @see CategoryUtil
 * @generated
 */
public interface CategoryPersistence extends BasePersistence<Category> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link CategoryUtil} to access the category persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the first category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the last category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the categories before and after the current category in the ordered set where uuid = &#63;.
    *
    * @param catId the primary key of the current category
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category[] findByUuid_PrevAndNext(
        long catId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Removes all the categories where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the categories where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByCL_Id(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the categories where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByCL_Id(
        long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the categories where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByCL_Id(
        long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findByCL_Id_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the first category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchByCL_Id_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findByCL_Id_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the last category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchByCL_Id_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the categories before and after the current category in the ordered set where checklistId = &#63;.
    *
    * @param catId the primary key of the current category
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category[] findByCL_Id_PrevAndNext(
        long catId, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Removes all the categories where checklistId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByCL_Id(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of categories where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public int countByCL_Id(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the categories where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findBycatId(
        long catId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the categories where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findBycatId(
        long catId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the categories where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findBycatId(
        long catId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the first category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the last category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the categories where catId = &#63; from the database.
    *
    * @param catId the cat ID
    * @throws SystemException if a system exception occurred
    */
    public void removeBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of categories where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public int countBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the categories where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findBysubcategoryId(
        long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the categories where subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findBysubcategoryId(
        long subcategoryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the categories where subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findBysubcategoryId(
        long subcategoryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findBysubcategoryId_First(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the first category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchBysubcategoryId_First(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findBysubcategoryId_Last(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the last category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchBysubcategoryId_Last(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the categories before and after the current category in the ordered set where subcategoryId = &#63;.
    *
    * @param catId the primary key of the current category
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category[] findBysubcategoryId_PrevAndNext(
        long catId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Removes all the categories where subcategoryId = &#63; from the database.
    *
    * @param subcategoryId the subcategory ID
    * @throws SystemException if a system exception occurred
    */
    public void removeBysubcategoryId(long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of categories where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public int countBysubcategoryId(long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByCL_subcatID(
        long checklistId, long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByCL_subcatID(
        long checklistId, long subcategoryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findByCL_subcatID(
        long checklistId, long subcategoryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findByCL_subcatID_First(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the first category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchByCL_subcatID_First(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findByCL_subcatID_Last(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the last category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchByCL_subcatID_Last(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the categories before and after the current category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param catId the primary key of the current category
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category[] findByCL_subcatID_PrevAndNext(
        long catId, long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Removes all the categories where checklistId = &#63; and subcategoryId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByCL_subcatID(long checklistId, long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public int countByCL_subcatID(long checklistId, long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the category in the entity cache if it is enabled.
    *
    * @param category the category
    */
    public void cacheResult(org.digitalArmour.verifier.model.Category category);

    /**
    * Caches the categories in the entity cache if it is enabled.
    *
    * @param categories the categories
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.Category> categories);

    /**
    * Creates a new category with the primary key. Does not add the category to the database.
    *
    * @param catId the primary key for the new category
    * @return the new category
    */
    public org.digitalArmour.verifier.model.Category create(long catId);

    /**
    * Removes the category with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param catId the primary key of the category
    * @return the category that was removed
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category remove(long catId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    public org.digitalArmour.verifier.model.Category updateImpl(
        org.digitalArmour.verifier.model.Category category)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the category with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchCategoryException} if it could not be found.
    *
    * @param catId the primary key of the category
    * @return the category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category findByPrimaryKey(
        long catId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException;

    /**
    * Returns the category with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param catId the primary key of the category
    * @return the category, or <code>null</code> if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Category fetchByPrimaryKey(
        long catId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the categories.
    *
    * @return the categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of categories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Category> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the categories from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of categories.
    *
    * @return the number of categories
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
