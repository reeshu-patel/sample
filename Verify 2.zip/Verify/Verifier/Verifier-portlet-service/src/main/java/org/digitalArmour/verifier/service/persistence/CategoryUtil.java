package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import org.digitalArmour.verifier.model.Category;

import java.util.List;

/**
 * The persistence utility for the category service. This utility wraps {@link CategoryPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CategoryPersistence
 * @see CategoryPersistenceImpl
 * @generated
 */
public class CategoryUtil {
    private static CategoryPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(Category category) {
        getPersistence().clearCache(category);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<Category> findWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<Category> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<Category> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static Category update(Category category) throws SystemException {
        return getPersistence().update(category);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static Category update(Category category,
        ServiceContext serviceContext) throws SystemException {
        return getPersistence().update(category, serviceContext);
    }

    /**
    * Returns all the categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the categories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the categories before and after the current category in the ordered set where uuid = &#63;.
    *
    * @param catId the primary key of the current category
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category[] findByUuid_PrevAndNext(
        long catId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findByUuid_PrevAndNext(catId, uuid, orderByComparator);
    }

    /**
    * Removes all the categories where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of categories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Returns all the categories where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByCL_Id(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByCL_Id(checklistId);
    }

    /**
    * Returns a range of all the categories where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByCL_Id(
        long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByCL_Id(checklistId, start, end);
    }

    /**
    * Returns an ordered range of all the categories where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByCL_Id(
        long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByCL_Id(checklistId, start, end, orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findByCL_Id_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().findByCL_Id_First(checklistId, orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchByCL_Id_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByCL_Id_First(checklistId, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findByCL_Id_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().findByCL_Id_Last(checklistId, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchByCL_Id_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByCL_Id_Last(checklistId, orderByComparator);
    }

    /**
    * Returns the categories before and after the current category in the ordered set where checklistId = &#63;.
    *
    * @param catId the primary key of the current category
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category[] findByCL_Id_PrevAndNext(
        long catId, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findByCL_Id_PrevAndNext(catId, checklistId,
            orderByComparator);
    }

    /**
    * Removes all the categories where checklistId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByCL_Id(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByCL_Id(checklistId);
    }

    /**
    * Returns the number of categories where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static int countByCL_Id(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByCL_Id(checklistId);
    }

    /**
    * Returns all the categories where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findBycatId(
        long catId) throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycatId(catId);
    }

    /**
    * Returns a range of all the categories where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findBycatId(
        long catId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycatId(catId, start, end);
    }

    /**
    * Returns an ordered range of all the categories where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findBycatId(
        long catId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBycatId(catId, start, end, orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().findBycatId_First(catId, orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchBycatId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchBycatId_First(catId, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().findBycatId_Last(catId, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchBycatId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchBycatId_Last(catId, orderByComparator);
    }

    /**
    * Removes all the categories where catId = &#63; from the database.
    *
    * @param catId the cat ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeBycatId(catId);
    }

    /**
    * Returns the number of categories where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static int countBycatId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countBycatId(catId);
    }

    /**
    * Returns all the categories where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findBysubcategoryId(
        long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBysubcategoryId(subcategoryId);
    }

    /**
    * Returns a range of all the categories where subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findBysubcategoryId(
        long subcategoryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findBysubcategoryId(subcategoryId, start, end);
    }

    /**
    * Returns an ordered range of all the categories where subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findBysubcategoryId(
        long subcategoryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findBysubcategoryId(subcategoryId, start, end,
            orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findBysubcategoryId_First(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findBysubcategoryId_First(subcategoryId, orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchBysubcategoryId_First(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBysubcategoryId_First(subcategoryId, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findBysubcategoryId_Last(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findBysubcategoryId_Last(subcategoryId, orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchBysubcategoryId_Last(
        long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchBysubcategoryId_Last(subcategoryId, orderByComparator);
    }

    /**
    * Returns the categories before and after the current category in the ordered set where subcategoryId = &#63;.
    *
    * @param catId the primary key of the current category
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category[] findBysubcategoryId_PrevAndNext(
        long catId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findBysubcategoryId_PrevAndNext(catId, subcategoryId,
            orderByComparator);
    }

    /**
    * Removes all the categories where subcategoryId = &#63; from the database.
    *
    * @param subcategoryId the subcategory ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeBysubcategoryId(long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeBysubcategoryId(subcategoryId);
    }

    /**
    * Returns the number of categories where subcategoryId = &#63;.
    *
    * @param subcategoryId the subcategory ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static int countBysubcategoryId(long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countBysubcategoryId(subcategoryId);
    }

    /**
    * Returns all the categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @return the matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByCL_subcatID(
        long checklistId, long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByCL_subcatID(checklistId, subcategoryId);
    }

    /**
    * Returns a range of all the categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByCL_subcatID(
        long checklistId, long subcategoryId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByCL_subcatID(checklistId, subcategoryId, start, end);
    }

    /**
    * Returns an ordered range of all the categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findByCL_subcatID(
        long checklistId, long subcategoryId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByCL_subcatID(checklistId, subcategoryId, start, end,
            orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findByCL_subcatID_First(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findByCL_subcatID_First(checklistId, subcategoryId,
            orderByComparator);
    }

    /**
    * Returns the first category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchByCL_subcatID_First(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByCL_subcatID_First(checklistId, subcategoryId,
            orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findByCL_subcatID_Last(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findByCL_subcatID_Last(checklistId, subcategoryId,
            orderByComparator);
    }

    /**
    * Returns the last category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching category, or <code>null</code> if a matching category could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchByCL_subcatID_Last(
        long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByCL_subcatID_Last(checklistId, subcategoryId,
            orderByComparator);
    }

    /**
    * Returns the categories before and after the current category in the ordered set where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param catId the primary key of the current category
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category[] findByCL_subcatID_PrevAndNext(
        long catId, long checklistId, long subcategoryId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence()
                   .findByCL_subcatID_PrevAndNext(catId, checklistId,
            subcategoryId, orderByComparator);
    }

    /**
    * Removes all the categories where checklistId = &#63; and subcategoryId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByCL_subcatID(long checklistId, long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByCL_subcatID(checklistId, subcategoryId);
    }

    /**
    * Returns the number of categories where checklistId = &#63; and subcategoryId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param subcategoryId the subcategory ID
    * @return the number of matching categories
    * @throws SystemException if a system exception occurred
    */
    public static int countByCL_subcatID(long checklistId, long subcategoryId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByCL_subcatID(checklistId, subcategoryId);
    }

    /**
    * Caches the category in the entity cache if it is enabled.
    *
    * @param category the category
    */
    public static void cacheResult(
        org.digitalArmour.verifier.model.Category category) {
        getPersistence().cacheResult(category);
    }

    /**
    * Caches the categories in the entity cache if it is enabled.
    *
    * @param categories the categories
    */
    public static void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.Category> categories) {
        getPersistence().cacheResult(categories);
    }

    /**
    * Creates a new category with the primary key. Does not add the category to the database.
    *
    * @param catId the primary key for the new category
    * @return the new category
    */
    public static org.digitalArmour.verifier.model.Category create(long catId) {
        return getPersistence().create(catId);
    }

    /**
    * Removes the category with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param catId the primary key of the category
    * @return the category that was removed
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category remove(long catId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().remove(catId);
    }

    public static org.digitalArmour.verifier.model.Category updateImpl(
        org.digitalArmour.verifier.model.Category category)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(category);
    }

    /**
    * Returns the category with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchCategoryException} if it could not be found.
    *
    * @param catId the primary key of the category
    * @return the category
    * @throws org.digitalArmour.verifier.NoSuchCategoryException if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category findByPrimaryKey(
        long catId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchCategoryException {
        return getPersistence().findByPrimaryKey(catId);
    }

    /**
    * Returns the category with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param catId the primary key of the category
    * @return the category, or <code>null</code> if a category with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Category fetchByPrimaryKey(
        long catId) throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(catId);
    }

    /**
    * Returns all the categories.
    *
    * @return the categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @return the range of categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the categories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of categories
    * @param end the upper bound of the range of categories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of categories
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Category> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the categories from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of categories.
    *
    * @return the number of categories
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static CategoryPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (CategoryPersistence) PortletBeanLocatorUtil.locate(org.digitalArmour.verifier.service.ClpSerializer.getServletContextName(),
                    CategoryPersistence.class.getName());

            ReferenceRegistry.registerReference(CategoryUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(CategoryPersistence persistence) {
    }
}
