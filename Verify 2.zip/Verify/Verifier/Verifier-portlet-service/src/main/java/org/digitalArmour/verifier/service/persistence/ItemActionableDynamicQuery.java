package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ItemActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ItemActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ItemLocalServiceUtil.getService());
        setClass(Item.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("itemId");
    }
}
