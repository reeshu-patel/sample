package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.ItemComment;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class ItemCommentActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ItemCommentActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ItemCommentLocalServiceUtil.getService());
        setClass(ItemComment.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("commId");
    }
}
