package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.ItemFile;

/**
 * The persistence interface for the item file service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ItemFilePersistenceImpl
 * @see ItemFileUtil
 * @generated
 */
public interface ItemFilePersistence extends BasePersistence<ItemFile> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link ItemFileUtil} to access the item file persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the item files where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the item files where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of item files
    * @param end the upper bound of the range of item files (not inclusive)
    * @return the range of matching item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the item files where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of item files
    * @param end the upper bound of the range of item files (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first item file in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching item file
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    /**
    * Returns the first item file in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching item file, or <code>null</code> if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last item file in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching item file
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    /**
    * Returns the last item file in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching item file, or <code>null</code> if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the item files before and after the current item file in the ordered set where uuid = &#63;.
    *
    * @param fileId the primary key of the current item file
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next item file
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile[] findByUuid_PrevAndNext(
        long fileId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    /**
    * Removes all the item files where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of item files where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching item files
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the item files where itemId = &#63;.
    *
    * @param itemId the item ID
    * @return the matching item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findByItemId(
        long itemId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the item files where itemId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param itemId the item ID
    * @param start the lower bound of the range of item files
    * @param end the upper bound of the range of item files (not inclusive)
    * @return the range of matching item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findByItemId(
        long itemId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the item files where itemId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param itemId the item ID
    * @param start the lower bound of the range of item files
    * @param end the upper bound of the range of item files (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findByItemId(
        long itemId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first item file in the ordered set where itemId = &#63;.
    *
    * @param itemId the item ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching item file
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile findByItemId_First(
        long itemId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    /**
    * Returns the first item file in the ordered set where itemId = &#63;.
    *
    * @param itemId the item ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching item file, or <code>null</code> if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile fetchByItemId_First(
        long itemId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last item file in the ordered set where itemId = &#63;.
    *
    * @param itemId the item ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching item file
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile findByItemId_Last(
        long itemId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    /**
    * Returns the last item file in the ordered set where itemId = &#63;.
    *
    * @param itemId the item ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching item file, or <code>null</code> if a matching item file could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile fetchByItemId_Last(
        long itemId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the item files before and after the current item file in the ordered set where itemId = &#63;.
    *
    * @param fileId the primary key of the current item file
    * @param itemId the item ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next item file
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile[] findByItemId_PrevAndNext(
        long fileId, long itemId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    /**
    * Removes all the item files where itemId = &#63; from the database.
    *
    * @param itemId the item ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByItemId(long itemId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of item files where itemId = &#63;.
    *
    * @param itemId the item ID
    * @return the number of matching item files
    * @throws SystemException if a system exception occurred
    */
    public int countByItemId(long itemId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the item file in the entity cache if it is enabled.
    *
    * @param itemFile the item file
    */
    public void cacheResult(org.digitalArmour.verifier.model.ItemFile itemFile);

    /**
    * Caches the item files in the entity cache if it is enabled.
    *
    * @param itemFiles the item files
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.ItemFile> itemFiles);

    /**
    * Creates a new item file with the primary key. Does not add the item file to the database.
    *
    * @param fileId the primary key for the new item file
    * @return the new item file
    */
    public org.digitalArmour.verifier.model.ItemFile create(long fileId);

    /**
    * Removes the item file with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param fileId the primary key of the item file
    * @return the item file that was removed
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile remove(long fileId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    public org.digitalArmour.verifier.model.ItemFile updateImpl(
        org.digitalArmour.verifier.model.ItemFile itemFile)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the item file with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchItemFileException} if it could not be found.
    *
    * @param fileId the primary key of the item file
    * @return the item file
    * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile findByPrimaryKey(
        long fileId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchItemFileException;

    /**
    * Returns the item file with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param fileId the primary key of the item file
    * @return the item file, or <code>null</code> if a item file with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.ItemFile fetchByPrimaryKey(
        long fileId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the item files.
    *
    * @return the item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the item files.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of item files
    * @param end the upper bound of the range of item files (not inclusive)
    * @return the range of item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the item files.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of item files
    * @param end the upper bound of the range of item files (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of item files
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.ItemFile> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the item files from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of item files.
    *
    * @return the number of item files
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
