package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.Notification;
import org.digitalArmour.verifier.service.NotificationLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class NotificationActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public NotificationActionableDynamicQuery() throws SystemException {
        setBaseLocalService(NotificationLocalServiceUtil.getService());
        setClass(Notification.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("noteId");
    }
}
