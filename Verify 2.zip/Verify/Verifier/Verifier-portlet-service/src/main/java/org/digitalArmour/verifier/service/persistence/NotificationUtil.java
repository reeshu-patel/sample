package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import org.digitalArmour.verifier.model.Notification;

import java.util.List;

/**
 * The persistence utility for the notification service. This utility wraps {@link NotificationPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see NotificationPersistence
 * @see NotificationPersistenceImpl
 * @generated
 */
public class NotificationUtil {
    private static NotificationPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(Notification notification) {
        getPersistence().clearCache(notification);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<Notification> findWithDynamicQuery(
        DynamicQuery dynamicQuery) throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<Notification> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<Notification> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static Notification update(Notification notification)
        throws SystemException {
        return getPersistence().update(notification);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static Notification update(Notification notification,
        ServiceContext serviceContext) throws SystemException {
        return getPersistence().update(notification, serviceContext);
    }

    /**
    * Returns all the notifications where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching notifications
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Notification> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the notifications where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.NotificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of notifications
    * @param end the upper bound of the range of notifications (not inclusive)
    * @return the range of matching notifications
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Notification> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the notifications where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.NotificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of notifications
    * @param end the upper bound of the range of notifications (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching notifications
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Notification> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first notification in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching notification
    * @throws org.digitalArmour.verifier.NoSuchNotificationException if a matching notification could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchNotificationException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first notification in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching notification, or <code>null</code> if a matching notification could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last notification in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching notification
    * @throws org.digitalArmour.verifier.NoSuchNotificationException if a matching notification could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchNotificationException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last notification in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching notification, or <code>null</code> if a matching notification could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the notifications before and after the current notification in the ordered set where uuid = &#63;.
    *
    * @param noteId the primary key of the current notification
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next notification
    * @throws org.digitalArmour.verifier.NoSuchNotificationException if a notification with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification[] findByUuid_PrevAndNext(
        long noteId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchNotificationException {
        return getPersistence()
                   .findByUuid_PrevAndNext(noteId, uuid, orderByComparator);
    }

    /**
    * Removes all the notifications where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of notifications where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching notifications
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Caches the notification in the entity cache if it is enabled.
    *
    * @param notification the notification
    */
    public static void cacheResult(
        org.digitalArmour.verifier.model.Notification notification) {
        getPersistence().cacheResult(notification);
    }

    /**
    * Caches the notifications in the entity cache if it is enabled.
    *
    * @param notifications the notifications
    */
    public static void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.Notification> notifications) {
        getPersistence().cacheResult(notifications);
    }

    /**
    * Creates a new notification with the primary key. Does not add the notification to the database.
    *
    * @param noteId the primary key for the new notification
    * @return the new notification
    */
    public static org.digitalArmour.verifier.model.Notification create(
        long noteId) {
        return getPersistence().create(noteId);
    }

    /**
    * Removes the notification with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param noteId the primary key of the notification
    * @return the notification that was removed
    * @throws org.digitalArmour.verifier.NoSuchNotificationException if a notification with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification remove(
        long noteId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchNotificationException {
        return getPersistence().remove(noteId);
    }

    public static org.digitalArmour.verifier.model.Notification updateImpl(
        org.digitalArmour.verifier.model.Notification notification)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(notification);
    }

    /**
    * Returns the notification with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchNotificationException} if it could not be found.
    *
    * @param noteId the primary key of the notification
    * @return the notification
    * @throws org.digitalArmour.verifier.NoSuchNotificationException if a notification with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification findByPrimaryKey(
        long noteId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchNotificationException {
        return getPersistence().findByPrimaryKey(noteId);
    }

    /**
    * Returns the notification with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param noteId the primary key of the notification
    * @return the notification, or <code>null</code> if a notification with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Notification fetchByPrimaryKey(
        long noteId) throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(noteId);
    }

    /**
    * Returns all the notifications.
    *
    * @return the notifications
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Notification> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the notifications.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.NotificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of notifications
    * @param end the upper bound of the range of notifications (not inclusive)
    * @return the range of notifications
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Notification> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the notifications.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.NotificationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of notifications
    * @param end the upper bound of the range of notifications (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of notifications
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Notification> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the notifications from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of notifications.
    *
    * @return the number of notifications
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static NotificationPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (NotificationPersistence) PortletBeanLocatorUtil.locate(org.digitalArmour.verifier.service.ClpSerializer.getServletContextName(),
                    NotificationPersistence.class.getName());

            ReferenceRegistry.registerReference(NotificationUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(NotificationPersistence persistence) {
    }
}
