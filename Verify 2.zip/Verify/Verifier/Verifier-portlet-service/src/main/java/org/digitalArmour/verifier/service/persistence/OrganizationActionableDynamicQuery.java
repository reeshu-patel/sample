package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.Organization;
import org.digitalArmour.verifier.service.OrganizationLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class OrganizationActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public OrganizationActionableDynamicQuery() throws SystemException {
        setBaseLocalService(OrganizationLocalServiceUtil.getService());
        setClass(Organization.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("orgId");
    }
}
