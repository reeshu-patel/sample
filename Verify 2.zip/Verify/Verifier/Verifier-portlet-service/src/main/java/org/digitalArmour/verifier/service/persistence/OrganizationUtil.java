package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import org.digitalArmour.verifier.model.Organization;

import java.util.List;

/**
 * The persistence utility for the organization service. This utility wraps {@link OrganizationPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see OrganizationPersistence
 * @see OrganizationPersistenceImpl
 * @generated
 */
public class OrganizationUtil {
    private static OrganizationPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(Organization organization) {
        getPersistence().clearCache(organization);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<Organization> findWithDynamicQuery(
        DynamicQuery dynamicQuery) throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<Organization> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<Organization> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static Organization update(Organization organization)
        throws SystemException {
        return getPersistence().update(organization);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static Organization update(Organization organization,
        ServiceContext serviceContext) throws SystemException {
        return getPersistence().update(organization, serviceContext);
    }

    /**
    * Returns all the organizations where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching organizations
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Organization> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the organizations where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.OrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of organizations
    * @param end the upper bound of the range of organizations (not inclusive)
    * @return the range of matching organizations
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Organization> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the organizations where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.OrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of organizations
    * @param end the upper bound of the range of organizations (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching organizations
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Organization> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first organization in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching organization
    * @throws org.digitalArmour.verifier.NoSuchOrganizationException if a matching organization could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchOrganizationException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first organization in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching organization, or <code>null</code> if a matching organization could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last organization in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching organization
    * @throws org.digitalArmour.verifier.NoSuchOrganizationException if a matching organization could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchOrganizationException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last organization in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching organization, or <code>null</code> if a matching organization could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the organizations before and after the current organization in the ordered set where uuid = &#63;.
    *
    * @param orgId the primary key of the current organization
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next organization
    * @throws org.digitalArmour.verifier.NoSuchOrganizationException if a organization with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization[] findByUuid_PrevAndNext(
        long orgId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchOrganizationException {
        return getPersistence()
                   .findByUuid_PrevAndNext(orgId, uuid, orderByComparator);
    }

    /**
    * Removes all the organizations where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of organizations where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching organizations
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Caches the organization in the entity cache if it is enabled.
    *
    * @param organization the organization
    */
    public static void cacheResult(
        org.digitalArmour.verifier.model.Organization organization) {
        getPersistence().cacheResult(organization);
    }

    /**
    * Caches the organizations in the entity cache if it is enabled.
    *
    * @param organizations the organizations
    */
    public static void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.Organization> organizations) {
        getPersistence().cacheResult(organizations);
    }

    /**
    * Creates a new organization with the primary key. Does not add the organization to the database.
    *
    * @param orgId the primary key for the new organization
    * @return the new organization
    */
    public static org.digitalArmour.verifier.model.Organization create(
        long orgId) {
        return getPersistence().create(orgId);
    }

    /**
    * Removes the organization with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param orgId the primary key of the organization
    * @return the organization that was removed
    * @throws org.digitalArmour.verifier.NoSuchOrganizationException if a organization with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization remove(
        long orgId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchOrganizationException {
        return getPersistence().remove(orgId);
    }

    public static org.digitalArmour.verifier.model.Organization updateImpl(
        org.digitalArmour.verifier.model.Organization organization)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(organization);
    }

    /**
    * Returns the organization with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchOrganizationException} if it could not be found.
    *
    * @param orgId the primary key of the organization
    * @return the organization
    * @throws org.digitalArmour.verifier.NoSuchOrganizationException if a organization with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization findByPrimaryKey(
        long orgId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchOrganizationException {
        return getPersistence().findByPrimaryKey(orgId);
    }

    /**
    * Returns the organization with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param orgId the primary key of the organization
    * @return the organization, or <code>null</code> if a organization with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static org.digitalArmour.verifier.model.Organization fetchByPrimaryKey(
        long orgId) throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(orgId);
    }

    /**
    * Returns all the organizations.
    *
    * @return the organizations
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Organization> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the organizations.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.OrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of organizations
    * @param end the upper bound of the range of organizations (not inclusive)
    * @return the range of organizations
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Organization> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the organizations.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.OrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of organizations
    * @param end the upper bound of the range of organizations (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of organizations
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<org.digitalArmour.verifier.model.Organization> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the organizations from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of organizations.
    *
    * @return the number of organizations
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static OrganizationPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (OrganizationPersistence) PortletBeanLocatorUtil.locate(org.digitalArmour.verifier.service.ClpSerializer.getServletContextName(),
                    OrganizationPersistence.class.getName());

            ReferenceRegistry.registerReference(OrganizationUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(OrganizationPersistence persistence) {
    }
}
