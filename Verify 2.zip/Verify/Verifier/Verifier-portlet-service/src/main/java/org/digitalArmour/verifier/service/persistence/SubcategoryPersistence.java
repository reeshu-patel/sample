package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.Subcategory;

/**
 * The persistence interface for the subcategory service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see SubcategoryPersistenceImpl
 * @see SubcategoryUtil
 * @generated
 */
public interface SubcategoryPersistence extends BasePersistence<Subcategory> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link SubcategoryUtil} to access the subcategory persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the subcategories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the subcategories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.SubcategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of subcategories
    * @param end the upper bound of the range of subcategories (not inclusive)
    * @return the range of matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the subcategories where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.SubcategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of subcategories
    * @param end the upper bound of the range of subcategories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first subcategory in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching subcategory
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    /**
    * Returns the first subcategory in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching subcategory, or <code>null</code> if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last subcategory in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching subcategory
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    /**
    * Returns the last subcategory in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching subcategory, or <code>null</code> if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the subcategories before and after the current subcategory in the ordered set where uuid = &#63;.
    *
    * @param subcatId the primary key of the current subcategory
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next subcategory
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a subcategory with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory[] findByUuid_PrevAndNext(
        long subcatId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    /**
    * Removes all the subcategories where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of subcategories where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the subcategories where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findByCategId(
        long catId) throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the subcategories where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.SubcategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of subcategories
    * @param end the upper bound of the range of subcategories (not inclusive)
    * @return the range of matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findByCategId(
        long catId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the subcategories where catId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.SubcategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param catId the cat ID
    * @param start the lower bound of the range of subcategories
    * @param end the upper bound of the range of subcategories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findByCategId(
        long catId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first subcategory in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching subcategory
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory findByCategId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    /**
    * Returns the first subcategory in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching subcategory, or <code>null</code> if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory fetchByCategId_First(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last subcategory in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching subcategory
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory findByCategId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    /**
    * Returns the last subcategory in the ordered set where catId = &#63;.
    *
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching subcategory, or <code>null</code> if a matching subcategory could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory fetchByCategId_Last(
        long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the subcategories before and after the current subcategory in the ordered set where catId = &#63;.
    *
    * @param subcatId the primary key of the current subcategory
    * @param catId the cat ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next subcategory
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a subcategory with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory[] findByCategId_PrevAndNext(
        long subcatId, long catId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    /**
    * Removes all the subcategories where catId = &#63; from the database.
    *
    * @param catId the cat ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByCategId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of subcategories where catId = &#63;.
    *
    * @param catId the cat ID
    * @return the number of matching subcategories
    * @throws SystemException if a system exception occurred
    */
    public int countByCategId(long catId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the subcategory in the entity cache if it is enabled.
    *
    * @param subcategory the subcategory
    */
    public void cacheResult(
        org.digitalArmour.verifier.model.Subcategory subcategory);

    /**
    * Caches the subcategories in the entity cache if it is enabled.
    *
    * @param subcategories the subcategories
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.Subcategory> subcategories);

    /**
    * Creates a new subcategory with the primary key. Does not add the subcategory to the database.
    *
    * @param subcatId the primary key for the new subcategory
    * @return the new subcategory
    */
    public org.digitalArmour.verifier.model.Subcategory create(long subcatId);

    /**
    * Removes the subcategory with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param subcatId the primary key of the subcategory
    * @return the subcategory that was removed
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a subcategory with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory remove(long subcatId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    public org.digitalArmour.verifier.model.Subcategory updateImpl(
        org.digitalArmour.verifier.model.Subcategory subcategory)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the subcategory with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchSubcategoryException} if it could not be found.
    *
    * @param subcatId the primary key of the subcategory
    * @return the subcategory
    * @throws org.digitalArmour.verifier.NoSuchSubcategoryException if a subcategory with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory findByPrimaryKey(
        long subcatId)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchSubcategoryException;

    /**
    * Returns the subcategory with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param subcatId the primary key of the subcategory
    * @return the subcategory, or <code>null</code> if a subcategory with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.Subcategory fetchByPrimaryKey(
        long subcatId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the subcategories.
    *
    * @return the subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the subcategories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.SubcategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of subcategories
    * @param end the upper bound of the range of subcategories (not inclusive)
    * @return the range of subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the subcategories.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.SubcategoryModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of subcategories
    * @param end the upper bound of the range of subcategories (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of subcategories
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.Subcategory> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the subcategories from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of subcategories.
    *
    * @return the number of subcategories
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
