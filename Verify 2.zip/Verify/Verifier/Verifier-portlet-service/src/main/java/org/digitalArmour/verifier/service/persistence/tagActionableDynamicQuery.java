package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

import org.digitalArmour.verifier.model.tag;
import org.digitalArmour.verifier.service.tagLocalServiceUtil;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public abstract class tagActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public tagActionableDynamicQuery() throws SystemException {
        setBaseLocalService(tagLocalServiceUtil.getService());
        setClass(tag.class);

        setClassLoader(org.digitalArmour.verifier.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("Id");
    }
}
