package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import org.digitalArmour.verifier.model.tag;

/**
 * The persistence interface for the tag service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see tagPersistenceImpl
 * @see tagUtil
 * @generated
 */
public interface tagPersistence extends BasePersistence<tag> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link tagUtil} to access the tag persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the tags where tagName = &#63;.
    *
    * @param tagName the tag name
    * @return the matching tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findBytagtagName(
        java.lang.String tagName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the tags where tagName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param tagName the tag name
    * @param start the lower bound of the range of tags
    * @param end the upper bound of the range of tags (not inclusive)
    * @return the range of matching tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findBytagtagName(
        java.lang.String tagName, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the tags where tagName = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param tagName the tag name
    * @param start the lower bound of the range of tags
    * @param end the upper bound of the range of tags (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findBytagtagName(
        java.lang.String tagName, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first tag in the ordered set where tagName = &#63;.
    *
    * @param tagName the tag name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching tag
    * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag findBytagtagName_First(
        java.lang.String tagName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    /**
    * Returns the first tag in the ordered set where tagName = &#63;.
    *
    * @param tagName the tag name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching tag, or <code>null</code> if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag fetchBytagtagName_First(
        java.lang.String tagName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last tag in the ordered set where tagName = &#63;.
    *
    * @param tagName the tag name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching tag
    * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag findBytagtagName_Last(
        java.lang.String tagName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    /**
    * Returns the last tag in the ordered set where tagName = &#63;.
    *
    * @param tagName the tag name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching tag, or <code>null</code> if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag fetchBytagtagName_Last(
        java.lang.String tagName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the tags before and after the current tag in the ordered set where tagName = &#63;.
    *
    * @param Id the primary key of the current tag
    * @param tagName the tag name
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next tag
    * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag[] findBytagtagName_PrevAndNext(
        long Id, java.lang.String tagName,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    /**
    * Removes all the tags where tagName = &#63; from the database.
    *
    * @param tagName the tag name
    * @throws SystemException if a system exception occurred
    */
    public void removeBytagtagName(java.lang.String tagName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of tags where tagName = &#63;.
    *
    * @param tagName the tag name
    * @return the number of matching tags
    * @throws SystemException if a system exception occurred
    */
    public int countBytagtagName(java.lang.String tagName)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the tags where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the matching tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findBychecklistId(
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the tags where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of tags
    * @param end the upper bound of the range of tags (not inclusive)
    * @return the range of matching tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findBychecklistId(
        long checklistId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the tags where checklistId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param checklistId the checklist ID
    * @param start the lower bound of the range of tags
    * @param end the upper bound of the range of tags (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findBychecklistId(
        long checklistId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first tag in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching tag
    * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag findBychecklistId_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    /**
    * Returns the first tag in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching tag, or <code>null</code> if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag fetchBychecklistId_First(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last tag in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching tag
    * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag findBychecklistId_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    /**
    * Returns the last tag in the ordered set where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching tag, or <code>null</code> if a matching tag could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag fetchBychecklistId_Last(
        long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the tags before and after the current tag in the ordered set where checklistId = &#63;.
    *
    * @param Id the primary key of the current tag
    * @param checklistId the checklist ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next tag
    * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag[] findBychecklistId_PrevAndNext(
        long Id, long checklistId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    /**
    * Removes all the tags where checklistId = &#63; from the database.
    *
    * @param checklistId the checklist ID
    * @throws SystemException if a system exception occurred
    */
    public void removeBychecklistId(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of tags where checklistId = &#63;.
    *
    * @param checklistId the checklist ID
    * @return the number of matching tags
    * @throws SystemException if a system exception occurred
    */
    public int countBychecklistId(long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the tag in the entity cache if it is enabled.
    *
    * @param tag the tag
    */
    public void cacheResult(org.digitalArmour.verifier.model.tag tag);

    /**
    * Caches the tags in the entity cache if it is enabled.
    *
    * @param tags the tags
    */
    public void cacheResult(
        java.util.List<org.digitalArmour.verifier.model.tag> tags);

    /**
    * Creates a new tag with the primary key. Does not add the tag to the database.
    *
    * @param Id the primary key for the new tag
    * @return the new tag
    */
    public org.digitalArmour.verifier.model.tag create(long Id);

    /**
    * Removes the tag with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param Id the primary key of the tag
    * @return the tag that was removed
    * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag remove(long Id)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    public org.digitalArmour.verifier.model.tag updateImpl(
        org.digitalArmour.verifier.model.tag tag)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the tag with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchtagException} if it could not be found.
    *
    * @param Id the primary key of the tag
    * @return the tag
    * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag findByPrimaryKey(long Id)
        throws com.liferay.portal.kernel.exception.SystemException,
            org.digitalArmour.verifier.NoSuchtagException;

    /**
    * Returns the tag with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param Id the primary key of the tag
    * @return the tag, or <code>null</code> if a tag with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public org.digitalArmour.verifier.model.tag fetchByPrimaryKey(long Id)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the tags.
    *
    * @return the tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the tags.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of tags
    * @param end the upper bound of the range of tags (not inclusive)
    * @return the range of tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the tags.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of tags
    * @param end the upper bound of the range of tags (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of tags
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<org.digitalArmour.verifier.model.tag> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the tags from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of tags.
    *
    * @return the number of tags
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
