package org.digitalArmour.verifier.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link tagService}.
 *
 * @author Brian Wing Shun Chan
 * @see tagService
 * @generated
 */
public class tagServiceWrapper implements tagService,
    ServiceWrapper<tagService> {
    private tagService _tagService;

    public tagServiceWrapper(tagService tagService) {
        _tagService = tagService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _tagService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _tagService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _tagService.invokeMethod(name, parameterTypes, arguments);
    }

    @Override
    public org.digitalArmour.verifier.model.tag AddTag(java.lang.String tag,
        long checklistId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _tagService.AddTag(tag, checklistId);
    }

    @Override
    public org.digitalArmour.verifier.model.tag DeleteTag(long tagid)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _tagService.DeleteTag(tagid);
    }

    @Override
    public java.util.List<org.digitalArmour.verifier.model.tag> searchbychecklistId(
        long checklistId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _tagService.searchbychecklistId(checklistId);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public tagService getWrappedtagService() {
        return _tagService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedtagService(tagService tagService) {
        _tagService = tagService;
    }

    @Override
    public tagService getWrappedService() {
        return _tagService;
    }

    @Override
    public void setWrappedService(tagService tagService) {
        _tagService = tagService;
    }
}
