package org.digitalArmour.verifier.command;

import java.io.Serializable;
import java.util.List;

import org.digitalArmour.verifier.model.ActItem;

public class ActiveCategoryCommand implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	long id;
	long   activechlid;
	String name;
	long subcatid;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public long getActivechlid() {
		return activechlid;
	}
	public void setActivechlid(long activechlid) {
		this.activechlid = activechlid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getSubcatid() {
		return subcatid;
	}
	public void setSubcatid(long subcatid) {
		this.subcatid = subcatid;
	}
	public List<ActItem> getActItem() {
		return actItem;
	}
	public void setActItem(List<ActItem> actItem) {
		this.actItem = actItem;
	}
	List<ActItem> actItem;
	
	
}
