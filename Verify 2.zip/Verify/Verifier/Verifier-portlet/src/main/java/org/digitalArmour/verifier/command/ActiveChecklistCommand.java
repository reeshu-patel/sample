package org.digitalArmour.verifier.command;

import java.io.Serializable;
import java.util.List;


public class ActiveChecklistCommand implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	long	activid;
	long	activchecklid;
	String  name;
	String  desc;
	String org;
	boolean ispublic;
	boolean iscomplate;
	long   actClUserId;

	

	public long getActClUserId() {
		return actClUserId;
	}

	public void setActClUserId(long actClUserId) {
		this.actClUserId = actClUserId;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public boolean isIspublic() {
		return ispublic;
	}

	public void setIspublic(boolean ispublic) {
		this.ispublic = ispublic;
	}

	public boolean isIscomplate() {
		return iscomplate;
	}

	public void setIscomplate(boolean iscomplate) {
		this.iscomplate = iscomplate;
	}

	List<ActiveCategoryCommand> activeCategoryCommand;

	public long getActivid() {
		return activid;
	}

	public void setActivid(long activid) {
		this.activid = activid;
	}

	public long getActivchecklid() {
		return activchecklid;
	}

	public void setActivchecklid(long activchecklid) {
		this.activchecklid = activchecklid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<ActiveCategoryCommand> getActiveCategoryCommand() {
		return activeCategoryCommand;
	}

	public void setActiveCategoryCommand(
			List<ActiveCategoryCommand> activeCategoryCommand) {
		this.activeCategoryCommand = activeCategoryCommand;
	}

	

	
	
}
