package org.digitalArmour.verifier.command;

import java.io.Serializable;
import java.util.List;

import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.Subcategory;

public class CategoryCommand implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	long	id;
	String name;
	String desc;
	long subcatid;
	
	public long getSubcatid() {
		return subcatid;
	}
	public void setSubcatid(long subcatid) {
		this.subcatid = subcatid;
	}
	List<Item> itemList;
	//List<Subcategory> subcats;
	
	/*public List<Subcategory> getSubcats() {
		return subcats;
	}
	public void setSubcats(List<Subcategory> subcats) {
		this.subcats = subcats;
	}*/
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public List<Item> getItemList() {
		return itemList;
	}
	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}
	


	
}
