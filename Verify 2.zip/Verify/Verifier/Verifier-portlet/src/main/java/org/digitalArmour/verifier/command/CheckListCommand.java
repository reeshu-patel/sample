package org.digitalArmour.verifier.command;

import java.io.Serializable;
import java.util.List;

import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.tag;

public class CheckListCommand implements Serializable{
	
		
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
long	id;
	String name;
	String desc;
	long userid;
	boolean ispublic;
	boolean ispubliccat;
	String clOrganiztion;
	
	public String getClOrganiztion() {
		return clOrganiztion;
	}
	public void setClOrganiztion(String clOrganiztion) {
		this.clOrganiztion = clOrganiztion;
	}
	public boolean isIspubliccat() {
		return ispubliccat;
	}
	public void setIspubliccat(boolean ispubliccat) {
		this.ispubliccat = ispubliccat;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	List<tag> tagList;
	List<CategoryCommand> categoryCommands;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public List<tag> getTagList() {
		return tagList;
	}
	public void setTagList(List<tag> tagList) {
		this.tagList = tagList;
	}
	public List<CategoryCommand> getCategoryCommands() {
		return categoryCommands;
	}
	public void setCategoryCommands(List<CategoryCommand> categoryCommands) {
		this.categoryCommands = categoryCommands;
	}
	public boolean isIspublic() {
		return ispublic;
	}
	public void setIspublic(boolean ispublic) {
		this.ispublic = ispublic;
	}
	
	

}
