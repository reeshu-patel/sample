package org.digitalArmour.verifier.controller;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.notifications.BaseUserNotificationHandler;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.model.UserNotificationEvent;
import com.liferay.portal.service.ServiceContext;


public class DockBarUserNotificationHandler extends BaseUserNotificationHandler{
	public static final String PORTLET_ID ="Verifier_WAR_Verifierportlet";
	
	
	public DockBarUserNotificationHandler() {
System.out.println("HANDLER"+PORTLET_ID);
		setPortletId(DockBarUserNotificationHandler.PORTLET_ID);
	}
	@Override
	protected String getBody(UserNotificationEvent userNotificationEvent,
			ServiceContext serviceContext) throws Exception {
		JSONObject jsonObject = JSONFactoryUtil
				.createJSONObject(userNotificationEvent.getPayload());
		String notification=jsonObject.getString("notification");
		String notificationText=jsonObject.getString("notificationText");
		String after=jsonObject.getString("after");
		
		String title = "<strong>Verify</strong>";
		String body = StringUtil.replace(getBodyTemplate(), new String[] {
				"[$TITLE$]", "[$BODY_TEXT$]" },
				new String[] { title, notificationText });
				return body;
		
	}
	
	protected String getBodyTemplate() throws Exception {
		StringBundler sb = new StringBundler(5);
		sb.append("<div class=\"title\">[$TITLE$]</div><div ");
		sb.append("class=\"body\">[$BODY_TEXT$]</div>");
		return sb.toString();
	}
}