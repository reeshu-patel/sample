package org.digitalArmour.verifier.controller;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletModeException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.WindowState;
import javax.portlet.WindowStateException;

import org.apache.commons.io.FileUtils;
import org.digitalArmour.verifier.command.ActiveCategoryCommand;
import org.digitalArmour.verifier.command.ActiveChecklistCommand;
import org.digitalArmour.verifier.command.CategoryCommand;
import org.digitalArmour.verifier.command.CheckListCommand;
import org.digitalArmour.verifier.model.ActCLCollab;
import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.model.ActItem;
import org.digitalArmour.verifier.model.ActItemComment;
import org.digitalArmour.verifier.model.ActItemFile;
import org.digitalArmour.verifier.model.ActivateCL;
import org.digitalArmour.verifier.model.CLCollab;
import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.ItemComment;
import org.digitalArmour.verifier.model.ItemFile;
import org.digitalArmour.verifier.model.Notification;
import org.digitalArmour.verifier.model.Subcategory;
import org.digitalArmour.verifier.model.tag;
import org.digitalArmour.verifier.model.impl.ActCLCollabImpl;
import org.digitalArmour.verifier.model.impl.ActCategoryImpl;
import org.digitalArmour.verifier.model.impl.ActItemCommentImpl;
import org.digitalArmour.verifier.model.impl.ActItemFileImpl;
import org.digitalArmour.verifier.model.impl.ActItemImpl;
import org.digitalArmour.verifier.model.impl.ActivateCLImpl;
import org.digitalArmour.verifier.model.impl.CLCollabImpl;
import org.digitalArmour.verifier.model.impl.CLTemplateImpl;
import org.digitalArmour.verifier.model.impl.CategoryImpl;
import org.digitalArmour.verifier.model.impl.ItemCommentImpl;
import org.digitalArmour.verifier.model.impl.ItemFileImpl;
import org.digitalArmour.verifier.model.impl.ItemImpl;
import org.digitalArmour.verifier.model.impl.NotificationImpl;
import org.digitalArmour.verifier.model.impl.SubcategoryImpl;
import org.digitalArmour.verifier.model.impl.tagImpl;
import org.digitalArmour.verifier.service.ActCLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemLocalServiceUtil;
import org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil;
import org.digitalArmour.verifier.service.CLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;
import org.digitalArmour.verifier.service.CategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;
import org.digitalArmour.verifier.service.NotificationLocalServiceUtil;
import org.digitalArmour.verifier.service.SubcategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.tagLocalServiceUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PrefsPropsUtil;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Portlet;
import com.liferay.portal.model.User;
import com.liferay.portal.model.UserNotificationEvent;
import com.liferay.portal.service.PortletLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.UserNotificationEventLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
//import org.junit.runner.Request;


@Controller
@RequestMapping(value="VIEW")
public class VerifierController {

	private  static final String  VIEW_JSP = "view";
	private  static final String  Grid_JSP = "Gridview";
	private  static final String  VIEW_JSP_PARAMETER = "veiwPage";
	private  static final String  CHECKLIST_JSP = "checklist";
	private  static final String  ACTIVE_CHECKLIST_JSP = "ActivChecklist";
	private  static final String  CHECKLIST_JSP_SEARCH = "checklist_list";
	private  static final String  CATEGORY_JSP = "category_list";
	private  static final String  ADD_ITEM_JSP = "addItem";
	private  static final String  ADD_ITEM_DESC_JSP = "itemDesc";
	private final static String fileInputName = "fileupload";
	private final static String baseDir = "/tmp/uploaded/";
	private final static String accounttab = "addNotificationEnm";
	private final static String accountset = "setNotification";
	
	@RenderMapping
    public String showForm(RenderRequest request, RenderResponse response, Model model) throws Exception {
		String redirectPage=VIEW_JSP; 
		
		if(request.getParameter(VIEW_JSP_PARAMETER)!=null && !request.getParameter(VIEW_JSP_PARAMETER).isEmpty())
		{redirectPage=request.getParameter(VIEW_JSP_PARAMETER);}
		else{
			ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
			User user = themeDisplay.getUser();
			long  userId=user.getUserId();
			//String check = ParamUtil.getString(request, "myselectItem");
			long selectItem =ParamUtil.getLong(request, "myselectItem");
			
			List<CLTemplate> clTemplates= CLTemplateLocalServiceUtil.getallUser(userId);
			List<CheckListCommand> clcommands = new ArrayList<CheckListCommand>();
			
			
			for(CLTemplate clt1:clTemplates){
		
			//long id1 =clt1.getChecklistId();
			String id11 = Long.toString(clt1.getChecklistId());
			//String id11 =String.valueOf(clt1.getChecklistId());
			//request.setAttribute("chkId", id11);
			Long id1 = Long.parseLong(id11);
			
			CheckListCommand cl = new CheckListCommand();
			CategoryCommand cat = new CategoryCommand();
			CLTemplate clt = CLTemplateLocalServiceUtil.getCLTemplate(id1);
			cl.setId(clt.getChecklistId());
			cl.setName(clt.getClName());
			cl.setDesc(clt.getClDescription());
			cl.setIspublic(clt.getIsPublic());
			cl.setIspubliccat(clt.getIsPubliccat());
			cl.setClOrganiztion(clt.getClOrganiztion());
			List<tag> tags = tagLocalServiceUtil.searchbychecklistId(id1);
			
			
			cl.setTagList(tags);
			List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
			List<Category> categories = CategoryLocalServiceUtil.getBySubClID(id1, 0);
			for (Category category : categories) {
				CategoryCommand cc = new CategoryCommand();
				cc.setId(category.getCatId());
				cc.setName(category.getCatName());

				cc.setSubcatid(category.getSubcategoryId());
				List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
				cc.setItemList(items);
				ccc.add(cc);
			}
			
			cl.setCategoryCommands(ccc);
			clcommands.add(cl);
			
			
			}
			List<CLCollab> clCollabs= CLCollabLocalServiceUtil.searchbyuserId(userId);
			for(CLCollab clcola:clCollabs){
				CLTemplate cluser = CLTemplateLocalServiceUtil.getCLTemplate(clcola.getChecklistId());
				CheckListCommand clUSercomm = new CheckListCommand();
				//SET COMMAND
				clUSercomm.setId(cluser.getChecklistId());
				clUSercomm.setName(cluser.getClName());
				clUSercomm.setDesc(cluser.getClDescription());
				clUSercomm.setUserid(cluser.getClUserId());
				clUSercomm.setIspublic(cluser.getIsPublic());
				clUSercomm.setIspubliccat(cluser.getIsPubliccat());
				List<tag> tags = tagLocalServiceUtil.searchbychecklistId(cluser.getChecklistId());
				
				
				clUSercomm.setTagList(tags);
				List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
				List<Category> categories = CategoryLocalServiceUtil.getBySubClID(cluser.getChecklistId(), 0);
				for (Category category : categories) {
					CategoryCommand cc = new CategoryCommand();
					cc.setId(category.getCatId());
					cc.setName(category.getCatName());

					cc.setSubcatid(category.getSubcategoryId());
					List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
					cc.setItemList(items);
					ccc.add(cc);
				}
				
				clUSercomm.setCategoryCommands(ccc);
				clcommands.add(clUSercomm);
				
			}
			List<CheckListCommand> publicommod = new ArrayList<CheckListCommand>();
			for(CheckListCommand checkListCommand23 : clcommands)
			{
				publicommod.add(checkListCommand23);
			}
			List<CLTemplate> clTemplates2 =CLTemplateLocalServiceUtil.searchbyisPublic(true);
			for(CLTemplate cl:clTemplates2){
				CLTemplate cluser = CLTemplateLocalServiceUtil.getCLTemplate(cl.getChecklistId());
				CheckListCommand finalc = new CheckListCommand();
				
				finalc.setId(cluser.getChecklistId());
				finalc.setName(cluser.getClName());
				finalc.setDesc(cluser.getClDescription());
				finalc.setUserid(cluser.getClUserId());
				finalc.setIspublic(cluser.getIsPublic());
				finalc.setIspubliccat(cluser.getIsPubliccat());
				finalc.setClOrganiztion(cluser.getClOrganiztion());
				List<tag> tags = tagLocalServiceUtil.searchbychecklistId(cluser.getChecklistId());
				
				
				finalc.setTagList(tags);
				List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
				List<Category> categories = CategoryLocalServiceUtil.getBySubClID(cluser.getChecklistId(), 0);
				for (Category category : categories) {
					CategoryCommand cc = new CategoryCommand();
					cc.setId(category.getCatId());
					cc.setName(category.getCatName());

					cc.setSubcatid(category.getSubcategoryId());
					List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
					cc.setItemList(items);
					ccc.add(cc);
				}
				
				boolean found = false;
				
				for(CheckListCommand sd:clcommands){
					long chek = sd.getId();
					
					if(cluser.getChecklistId() == chek)
					{
					found =true;
					break;
					}
				}
				if(found == false){
					finalc.setCategoryCommands(ccc);
					publicommod.add(finalc);
				}
			
				 
			}
			
			model.addAttribute("checkList1",publicommod );
			model.addAttribute("myselectItem", selectItem);
			
			
		}
		return redirectPage;
		
    }
	
	@RenderMapping(params ="action=viewPage")
    public String showFormMain(RenderRequest request, RenderResponse response, Model model) throws Exception {
		ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		User user = themeDisplay.getUser();
		long  userId=user.getUserId();
		//String check = ParamUtil.getString(request, "myselectItem");
		long selectItem =ParamUtil.getLong(request, "myselectItem");
		
		List<CLTemplate> clTemplates= CLTemplateLocalServiceUtil.getallUser(userId);
		List<CheckListCommand> clcommands = new ArrayList<CheckListCommand>();
		
		
		for(CLTemplate clt1:clTemplates){
	
		//long id1 =clt1.getChecklistId();
		String id11 = Long.toString(clt1.getChecklistId());
		//String id11 =String.valueOf(clt1.getChecklistId());
		//request.setAttribute("chkId", id11);
		Long id1 = Long.parseLong(id11);
		
		CheckListCommand cl = new CheckListCommand();
		CategoryCommand cat = new CategoryCommand();
		CLTemplate clt = CLTemplateLocalServiceUtil.getCLTemplate(id1);
		cl.setId(clt.getChecklistId());
		cl.setName(clt.getClName());
		cl.setDesc(clt.getClDescription());
		cl.setIspublic(clt.getIsPublic());
		cl.setIspubliccat(clt.getIsPubliccat());
		cl.setClOrganiztion(clt.getClOrganiztion());
		List<tag> tags = tagLocalServiceUtil.searchbychecklistId(id1);
		
		
		cl.setTagList(tags);
		List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
		List<Category> categories = CategoryLocalServiceUtil.getBySubClID(id1, 0);
		for (Category category : categories) {
			CategoryCommand cc = new CategoryCommand();
			cc.setId(category.getCatId());
			cc.setName(category.getCatName());

			cc.setSubcatid(category.getSubcategoryId());
			List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
			cc.setItemList(items);
			ccc.add(cc);
		}
		
		cl.setCategoryCommands(ccc);
		clcommands.add(cl);
		
		
		}
		List<CLCollab> clCollabs= CLCollabLocalServiceUtil.searchbyuserId(userId);
		for(CLCollab clcola:clCollabs){
			CLTemplate cluser = CLTemplateLocalServiceUtil.getCLTemplate(clcola.getChecklistId());
			CheckListCommand clUSercomm = new CheckListCommand();
			//SET COMMAND
			clUSercomm.setId(cluser.getChecklistId());
			clUSercomm.setName(cluser.getClName());
			clUSercomm.setDesc(cluser.getClDescription());
			clUSercomm.setUserid(cluser.getClUserId());
			clUSercomm.setIspublic(cluser.getIsPublic());
			clUSercomm.setIspubliccat(cluser.getIsPubliccat());
			clUSercomm.setClOrganiztion(cluser.getClOrganiztion());
			List<tag> tags = tagLocalServiceUtil.searchbychecklistId(cluser.getChecklistId());
			
			
			clUSercomm.setTagList(tags);
			List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
			List<Category> categories = CategoryLocalServiceUtil.getBySubClID(cluser.getChecklistId(), 0);
			for (Category category : categories) {
				CategoryCommand cc = new CategoryCommand();
				cc.setId(category.getCatId());
				cc.setName(category.getCatName());

				cc.setSubcatid(category.getSubcategoryId());
				List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
				cc.setItemList(items);
				ccc.add(cc);
			}
			
			clUSercomm.setCategoryCommands(ccc);
			clcommands.add(clUSercomm);
			
		}
		List<CheckListCommand> publicommod = new ArrayList<CheckListCommand>();
		for(CheckListCommand checkListCommand23 : clcommands)
		{
			publicommod.add(checkListCommand23);
		}
		List<CLTemplate> clTemplates2 =CLTemplateLocalServiceUtil.searchbyisPublic(true);
		for(CLTemplate cl:clTemplates2){
			CLTemplate cluser = CLTemplateLocalServiceUtil.getCLTemplate(cl.getChecklistId());
			CheckListCommand finalc = new CheckListCommand();
			
			finalc.setId(cluser.getChecklistId());
			finalc.setName(cluser.getClName());
			finalc.setDesc(cluser.getClDescription());
			finalc.setUserid(cluser.getClUserId());
			finalc.setIspublic(cluser.getIsPublic());
			finalc.setIspubliccat(cluser.getIsPubliccat());
			finalc.setClOrganiztion(cluser.getClOrganiztion());
			List<tag> tags = tagLocalServiceUtil.searchbychecklistId(cluser.getChecklistId());
			
			
			finalc.setTagList(tags);
			List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
			List<Category> categories = CategoryLocalServiceUtil.getBySubClID(cluser.getChecklistId(), 0);
			for (Category category : categories) {
				CategoryCommand cc = new CategoryCommand();
				cc.setId(category.getCatId());
				cc.setName(category.getCatName());

				cc.setSubcatid(category.getSubcategoryId());
				List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
				cc.setItemList(items);
				ccc.add(cc);
			}
			
			boolean found = false;
			
			for(CheckListCommand sd:clcommands){
				long chek = sd.getId();
				
				if(cluser.getChecklistId() == chek)
				{
				found =true;
				break;
				}
			}
			if(found == false){
				finalc.setCategoryCommands(ccc);
				publicommod.add(finalc);
			}
		
			 
		}
		
		model.addAttribute("checkList1",publicommod );
		model.addAttribute("myselectItem", selectItem);
		return VIEW_JSP;
	}
		
	
	@RenderMapping(params ="action=Gridview")
    public String showGridview(RenderRequest request, RenderResponse response, Model model) throws Exception {
		ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		User user = themeDisplay.getUser();
		long  userId=user.getUserId();
		//String check = ParamUtil.getString(request, "myselectItem");
		long selectItem =ParamUtil.getLong(request, "myselectItem");
		
		List<CLTemplate> clTemplates= CLTemplateLocalServiceUtil.getallUser(userId);
		List<CheckListCommand> clcommands = new ArrayList<CheckListCommand>();
		
		
		for(CLTemplate clt1:clTemplates){
	
		//long id1 =clt1.getChecklistId();
		String id11 = Long.toString(clt1.getChecklistId());
		//String id11 =String.valueOf(clt1.getChecklistId());
		//request.setAttribute("chkId", id11);
		Long id1 = Long.parseLong(id11);
		
		CheckListCommand cl = new CheckListCommand();
		CategoryCommand cat = new CategoryCommand();
		CLTemplate clt = CLTemplateLocalServiceUtil.getCLTemplate(id1);
		cl.setId(clt.getChecklistId());
		cl.setName(clt.getClName());
		cl.setDesc(clt.getClDescription());
		cl.setIspublic(clt.getIsPublic());
		cl.setIspubliccat(clt.getIsPubliccat());
		cl.setClOrganiztion(clt.getClOrganiztion());
		List<tag> tags = tagLocalServiceUtil.searchbychecklistId(id1);
		
		
		cl.setTagList(tags);
		List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
		List<Category> categories = CategoryLocalServiceUtil.getBySubClID(id1, 0);
		for (Category category : categories) {
			CategoryCommand cc = new CategoryCommand();
			cc.setId(category.getCatId());
			cc.setName(category.getCatName());

			cc.setSubcatid(category.getSubcategoryId());
			List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
			cc.setItemList(items);
			ccc.add(cc);
		}
		
		cl.setCategoryCommands(ccc);
		clcommands.add(cl);
		
		
		}
		List<CLCollab> clCollabs= CLCollabLocalServiceUtil.searchbyuserId(userId);
		for(CLCollab clcola:clCollabs){
			CLTemplate cluser = CLTemplateLocalServiceUtil.getCLTemplate(clcola.getChecklistId());
			CheckListCommand clUSercomm = new CheckListCommand();
			//SET COMMAND
			clUSercomm.setId(cluser.getChecklistId());
			clUSercomm.setName(cluser.getClName());
			clUSercomm.setDesc(cluser.getClDescription());
			clUSercomm.setUserid(cluser.getClUserId());
			clUSercomm.setIspublic(cluser.getIsPublic());
			clUSercomm.setIspubliccat(cluser.getIsPubliccat());
			clUSercomm.setClOrganiztion(cluser.getClOrganiztion());
			List<tag> tags = tagLocalServiceUtil.searchbychecklistId(cluser.getChecklistId());
			
			
			clUSercomm.setTagList(tags);
			List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
			List<Category> categories = CategoryLocalServiceUtil.getBySubClID(cluser.getChecklistId(), 0);
			for (Category category : categories) {
				CategoryCommand cc = new CategoryCommand();
				cc.setId(category.getCatId());
				cc.setName(category.getCatName());

				cc.setSubcatid(category.getSubcategoryId());
				List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
				cc.setItemList(items);
				ccc.add(cc);
			}
			
			clUSercomm.setCategoryCommands(ccc);
			clcommands.add(clUSercomm);
			
		}
		List<CheckListCommand> publicommod = new ArrayList<CheckListCommand>();
		for(CheckListCommand checkListCommand23 : clcommands)
		{
			publicommod.add(checkListCommand23);
		}
		List<CLTemplate> clTemplates2 =CLTemplateLocalServiceUtil.searchbyisPublic(true);
		for(CLTemplate cl:clTemplates2){
			CLTemplate cluser = CLTemplateLocalServiceUtil.getCLTemplate(cl.getChecklistId());
			CheckListCommand finalc = new CheckListCommand();
			
			finalc.setId(cluser.getChecklistId());
			finalc.setName(cluser.getClName());
			finalc.setDesc(cluser.getClDescription());
			finalc.setUserid(cluser.getClUserId());
			finalc.setIspublic(cluser.getIsPublic());
			finalc.setIspubliccat(cluser.getIsPubliccat());
			finalc.setClOrganiztion(cluser.getClOrganiztion());
			List<tag> tags = tagLocalServiceUtil.searchbychecklistId(cluser.getChecklistId());
			
			
			finalc.setTagList(tags);
			List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
			List<Category> categories = CategoryLocalServiceUtil.getBySubClID(cluser.getChecklistId(), 0);
			for (Category category : categories) {
				CategoryCommand cc = new CategoryCommand();
				cc.setId(category.getCatId());
				cc.setName(category.getCatName());

				cc.setSubcatid(category.getSubcategoryId());
				List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
				cc.setItemList(items);
				ccc.add(cc);
			}
			
			boolean found = false;
			
			for(CheckListCommand sd:clcommands){
				long chek = sd.getId();
				
				if(cluser.getChecklistId() == chek)
				{
				found =true;
				break;
				}
			}
			if(found == false){
				finalc.setCategoryCommands(ccc);
				publicommod.add(finalc);
			}
		
			 
		}
		
		model.addAttribute("checkList1",publicommod );
		model.addAttribute("myselectItem", selectItem);
		return Grid_JSP;
		
	}
	
	

	@RenderMapping(params ="action=ChecklistAction")
    public String checklist(RenderRequest request, RenderResponse response, Model model) throws Exception {
		long v1 = Long.parseLong(request.getParameter("checkId"));
		request.setAttribute("chkId", v1);
        return CHECKLIST_JSP;
    }
	
	@RenderMapping(params ="action=Activchecklist")
    public String activecheck1(RenderRequest request, RenderResponse response, Model model) throws Exception {
		//long v2 =(Long)request.getAttribute("ActivecheckId");
		//long v2 = Long.parseLong(request.getParameter("ActivecheckId"));
		long v2 = Long.parseLong(ParamUtil.getString(request, "ActivecheckId"));
		//request.setAttribute("checklistId", v2);
		
		String myString = Long.toString(v2);
		
		request.setAttribute("checkId", myString);
 		
    	request.setAttribute("action","addJSP");
 		return CHECKLIST_JSP;
 	
		
    }
	
	
	@RenderMapping(params ="accn=accnRedirect")
    public String showAccountMain(RenderRequest request, RenderResponse response, Model model) throws Exception {
		
        return accounttab;
    }
	@RenderMapping(params ="account=accounts")
    public String showAccountTab(RenderRequest request, RenderResponse response, Model model) throws Exception {
		
        return accountset;
    }
	
	
	@ResourceMapping("getNoteConfig")
	public void getNoteConfig(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, SystemException, PortalException
	{
		
		
	System.out.println("Coming For Updating Notification Configuration");
	//long id1 = Long.valueOf(resourceRequest.getParameter("notif"));
	long id = Long.valueOf(resourceRequest.getParameter("notif"));
	Notification note = NotificationLocalServiceUtil.getNotification(id);
	
	  String newsval = ParamUtil.getString(resourceRequest, "isnews");
	  String mailval = ParamUtil.getString(resourceRequest, "ismail");
	  System.out.println("Got News State: " + newsval);
	 
	  if(newsval.equals("true"))
	  {
	  note.setIsNewsFeed(true);
	  }
	  else
	  {
		  note.setIsNewsFeed(false);
	  }
	  
	  if(mailval.equals("true"))
	  {
	  note.setIsMail(true);
	  }
	  else
	  {
		  note.setIsMail(false);
	  }
	 
	  NotificationLocalServiceUtil.updateNotification(note);
	 }

	
	
	@ResourceMapping("getsettingchecklist")
	public void getchecklistConfig(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, SystemException, PortalException
	{
		
	long id = Long.valueOf(resourceRequest.getParameter("checkId"));
	
	 System.out.println("Check LIst Id"+id);
	 String check = ParamUtil.getString(resourceRequest, "public");
	 String iscategory = ParamUtil.getString(resourceRequest, "iscategory");
	 
	
	 CLTemplate clTemplate = CLTemplateLocalServiceUtil.getCLTemplate(id);
	 
	
	  String newsval = ParamUtil.getString(resourceRequest, "isnews");
	  String mailval = ParamUtil.getString(resourceRequest, "ismail");
	  System.out.println("Got News State: " + newsval);
	 
	  if(check.equals(""))
	  {
	  clTemplate.setIsPublic(false);
	  }
	  else
	  {
		  clTemplate.setIsPublic(true);
	  }
	  if(iscategory.equals("")){
		  clTemplate.setIsPubliccat(false);
		  
	  }
	  else{
		  
		  clTemplate.setIsPubliccat(true);
	  }
	
	 CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
	 }

	
	
	 @ActionMapping(params ="Checklist=Checklistone")
     public void Checklist(ActionRequest actionRequest,
 			ActionResponse actionResponse) throws IOException, PortletException {
 		try{
		
 		ThemeDisplay themeDisplay =(ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
 	 	User user = themeDisplay.getUser();
 	 	long  userId=user.getUserId();
 		String titleName = ParamUtil.getString(actionRequest, "title");
 		String discriptionName = ParamUtil.getString(actionRequest, "description");
 		//long checklistId =ParamUtil.getLong(actionRequest, "checkId");
 		long verifyId=CounterLocalServiceUtil.increment();
 		CLTemplate CLTemplate =null;
 		CLTemplate = new CLTemplateImpl();
 		CLTemplate =CLTemplateLocalServiceUtil.createCLTemplate(verifyId);
 		
 		
 		CLTemplate.setClName(titleName);
 		CLTemplate.setClDescription(discriptionName);
 	 	CLTemplate.setClOrganiztion(CLTemplate.getClOrganiztion());
 		CLTemplate.setClUserId(userId);
 		CLTemplateLocalServiceUtil.addCLTemplate(CLTemplate);
 		
 
 		//String myString = Long.toString(checklistId);
 		
    	actionResponse.setRenderParameter("checkId",String.valueOf(CLTemplate.getChecklistId()));
 		
 		actionResponse.setRenderParameter("action", "addJSP");
 		}catch(Exception e){
 			SessionErrors.add(actionRequest.getPortletSession(),"checklist-add-error");
 			e.printStackTrace();
 		}
 	}
	 @ActionMapping(params ="Tag=actiontwo")
     public void Tag(ActionRequest actionRequest,
 			ActionResponse actionResponse) throws IOException, PortletException {
 		try{
 		String Tag = ParamUtil.getString(actionRequest, "tag");
 		//Long checklistId = ParamUtil.getLong(request, param)actionRequest, "checklistID");
 		long checklistId =ParamUtil.getLong(actionRequest, "checklistID");

 		//add department record
 		//create primary key    		
 		long tagId=CounterLocalServiceUtil.increment();
 		//create department persistance object
 		tag tag=null;
 		tag = new tagImpl();
 		
 		tag = tagLocalServiceUtil.createtag(tagId);
 		//fill the data in persistance object
 		tag.setTagName(Tag);
 		tag.setChecklistId(checklistId);
 		//Add department persistance object to database department table
 		tagLocalServiceUtil.addtag(tag);
 		
 		String myString = Long.toString(checklistId);
 		
    	actionResponse.setRenderParameter("checkId",myString);
 		
 		actionResponse.setRenderParameter("action", "addJSP");
		
	
 		}catch(Exception e){
 			SessionErrors.add(actionRequest.getPortletSession(),"checklist-add-error");
 			e.printStackTrace();
 		}
 	}
	 @ActionMapping(params ="Tag=allactiontwo")
     public void allactiontwoTag(ActionRequest actionRequest,
 			ActionResponse actionResponse) throws IOException, PortletException {
 		try{
 		String Tag = ParamUtil.getString(actionRequest, "tag");
 		//Long checklistId = ParamUtil.getLong(request, param)actionRequest, "checklistID");
 		long checklistId =ParamUtil.getLong(actionRequest, "checklistID");

 		//add department record
 		//create primary key    		
 		long tagId=CounterLocalServiceUtil.increment();
 		//create department persistance object
 		tag tag=null;
 		tag = new tagImpl();
 		
 		tag = tagLocalServiceUtil.createtag(tagId);
 		//fill the data in persistance object
 		tag.setTagName(Tag);
 		tag.setChecklistId(checklistId);
 		//Add department persistance object to database department table
 		tagLocalServiceUtil.addtag(tag);
 		
 		String myString = Long.toString(checklistId);
 		
    	actionResponse.setRenderParameter("checkId",myString);
 		
 		actionResponse.setRenderParameter("action", "veiwPage");
		
	
 		}catch(Exception e){
 			SessionErrors.add(actionRequest.getPortletSession(),"checklist-add-error");
 			e.printStackTrace();
 		}
 	}
	 @ActionMapping(params ="Tag=gridactiontwo")
     public void GridTag(ActionRequest actionRequest,
 			ActionResponse actionResponse) throws IOException, PortletException {
 		try{
 		String Tag = ParamUtil.getString(actionRequest, "tag");
 		//Long checklistId = ParamUtil.getLong(request, param)actionRequest, "checklistID");
 		long checklistId =ParamUtil.getLong(actionRequest, "checklistID");

 		//add department record
 		//create primary key    		
 		long tagId=CounterLocalServiceUtil.increment();
 		//create department persistance object
 		tag tag=null;
 		tag = new tagImpl();
 		
 		tag = tagLocalServiceUtil.createtag(tagId);
 		//fill the data in persistance object
 		tag.setTagName(Tag);
 		tag.setChecklistId(checklistId);
 		//Add department persistance object to database department table
 		tagLocalServiceUtil.addtag(tag);
 		
 		String myString = Long.toString(checklistId);
 		
    	actionResponse.setRenderParameter("checkId",myString);
 		
 		actionResponse.setRenderParameter("action", "Gridview");
		
	
 		}catch(Exception e){
 			SessionErrors.add(actionRequest.getPortletSession(),"checklist-add-error");
 			e.printStackTrace();
 		}
 	}
	  
	 
	 @ActionMapping(params ="ActiveCheckList=Activelistchecklist")
     public void ActiveCheckList(ActionRequest actionRequest,
 			ActionResponse actionResponse) throws IOException, PortletException {
 		try{
 			
 		ThemeDisplay themeDisplay =(ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
 	 	User user = themeDisplay.getUser();
 	 	long  userId=user.getUserId();
 	 	
 		
  		//String titleName = ParamUtil.getString(actionRequest, "title");
 		long checklistId =ParamUtil.getLong(actionRequest, "checkId");
 		String org = ParamUtil.getString(actionRequest, "orgId");
 		String shared = ParamUtil.getString(actionRequest, "check");
 		//Boolean radio =ParamUtil.getBoolean(actionRequest, "collaboration");
 		
 		CLTemplate clTemplate = CLTemplateLocalServiceUtil.getCLTemplate(checklistId);
 		//List<Category> ctl = new ArrayList<Category>();
 		
	 
 		String cldescription = clTemplate.getClDescription();
 		String clName = clTemplate.getClName();
 		String title = clTemplate.getClName();
 		//add department record
 		//create primary key
 		
 		long verifyId=CounterLocalServiceUtil.increment();
 		//create department persistance object
 		
 		ActivateCL ActivateCL =null;
 		ActivateCL =new ActivateCLImpl();
  		ActivateCL = ActivateCLLocalServiceUtil.createActivateCL(verifyId);
  		ActivateCL.setChecklistId(checklistId);
 		if(shared.equals("admin"))
 		 {
 			ActivateCL.setIsPublic(false);
 		 }
 		 else {
 			ActivateCL.setIsPublic(true);
 			
 			List<CLCollab> clCollabs =CLCollabLocalServiceUtil.getCollabByCL(checklistId);
 			for(CLCollab clc:clCollabs){
 				long usrid =clc.getUserId();
 				ActCLCollab ActCollab =null;
 	 			ActCollab =new ActCLCollabImpl();
 	 			long increment=CounterLocalServiceUtil.increment();
 	 			ActCollab =ActCLCollabLocalServiceUtil.createActCLCollab(increment);
 	 			
 	 			ActCollab.setActChecklistId(ActivateCL.getActivateId());
 	 			ActCollab.setUserId(clc.getUserId());
 				ActCollab.setActCollabType(clc.getCollabType());
 				ActCLCollabLocalServiceUtil.addActCLCollab(ActCollab);
 				
 				 String msg = "you hae been added to a checklist";
 				 String msg1="Someone comments on an activated checklist I belong to";
 				 ServiceContext serviceContext = ServiceContextFactory.getInstance(User.class.getName(), actionRequest);
 				 
 				 String  username=user.getFullName();
 				 List<Portlet> list = PortletLocalServiceUtil.getPortlets();
 				 for(int i=0;i<list.size();i++){
 				 			         
 				 try{    
 				 			                 
 				 if(list.get(i).getDisplayName().equalsIgnoreCase("verifier")){
 				 		String portletid = list.get(i).getPortletId();
 				 		System.out.println("PLID IS:: "+list.get(i).getPortletId());
 				 			PortletURL myUrl = PortletURLFactoryUtil.create(actionRequest, portletid, themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);	
 				 			myUrl.setWindowState(WindowState.MAXIMIZED);
 				 			myUrl.setPortletMode(PortletMode.VIEW);
 				 			String fromAddress = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_ADDRESS);
 				 			String subject = "VERIFY ORGANIZTION MEMBER: "+username;
 				 			User userr = UserLocalServiceUtil.getUserById(usrid);
 				 		if (userr != null)
 				 		
 				 		{
 				 				 //long userId = userr.getUserId();
 				 				 //String userName = userr.getFullName();
 				 			long notifiid=0;
 				 			List<Notification> notifications = NotificationLocalServiceUtil.getNotifications(0, NotificationLocalServiceUtil.getNotificationsCount());
 				 			for(Notification ntf:notifications)
 				 			{
 				 				long notid =ntf.getNoteId();
 				 				
 				 				Notification nott = NotificationLocalServiceUtil.getNotification(notid);
 				 				String notename= nott.getNoteName();
 				 				if(notename.equals(msg1))
 				 				{
 				 					notifiid =notid;
 				 					break;
 				 				}
 				 				
 				 			}
 				 				 //Long id = 55503L;
 				 				 Notification not = NotificationLocalServiceUtil.getNotification(notifiid);		 				
 				 				 /*	Email Send */
 				 				 				
 				 			if (not.getIsMail() == true) {
 				 					String body = "<h2>Verify Notification Center</h2>"
 				 				 							+"<BR/><BR/>"
 				 				 							+username+" Activate this '"+title+"' checklist"
 				 				 							+"<BR/><BR/>"
 				 				 							+"Take a look"
 				 				 							+" here. "+myUrl+"<BR/> Link doesn't work? Here's the URL:<BR/>";
 				 				 			
 				 					UserLocalServiceUtil.sendPassword(userr.getCompanyId(), userr.getEmailAddress(), "verify", fromAddress, subject, body, serviceContext);
 				 				 		//UserLocalServiceUtil.sendEmailAddressVerification(userr, userr.getEmailAddress(), serviceContext);
 				 				 	System.out.println("Email Was Sent");
 				 				 				
 				 									}
 				 			
 				 			/********************/
 				 			 
 				 			

 				 				
 				 			//	User u = UserLocalServiceUtil.getUser(userId);
 				 				
 				 	
// 				 				String notificationText = "You are Assigned to Task : "+title +" by " +u1.getFullName();
 				 				
 				 				Date now = new Date();
 				 				Calendar cal = Calendar.getInstance();
 				 				cal.setTime(now);
 				 				cal.add(Calendar.DAY_OF_YEAR, 1);
 				 				Date tomorrow = cal.getTime();
 				 				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
 				 				String tomorrow1 = dateFormat.format(tomorrow);
 				 				//System.out.println("TOMORROW DATE=========="+tomorrow1);
 				 			
 				 				JSONObject payloadJSON = JSONFactoryUtil.createJSONObject();
 				 				String DATE_FORMAT_Display = "dd MMMM yyyy";
 				 				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_Display);
 				 			//	String printDate =sdf1.format(stdt);
 				 				//String notification = username +" Add to you this : "+title ;

 				 				
 				 				String notificationText = username+": Activate This : "+title+" checklist"; 
 				 				payloadJSON.put("notificationText", notificationText);	
 				 				
 				 				/*System.out.println("REAL================="+stdt);
 				 				System.out.println("TOM=================="+tomorrow1);*/
 				
 				 	
 				 				payloadJSON.put("userId", usrid);
 				 				
 				 					
 				 					
 				 				UserNotificationEventLocalServiceUtil.addUserNotificationEvent(
 				 					usrid,DockBarUserNotificationHandler.PORTLET_ID,(new Date()).getTime(), usrid,payloadJSON.toString(), false, serviceContext);
 				 			
 				 				
 				 				
 				 				//UserNotificationEventUtil.countByU_D(userId, false);
 				 				//System.out.println("User Notificaion count   " +un);
 				 					
 				 				List<UserNotificationEvent> un=UserNotificationEventLocalServiceUtil.getUserNotificationEvents(usrid);	
 				 					for (UserNotificationEvent event :un)
 				 					{
 				 						boolean deliver = event.getDelivered();
 				 						
 				 						if(deliver==true)
 				 						{
 				 							long eventId=event.getUserNotificationEventId();
 				 							UserNotificationEventLocalServiceUtil.deleteUserNotificationEvent(eventId);
 				 							
 				 						}
 				 					}
 				 					for (UserNotificationEvent userNotificationEvent : un) {
 				 						//System.out.println("User Notificaion   " +userNotificationEvent);
 				 						
 				 					}
 				 		
 				 			
 				 				 }
 				 			   }
 				 			}
 				 			               
 				 	 catch(Exception e){
 				   System.out.println("NO such User found");
 				   }
 			  }
 				
 				
 			}
 			
 			
 		}
 		
 	 		ActivateCL.setClName(clName);
 	 		ActivateCL.setClDescription(cldescription);
 	 		ActivateCL.setOrganiztion(org);
 	 		//ActivateCL.setIsPublic(radio);
 	 		ActivateCL.setIsCompleted(false);
 	 		ActivateCL.setActClUserId(userId);
 		
 		//fill the data in persistance object
 		//CLTemplate.setChecklistId(verifyId);
 		   	
 		//Add department persistance object to database department table
 	   ActivateCLLocalServiceUtil.addActivateCL(ActivateCL);
 		
 	   List<Category>   category = CategoryLocalServiceUtil.getBySubClID(checklistId, 0);
		
		for (Category category1 : category) {
			
			ActCategory ActCategory =null;
	 		ActCategory =new ActCategoryImpl();
	 		long verifyId1=CounterLocalServiceUtil.increment();

	 		ActCategory = ActCategoryLocalServiceUtil.createActCategory(verifyId1);
	 		ActCategory.setActiveCheckListID(ActivateCL.getActivateId());
	 		ActCategory.setCategoryName(category1.getCatName());
	 		ActCategory.setSubCatogryId(category1.getSubcategoryId());
	 		ActCategoryLocalServiceUtil.addActCategory(ActCategory);
	 		
	 		//FOR SUBCATEGORY
	 		List<Category> scategory = CategoryLocalServiceUtil.getBySubClID(checklistId, category1.getCatId());
	 		for (Category scategory1 : scategory) {
				
				ActCategory SActCategory =null;
		 		SActCategory =new ActCategoryImpl();
		 		long SverifyId1=CounterLocalServiceUtil.increment();

		 		SActCategory = ActCategoryLocalServiceUtil.createActCategory(SverifyId1);
		 		SActCategory.setActiveCheckListID(ActivateCL.getActivateId());
		 		SActCategory.setCategoryName(scategory1.getCatName());
		 		SActCategory.setSubCatogryId(ActCategory.getActCategoryId());
		 		ActCategoryLocalServiceUtil.addActCategory(SActCategory);
		 		
		 		
		 		List<Category> categories= CategoryLocalServiceUtil.getCatBysubcategoryId(scategory1.getSubcategoryId());
		 		for( Category subcatid :categories)
		 		{
		 			long catid = subcatid.getCatId();
		 			List<Item> aItems = ItemLocalServiceUtil.searchbycatId(subcatid.getCatId());
		 			for(Item aItems1:aItems)
		 			{
		 				
		 				  
		 				  ActItem actItem=null;
		 				  actItem =new ActItemImpl();
			 		 	  long verifyId3=CounterLocalServiceUtil.increment();
			 		 	  actItem= ActItemLocalServiceUtil.createActItem(verifyId3);
			 		 	  actItem.setItemName(aItems1.getItemName());
			 		 	  actItem.setItemDesc(aItems1.getItemDesc());
			 		 	  actItem.setIsMajor(aItems1.getMajor());
			 		 	  actItem.setPercentage(aItems1.getMajor_percent());
			 		 	  actItem.setActivateClid(ActCategory.getActiveCheckListID());
			 		 	  actItem.setUsergroupId(aItems1.getUserGroupId());
			 		 	  
					      List<ActCategory> actCategories = ActCategoryLocalServiceUtil.getByActClSubID(ActivateCL.getActivateId(), ActCategory.getActCategoryId());
					      for(ActCategory actcatid :actCategories){
					    	  //long caitd = actcatid.getActCategoryId();
					    	  
					      actItem.setCatId(actcatid.getActCategoryId());
			 		 	  
			 		 	  
			 		 	 
					      }
					      ActItemLocalServiceUtil.addActItem(actItem);
		 			}
		 		}
		 		 
		 		
	 		}
	 		
	 		List<Item> AItem = ItemLocalServiceUtil.searchbycatId(category1.getCatId());
	 		for (Item actItem:AItem)
	 		{
	 			  ActItem ActItem=null;
	 	 		  ActItem =new ActItemImpl();
	 		 	  long verifyId2=CounterLocalServiceUtil.increment();

	 	 		  ActItem= ActItemLocalServiceUtil.createActItem(verifyId2);
	 	 		  ActItem.setItemName(actItem.getItemName());
	 	 		  ActItem.setItemDesc(actItem.getItemDesc());
	 	 		  ActItem.setIsMajor(actItem.getMajor());
	 	 		  ActItem.setPercentage(actItem.getMajor_percent());
	 	 		  ActItem.setCatId(ActCategory.getActCategoryId());
	 	 		  ActItem.setActivateClid(ActCategory.getActiveCheckListID());
	 	 		  ActItem.setUsergroupId(actItem.getUserGroupId());
	 	 		  
	 		  	  ActItemLocalServiceUtil.addActItem(ActItem);	 		
	 		  
	 			
	 		List<ItemFile> AItemfile=ItemFileLocalServiceUtil.getAllFiles(actItem.getItemId());
 		  	for(ItemFile file: AItemfile)
 		  	{
 		  		ActItemFile actfile = new ActItemFileImpl();
 		  		long actfileid = CounterLocalServiceUtil.increment();
 		  		actfile = ActItemFileLocalServiceUtil.createActItemFile(actfileid);
 		  		actfile.setFileName(file.getFileName());
 		  		actfile.setFilePath(file.getFilePath());
 		  		actfile.setCreateTime(new Date());
 		  		actfile.setItemId(ActItem.getItemId());
 		  		actfile.setUserId(file.getUserId());
 		  		ActItemFileLocalServiceUtil.addActItemFile(actfile);
 		  	}
 		  }
		}
		
		List<Item> AItem1 = ItemLocalServiceUtil.searchByCheckId(checklistId);
 		for (Item actItem1:AItem1)
 		{
 			  ActItem ActItem1=null;
 	 		  ActItem1 =new ActItemImpl();
 		 	  long verifyId3=CounterLocalServiceUtil.increment();

 	 		  ActItem1= ActItemLocalServiceUtil.createActItem(verifyId3);
 	 		  ActItem1.setItemName(actItem1.getItemName());
 	 		  ActItem1.setCatId(0);
 	 		  ActItem1.setActivateClid(ActivateCL.getActivateId());
 		  	  ActItemLocalServiceUtil.addActItem(ActItem1);	 		
 		  }
	  

	  
		//navigate to add department jsp page
 		//actionRequest.setAttribute("chkId",checklistId);
 		
 		String myString = Long.toString(checklistId);
 		
    	actionResponse.setRenderParameter("checkId",String.valueOf(ActivateCL.getActivateId()));
    	
		actionResponse.setRenderParameter("action","addNewJSP");
		
 		System.out.println("Redirected: " );
		}
		catch(Exception e){
 			SessionErrors.add(actionRequest.getPortletSession(),"checklist-add-error");
 			e.printStackTrace();
 		}
 	} 
	 
	
/*	>>>>>>>>>>>>>>>>> Activate Comment <<<<<<<<<<<<<<<<<<<<<*/
	 
	 @ActionMapping(params = "addnewcomment=addnewcomment")
	 public void addcommentActive(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException
		{
		 try{
			 
		 ThemeDisplay themeDisplay =
		           (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		  User user = themeDisplay.getUser();
		  	long  userId=user.getUserId();
			Long check1 = Long.parseLong(actionRequest.getParameter("checkId"));
			ActivateCL activateCL =ActivateCLLocalServiceUtil.getActivateCL(check1);
			String title =activateCL.getClName();
		  /*	long checkl =ParamUtil.getLong(actionRequest, "ActcheckId");*/
		//	long checkl =ParamUtil.getLong(actionRequest, "checkId");
			ActItemComment comment=new ActItemCommentImpl();
			comment.setActCommId(Long.valueOf(CounterLocalServiceUtil.increment()));
			comment.setComment(actionRequest.getParameter("message"));
			comment.setCreateTime(new Date());
			/*System.out.println(ParamUtil.getLong(actionRequest, "itemid"));*/
			comment.setItemId(Long.valueOf(ParamUtil.getLong(actionRequest, "itemid")));
			comment.setUserId(userId);
			ActItemCommentLocalServiceUtil.addActItemComment(comment);
						
			List<ActCLCollab> actCLCollabs = ActCLCollabLocalServiceUtil.getActCLCollabs(0, ActCLCollabLocalServiceUtil.getActCLCollabsCount());
			
			for(ActCLCollab clco:actCLCollabs){
				long usrid =clco.getUserId();
			     String msg = "you hae been added to a checklist";
				 String msg1="Someone comments on an activated checklist I belong to";
				 String msg2="Someone comments on a checklist I belong to";
				 
				 ServiceContext serviceContext = ServiceContextFactory.getInstance(User.class.getName(), actionRequest);
				 
				 String  username=user.getFullName();
				 List<Portlet> list = PortletLocalServiceUtil.getPortlets();
				 for(int i=0;i<list.size();i++){
				 			         
				 try{    
				 			                 
				 if(list.get(i).getDisplayName().equalsIgnoreCase("verifier")){
				 		String portletid = list.get(i).getPortletId();
				 		System.out.println("PLID IS:: "+list.get(i).getPortletId());
				 			PortletURL myUrl = PortletURLFactoryUtil.create(actionRequest, portletid, themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);	
				 			myUrl.setWindowState(WindowState.MAXIMIZED);
				 			myUrl.setPortletMode(PortletMode.VIEW);
				 			String fromAddress = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_ADDRESS);
				 			String subject = "VERIFY ORGANIZTION MEMBER: "+username;
				 			User userr = UserLocalServiceUtil.getUserById(usrid);
				 		if (userr != null)
				 		
				 		{
				 				 //long userId = userr.getUserId();
				 				 //String userName = userr.getFullName();
				 			long notifiid=0;
				 			List<Notification> notifications = NotificationLocalServiceUtil.getNotifications(0, NotificationLocalServiceUtil.getNotificationsCount());
				 			for(Notification ntf:notifications)
				 			{
				 				long notid =ntf.getNoteId();
				 				
				 				Notification nott = NotificationLocalServiceUtil.getNotification(notid);
				 				String notename= nott.getNoteName();
				 				if(notename.equals(msg1))
				 				{
				 					notifiid =notid;
				 					break;
				 				}
				 				
				 			}
				 				 //Long id = 55503L;
				 				 Notification not = NotificationLocalServiceUtil.getNotification(notifiid);		 				
				 				 /*	Email Send */
				 				 				
				 			if (not.getIsMail() == true) {
				 					String body = "<h2>Verify Notification Center</h2>"
				 				 							+"<BR/><BR/>"
				 				 							+username+" Comment on this Acive '"+title+"' Item"
				 				 							+"<BR/><BR/>"
				 				 							+"Take a look"
				 				 							+" here. "+myUrl+"<BR/> Link doesn't work? Here's the URL:<BR/>";
				 				 			
				 					UserLocalServiceUtil.sendPassword(userr.getCompanyId(), userr.getEmailAddress(), "verify", fromAddress, subject, body, serviceContext);
				 				 		//UserLocalServiceUtil.sendEmailAddressVerification(userr, userr.getEmailAddress(), serviceContext);
				 				 	System.out.println("Email Was Sent");
				 				 				
				 									}
				 			
				 			/********************/
				 			 
				 			

				 				
				 			//	User u = UserLocalServiceUtil.getUser(userId);
				 				
				 	
//				 				String notificationText = "You are Assigned to Task : "+title +" by " +u1.getFullName();
				 				
				 				Date now = new Date();
				 				Calendar cal = Calendar.getInstance();
				 				cal.setTime(now);
				 				cal.add(Calendar.DAY_OF_YEAR, 1);
				 				Date tomorrow = cal.getTime();
				 				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				 				String tomorrow1 = dateFormat.format(tomorrow);
				 				//System.out.println("TOMORROW DATE=========="+tomorrow1);
				 			
				 				JSONObject payloadJSON = JSONFactoryUtil.createJSONObject();
				 				String DATE_FORMAT_Display = "dd MMMM yyyy";
				 				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_Display);
				 			//	String printDate =sdf1.format(stdt);
				 				//String notification = username +" Add to you this : "+title ;

				 				
				 				String notificationText = username+": Comment on this Active : "+title; 
				 				payloadJSON.put("notificationText", notificationText);	
				 				
				 				/*System.out.println("REAL================="+stdt);
				 				System.out.println("TOM=================="+tomorrow1);*/
				
				 	
				 				payloadJSON.put("userId", usrid);
				 				
				 					
				 					
				 				UserNotificationEventLocalServiceUtil.addUserNotificationEvent(
				 					usrid,DockBarUserNotificationHandler.PORTLET_ID,(new Date()).getTime(), usrid,payloadJSON.toString(), false, serviceContext);
				 			
				 				System.out.println("Notification Has Beeen Sent");
				 				
				 				//UserNotificationEventUtil.countByU_D(userId, false);
				 				//System.out.println("User Notificaion count   " +un);
				 					
				 				List<UserNotificationEvent> un=UserNotificationEventLocalServiceUtil.getUserNotificationEvents(usrid);	
				 					for (UserNotificationEvent event :un)
				 					{
				 						boolean deliver = event.getDelivered();
				 						
				 						if(deliver==true)
				 						{
				 							long eventId=event.getUserNotificationEventId();
				 							UserNotificationEventLocalServiceUtil.deleteUserNotificationEvent(eventId);
				 							
				 						}
				 					}
				 					for (UserNotificationEvent userNotificationEvent : un) {
				 						//System.out.println("User Notificaion   " +userNotificationEvent);
				 						
				 					}
				 		
				 			
				 				 }
				 			   }
				 			}
				 			               
				 	 catch(Exception e){
				   System.out.println("NO such User found");
				   }
			  }
			}
			
			
			
			
			String myString = Long.toString(check1);
		    actionResponse.setRenderParameter("checkId",myString);
		 	actionResponse.setRenderParameter("action", "addNewJSP");
		 	
	 		//System.out.println("Redirected: " );
	 		}catch(Exception e){
	 			SessionErrors.add(actionRequest.getPortletSession(),"checklist-add-error");
	 			e.printStackTrace();
	 		}
		
		}
	 
	 /* <<<<<<<<<Remove active comment<<<<<<<<<<<<<<<<<*/
	 
		@ActionMapping(params="removeactivecomment=removeactivecomment")
		 public void removeactivecomment(ActionRequest request,ActionResponse response) throws PortalException, SystemException
		 {
			 long commentid=ParamUtil.getLong(request, "commentid");
			 ActItemCommentLocalServiceUtil.deleteActItemComment(commentid);
			
			 Long id1 = Long.parseLong(request.getParameter("checkId"));
			 String myString = Long.toString(id1);
			    response.setRenderParameter("checkId",myString);
			    response.setRenderParameter("action", "addNewJSP");
			/* response.setRenderParameter("removecmnt", "removecmnt");*/
			 
		 }
		
		
		 @ActionMapping(params = "updatenewactive=updatenewactive")
		 public void updateDescActive(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
		 
		 {
			 
			 
			/* System.out.println(ParamUtil.getLong(actionRequest, "itemid1"));
			 System.out.println("ID IS:::::::::::>> "+actionRequest.getParameter("itemId1"));*/
				Long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
				Long ItemId = Long.parseLong(actionRequest.getParameter("itemid"));
				String desc =actionRequest.getParameter("message");


			   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
				
				
			   ActItem   item = ActItemLocalServiceUtil.getActItem(ItemId);
					   
					   
			    
			    if(item !=null)
			    {
			    	item.setItemName(item.getItemName());
			    	item.setItemDesc(desc);
			    	
			    	
			    	item.setCatId(item.getCatId());
			    	
			    	ActItemLocalServiceUtil.updateActItem(item);
			    	
			    	
			    }
				 
			  //  i.setItemDesc(actionRequest.getParameter("desc1"));
			 
			 
				String myString = Long.toString(id1);
			    actionResponse.setRenderParameter("checkId",myString);
			    actionResponse.setRenderParameter("action", "addNewJSP");
			 	/*ItemLocalServiceUtil.updateItem(i);
			 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
		 }
		 
		 /*>>>>>>>>>update comment activate<<<<<<<<<<<<<<*/
		 
		 @ActionMapping(params="updtComm=updateComm")
		 public void updateCommentss(ActionRequest request, ActionResponse response) throws PortalException, SystemException
		 {
			 long commid = ParamUtil.getLong(request, "comid");
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkId"));
			 ActItemComment itemComm=ActItemCommentLocalServiceUtil.getActItemComment(commid);
			 
			 itemComm.setComment(ParamUtil.getString(request, "comment"));
			 ActItemCommentLocalServiceUtil.updateActItemComment(itemComm);
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);
			 response.setRenderParameter("action","addNewJSP");
		 }
		 
		 
		 
		 /*>>>>>>>>>>>>>>>>>Upload new activated<<<<<<<<<<<<<<<<<<<*/
		 
		 @ActionMapping(params="uploadactivatenew=uploadactivatenew")
		 public void fileuploadingactivate(ActionRequest request, ActionResponse response)
					throws Exception {
		 
			 ThemeDisplay themeDisplay =
			           (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
			  User user = themeDisplay.getUser();
			  	long  userId=user.getUserId();
			  	
				Long id1 = Long.parseLong(request.getParameter("checkId"));
				//long id1 = ParamUtil.getLong(request, "checkId");
				long val =ParamUtil.getLong(request, "itemfileid");
				//System.out.println("ITEM ID IS::::::::::: "+val);

				/*Long  = ParamUtil.getLong(request, "ItemID");
				System.out.println("ITEM ID IS::::::::::: "+val);
		*/
				UploadPortletRequest uploadRequest = PortalUtil.getUploadPortletRequest(request);
		
				
				// Get the uploaded file as a file.
				File uploadedFile = uploadRequest.getFile(fileInputName);
		 
				String sourceFileName = uploadRequest.getFileName(fileInputName);
		 
				
				// Where should we store this file?
				File folder = new File(baseDir);
		 
				// This is our final file path.
				File filePath = new File(folder.getAbsolutePath() + File.separator + sourceFileName);
		 
				// Move the existing temporary file to new location.
				FileUtils.copyFile(uploadedFile, filePath, true);
				ActItemFile file1=new ActItemFileImpl();
				file1.setActItemFileId(Long.valueOf(CounterLocalServiceUtil.increment()));
				file1.setFileName(sourceFileName);
				file1.setFilePath(filePath.toString());
				
				file1.setCreateTime(new Date());
				
				file1.setItemId(val);
				file1.setUserId(userId);
				ActItemFileLocalServiceUtil.addActItemFile(file1);
			
				String myString = Long.toString(id1);
			    response.setRenderParameter("checkId",myString);
			 	response.setRenderParameter("action", "addNewJSP");
	}
		
		 @ActionMapping(params = "uploadactiveremove=uploadactiveremove")
		 public void deleteactivefile(ActionRequest request,ActionResponse response) throws PortalException, SystemException
		 {
			 
			 long fileid=ParamUtil.getLong(request, "fileId");
			 Long id1 = Long.parseLong(request.getParameter("checkId"));
			 ActItemFileLocalServiceUtil.deleteActItemFile(fileid);
			 String myString = Long.toString(id1);
			    response.setRenderParameter("checkId",myString);
			 	response.setRenderParameter("action", "addNewJSP");

			/* response.setRenderParameter("remove", "removefile");*/
			 
		 }
	 //NISHA CATEGORY & SUBCATEGORY
	 
	 
	 //------------------------------ADD NOTIFICATIONS FOR ACCOUNT-------------------
	 @ActionMapping(params="addNote=addNote")
	 public void addNotification(ActionRequest request, ActionResponse response) throws SystemException
	 {
		 String noteName = ParamUtil.getString(request, "noti");
		 boolean mail = Boolean.parseBoolean(ParamUtil.getString(request, "ismail"));
		 boolean news = Boolean.parseBoolean(ParamUtil.getString(request, "isnews"));
		 long notId=CounterLocalServiceUtil.increment();
		 Notification notif = new NotificationImpl();
		 notif = NotificationLocalServiceUtil.createNotification(notId);
		 System.out.println("Mail is :: "+mail);
		 notif.setNoteName(noteName);
		 notif.setIsMail(mail);
		 notif.setIsNewsFeed(news);
		/* if(mail.equals("true"))
		 {
			 System.out.println("true");
		 notif.setIsMail(true);
		 }
		 else
		 {
			 System.out.println("false");
			 notif.setIsMail(false);
		 }
		 if(news.equals("true"))
		 {
		 notif.setIsNewsFeed(true);
		 }
		 else {
			notif.setIsNewsFeed(false);
		}*/
	
		 NotificationLocalServiceUtil.addNotification(notif);

		 response.setRenderParameter("accn","accnRedirect");
	 }
	
	 
	 //ADD COLLABORATION USER
	 @ActionMapping(params="ClCollab=CollaborationCL")
	 public void addCollaborationUser(ActionRequest request, ActionResponse response) throws  SystemException, PortalException, WindowStateException, PortletModeException
	 {
		 
		 ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		 User user = themeDisplay.getUser();
		 long userid = user.getUserId();
		 String collabtype = ParamUtil.getString(request, "userType");
		 Long usrid = Long.valueOf(request.getParameter("usr"));
		 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkId"));
		 CLTemplate clTemplate = CLTemplateLocalServiceUtil.getCLTemplate(clId);
		 String title = clTemplate.getClName();
		 
		 long collId=CounterLocalServiceUtil.increment();
		 CLCollab collab = new CLCollabImpl();
		 collab = CLCollabLocalServiceUtil.createCLCollab(collId);
		 
		 collab.setCollabType(collabtype);
		 collab.setUserId(usrid);
		 collab.setChecklistId(clId);
	
		 CLCollabLocalServiceUtil.addCLCollab(collab);
		 
		 /*
		  * Email Parameters
		  * 
		  * */
		 			
		 
		/*String password = ParamUtil.getString(request, "password2");*/
		 String msg = "you hae been added to a checklist";
		 String msg1="Someone is added to a checklist I belong to";
		 ServiceContext serviceContext = ServiceContextFactory.getInstance(User.class.getName(), request);
		 
		 String  username=user.getFullName();
		 List<Portlet> list = PortletLocalServiceUtil.getPortlets();
		 for(int i=0;i<list.size();i++){
		 			         
		 try{    
		 			                 
		 if(list.get(i).getDisplayName().equalsIgnoreCase("verifier")){
		 		String portletid = list.get(i).getPortletId();
		 		System.out.println("PLID IS:: "+list.get(i).getPortletId());
		 			PortletURL myUrl = PortletURLFactoryUtil.create(request, portletid, themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);	
		 			myUrl.setWindowState(WindowState.MAXIMIZED);
		 			myUrl.setPortletMode(PortletMode.VIEW);
		 			String fromAddress = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_ADDRESS);
		 			String subject = "VERIFY ORGANIZTION MEMBER: "+username;
		 			User userr = UserLocalServiceUtil.getUserById(usrid);
		 		if (userr != null)
		 		
		 		{
		 				 //long userId = userr.getUserId();
		 				 //String userName = userr.getFullName();
		 			long notifiid=0;
		 			List<Notification> notifications = NotificationLocalServiceUtil.getNotifications(0, NotificationLocalServiceUtil.getNotificationsCount());
		 			for(Notification ntf:notifications)
		 			{
		 				long notid =ntf.getNoteId();
		 				
		 				Notification nott = NotificationLocalServiceUtil.getNotification(notid);
		 				String notename =nott.getNoteName();
		 				if(notename.equals(msg1)){
		 					notifiid =notid;
		 					break;
		 				}
		 				
		 			}
		 			
		 				 //Long id = 55503L;
		 				 Notification not = NotificationLocalServiceUtil.getNotification(notifiid);		 				
		 				 /*	Email Send */
		 				 				
		 			if (not.getIsMail() == true) {
		 					String body = "<h2>Verify Notification Center</h2>"
		 				 							+"<BR/><BR/>"
		 				 							+username+" added you to '"+username+"' organization"
		 				 							+"<BR/><BR/>"
		 				 							+"Take a look"
		 				 							+" here. "+myUrl+"<BR/> Link doesn't work? Here's the URL:<BR/>";
		 				 			
		 					UserLocalServiceUtil.sendPassword(userr.getCompanyId(), userr.getEmailAddress(), "verify", fromAddress, subject, body, serviceContext);
		 				 		//UserLocalServiceUtil.sendEmailAddressVerification(userr, userr.getEmailAddress(), serviceContext);
		 				 	System.out.println("Email Was Sent");
		 				 				
		 									}
		 			
		 			/********************/
		 			 
		 			

		 				
		 			//	User u = UserLocalServiceUtil.getUser(userId);
		 				
		 	
//		 				String notificationText = "You are Assigned to Task : "+title +" by " +u1.getFullName();
		 				
		 				Date now = new Date();
		 				Calendar cal = Calendar.getInstance();
		 				cal.setTime(now);
		 				cal.add(Calendar.DAY_OF_YEAR, 1);
		 				Date tomorrow = cal.getTime();
		 				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		 				String tomorrow1 = dateFormat.format(tomorrow);
		 				//System.out.println("TOMORROW DATE=========="+tomorrow1);
		 			
		 				JSONObject payloadJSON = JSONFactoryUtil.createJSONObject();
		 				String DATE_FORMAT_Display = "dd MMMM yyyy";
		 				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_Display);
		 			//	String printDate =sdf1.format(stdt);
		 				//String notification = username +" Add to you this : "+title ;

		 				
		 				String notificationText = username+": Add to You in This : "+title+" checklist"; 
		 				payloadJSON.put("notificationText", notificationText);	
		 				
		 				/*System.out.println("REAL================="+stdt);
		 				System.out.println("TOM=================="+tomorrow1);*/
		
		 	
		 				payloadJSON.put("userId", usrid);
		 				
		 					
		 					
		 				UserNotificationEventLocalServiceUtil.addUserNotificationEvent(
		 					usrid,DockBarUserNotificationHandler.PORTLET_ID,(new Date()).getTime(), usrid,payloadJSON.toString(), false, serviceContext);
		 			
		 				
		 				
		 				//UserNotificationEventUtil.countByU_D(userId, false);
		 				//System.out.println("User Notificaion count " +un);
		 					
		 				List<UserNotificationEvent> un=UserNotificationEventLocalServiceUtil.getUserNotificationEvents(usrid);	
		 					for (UserNotificationEvent event :un)
		 					{
		 						boolean deliver = event.getDelivered();
		 						
		 						if(deliver==true)
		 						{
		 							long eventId=event.getUserNotificationEventId();
		 							UserNotificationEventLocalServiceUtil.deleteUserNotificationEvent(eventId);
		 							
		 						}
		 					}
		 					for (UserNotificationEvent userNotificationEvent : un) {
		 						//System.out.println("User Notificaion   " +userNotificationEvent);
		 						
		 					}
		 		
		 			
		 				 }
		 			   }
		 			}
		 			               
		 	 catch(Exception e){
		   System.out.println("NO such User found");
		   }
	  }

		 			
//String fromName = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_NAME);
/*String subject = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_USER_ADDED_SUBJECT);*/
		 			

//String portalURL = PortalUtil.getPortalURL(themeDisplay);
		 			
		 String ckId = Long.toString(clId);
		 response.setRenderParameter("checkId", ckId);

		 response.setRenderParameter("action","addJSP");
	 }
	 
	//ADD COLLABORATION USER
		 @ActionMapping(params="activeClCollab=activeCollaborationCL")
		 public void addactiveCollaborationUser(ActionRequest request, ActionResponse response) throws  SystemException, PortalException, WindowStateException, PortletModeException

		 {
			
			 ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
			 User user = themeDisplay.getUser();
			 long userid = user.getUserId();
			 
			 String collabtype = ParamUtil.getString(request, "userType");
			 Long usrid = Long.valueOf(request.getParameter("usr"));
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkId"));
			 
			 ActivateCL activateCL = ActivateCLLocalServiceUtil.getActivateCL(clId);
			 
			 String title = activateCL.getClName();
			 
			 
			 long collId=CounterLocalServiceUtil.increment();
			 ActCLCollab collab = new ActCLCollabImpl();
			 collab = ActCLCollabLocalServiceUtil.createActCLCollab(collId);
			 
			 
			 
			 
			 collab.setActCollabType(collabtype);
			 collab.setUserId(usrid);
			 collab.setActChecklistId(clId);
		
			 ActCLCollabLocalServiceUtil.addActCLCollab(collab);

			 
			 
			 String msg = "you hae been added to a checklist";
			 String msg1="Someone is added to a checklist I belong to";
			 ServiceContext serviceContext = ServiceContextFactory.getInstance(User.class.getName(), request);
			 
			 String  username=user.getFullName();
			 List<Portlet> list = PortletLocalServiceUtil.getPortlets();
			 for(int i=0;i<list.size();i++){
			 			         
			 try{    
			 			                 
			 if(list.get(i).getDisplayName().equalsIgnoreCase("verifier")){
			 		String portletid = list.get(i).getPortletId();
			 		System.out.println("PLID IS:: "+list.get(i).getPortletId());
			 			PortletURL myUrl = PortletURLFactoryUtil.create(request, portletid, themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);	
			 			myUrl.setWindowState(WindowState.MAXIMIZED);
			 			myUrl.setPortletMode(PortletMode.VIEW);
			 			String fromAddress = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_ADDRESS);
			 			String subject = "VERIFY ORGANIZTION MEMBER: "+username;
			 			User userr = UserLocalServiceUtil.getUserById(usrid);
			 		if (userr != null)
			 		
			 		{
			 				 //long userId = userr.getUserId();
			 				 //String userName = userr.getFullName();
			 			long notifiid=0;
			 			List<Notification> notifications = NotificationLocalServiceUtil.getNotifications(0, NotificationLocalServiceUtil.getNotificationsCount());
			 			for(Notification ntf:notifications)
			 			{
			 				long notid =ntf.getNoteId();
			 				
			 				Notification nott = NotificationLocalServiceUtil.getNotification(notid);
			 				String notename= nott.getNoteName();
			 				if(notename.equals(msg1))
			 				{
			 					notifiid =notid;
			 					break;
			 				}
			 				
			 			}
			 				 //Long id = 55503L;
			 				 Notification not = NotificationLocalServiceUtil.getNotification(notifiid);		 				
			 				 /*	Email Send */
			 				 				
			 			if (not.getIsMail() == true) {
			 					String body = "<h2>Verify Notification Center</h2>"
			 				 							+"<BR/><BR/>"
			 				 							+username+" add to you   '"+title+"' Activate checklist"
			 				 							+"<BR/><BR/>"
			 				 							+"Take a look"
			 				 							+" here. "+myUrl+"<BR/> Link doesn't work? Here's the URL:<BR/>";
			 				 			
			 					UserLocalServiceUtil.sendPassword(userr.getCompanyId(), userr.getEmailAddress(), "verify", fromAddress, subject, body, serviceContext);
			 				 		//UserLocalServiceUtil.sendEmailAddressVerification(userr, userr.getEmailAddress(), serviceContext);
			 				 	System.out.println("Email Was Sent");
			 				 				
			 									}
			 			
			 			/********************/
			 			 
			 			

			 				
			 			//	User u = UserLocalServiceUtil.getUser(userId);
			 				
			 	
//			 				String notificationText = "You are Assigned to Task : "+title +" by " +u1.getFullName();
			 				
			 				Date now = new Date();
			 				Calendar cal = Calendar.getInstance();
			 				cal.setTime(now);
			 				cal.add(Calendar.DAY_OF_YEAR, 1);
			 				Date tomorrow = cal.getTime();
			 				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			 				String tomorrow1 = dateFormat.format(tomorrow);
			 				//System.out.println("TOMORROW DATE=========="+tomorrow1);
			 			
			 				JSONObject payloadJSON = JSONFactoryUtil.createJSONObject();
			 				String DATE_FORMAT_Display = "dd MMMM yyyy";
			 				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_Display);
			 			//	String printDate =sdf1.format(stdt);
			 				//String notification = username +" Add to you this : "+title ;

			 				
			 				String notificationText = username+": add to you  : "+title+" activate checklist"; 
			 				payloadJSON.put("notificationText", notificationText);	
			 				
			 				/*System.out.println("REAL================="+stdt);
			 				System.out.println("TOM=================="+tomorrow1);*/
			
			 	
			 				payloadJSON.put("userId", usrid);
			 				
			 					
			 					
			 				UserNotificationEventLocalServiceUtil.addUserNotificationEvent(
			 					usrid,DockBarUserNotificationHandler.PORTLET_ID,(new Date()).getTime(), usrid,payloadJSON.toString(), false, serviceContext);
			 			
			 				
			 				
			 				//UserNotificationEventUtil.countByU_D(userId, false);
			 				//System.out.println("User Notificaion count   " +un);
			 					
			 				List<UserNotificationEvent> un=UserNotificationEventLocalServiceUtil.getUserNotificationEvents(usrid);	
			 					for (UserNotificationEvent event :un)
			 					{
			 						boolean deliver = event.getDelivered();
			 						
			 						if(deliver==true)
			 						{
			 							long eventId=event.getUserNotificationEventId();
			 							UserNotificationEventLocalServiceUtil.deleteUserNotificationEvent(eventId);
			 							
			 						}
			 					}
			 					for (UserNotificationEvent userNotificationEvent : un) {
			 						//System.out.println("User Notificaion   " +userNotificationEvent);
			 						
			 					}
			 		
			 			
			 				 }
			 			   }
			 			}
			 			               
			 	 catch(Exception e){
			   System.out.println("NO such User found");
			   }
		  }
			 
			 
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);

			 response.setRenderParameter("action","addNewJSP");
		 }
	 
	 @RenderMapping(params="action=addJSP")
		public String addRenderRequest(RenderRequest request, RenderResponse response, Model model) throws PortalException, SystemException
		{
		 	ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
			User user = themeDisplay.getUser();
			long  userId=user.getUserId();
		 	List<CheckListCommand> clcommands = getChecListCommands(request);
		    long selectItem =ParamUtil.getLong(request, "myselectItem");

			model.addAttribute("checkList1",clcommands );
			model.addAttribute("myselectItem", selectItem);
			
			Long id1 = Long.parseLong(request.getParameter("checkId"));
			request.setAttribute("chkId", id1);
			
			CheckListCommand cl = new CheckListCommand();
			CategoryCommand cat = new CategoryCommand();
			CLTemplate clt = CLTemplateLocalServiceUtil.getCLTemplate(id1);
			cl.setId(clt.getChecklistId());
			cl.setName(clt.getClName());
			cl.setDesc(clt.getClDescription());
			cl.setUserid(clt.getClUserId());
			cl.setIspublic(clt.getIsPublic());
			cl.setIspubliccat(clt.getIsPubliccat());
			cl.setClOrganiztion(clt.getClOrganiztion());
			List<tag> tags = tagLocalServiceUtil.searchbychecklistId(id1);
			cl.setTagList(tags);
			List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
			List<Category> categories = CategoryLocalServiceUtil.getBySubClID(id1, 0);
			for (Category category : categories) {
				CategoryCommand cc = new CategoryCommand();
				cc.setId(category.getCatId());
				cc.setName(category.getCatName());

				cc.setSubcatid(category.getSubcategoryId());
				List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
				cc.setItemList(items);
				ccc.add(cc);
			}
			cl.setCategoryCommands(ccc);
			model.addAttribute("checkList", cl);
			//
			return CHECKLIST_JSP;
		}
	 
	 @RenderMapping(params="action=addNewJSP")
		public String addActivechecklist(RenderRequest request, RenderResponse response, Model model) throws PortalException, SystemException
		{
		
		 	long selectItem =ParamUtil.getLong(request, "myselectItem");
		 	List<CheckListCommand> clcommands = getChecListCommands(request);
			
			model.addAttribute("checkList1",clcommands );
			model.addAttribute("myselectItem", selectItem);
		    System.out.println("Coming inside Add new");
			Long id1 = Long.parseLong(request.getParameter("checkId"));
			String userinitialas = ParamUtil.getString(request, "checkfn");
			
			request.setAttribute("atstring", userinitialas);
			ActiveChecklistCommand cl = new ActiveChecklistCommand();
			ActiveCategoryCommand cat = new ActiveCategoryCommand();
			ActivateCL clt =ActivateCLLocalServiceUtil.getActivateCL(id1);
			
		    cl.setActivid(clt.getActivateId());
			cl.setActivchecklid(clt.getChecklistId());
			cl.setName(clt.getClName());
			cl.setDesc(clt.getClDescription());
			cl.setIscomplate(clt.getIsCompleted());
			cl.setIspublic(clt.getIsPublic());
			cl.setOrg(clt.getOrganiztion());
			cl.setActClUserId(clt.getActClUserId());
			List<ActiveCategoryCommand>ccc = new ArrayList<ActiveCategoryCommand>();
			List<ActCategory> actcategories =ActCategoryLocalServiceUtil.getByActClSubID(id1, 0);
			
			for (ActCategory category : actcategories) {
				ActiveCategoryCommand cc =new ActiveCategoryCommand();
				
				cc.setId(category.getActiveCheckListID());
				cc.setName(category.getCategoryName());
				cc.setSubcatid(category.getSubCatogryId());
				
				cc.setActivechlid(category.getActCategoryId());
				
				List<ActItem> items = ActItemLocalServiceUtil.searchbycatId(category.getActCategoryId());
				cc.setActItem(items);
				
				ccc.add(cc);
			}		
			cl.setActiveCategoryCommand(ccc);
			model.addAttribute("ActivChecklist", cl);
			//
			return ACTIVE_CHECKLIST_JSP;
		}
	 	 
	 @ActionMapping(params = "addCategory=addCategory")
		public void addCategory(ActionRequest request, ActionResponse response)
		        throws Exception {
		 
		 try{
			 String titleName = ParamUtil.getString(request, "cat");
			 Long scatid = Long.valueOf(request.getParameter("catid"));
			 //add category record
			 //create primary key
			 long catId=CounterLocalServiceUtil.increment();
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
			 
			 //create category persistence object
			 Category category=null;
			 category = new CategoryImpl();
			
			 //fill the data in persistence object
			 category.setCatId(CounterLocalServiceUtil.increment(Category.class.getName()));
			 category.setCatName(titleName);
			 category.setSubcategoryId(scatid);
			 category.setChecklistId(clId);
			 //Add category persistence object to database category table
			 CategoryLocalServiceUtil.addCategory(category);

			 //navigate to checlist jsp page
			 
			 request.setAttribute("catId",catId );
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);

			 response.setRenderParameter("action","addJSP");
		 	
		 	}catch(Exception e){
			 SessionErrors.add(request.getPortletSession(),"category-add-error");
			 e.printStackTrace();
			 }
			 }
	 	
	 @ActionMapping(params = "addCategory=addCategoryview")
		public void viewaddCategory(ActionRequest request, ActionResponse response)
		        throws Exception {
		 
		 try{
			 String titleName = ParamUtil.getString(request, "cat");
			 Long scatid = Long.valueOf(request.getParameter("catid"));
			 //add category record
			 //create primary key
			 long catId=CounterLocalServiceUtil.increment();
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
			 
			 //create category persistence object
			 Category category=null;
			 category = new CategoryImpl();
		 	 category =CategoryLocalServiceUtil.createCategory(catId);
			 //fill the data in persistence object
			 category.setCatId(CounterLocalServiceUtil.increment(Category.class.getName()));
			 category.setCatName(titleName);
			 category.setSubcategoryId(scatid);
			 category.setChecklistId(clId);
			 //Add category persistence object to database category table
			 CategoryLocalServiceUtil.addCategory(category);

			 //navigate to checlist jsp page
			 
			 request.setAttribute("catId",catId );
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);

			 response.setRenderParameter("action","viewPage");
		 	
		 	}catch(Exception e){
			 SessionErrors.add(request.getPortletSession(),"category-add-error");
			 e.printStackTrace();
			 }
			 }
	 
	 @ActionMapping(params = "addCategory=GridaddCategoryview")
		public void GridaddCategoryview(ActionRequest request, ActionResponse response)
		        throws Exception {
		 
		 try{
			 String titleName = ParamUtil.getString(request, "cat");
			 Long scatid = Long.valueOf(request.getParameter("catid"));
			 //add category record
			 //create primary key
			 long catId=CounterLocalServiceUtil.increment();
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
			 
			 //create category persistence object
			 Category category=null;
			 category = new CategoryImpl();
			
			 //fill the data in persistence object
			 category.setCatId(CounterLocalServiceUtil.increment(Category.class.getName()));
			 category.setCatName(titleName);
			 category.setSubcategoryId(scatid);
			 category.setChecklistId(clId);
			 //Add category persistence object to database category table
			 CategoryLocalServiceUtil.addCategory(category);

			 //navigate to checlist jsp page
			 
			 request.setAttribute("catId",catId );
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);

			 response.setRenderParameter("action","Gridview");
		 	
		 	}catch(Exception e){
			 SessionErrors.add(request.getPortletSession(),"category-add-error");
			 e.printStackTrace();
			 }
			 }
	//UPDATE ACTIVE CATEGORY AND SUBCATEGORY
	 	@ActionMapping(params="actcategoryaction=updateactSubcategory")
	 	public void updateActCategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	 	{
	 		long pkid = ParamUtil.getLong(request, "hcatid");
	 		long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
	 		ActCategory ecat = ActCategoryLocalServiceUtil.getActCategory(pkid);
	 		ecat.setCategoryName(ParamUtil.getString(request, "hcatname"));
	 		ActCategoryLocalServiceUtil.updateActCategory(ecat);
	 		String ckId = Long.toString(clId);
			response.setRenderParameter("checkId", ckId);
	 		response.setRenderParameter("action","addNewJSP");
	 	}
	 	@ActionMapping(params = "cataction=updateaction")
	 	public void updatecategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	 	{
	 		long pkid = ParamUtil.getLong(request, "hcatid");
	 		long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
	 		Category ecat = CategoryLocalServiceUtil.getCategory(pkid);
	 		ecat.setCatName(ParamUtil.getString(request, "hcatname"));
	 		CategoryLocalServiceUtil.updateCategory(ecat);
	 		String ckId = Long.toString(clId);
			response.setRenderParameter("checkId", ckId);
	 		response.setRenderParameter("action","addJSP");
	 	}
	 	
	 	@ActionMapping(params = "cataction=updateactionall")
	 	public void updatesubcategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	 	{
	 		long pkid = ParamUtil.getLong(request, "hcatid");
	 		long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
	 		Category ecat = CategoryLocalServiceUtil.getCategory(pkid);
	 		ecat.setCatName(ParamUtil.getString(request, "hcatname"));
	 		CategoryLocalServiceUtil.updateCategory(ecat);
	 		String ckId = Long.toString(clId);
			response.setRenderParameter("checkId", ckId);
	 		response.setRenderParameter("action","viewPage");
	 	}
	 
	 	@ActionMapping(params = "cataction=gridupdateaction")
	 	public void gridupdateaction(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	 	{
	 		ActCategory a = new ActCategoryImpl();
	 		long pkid = ParamUtil.getLong(request, "hcatid");
	 		long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
	 		Category ecat = CategoryLocalServiceUtil.getCategory(pkid);
	 		ecat.setCatName(ParamUtil.getString(request, "hcatname"));
	 		CategoryLocalServiceUtil.updateCategory(ecat);
	 		String ckId = Long.toString(clId);
			response.setRenderParameter("checkId", ckId);
	 		response.setRenderParameter("action","Gridview");
	 	}
	 
	 	
	 	@ActionMapping(params = "cataction=allupdateaction")
	 	public void allupdatecategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	 	{
	 		ActCategory a = new ActCategoryImpl();
	 		long pkid = ParamUtil.getLong(request, "hcatid");
	 		long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
	 		Category ecat = CategoryLocalServiceUtil.getCategory(pkid);
	 		ecat.setCatName(ParamUtil.getString(request, "hcatname"));
	 		CategoryLocalServiceUtil.updateCategory(ecat);
	 		String ckId = Long.toString(clId);
			response.setRenderParameter("checkId", ckId);
	 		response.setRenderParameter("action","viewPage");
	 	}
	 	
		@ActionMapping(params = "cataction=gridallupdateaction")
	 	public void gridallupdateaction(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	 	{
	 		ActCategory a = new ActCategoryImpl();
	 		long pkid = ParamUtil.getLong(request, "hcatid");
	 		long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
	 		Category ecat = CategoryLocalServiceUtil.getCategory(pkid);
	 		ecat.setCatName(ParamUtil.getString(request, "hcatname"));
	 		CategoryLocalServiceUtil.updateCategory(ecat);
	 		String ckId = Long.toString(clId);
			response.setRenderParameter("checkId", ckId);
	 		response.setRenderParameter("action","Gridview");
	 	}
	 	
	 	
	 	@ActionMapping(params = "ActiveAction=addActCategory")
		public void addActiveCategory(ActionRequest request, ActionResponse response)
		        throws Exception {
		 
		 try{
			 String titleName = ParamUtil.getString(request, "cat");
			 Long scatid = Long.valueOf(request.getParameter("catid"));
			 //add category record
			 //create primary key
			 long clId = Long.valueOf(request.getParameter("checklist"));
			// long clId = Long.valueOf(ParamUtil.getInteger(request, "checklist"));
			 
			 long verifyId=CounterLocalServiceUtil.increment();
		 		//create department persistance object
		 		
			 
			 ActCategory ActCategory=null;
			 ActCategory = new ActCategoryImpl();
			 
		 	 ActCategory = ActCategoryLocalServiceUtil.createActCategory(verifyId);
		 		
		 	 ActCategory.setActiveCheckListID(clId);
		 	 ActCategory.setCategoryName(titleName);
		 	 ActCategory.setSubCatogryId(scatid);
		 		
		 	 	
		    ActCategoryLocalServiceUtil.addActCategory(ActCategory);	
		 		
		 	

			 //navigate to add category jsp page
			 
			 //request.setAttribute("catId",catId );
			
		     String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);

			 response.setRenderParameter("action","addNewJSP");
		
			 }catch(Exception e){
			 SessionErrors.add(request.getPortletSession(),"category-add-error");
			 e.printStackTrace();
			 }
			 }
	 	
		
	 	@ActionMapping(params = "cataction=updateActiveCat")
		public void UpdateActiveCategory(ActionRequest request, ActionResponse response)
		        throws Exception {
		 
		 try{
			 long catId =ParamUtil.getLong(request, "actcatid");
			 String titleName = ParamUtil.getString(request, "hcatname");
			 Long ActiveClId = Long.valueOf(request.getParameter("checklist"));
			
			 ActCategory actCategory=ActCategoryLocalServiceUtil.getActCategory(catId);
			 actCategory.setCategoryName(titleName);
		 	
			 ActCategoryLocalServiceUtil.updateActCategory(actCategory);	
		 	
			 String ckId = Long.toString(ActiveClId);
			 response.setRenderParameter("checkId", ckId);

			 response.setRenderParameter("action","addNewJSP");
		
			 }catch(Exception e){
			 SessionErrors.add(request.getPortletSession(),"category-add-error");
			 e.printStackTrace();
			 }
			 }
	 	@ActionMapping(params = "action=ActiveItem")
		public void addActiveItem(ActionRequest request, ActionResponse response)
		        throws Exception {
		 
	 		/*String itemName = ParamUtil.getString(actionRequest, "itemname");*/
			String itemName=request.getParameter("itemname");
			long catId =ParamUtil.getLong(request, "categaryId");	
			long checkl =ParamUtil.getLong(request, "ActcheckId");	
			long userGid =ParamUtil.getLong(request, "useragropid");
			long majorPer =ParamUtil.getLong(request, "mejorweght");
			boolean major = ParamUtil.getBoolean(request, "mejoritem");
			
			System.out.println("this is my major Id"+major);
			/*Long catid = Long.valueOf(request.getParameter("cattid"));
			String idCheck = request.getParameter("ckkid");*/
			long ActitemId = CounterLocalServiceUtil.increment();
			// create department persistance object
			ActItem ActItem =new ActItemImpl();
			ActItem = ActItemLocalServiceUtil.createActItem(ActitemId);
			// fill the data in persistance object
			ActItem.setCatId(catId);
			ActItem.setActivateClid(checkl);
			ActItem.setUsergroupId(userGid);
			ActItem.setItemName(itemName);
			if(major == false){
				ActItem.setMajor(false);
				}else{
					ActItem.setMajor(true);
				}
			ActItem.setIsMajor(major);
			ActItem.setPercentage(majorPer);
			// Add department persistance object to database department table
			ActItem = ActItemLocalServiceUtil.addActItem(ActItem);
				//actionRequest.setRenderParameter("checkId", checkl);
			String myString = Long.toString(checkl);
		    response.setRenderParameter("checkId",myString);
		 	response.setRenderParameter("action", "addNewJSP");
		}
	 	//UPDATE DESCRIPTION
		 @ActionMapping(params="updtDesc=updateDesc")
		 public void updateDescription(ActionRequest request, ActionResponse response) throws PortalException, SystemException
		 {
			 long descid = ParamUtil.getLong(request, "itemid");
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkid"));
			 Item itemDesc = ItemLocalServiceUtil.getItem(descid);
			 itemDesc.setItemDesc(ParamUtil.getString(request, "message"));
			 ItemLocalServiceUtil.updateItem(itemDesc);
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);
			 response.setRenderParameter("action","addJSP");
		 }
		 
		//UPDATE DESCRIPTION
		 @ActionMapping(params="updtDesc=allupdateDesc")
		 public void allupdateDescription(ActionRequest request, ActionResponse response) throws PortalException, SystemException
		 {
			 long descid = ParamUtil.getLong(request, "itemid");
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkid"));
			 Item itemDesc = ItemLocalServiceUtil.getItem(descid);
			 itemDesc.setItemDesc(ParamUtil.getString(request, "message"));
			 ItemLocalServiceUtil.updateItem(itemDesc);
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);
			 response.setRenderParameter("action","viewPage");
		 }
		 
		 @ActionMapping(params="updtDesc=GridupdateDesc")
		 public void GridupdateDesc(ActionRequest request, ActionResponse response) throws PortalException, SystemException
		 {
			 long descid = ParamUtil.getLong(request, "itemid");
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkid"));
			 Item itemDesc = ItemLocalServiceUtil.getItem(descid);
			 itemDesc.setItemDesc(ParamUtil.getString(request, "message"));
			 ItemLocalServiceUtil.updateItem(itemDesc);
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);
			 response.setRenderParameter("action","Gridview");
		 }
		 //UPDATE COMMENTS
		 @ActionMapping(params="updtComm=updateComm1")
		 public void updateComments(ActionRequest request, ActionResponse response) throws PortalException, SystemException
		 {
			 long commid = ParamUtil.getLong(request, "comid");
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkid"));
			 ItemComment itemComm = ItemCommentLocalServiceUtil.getItemComment(commid);
			 itemComm.setComment(ParamUtil.getString(request, "comment"));
			 ItemCommentLocalServiceUtil.updateItemComment(itemComm);
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);
			 response.setRenderParameter("action","addJSP");
		 }
		 
		 @ActionMapping(params="updtComm=updateCommgrid")
		 public void updateCommgrid(ActionRequest request, ActionResponse response) throws PortalException, SystemException
		 {
			 long commid = ParamUtil.getLong(request, "comid");
			 long clId = Long.valueOf(ParamUtil.getInteger(request, "checkid"));
			 ItemComment itemComm = ItemCommentLocalServiceUtil.getItemComment(commid);
			 itemComm.setComment(ParamUtil.getString(request, "comment"));
			 ItemCommentLocalServiceUtil.updateItemComment(itemComm);
			 String ckId = Long.toString(clId);
			 response.setRenderParameter("checkId", ckId);
			 response.setRenderParameter("action","Gridview");
		 }
		 
	 @ActionMapping(params="addsubcat=addSubcat")
		public void addSubcategory(ActionRequest request, ActionResponse response) throws SystemException
		{
			String subcatN = ParamUtil.getString(request, "subcatname");
			long subcatid=CounterLocalServiceUtil.increment();
			Long catid = Long.valueOf(request.getParameter("catid"));
			String idCheck = request.getParameter("ckid");
			
			//Create Subcategory Persistence Object
			Subcategory subcategory = new SubcategoryImpl();
			
			//Set Values In Persistence Object
			subcategory.setSubcatId(CounterLocalServiceUtil.increment(Subcategory.class.getName()));
			subcategory.setSubcatName(subcatN);
			subcategory.setCatId(catid);
			
			//Add subcategory persistence object to subcategory table
			SubcategoryLocalServiceUtil.addSubcategory(subcategory);
			
			//navigate to checklist jsp page
			response.setRenderParameter("checkId", idCheck);
			response.setRenderParameter("action", "addJSP");			
			
		}
	 
	 
	 @ActionMapping(params = "addnew=addnewgrid")
	 public void addnewgrid(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException
		{
		 ThemeDisplay themeDisplay = 
				 (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		  	User user = themeDisplay.getUser();
		  	long  userId=user.getUserId();
			Long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			CLTemplate clTemplate =CLTemplateLocalServiceUtil.getCLTemplate(id1);
			String title= clTemplate.getClName();
			long Itemname =Long.valueOf(ParamUtil.getLong(actionRequest, "itemid"));
			
			
			ItemComment items=new ItemCommentImpl();
			items.setCommId(Long.valueOf(CounterLocalServiceUtil.increment()));
			items.setComment(actionRequest.getParameter("message"));
			items.setCreateTime(new Date());
			/*System.out.println(ParamUtil.getLong(actionRequest, "itemid"));*/
			items.setItemId(Long.valueOf(ParamUtil.getLong(actionRequest, "itemid")));
			items.setUserId(userId);
			ItemCommentLocalServiceUtil.addItemComment(items);
			
			List<CLCollab> clCollabs = CLCollabLocalServiceUtil.getCLCollabs(0, CLCollabLocalServiceUtil.getCLCollabsCount());
			for(CLCollab clco:clCollabs){
				long usrid =clco.getUserId();
			     String msg = "you hae been added to a checklist";
				 String msg1="Someone comments on an activated checklist I belong to";
				 String msg2="Someone comments on a checklist I belong to";
				 
				 ServiceContext serviceContext = ServiceContextFactory.getInstance(User.class.getName(), actionRequest);
				 
				 String  username=user.getFullName();
				 List<Portlet> list = PortletLocalServiceUtil.getPortlets();
				 for(int i=0;i<list.size();i++){
				 			         
				 try{    
				 			                 
				 if(list.get(i).getDisplayName().equalsIgnoreCase("verifier")){
				 		String portletid = list.get(i).getPortletId();
				 		System.out.println("PLID IS:: "+list.get(i).getPortletId());
				 			PortletURL myUrl = PortletURLFactoryUtil.create(actionRequest, portletid, themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);	
				 			myUrl.setWindowState(WindowState.MAXIMIZED);
				 			myUrl.setPortletMode(PortletMode.VIEW);
				 			String fromAddress = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_ADDRESS);
				 			String subject = "VERIFY ORGANIZTION MEMBER: "+username;
				 			User userr = UserLocalServiceUtil.getUserById(usrid);
				 		if (userr != null)
				 		
				 		{
				 				 //long userId = userr.getUserId();
				 				 //String userName = userr.getFullName();
				 			long notifiid=0;
				 			List<Notification> notifications = NotificationLocalServiceUtil.getNotifications(0, NotificationLocalServiceUtil.getNotificationsCount());
				 			for(Notification ntf:notifications)
				 			{
				 				long notid =ntf.getNoteId();
				 				
				 				Notification nott = NotificationLocalServiceUtil.getNotification(notid);
				 				String notename= nott.getNoteName();
				 				if(notename.equals(msg2))
				 				{
				 					notifiid =notid;
				 					break;
				 				}
				 				
				 			}
				 				 //Long id = 55503L;
				 				 Notification not = NotificationLocalServiceUtil.getNotification(notifiid);		 				
				 				 /*	Email Send */
				 				 				
				 			if (not.getIsMail() == true) {
				 					String body = "<h2>Verify Notification Center</h2>"
				 				 							+"<BR/><BR/>"
				 				 							+username+" Comment on this '"+title+"' Item"
				 				 							+"<BR/><BR/>"
				 				 							+"Take a look"
				 				 							+" here. "+myUrl+"<BR/> Link doesn't work? Here's the URL:<BR/>";
				 				 			
				 					UserLocalServiceUtil.sendPassword(userr.getCompanyId(), userr.getEmailAddress(), "verify", fromAddress, subject, body, serviceContext);
				 				 		//UserLocalServiceUtil.sendEmailAddressVerification(userr, userr.getEmailAddress(), serviceContext);
				 				 	System.out.println("Email Was Sent");
				 				 				
				 									}
				 			
				 			/********************/
				 			 
				 			

				 				
				 			//	User u = UserLocalServiceUtil.getUser(userId);
				 				
				 	
//				 				String notificationText = "You are Assigned to Task : "+title +" by " +u1.getFullName();
				 				
				 				Date now = new Date();
				 				Calendar cal = Calendar.getInstance();
				 				cal.setTime(now);
				 				cal.add(Calendar.DAY_OF_YEAR, 1);
				 				Date tomorrow = cal.getTime();
				 				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				 				String tomorrow1 = dateFormat.format(tomorrow);
				 				//System.out.println("TOMORROW DATE=========="+tomorrow1);
				 			
				 				JSONObject payloadJSON = JSONFactoryUtil.createJSONObject();
				 				String DATE_FORMAT_Display = "dd MMMM yyyy";
				 				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_Display);
				 			//	String printDate =sdf1.format(stdt);
				 				//String notification = username +" Add to you this : "+title ;

				 				
				 				String notificationText = username+": Comment on this : "+title; 
				 				payloadJSON.put("notificationText", notificationText);	
				 				
				 				/*System.out.println("REAL================="+stdt);
				 				System.out.println("TOM=================="+tomorrow1);*/
				
				 	
				 				payloadJSON.put("userId", usrid);
				 				
				 					
				 					
				 				UserNotificationEventLocalServiceUtil.addUserNotificationEvent(
				 					usrid,DockBarUserNotificationHandler.PORTLET_ID,(new Date()).getTime(), usrid,payloadJSON.toString(), false, serviceContext);
				 			
				 				System.out.println("Notification Has Beeen Sent");
				 				
				 				//UserNotificationEventUtil.countByU_D(userId, false);
				 				//System.out.println("User Notificaion count   " +un);
				 					
				 				List<UserNotificationEvent> un=UserNotificationEventLocalServiceUtil.getUserNotificationEvents(usrid);	
				 					for (UserNotificationEvent event :un)
				 					{
				 						boolean deliver = event.getDelivered();
				 						
				 						if(deliver==true)
				 						{
				 							long eventId=event.getUserNotificationEventId();
				 							UserNotificationEventLocalServiceUtil.deleteUserNotificationEvent(eventId);
				 							
				 						}
				 					}
				 					for (UserNotificationEvent userNotificationEvent : un) {
				 						//System.out.println("User Notificaion   " +userNotificationEvent);
				 						
				 					}
				 		
				 			
				 				 }
				 			   }
				 			}
				 			               
				 	 catch(Exception e){
				   System.out.println("NO such User found");
				   }
			  }
			}
			
						
			
			
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "Gridview");
/*			actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);
*/		
		}
	 @ActionMapping(params = "addnew=addnew")
	 public void add(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException
		{
		 ThemeDisplay themeDisplay = 
				 (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		  	User user = themeDisplay.getUser();
		  	long  userId=user.getUserId();
			Long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			CLTemplate clTemplate =CLTemplateLocalServiceUtil.getCLTemplate(id1);
			String title= clTemplate.getClName();
			long Itemname =Long.valueOf(ParamUtil.getLong(actionRequest, "itemid"));
			
			
			ItemComment items=new ItemCommentImpl();
			items.setCommId(Long.valueOf(CounterLocalServiceUtil.increment()));
			items.setComment(actionRequest.getParameter("message"));
			items.setCreateTime(new Date());
			/*System.out.println(ParamUtil.getLong(actionRequest, "itemid"));*/
			items.setItemId(Long.valueOf(ParamUtil.getLong(actionRequest, "itemid")));
			items.setUserId(userId);
			ItemCommentLocalServiceUtil.addItemComment(items);
			
			List<CLCollab> clCollabs = CLCollabLocalServiceUtil.getCLCollabs(0, CLCollabLocalServiceUtil.getCLCollabsCount());
			for(CLCollab clco:clCollabs){
				long usrid =clco.getUserId();
			     String msg = "you hae been added to a checklist";
				 String msg1="Someone comments on an activated checklist I belong to";
				 String msg2="Someone comments on a checklist I belong to";
				 
				 ServiceContext serviceContext = ServiceContextFactory.getInstance(User.class.getName(), actionRequest);
				 
				 String  username=user.getFullName();
				 List<Portlet> list = PortletLocalServiceUtil.getPortlets();
				 for(int i=0;i<list.size();i++){
				 			         
				 try{    
				 			                 
				 if(list.get(i).getDisplayName().equalsIgnoreCase("verifier")){
				 		String portletid = list.get(i).getPortletId();
				 		System.out.println("PLID IS:: "+list.get(i).getPortletId());
				 			PortletURL myUrl = PortletURLFactoryUtil.create(actionRequest, portletid, themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);	
				 			myUrl.setWindowState(WindowState.MAXIMIZED);
				 			myUrl.setPortletMode(PortletMode.VIEW);
				 			String fromAddress = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_ADDRESS);
				 			String subject = "VERIFY ORGANIZTION MEMBER: "+username;
				 			User userr = UserLocalServiceUtil.getUserById(usrid);
				 		if (userr != null)
				 		
				 		{
				 				 //long userId = userr.getUserId();
				 				 //String userName = userr.getFullName();
				 			long notifiid=0;
				 			List<Notification> notifications = NotificationLocalServiceUtil.getNotifications(0, NotificationLocalServiceUtil.getNotificationsCount());
				 			for(Notification ntf:notifications)
				 			{
				 				long notid =ntf.getNoteId();
				 				
				 				Notification nott = NotificationLocalServiceUtil.getNotification(notid);
				 				String notename= nott.getNoteName();
				 				if(notename.equals(msg2))
				 				{
				 					notifiid =notid;
				 					break;
				 				}
				 				
				 			}
				 				 //Long id = 55503L;
				 				 Notification not = NotificationLocalServiceUtil.getNotification(notifiid);		 				
				 				 /*	Email Send */
				 				 				
				 			if (not.getIsMail() == true) {
				 					String body = "<h2>Verify Notification Center</h2>"
				 				 							+"<BR/><BR/>"
				 				 							+username+" Comment on this '"+title+"' Item"
				 				 							+"<BR/><BR/>"
				 				 							+"Take a look"
				 				 							+" here. "+myUrl+"<BR/> Link doesn't work? Here's the URL:<BR/>";
				 				 			
				 					UserLocalServiceUtil.sendPassword(userr.getCompanyId(), userr.getEmailAddress(), "verify", fromAddress, subject, body, serviceContext);
				 				 		//UserLocalServiceUtil.sendEmailAddressVerification(userr, userr.getEmailAddress(), serviceContext);
				 				 	System.out.println("Email Was Sent");
				 				 				
				 									}
				 			
				 			/********************/
				 			 
				 			

				 				
				 			//	User u = UserLocalServiceUtil.getUser(userId);
				 				
				 	
//				 				String notificationText = "You are Assigned to Task : "+title +" by " +u1.getFullName();
				 				
				 				Date now = new Date();
				 				Calendar cal = Calendar.getInstance();
				 				cal.setTime(now);
				 				cal.add(Calendar.DAY_OF_YEAR, 1);
				 				Date tomorrow = cal.getTime();
				 				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				 				String tomorrow1 = dateFormat.format(tomorrow);
				 				//System.out.println("TOMORROW DATE=========="+tomorrow1);
				 			
				 				JSONObject payloadJSON = JSONFactoryUtil.createJSONObject();
				 				String DATE_FORMAT_Display = "dd MMMM yyyy";
				 				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_Display);
				 			//	String printDate =sdf1.format(stdt);
				 				//String notification = username +" Add to you this : "+title ;

				 				
				 				String notificationText = username+": Comment on this : "+title; 
				 				payloadJSON.put("notificationText", notificationText);	
				 				
				 				/*System.out.println("REAL================="+stdt);
				 				System.out.println("TOM=================="+tomorrow1);*/
				
				 	
				 				payloadJSON.put("userId", usrid);
				 				
				 					
				 					
				 				UserNotificationEventLocalServiceUtil.addUserNotificationEvent(
				 					usrid,DockBarUserNotificationHandler.PORTLET_ID,(new Date()).getTime(), usrid,payloadJSON.toString(), false, serviceContext);
				 			
				 				System.out.println("Notification Has Beeen Sent");
				 				
				 				//UserNotificationEventUtil.countByU_D(userId, false);
				 				//System.out.println("User Notificaion count   " +un);
				 					
				 				List<UserNotificationEvent> un=UserNotificationEventLocalServiceUtil.getUserNotificationEvents(usrid);	
				 					for (UserNotificationEvent event :un)
				 					{
				 						boolean deliver = event.getDelivered();
				 						
				 						if(deliver==true)
				 						{
				 							long eventId=event.getUserNotificationEventId();
				 							UserNotificationEventLocalServiceUtil.deleteUserNotificationEvent(eventId);
				 							
				 						}
				 					}
				 					for (UserNotificationEvent userNotificationEvent : un) {
				 						//System.out.println("User Notificaion   " +userNotificationEvent);
				 						
				 					}
				 		
				 			
				 				 }
				 			   }
				 			}
				 			               
				 	 catch(Exception e){
				   System.out.println("NO such User found");
				   }
			  }
			}
			
						
			
			
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "addJSP");
/*			actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);
*/			
		}
	 
	 
	 @ResourceMapping("myselectedvalue")
		public void seletedcheck(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, SystemException, PortalException
		{
		 
		 long selected =ParamUtil.getLong(resourceRequest, "selectedvalueid");
		 
		 System.out.println("my selecte value"+selected);
		
		 PortletSession session = resourceRequest.getPortletSession();
		 session.setAttribute("myselectItem1",selected,PortletSession.APPLICATION_SCOPE);
		 
		 //long portletScopeValue1 = (Long)session.getAttribute("myselectItem1");
		 //System.out.println("my selecte set value"+portletScopeValue1);
		 Long portletScopeValue = (Long) session.getAttribute("myselectItem1", PortletSession.APPLICATION_SCOPE);
		 
		 //long attributeValue = (Long) session.getAttribute("myselectItem1", PortletSession.APPLICATION_SCOPE); 
		 System.out.println("my selecte set value"+portletScopeValue);
		  
		}
	 
	 @ActionMapping(params = "addnew=Allviewaddnew")
	 public void Allviewaddnewadd(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException
		{
		 ThemeDisplay themeDisplay = 
				 (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		  	User user = themeDisplay.getUser();
		  	long  userId=user.getUserId();
			Long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			CLTemplate clTemplate =CLTemplateLocalServiceUtil.getCLTemplate(id1);
			String title= clTemplate.getClName();
			long Itemname =Long.valueOf(ParamUtil.getLong(actionRequest, "itemid"));
			
			
			ItemComment items=new ItemCommentImpl();
			items.setCommId(Long.valueOf(CounterLocalServiceUtil.increment()));
			items.setComment(actionRequest.getParameter("message"));
			items.setCreateTime(new Date());
			/*System.out.println(ParamUtil.getLong(actionRequest, "itemid"));*/
			items.setItemId(Long.valueOf(ParamUtil.getLong(actionRequest, "itemid")));
			items.setUserId(userId);
			ItemCommentLocalServiceUtil.addItemComment(items);
			
			List<CLCollab> clCollabs = CLCollabLocalServiceUtil.getCLCollabs(0, CLCollabLocalServiceUtil.getCLCollabsCount());
			for(CLCollab clco:clCollabs){
				long usrid =clco.getUserId();
			     String msg = "you hae been added to a checklist";
				 String msg1="Someone comments on an activated checklist I belong to";
				 String msg2="Someone comments on a checklist I belong to";
				 
				 ServiceContext serviceContext = ServiceContextFactory.getInstance(User.class.getName(), actionRequest);
				 
				 String  username=user.getFullName();
				 List<Portlet> list = PortletLocalServiceUtil.getPortlets();
				 for(int i=0;i<list.size();i++){
				 			         
				 try{    
				 			                 
				 if(list.get(i).getDisplayName().equalsIgnoreCase("verifier")){
				 		String portletid = list.get(i).getPortletId();
				 		System.out.println("PLID IS:: "+list.get(i).getPortletId());
				 			PortletURL myUrl = PortletURLFactoryUtil.create(actionRequest, portletid, themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);	
				 			myUrl.setWindowState(WindowState.MAXIMIZED);
				 			myUrl.setPortletMode(PortletMode.VIEW);
				 			String fromAddress = PrefsPropsUtil.getString(themeDisplay.getCompanyId(),PropsKeys.ADMIN_EMAIL_FROM_ADDRESS);
				 			String subject = "VERIFY ORGANIZTION MEMBER: "+username;
				 			User userr = UserLocalServiceUtil.getUserById(usrid);
				 		if (userr != null)
				 		
				 		{
				 				 //long userId = userr.getUserId();
				 				 //String userName = userr.getFullName();
				 			long notifiid=0;
				 			List<Notification> notifications = NotificationLocalServiceUtil.getNotifications(0, NotificationLocalServiceUtil.getNotificationsCount());
				 			for(Notification ntf:notifications)
				 			{
				 				long notid =ntf.getNoteId();
				 				
				 				Notification nott = NotificationLocalServiceUtil.getNotification(notid);
				 				String notename= nott.getNoteName();
				 				if(notename.equals(msg2))
				 				{
				 					notifiid =notid;
				 					break;
				 				}
				 				
				 			}
				 				 //Long id = 55503L;
				 				 Notification not = NotificationLocalServiceUtil.getNotification(notifiid);		 				
				 				 /*	Email Send */
				 				 				
				 			if (not.getIsMail() == true) {
				 					String body = "<h2>Verify Notification Center</h2>"
				 				 							+"<BR/><BR/>"
				 				 							+username+" Comment on this '"+title+"' Item"
				 				 							+"<BR/><BR/>"
				 				 							+"Take a look"
				 				 							+" here. "+myUrl+"<BR/> Link doesn't work? Here's the URL:<BR/>";
				 				 			
				 					UserLocalServiceUtil.sendPassword(userr.getCompanyId(), userr.getEmailAddress(), "verify", fromAddress, subject, body, serviceContext);
				 				 		//UserLocalServiceUtil.sendEmailAddressVerification(userr, userr.getEmailAddress(), serviceContext);
				 				 	System.out.println("Email Was Sent");
				 				 				
				 									}
				 			
				 			/********************/
				 			 
				 			

				 				
				 			//	User u = UserLocalServiceUtil.getUser(userId);
				 				
				 	
//				 				String notificationText = "You are Assigned to Task : "+title +" by " +u1.getFullName();
				 				
				 				Date now = new Date();
				 				Calendar cal = Calendar.getInstance();
				 				cal.setTime(now);
				 				cal.add(Calendar.DAY_OF_YEAR, 1);
				 				Date tomorrow = cal.getTime();
				 				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				 				String tomorrow1 = dateFormat.format(tomorrow);
				 				//System.out.println("TOMORROW DATE=========="+tomorrow1);
				 			
				 				JSONObject payloadJSON = JSONFactoryUtil.createJSONObject();
				 				String DATE_FORMAT_Display = "dd MMMM yyyy";
				 				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_Display);
				 			//	String printDate =sdf1.format(stdt);
				 				//String notification = username +" Add to you this : "+title ;

				 				
				 				String notificationText = username+": Comment on this : "+title; 
				 				payloadJSON.put("notificationText", notificationText);	
				 				
				 				/*System.out.println("REAL================="+stdt);
				 				System.out.println("TOM=================="+tomorrow1);*/
				
				 	
				 				payloadJSON.put("userId", usrid);
				 				
				 					
				 					
				 				UserNotificationEventLocalServiceUtil.addUserNotificationEvent(
				 					usrid,DockBarUserNotificationHandler.PORTLET_ID,(new Date()).getTime(), usrid,payloadJSON.toString(), false, serviceContext);
				 			
				 				System.out.println("Notification Has Beeen Sent");
				 				
				 				//UserNotificationEventUtil.countByU_D(userId, false);
				 				//System.out.println("User Notificaion count   " +un);
				 					
				 				List<UserNotificationEvent> un=UserNotificationEventLocalServiceUtil.getUserNotificationEvents(usrid);	
				 					for (UserNotificationEvent event :un)
				 					{
				 						boolean deliver = event.getDelivered();
				 						
				 						if(deliver==true)
				 						{
				 							long eventId=event.getUserNotificationEventId();
				 							UserNotificationEventLocalServiceUtil.deleteUserNotificationEvent(eventId);
				 							
				 						}
				 					}
				 					for (UserNotificationEvent userNotificationEvent : un) {
				 						//System.out.println("User Notificaion   " +userNotificationEvent);
				 						
				 					}
				 		
				 			
				 				 }
				 			   }
				 			}
				 			               
				 	 catch(Exception e){
				   System.out.println("NO such User found");
				   }
			  }
			}
			
						
			
			
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "viewPage");
/*			actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);
*/		
		}
	 
	 @ActionMapping(params="removecomment1=removecomment1")
	 public void removecomment(ActionRequest request,ActionResponse response) throws PortalException, SystemException
	 {
		 long commentid=ParamUtil.getLong(request, "commentid");
		 ItemCommentLocalServiceUtil.deleteItemComment(commentid);
		 Long id1 = Long.parseLong(request.getParameter("checkId"));
		 String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		    response.setRenderParameter("action", "addJSP");
		/* response.setRenderParameter("removecmnt", "removecmnt");*/
		 
	 }
	 
	 @ActionMapping(params="removecomment1=removecomment1all")
	 public void removecommentall(ActionRequest request,ActionResponse response) throws PortalException, SystemException
	 {
		 long commentid=ParamUtil.getLong(request, "commentid");
		 ItemCommentLocalServiceUtil.deleteItemComment(commentid);
		 Long id1 = Long.parseLong(request.getParameter("checkId"));
		 String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		    response.setRenderParameter("action", "viewPage");
		/* response.setRenderParameter("removecmnt", "removecmnt");*/
		 
	 }
	 
	 @ActionMapping(params="removecomment1=removecommentgrid")
	 public void removecommentgrid(ActionRequest request,ActionResponse response) throws PortalException, SystemException
	 {
		 long commentid=ParamUtil.getLong(request, "commentid");
		 ItemCommentLocalServiceUtil.deleteItemComment(commentid);
		 Long id1 = Long.parseLong(request.getParameter("checkId"));
		 String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		    response.setRenderParameter("action", "Gridview");
		/* response.setRenderParameter("removecmnt", "removecmnt");*/
		 
	 }
	 
	 @ActionMapping(params = "updatenew=updatenew")
	 public void updateComment(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		/* System.out.println(ParamUtil.getLong(actionRequest, "itemid1"));
		 System.out.println("ID IS:::::::::::>> "+actionRequest.getParameter("itemId1"));*/
			Long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			Long ItemId = Long.parseLong(actionRequest.getParameter("itemid1"));
			String desc =actionRequest.getParameter("desc1");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			
		    Item   item = ItemLocalServiceUtil.getItem(ItemId);
		    
		    if(item !=null)
		    {
		    	item.setItemName(item.getItemName());
		    	item.setItemDesc(desc);
		    	item.setCatId(item.getCatId());
		    	
		    	ItemLocalServiceUtil.updateItem(item);
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "addJSP");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 @ActionMapping(params = "updatenew=allupdatenew")
	 public void allupdateComment(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		/* System.out.println(ParamUtil.getLong(actionRequest, "itemid1"));
		 System.out.println("ID IS:::::::::::>> "+actionRequest.getParameter("itemId1"));*/
			Long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			Long ItemId = Long.parseLong(actionRequest.getParameter("itemid1"));
			String desc =actionRequest.getParameter("desc1");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			
		    Item   item = ItemLocalServiceUtil.getItem(ItemId);
		    
		    if(item !=null)
		    {
		    	item.setItemName(item.getItemName());
		    	item.setItemDesc(desc);
		    	item.setCatId(item.getCatId());
		    	
		    	ItemLocalServiceUtil.updateItem(item);
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "viewPage");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 @ActionMapping(params = "updatenew=updatenewGrid")
	 public void updatenewGrid(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		/* System.out.println(ParamUtil.getLong(actionRequest, "itemid1"));
		 System.out.println("ID IS:::::::::::>> "+actionRequest.getParameter("itemId1"));*/
			Long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			Long ItemId = Long.parseLong(actionRequest.getParameter("itemid1"));
			String desc =actionRequest.getParameter("desc1");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			
		    Item   item = ItemLocalServiceUtil.getItem(ItemId);
		    
		    if(item !=null)
		    {
		    	item.setItemName(item.getItemName());
		    	item.setItemDesc(desc);
		    	item.setCatId(item.getCatId());
		    	
		    	ItemLocalServiceUtil.updateItem(item);
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "Gridview");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 @ActionMapping(params = "action=checklistUpdate")
	 public void updatechecklist(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		/* System.out.println(ParamUtil.getLong(actionRequest, "itemid1"));
		 System.out.println("ID IS:::::::::::>> "+actionRequest.getParameter("itemId1"));*/
			long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			//Long checkId = Long.parseLong(actionRequest.getParameter("itemid1"));
			String checkname =actionRequest.getParameter("chekname");
			String desc =actionRequest.getParameter("desc");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			CLTemplate clTemplate=CLTemplateLocalServiceUtil.getCLTemplate(id1);
			
		    if(clTemplate !=null)
		    {
		    	
		    	clTemplate.setClName(checkname);
		    	
		    	
		    	CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "addJSP");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 
	 @ActionMapping(params = "action=checklistdelet")
	 public void deletchecklist(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
			//long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
		long id1 =ParamUtil.getLong(actionRequest, "checkId");
		System.out.println("this is"+id1);
		String id = Long.toString(id1);
		System.out.println("this issfdsgsdgdgr"+id);
		
				
				List<Category> categories= CategoryLocalServiceUtil.getCatByChecklistId(id1);
				System.out.println("categories   ========="+categories);
				for(Category cat:categories){
					long catid =cat.getCatId();
					
					List<Item> items =ItemLocalServiceUtil.searchbycatId(catid);
					for(Item Itemx:items){
						long itemid =Itemx.getItemId();
						
						List<ItemFile> itemFiles =ItemFileLocalServiceUtil.searchbyItemId(itemid);
						
						for(ItemFile If:itemFiles){
							long ItemFile =If.getFileId();
							ItemFileLocalServiceUtil.deleteItemFile(ItemFile);
							
						}
						
						List<ItemComment> itemComments = ItemCommentLocalServiceUtil.searchbyitemId(itemid);
						
						for(ItemComment ItemComm:itemComments){
							long Itemcomid =ItemComm.getCommId();
							ItemCommentLocalServiceUtil.deleteItemComment(Itemcomid);
							
						}
						ItemLocalServiceUtil.deleteItem(itemid);
						
					}
					
					CategoryLocalServiceUtil.deleteCategory(catid);
					
				}
				List<tag> tags =tagLocalServiceUtil.searchbychecklistId(id1);
				for(tag tag1:tags){
					long tagid =tag1.getId();
					if(tagid !=0){
						tag tag = tagLocalServiceUtil.deletetag(tagid);
					}
					
				}
				List<CLCollab> clCollabs =CLCollabLocalServiceUtil.getCollabByCL(id1);
				for(CLCollab clx:clCollabs){
					long checkid =clx.getClCollabId();
					if(checkid !=0){
						CLCollab clCollab =CLCollabLocalServiceUtil.deleteCLCollab(checkid);
					}
				}
				CLTemplate clTemplate=CLTemplateLocalServiceUtil.deleteCLTemplate(id1);
				actionResponse.setRenderParameter("action", "viewPage");
	 }
	 
	 @ActionMapping(params = "action=checklistdscUpdate")
	 public void updatechecklisdesct(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		
			long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
		
			String desc =actionRequest.getParameter("desc");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			CLTemplate clTemplate=CLTemplateLocalServiceUtil.getCLTemplate(id1);
			
		    if(clTemplate !=null)
		    {
		    	
		    	clTemplate.setClName(clTemplate.getClName());
		    	clTemplate.setClDescription(desc);
		    	clTemplate.setClOrganiztion(clTemplate.getClOrganiztion());
		    	
		    	
		    	CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "addJSP");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 @ActionMapping(params = "action=AllchecklistUpdate")
	 public void updateallchecklist(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		/* System.out.println(ParamUtil.getLong(actionRequest, "itemid1"));
		 System.out.println("ID IS:::::::::::>> "+actionRequest.getParameter("itemId1"));*/
			long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			//Long checkId = Long.parseLong(actionRequest.getParameter("itemid1"));
			String checkname =actionRequest.getParameter("chekname");
			String desc =actionRequest.getParameter("desc");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			CLTemplate clTemplate=CLTemplateLocalServiceUtil.getCLTemplate(id1);
			
		    if(clTemplate !=null)
		    {
		    	
		    	clTemplate.setClName(checkname);
		    	
		    	
		    	CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "viewPage");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 
	 @ActionMapping(params = "action=gridchecklistUpdate")
	 public void updategridchecklist(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		/* System.out.println(ParamUtil.getLong(actionRequest, "itemid1"));
		 System.out.println("ID IS:::::::::::>> "+actionRequest.getParameter("itemId1"));*/
			long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			//Long checkId = Long.parseLong(actionRequest.getParameter("itemid1"));
			String checkname =actionRequest.getParameter("chekname");
			String desc =actionRequest.getParameter("desc");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			CLTemplate clTemplate=CLTemplateLocalServiceUtil.getCLTemplate(id1);
			
		    if(clTemplate !=null)
		    {
		    	
		    	clTemplate.setClName(checkname);
		    	
		    	
		    	CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "Gridview");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 @ActionMapping(params = "action=Actchecklistdelet")
	 public void deletActchecklist(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
			//long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			long id1 =ParamUtil.getLong(actionRequest, "checkId");
			
			List<ActCategory> actCategories= ActCategoryLocalServiceUtil.searchbyActiveClId(id1);
			System.out.println("categories   ========="+actCategories);
			for(ActCategory actcat:actCategories){
				long catid =actcat.getActCategoryId();
				ActCategoryLocalServiceUtil.deleteActCategory(catid);
				List<ActItem> actItems =ActItemLocalServiceUtil.searchbycatId(catid);
				for(ActItem Actr:actItems){
					long actItemId = Actr.getItemId();
					
/*					List<ActItemFile> actItemFiles = ActItemFileLocalServiceUtil.g
*/					ActItemLocalServiceUtil.deleteActItem(actItemId);
					
				}
			}
			
			List<ActCLCollab> actCLCollabs =ActCLCollabLocalServiceUtil.getCollabByActiveCL(id1);
			for(ActCLCollab clx:actCLCollabs){
				long checkid =clx.getActClCollabId();
				if(checkid !=0){
					ActCLCollab actCLCollab =ActCLCollabLocalServiceUtil.deleteActCLCollab(checkid);
				}
			}
			
			ActivateCL activateCL=ActivateCLLocalServiceUtil.deleteActivateCL(id1);
			
			actionResponse.setRenderParameter("action", "addNewJsp");
	 }
	 
	 
	 @ActionMapping(params = "action=AllchecklistdscUpdate")
	 public void updateAllchecklisdesct(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		
			long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
		
			String desc =actionRequest.getParameter("desc");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			CLTemplate clTemplate=CLTemplateLocalServiceUtil.getCLTemplate(id1);
			
		    if(clTemplate !=null)
		    {
		    	
		    	clTemplate.setClName(clTemplate.getClName());
		    	clTemplate.setClDescription(desc);
		    	clTemplate.setClOrganiztion(clTemplate.getClOrganiztion());
		    	
		    	
		    	CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		   
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "viewPage");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 
	 @ActionMapping(params = "action=gridchecklistdscUpdate")
	 public void gridchecklistdscUpdate(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		 
		
			long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
		
			String desc =actionRequest.getParameter("desc");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			CLTemplate clTemplate=CLTemplateLocalServiceUtil.getCLTemplate(id1);
			
		    if(clTemplate !=null)
		    {
		    	
		    	clTemplate.setClName(clTemplate.getClName());
		    	clTemplate.setClDescription(desc);
		    	clTemplate.setClOrganiztion(clTemplate.getClOrganiztion());
		    	
		    	
		    	CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		   
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "Gridview");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	 @ActionMapping(params = "action=ActivechecklistUpdate")
	 public void updateActivechecklist(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 
		long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
			//Long checkId = Long.parseLong(actionRequest.getParameter("itemid1"));
			String checkname =actionRequest.getParameter("chekname");
			


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			ActivateCL activateCL =ActivateCLLocalServiceUtil.getActivateCL(id1);
			
		    if(activateCL !=null)
		    {
		    	
		    	activateCL.setClName(checkname);
		    	
		    	ActivateCLLocalServiceUtil.updateActivateCL(activateCL);
		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "addNewJSP");
		 	
	 }
	 @ActionMapping(params = "action=ActdscUpdate")
	 public void updateActivechecklisdesct(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		long id1 = Long.parseLong(actionRequest.getParameter("checkId"));
		
			String desc =actionRequest.getParameter("desc");


		   // Item  = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemid1"));
			
			ActivateCL activateCL =ActivateCLLocalServiceUtil.getActivateCL(id1);
			
		    if(activateCL !=null)
		    {
		    	
		    	activateCL.setClName(activateCL.getClName());
		    	activateCL.setClDescription(desc);
		    	
		    	
		    	ActivateCLLocalServiceUtil.updateActivateCL(activateCL);

		    	
		    	
		    	
		    }
			 
		  //  i.setItemDesc(actionRequest.getParameter("desc1"));
		 
		 
		 
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "addNewJSP");
		 
	 }
	 
	 @ActionMapping(params="uploadnew=uploadnew1")
	 public void fileuploading(ActionRequest request, ActionResponse response)
				throws Exception {
	 
		 ThemeDisplay themeDisplay =
		           (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		  User user = themeDisplay.getUser();
		  	long  userId=user.getUserId();
		  	
			//Long id1 = Long.parseLong(request.getParameter("checkId"));
			long id1 = ParamUtil.getLong(request, "checkId");
			long val =ParamUtil.getLong(request, "itemfileid");
			//System.out.println("ITEM ID IS::::::::::: "+val);

			/*Long  = ParamUtil.getLong(request, "ItemID");
			System.out.println("ITEM ID IS::::::::::: "+val);
	*/
			UploadPortletRequest uploadRequest = PortalUtil.getUploadPortletRequest(request);
	
			
			// Get the uploaded file as a file.
			File uploadedFile = uploadRequest.getFile(fileInputName);
	 
			String sourceFileName = uploadRequest.getFileName(fileInputName);
	 
			
			// Where should we store this file?
			File folder = new File(baseDir);
	 
			// This is our final file path.
			File filePath = new File(folder.getAbsolutePath() + File.separator + sourceFileName);
	 
			// Move the existing temporary file to new location.
			FileUtils.copyFile(uploadedFile, filePath, true);
			ItemFile file1=new ItemFileImpl();
			file1.setFileId(Long.valueOf(CounterLocalServiceUtil.increment()));
			file1.setFileName(sourceFileName);
			file1.setFilePath(filePath.toString());
			
			file1.setCreateTime(new Date());
			
			file1.setItemId(val);
			file1.setUserId(userId);
			ItemFileLocalServiceUtil.addItemFile(file1);
			
			
			String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		 	response.setRenderParameter("action", "addJSP");

			
/*			response.setRenderParameter("upload", "uploadfile1");
*/		  	
			
		 	
			
			 
		}
	 
	 @ActionMapping(params="uploadnew=allviewuploadnew1")
	 public void allviewfileuploading(ActionRequest request, ActionResponse response)
				throws Exception {
	 
		 ThemeDisplay themeDisplay =
		           (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		  User user = themeDisplay.getUser();
		  	long  userId=user.getUserId();
		  	
			//Long id1 = Long.parseLong(request.getParameter("checkId"));
			long id1 = ParamUtil.getLong(request, "checkId");
			long val =ParamUtil.getLong(request, "itemfileid");
			//System.out.println("ITEM ID IS::::::::::: "+val);

			/*Long  = ParamUtil.getLong(request, "ItemID");
			System.out.println("ITEM ID IS::::::::::: "+val);
	*/
			UploadPortletRequest uploadRequest = PortalUtil.getUploadPortletRequest(request);
	
			
			// Get the uploaded file as a file.
			File uploadedFile = uploadRequest.getFile(fileInputName);
	 
			String sourceFileName = uploadRequest.getFileName(fileInputName);
	 
			
			// Where should we store this file?
			File folder = new File(baseDir);
	 
			// This is our final file path.
			File filePath = new File(folder.getAbsolutePath() + File.separator + sourceFileName);
	 
			// Move the existing temporary file to new location.
			FileUtils.copyFile(uploadedFile, filePath, true);
			ItemFile file1=new ItemFileImpl();
			file1.setFileId(Long.valueOf(CounterLocalServiceUtil.increment()));
			file1.setFileName(sourceFileName);
			file1.setFilePath(filePath.toString());
			
			file1.setCreateTime(new Date());
			
			file1.setItemId(val);
			file1.setUserId(userId);
			ItemFileLocalServiceUtil.addItemFile(file1);
			
			
			String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		 	response.setRenderParameter("action", "viewPage");

			
/*			response.setRenderParameter("upload", "uploadfile1");
*/		  	
			
		 	
			
			 
		}
	 @ActionMapping(params="uploadnew=uploadnewgrid")
	 public void uploadnewgrid(ActionRequest request, ActionResponse response)
				throws Exception {
	 
		 ThemeDisplay themeDisplay =
		           (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		  User user = themeDisplay.getUser();
		  	long  userId=user.getUserId();
		  	
			//Long id1 = Long.parseLong(request.getParameter("checkId"));
			long id1 = ParamUtil.getLong(request, "checkId");
			long val =ParamUtil.getLong(request, "itemfileid");
			//System.out.println("ITEM ID IS::::::::::: "+val);

			/*Long  = ParamUtil.getLong(request, "ItemID");
			System.out.println("ITEM ID IS::::::::::: "+val);
	*/
			UploadPortletRequest uploadRequest = PortalUtil.getUploadPortletRequest(request);
	
			
			// Get the uploaded file as a file.
			File uploadedFile = uploadRequest.getFile(fileInputName);
	 
			String sourceFileName = uploadRequest.getFileName(fileInputName);
	 
			
			// Where should we store this file?
			File folder = new File(baseDir);
	 
			// This is our final file path.
			File filePath = new File(folder.getAbsolutePath() + File.separator + sourceFileName);
	 
			// Move the existing temporary file to new location.
			FileUtils.copyFile(uploadedFile, filePath, true);
			ItemFile file1=new ItemFileImpl();
			file1.setFileId(Long.valueOf(CounterLocalServiceUtil.increment()));
			file1.setFileName(sourceFileName);
			file1.setFilePath(filePath.toString());
			
			file1.setCreateTime(new Date());
			
			file1.setItemId(val);
			file1.setUserId(userId);
			ItemFileLocalServiceUtil.addItemFile(file1);
			
			
			String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		 	response.setRenderParameter("action", "Gridview");

			
/*			response.setRenderParameter("upload", "uploadfile1");
*/		  	
			
		 	
			
			 
		}
	 @ActionMapping(params = "uploadremove=uploadremove")
	 public void delete(ActionRequest request,ActionResponse response) throws PortalException, SystemException
	 {
		 
		 long fileid=ParamUtil.getLong(request, "fileId");
		 Long id1 = Long.parseLong(request.getParameter("checkId"));
		 ItemFileLocalServiceUtil.deleteItemFile(fileid);
		 String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		 	response.setRenderParameter("action", "addJSP");

		/* response.setRenderParameter("remove", "removefile");*/
		 
	 }
	 
	 @ActionMapping(params = "uploadremove=uploadremovegrid")
	 public void deletegridfile(ActionRequest request,ActionResponse response) throws PortalException, SystemException
	 {
		 
		 long fileid=ParamUtil.getLong(request, "fileId");
		 Long id1 = Long.parseLong(request.getParameter("checkId"));
		 ItemFileLocalServiceUtil.deleteItemFile(fileid);
		 String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		 	response.setRenderParameter("action", "Gridview");

		/* response.setRenderParameter("remove", "removefile");*/
		 
	 }
	 
	 @ActionMapping(params = "uploadremove=uploadremoveall")
	 public void deletegridfileall(ActionRequest request,ActionResponse response) throws PortalException, SystemException
	 {
		 
		 long fileid=ParamUtil.getLong(request, "fileId");
		 Long id1 = Long.parseLong(request.getParameter("checkId"));
		 ItemFileLocalServiceUtil.deleteItemFile(fileid);
		 String myString = Long.toString(id1);
		    response.setRenderParameter("checkId",myString);
		 	response.setRenderParameter("action", "viewPage");

		/* response.setRenderParameter("remove", "removefile");*/
		 
	 }
	 
	 @ActionMapping(params = "action=ItemUpdate")
		public void updateItem(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException, PortalException  
		{ 
		 try
		 {
			/*Item v=new ItemImpl();*/
			long itemId = ParamUtil.getLong(actionRequest,"itId");
			String itemName=ParamUtil.getString(actionRequest,"editem");
			long checkl =ParamUtil.getLong(actionRequest, "checkId");	

			Item m = ItemLocalServiceUtil.getItem(itemId);
			m.setItemName(itemName);
			m = ItemLocalServiceUtil.updateItem(m);
			
			
			String myString = Long.toString(checkl);
	    	actionResponse.setRenderParameter("checkId",myString);
	 		
	 		actionResponse.setRenderParameter("action", "addJSP");
			
			/*v.setItemName(itemName);
			actionResponse.setRenderParameter("mvcPath","/html/jsps/update_student.jsp");*/
		 }
		 catch(Exception e){
			 
			 e.printStackTrace();
			 }
		 }
	
	 @ActionMapping(params = "action=ViewallItemUpdate")
		public void ViewallItemUpdate(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException, PortalException  
		{ 
		 try
		 {
			/*Item v=new ItemImpl();*/
			long itemId = ParamUtil.getLong(actionRequest,"itId");
			String itemName=ParamUtil.getString(actionRequest,"editem");
			long checkl =ParamUtil.getLong(actionRequest, "checkId");	

			Item m = ItemLocalServiceUtil.getItem(itemId);
			m.setItemName(itemName);
			m = ItemLocalServiceUtil.updateItem(m);
			
			
			String myString = Long.toString(checkl);
	    	actionResponse.setRenderParameter("checkId",myString);
	 		
	 		actionResponse.setRenderParameter("action", "viewPage");
			
			/*v.setItemName(itemName);
			actionResponse.setRenderParameter("mvcPath","/html/jsps/update_student.jsp");*/
		 }
		 catch(Exception e){
			 
			 e.printStackTrace();
			 }
		 }
	 @ActionMapping(params = "action=allItemUpdate")
		public void allupdateItem(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException, PortalException  
		{ 
		 try
		 {
			/*Item v=new ItemImpl();*/
			long itemId = ParamUtil.getLong(actionRequest,"itId");
			String itemName=ParamUtil.getString(actionRequest,"editem");
			long checkl =ParamUtil.getLong(actionRequest, "checkId");	

			Item m = ItemLocalServiceUtil.getItem(itemId);
			m.setItemName(itemName);
			m = ItemLocalServiceUtil.updateItem(m);
			
			
			String myString = Long.toString(checkl);
	    	actionResponse.setRenderParameter("checkId",myString);
	 		
	 		actionResponse.setRenderParameter("action", "viewPage");
			
			/*v.setItemName(itemName);
			actionResponse.setRenderParameter("mvcPath","/html/jsps/update_student.jsp");*/
		 }
		 catch(Exception e){
			 
			 e.printStackTrace();
			 }
		 }
	 
	 @ActionMapping(params = "action=GridallItemUpdate")
		public void GridallItemUpdate(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException, PortalException  
		{ 
		 try
		 {
			/*Item v=new ItemImpl();*/
			long itemId = ParamUtil.getLong(actionRequest,"itId");
			String itemName=ParamUtil.getString(actionRequest,"editem");
			long checkl =ParamUtil.getLong(actionRequest, "checkId");	

			Item m = ItemLocalServiceUtil.getItem(itemId);
			m.setItemName(itemName);
			m = ItemLocalServiceUtil.updateItem(m);
			
			
			String myString = Long.toString(checkl);
	    	actionResponse.setRenderParameter("checkId",myString);
	 		
	 		actionResponse.setRenderParameter("action", "Gridview");
			
			/*v.setItemName(itemName);
			actionResponse.setRenderParameter("mvcPath","/html/jsps/update_student.jsp");*/
		 }
		 catch(Exception e){
			 
			 e.printStackTrace();
			 }
		 }
	 
	 @ActionMapping(params = "action=actItemUpdate")
	 public void updateactitem(ActionRequest actionRequest,
	 ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException, PortalException  
	 { 
	 try
	 {
	 long itemId = Long.valueOf(actionRequest.getParameter("itId"));
	 String itemName=ParamUtil.getString(actionRequest,"editem");
	 long checkl = Long.valueOf(actionRequest.getParameter("checkId"));

	             ActItem a =ActItemLocalServiceUtil.getActItem(itemId);
	             a.setItemName(itemName);
	             a=ActItemLocalServiceUtil.updateActItem(a);
	 //Item m = ItemLocalServiceUtil.getItem(itemId);
	 //m.setItemName(itemName);
	 //m = ItemLocalServiceUtil.updateItem(m);


	 String myString = Long.toString(checkl);
	     actionResponse.setRenderParameter("checkId",myString);
	    	
	 actionResponse.setRenderParameter("action", "addNewJSP");

	 
	 }
	 catch(Exception e){

	 e.printStackTrace();
	 }
	 }
	 @ActionMapping(params = "action=actionOne")
		public void addCheckListItem(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException {
	 		/*String itemName = ParamUtil.getString(actionRequest, "itemname");*/
			String itemName=actionRequest.getParameter("itemname");
			long catId =ParamUtil.getLong(actionRequest, "categaryId");
			long userGid =ParamUtil.getLong(actionRequest, "useragropid");	
			
			System.out.println("this is my User Id"+userGid);
		//	boolean mejor =ParamUtil.getBoolean(actionRequest, "mejoritem");
			String mejor =ParamUtil.getString(actionRequest, "mejoritem");
			long mejorvalue =ParamUtil.getLong(actionRequest, "mejorweght");
			long checkl =ParamUtil.getLong(actionRequest, "checkId");	
			
		
	/*		Long catid = Long.valueOf(request.getParameter("cattid"));
			String idCheck = request.getParameter("ckkid");*/
			
			
			long itemId = CounterLocalServiceUtil.increment();

				// create department persistance object

			     Item verify = new ItemImpl();
			
			
				verify = ItemLocalServiceUtil.createItem(itemId);

				// fill the data in persistance object
				
				verify.setItemName(itemName);
				verify.setChecklistId(checkl);
				verify.setCatId(catId);
				verify.setUserGroupId(userGid);
				if(mejor == null || mejor.equals("")){
				verify.setMajor(false);
				}else{
					verify.setMajor(true);
				}
				verify.setMajor_percent(mejorvalue);
				
				// Add department persistance object to database department table

				verify = ItemLocalServiceUtil.addItem(verify);
				
				
				//actionRequest.setRenderParameter("checkId", checkl);


				String myString = Long.toString(checkl);
		    	actionResponse.setRenderParameter("checkId",myString);
		 		
		 		actionResponse.setRenderParameter("action", "addJSP");
		}
	 
	 
	 @ActionMapping(params = "action=actionOneview")
		public void addviewCheckListItem(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException {
	 		/*String itemName = ParamUtil.getString(actionRequest, "itemname");*/
			String itemName=actionRequest.getParameter("itemname");
			long catId =ParamUtil.getLong(actionRequest, "categaryId");	
			long userid =ParamUtil.getLong(actionRequest, "allusergropid");	

		//	boolean mejor =ParamUtil.getBoolean(actionRequest, "mejoritem");
			String mejor =ParamUtil.getString(actionRequest, "mejoritem");
			long mejorvalue =ParamUtil.getLong(actionRequest, "mejorweght");
			long checkl =ParamUtil.getLong(actionRequest, "checkId");	
			//System.out.println("===============weight===="+mejor);
			//System.out.println("===============weight===="+mejorvalue);
		
	/*		Long catid = Long.valueOf(request.getParameter("cattid"));
			String idCheck = request.getParameter("ckkid");*/
			
			
			long itemId = CounterLocalServiceUtil.increment();

				// create department persistance object

			     Item verify = new ItemImpl();
			
			
				verify = ItemLocalServiceUtil.createItem(itemId);

				// fill the data in persistance object
				
				verify.setItemName(itemName);
				verify.setChecklistId(checkl);
				verify.setCatId(catId);
				verify.setUserGroupId(userid);
				if(mejor != null){
				verify.setMajor(true);
				}
				verify.setMajor_percent(mejorvalue);
				
				// Add department persistance object to database department table

				verify = ItemLocalServiceUtil.addItem(verify);
				
				
				//actionRequest.setRenderParameter("checkId", checkl);


				String myString = Long.toString(checkl);
		    	actionResponse.setRenderParameter("checkId",myString);
		 		
		 		actionResponse.setRenderParameter("action", "viewPage");
		}
	 /*
	 @ActionMapping(params="add=add")
		public void addItemDrag(ActionRequest actionRequest, ActionResponse actionResponse) throws SystemException
		{
			
			
		}*/

	 @ActionMapping(params = "action=gridactionOneview")
		public void gridactionOneview(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, com.liferay.portal.kernel.exception.SystemException {
	 		/*String itemName = ParamUtil.getString(actionRequest, "itemname");*/
			String itemName=actionRequest.getParameter("itemname");
			long catId =ParamUtil.getLong(actionRequest, "categaryId");	
			long userid =ParamUtil.getLong(actionRequest, "gridusergropid");	

			
		//	boolean mejor =ParamUtil.getBoolean(actionRequest, "mejoritem");
			String mejor =ParamUtil.getString(actionRequest, "mejoritem");
			long mejorvalue =ParamUtil.getLong(actionRequest, "mejorweght");
			long checkl =ParamUtil.getLong(actionRequest, "checkId");	
		//	System.out.println("===============weight===="+mejor);
			//System.out.println("===============weight===="+mejorvalue);
		
	/*		Long catid = Long.valueOf(request.getParameter("cattid"));
			String idCheck = request.getParameter("ckkid");*/
			
			
			long itemId = CounterLocalServiceUtil.increment();

				// create department persistance object

			     Item verify = new ItemImpl();
			
			
				verify = ItemLocalServiceUtil.createItem(itemId);

				// fill the data in persistance object
				
				verify.setItemName(itemName);
				verify.setChecklistId(checkl);
				verify.setCatId(catId);
				verify.setUserGroupId(userid);
				if(mejor != null){
				verify.setMajor(true);
				}
				verify.setMajor_percent(mejorvalue);
				
				// Add department persistance object to database department table

				verify = ItemLocalServiceUtil.addItem(verify);
				
				
				//actionRequest.setRenderParameter("checkId", checkl);


				String myString = Long.toString(checkl);
		    	actionResponse.setRenderParameter("checkId",myString);
		 		
		 		actionResponse.setRenderParameter("action", "Gridview");
		}
	 /*
	 @ActionMapping(params="add=add")
		public void addItemDrag(ActionRequest actionRequest, ActionResponse actionResponse) throws SystemException
		{
			
			
		}*/
	 
	@ResourceMapping
	public void serveResource(ResourceRequest request, ResourceResponse response){
	 
	    	long resourceID = Long.valueOf(request.getResourceID());
	    			
	      System.out.println(resourceID);
	    	

	       try {
	    	   
	    	   
			ItemLocalServiceUtil.deleteItem(resourceID);
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      
	       
	}

	//reshu
	@ActionMapping(params = "action=ActItem")
	public void UpdateActiveItem(ActionRequest actionRequest, ActionResponse actionResponse)
	        throws Exception {
	 
	try {
 			//String itemName=request.getParameter("itemname");
 			
 			ThemeDisplay themeDisplay = 
 					 (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
 			User user = themeDisplay.getUser();
 			
 			long  userId=user.getUserId();
 			long ActId =ParamUtil.getLong(actionRequest, "activeItemId");	
			long checkl =ParamUtil.getLong(actionRequest, "actcheckId");
			/*User currentUser = PortalUtil.getUser(actionRequest);
			System.out.println("=========currentUser Id"+currentUser);*/


			ActItem  ActItem = ActItemLocalServiceUtil.getActItem(ActId);
					
			
			if(ActItem!=null){
				//fill update information
				ActItem.setItemName(ActItem.getItemName());
				ActItem.setCatId(ActItem.getCatId());
				ActItem.setCompleted(true);
				ActItem.setCompletedDate(new Date());
				ActItem.setUserId(userId);
/*					ActItem.setUserId(currentUser.getUserId());
*/					
				ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
				}
			
			//navigate to add department jsp page
		/*	actionResponse.setRenderParameter("mvcPath",
					"/html/jsps/update_department.jsp");*/
			
			String myString = Long.toString(checkl);
		    actionResponse.setRenderParameter("checkId",myString);
		 	actionResponse.setRenderParameter("action", "addNewJSP");
			
		} catch (Exception e) {
			SessionErrors.add(actionRequest.getPortletSession(),
					"Activate-Item-error");
			e.printStackTrace();
		}
	}
	
	@ActionMapping(params = "action=recheckItem")
	public void RecheckActiveItem(ActionRequest actionRequest, ActionResponse actionResponse)
	        throws Exception {
	 
 		try {
 			//String itemName=request.getParameter("itemname");
			long ActId =ParamUtil.getLong(actionRequest, "recheckItemId");	
			long checkl =ParamUtil.getLong(actionRequest, "actcheckId");
			/*User currentUser = PortalUtil.getUser(actionRequest);
			System.out.println("=========currentUser Id"+currentUser);*/


			ActItem  ActItem = ActItemLocalServiceUtil.getActItem(ActId);
					
			
			if(ActItem!=null){
				//fill update information
				ActItem.setItemName(ActItem.getItemName());
				ActItem.setCatId(ActItem.getCatId());
				ActItem.setCompleted(false);
/*					ActItem.setUserId(currentUser.getUserId());
*/					
				ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
				}
			
			//navigate to add department jsp page
		/*	actionResponse.setRenderParameter("mvcPath",
					"/html/jsps/update_department.jsp");*/
			
			String myString = Long.toString(checkl);
		    actionResponse.setRenderParameter("checkId",myString);
		 	actionResponse.setRenderParameter("action", "addNewJSP");
			
		} catch (Exception e) {
			SessionErrors.add(actionRequest.getPortletSession(),
					"Activate-Item-error");
			e.printStackTrace();
		}
	}
	
 	
	@ActionMapping(params = "action=IgnoreItem")
	public void IgnoreActiveItem(ActionRequest actionRequest, ActionResponse actionResponse)
	        throws Exception {
	 
 		try {
 			//String itemName=request.getParameter("itemname");
			long ActId =ParamUtil.getLong(actionRequest, "IgnoreItem");	
			long checkl =ParamUtil.getLong(actionRequest, "actcheckId");
/*				User currentUser = PortalUtil.getUser(actionRequest);
*/				
			ActItem  ActItem = ActItemLocalServiceUtil.getActItem(ActId);
					
			
			if(ActItem!=null){
				//fill update information
				ActItem.setItemName(ActItem.getItemName());
				ActItem.setCatId(ActItem.getCatId());
				ActItem.setIgnore(true);
/*					ActItem.setUserId(currentUser.getUserId());
*/					
				ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
				}
			
			//navigate to add department jsp page
		/*	actionResponse.setRenderParameter("mvcPath",
					"/html/jsps/update_department.jsp");*/
			
			String myString = Long.toString(checkl);
		    actionResponse.setRenderParameter("checkId",myString);
		 	actionResponse.setRenderParameter("action", "addNewJSP");
			
		} catch (Exception e) {
			SessionErrors.add(actionRequest.getPortletSession(),
					"Activate-Item-error");
			e.printStackTrace();
		}
	}
	 
	@ActionMapping(params = "action=IgnoreItemupdate")
	public void IgnoreActiveItemupdate(ActionRequest actionRequest, ActionResponse actionResponse)
	        throws Exception {
	 
 		try {
 			//String itemName=request.getParameter("itemname");
			long ActId =ParamUtil.getLong(actionRequest, "IgnoreItem");	
			long checkl =ParamUtil.getLong(actionRequest, "actcheckId");
/*				User currentUser = PortalUtil.getUser(actionRequest);
*/				
			ActItem  ActItem = ActItemLocalServiceUtil.getActItem(ActId);
					
			
			if(ActItem!=null){
				//fill update information
				ActItem.setItemName(ActItem.getItemName());
				ActItem.setCatId(ActItem.getCatId());
				ActItem.setIgnore(false);
/*					ActItem.setUserId(currentUser.getUserId());
*/					
				ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
				}
			
			//navigate to add department jsp page
		/*	actionResponse.setRenderParameter("mvcPath",
					"/html/jsps/update_department.jsp");*/
			
			String myString = Long.toString(checkl);
		    actionResponse.setRenderParameter("checkId",myString);
		 	actionResponse.setRenderParameter("action", "addNewJSP");
			
		} catch (Exception e) {
			SessionErrors.add(actionRequest.getPortletSession(),
					"Activate-Item-error");
			e.printStackTrace();
		}
	}
	
	 @ActionMapping(params = "action=ReopenChecklist")
	 public void updateActiveCl(ActionRequest actionRequest,ActionResponse actionResponse) throws NumberFormatException, PortalException, SystemException
	 
	 {
		 long id1 = Long.parseLong(actionRequest.getParameter("checkid"));
		 
		 ActivateCL activateCL =ActivateCLLocalServiceUtil.getActivateCL(id1);
			  if(activateCL !=null)
		    {
		    	
		    	activateCL.setIsCompleted(false);
		    	
		    	ActivateCLLocalServiceUtil.updateActivateCL(activateCL);
		    }
			String myString = Long.toString(id1);
		    actionResponse.setRenderParameter("checkId",myString);
		    actionResponse.setRenderParameter("action", "addNewJSP");
		 	/*ItemLocalServiceUtil.updateItem(i);
		 	actionResponse.setRenderParameter(VIEW_JSP_PARAMETER, ADD_ITEM_DESC_JSP);*/
	 }
	
	
	
	//SHIVAM
	 // update categoryId on drop event
	 
	@ActionMapping(params ="updateform=updateform")
	   public void updateform(ActionRequest actionRequest,
	 			ActionResponse actionResponse) throws IOException, PortletException, NumberFormatException, PortalException, SystemException {
		/*System.out.println("enter into update");*/
		Item item = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemchild1"));	
		long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
		/*System.out.println(item);
		System.out.println("==================="+item);*/
		item.setCatId(Long.valueOf(actionRequest.getParameter("category1")));
		
		 Category category = new CategoryImpl();
		 String ckId = Long.toString(clId);
		 
		 ItemLocalServiceUtil.updateItem(item);
		 actionResponse.setRenderParameter("checkId", ckId);
		 actionResponse.setRenderParameter("action","addJSP");
		
		
	}
	
	// update subcategoryId on drop event shivam
	
			@ActionMapping(params ="abc=abc")
			   public void abc(ActionRequest actionRequest,
			 			ActionResponse actionResponse) throws Exception,NumberFormatException {
				
				/*System.out.println("enter into update sc");*/
				
				Item item = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "scitemchild1"));	
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
			
				item.setCatId(Long.valueOf(actionRequest.getParameter("sccategory1")));
				
				Subcategory sc = new SubcategoryImpl();
				Category category = new CategoryImpl();
				
				 String ckId = Long.toString(clId);
				 
				 ItemLocalServiceUtil.updateItem(item);
				 actionResponse.setRenderParameter("checkId", ckId);
				 actionResponse.setRenderParameter("action","addJSP");
				
				
			}
			
			
			
			// delete item on drop event
			
			@ActionMapping(params ="deleteform=deleteform")
			 public void deleteform(ActionRequest actionRequest,
			 			ActionResponse actionResponse) throws Exception {
			/*System.out.println("inside delete mthd");*/
				long Itemid =ParamUtil.getLong(actionRequest, "itemchild2");
				Item item1 = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemchild2"));
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
				
				
			 	Category category = new CategoryImpl();
			 	
			 	List<ItemFile>  itemFiles =ItemFileLocalServiceUtil.getAllFiles(Itemid);
			 	for(ItemFile itemf:itemFiles){
			 		long fileif =itemf.getFileId();
			 		ItemFileLocalServiceUtil.deleteItemFile(fileif);
			 		
			 		List<ItemComment> itemComments =ItemCommentLocalServiceUtil.getAllComments(Itemid);
			 		for(ItemComment itemcomm:itemComments){
			 			
			 			long itemcommId =itemcomm.getCommId();
			 			ItemCommentLocalServiceUtil.deleteItemComment(itemcommId);
			 		}
			 	}
				String ckId = Long.toString(clId);
				
				ItemLocalServiceUtil.deleteItem(item1);
				
				 actionResponse.setRenderParameter("checkId", ckId);
				 actionResponse.setRenderParameter("action","addJSP");
				
			}
			
			// delete category on drop event with sub category and its item
			 
			@ActionMapping(params ="deletecatform=deletecatform")
			 public void deletecatform(ActionRequest actionRequest,
			 			ActionResponse actionResponse) throws Exception {
			long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
			
				Category categorydel = CategoryLocalServiceUtil.getCategory(ParamUtil.getLong(actionRequest, "category2"));
				List<Item> itemdel = ItemLocalServiceUtil.searchbycatId(ParamUtil.getLong(actionRequest, "category2"));	
				List<Category> subcat = CategoryLocalServiceUtil.getBySubClID(clId, ParamUtil.getLong(actionRequest, "category2"));		
				for(Item delItem: itemdel)
				{
					ItemLocalServiceUtil.deleteItem(delItem);
				}
				for(Category delsc: subcat)
				{
					CategoryLocalServiceUtil.deleteCategory(delsc);
					List<Item> sitemdel = ItemLocalServiceUtil.searchbycatId(delsc.getCatId());
					for(Item delItem: sitemdel)
					{
						ItemLocalServiceUtil.deleteItem(delItem);
					}
				}
			    
						
			 	Category category = new CategoryImpl();
				String ckId = Long.toString(clId);
				
				CategoryLocalServiceUtil.deleteCategory(categorydel);
				
						
				 actionResponse.setRenderParameter("checkId", ckId);
				 actionResponse.setRenderParameter("action","addJSP");
				
			}


			// delete tag on drop event
			
			@ActionMapping(params ="deletetagform=deletetagform")
			public void deletetagform(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception{
				
				
				tag t1 = tagLocalServiceUtil.gettag(ParamUtil.getLong(actionRequest, "checktagdel"));
				System.out.println("inside deletetag method"+ParamUtil.getLong(actionRequest, "checktagdel"));
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
				System.out.println("inside checklist id method"+ParamUtil.getInteger(actionRequest, "checklist"));
				Category category = new CategoryImpl();
				String ckId = Long.toString(clId);
				
				tagLocalServiceUtil.deletetag(t1);
				
				actionResponse.setRenderParameter("checkId", ckId);
			 actionResponse.setRenderParameter("action","addJSP");
				
			}
			
			// delete subcategory on drop event
		 
			@ActionMapping(params ="deletescform=deletescform")
			 public void deletescform(ActionRequest actionRequest,
			 			ActionResponse actionResponse) throws Exception {
			/*System.out.println("inside deletesubcat mthd");*/
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
				Category s1 = CategoryLocalServiceUtil.getCategory(ParamUtil.getLong(actionRequest, "scdel"));	
				
				/*List<Category> subcatgry = CategoryLocalServiceUtil.getBySubClID(clId,ParamUtil.getLong(actionRequest, "scdel"));*/
			
					List<Item> scitemdel = ItemLocalServiceUtil.searchbycatId(s1.getCatId());
					for (Item sbctgryitm : scitemdel)
					{
						ItemLocalServiceUtil.deleteItem(sbctgryitm);
						
					}
					CategoryLocalServiceUtil.deleteCategory(s1);
		
				String ckId = Long.toString(clId);

				actionResponse.setRenderParameter("checkId", ckId);
				 actionResponse.setRenderParameter("action","addJSP");
				
			}
	//view Page drag method 
			
			
			 // update categoryId on drop event
			 
			@ActionMapping(params ="updateform=updateformview")
			   public void updateformview(ActionRequest actionRequest,
			 			ActionResponse actionResponse) throws IOException, PortletException, NumberFormatException, PortalException, SystemException {
				/*System.out.println("enter into update");*/
				Item item = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemchild1"));	
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
				/*System.out.println(item);
				System.out.println("==================="+item);*/
				item.setCatId(Long.valueOf(actionRequest.getParameter("category1")));
				
				Category category = new CategoryImpl();
				 String ckId = Long.toString(clId);
				 
				 ItemLocalServiceUtil.updateItem(item);
				 actionResponse.setRenderParameter("checkId", ckId);
				 actionResponse.setRenderParameter("action","veiwPage");
				
				
			}
			
			
			
					@ActionMapping(params ="abc=abcview")
					   public void abcview(ActionRequest actionRequest,
					 			ActionResponse actionResponse) throws Exception,NumberFormatException {
						
						/*System.out.println("enter into update sc");*/
						
						Item item = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "scitemchild1"));	
						long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
					
						item.setCatId(Long.valueOf(actionRequest.getParameter("sccategory1")));
						
						Subcategory sc = new SubcategoryImpl();
						Category category = new CategoryImpl();
						
						 String ckId = Long.toString(clId);
						 
						 ItemLocalServiceUtil.updateItem(item);
						 actionResponse.setRenderParameter("checkId", ckId);
						 actionResponse.setRenderParameter("action","veiwPage");
						
						
					}
					
					
					
					// delete item on drop event
					
					@ActionMapping(params ="deleteform=deleteformview")
					 public void deleteformview(ActionRequest actionRequest,
					 			ActionResponse actionResponse) throws Exception {
					/*System.out.println("inside delete mthd");*/
					
						Item item1 = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemchild2"));
						long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
						
						
					 	Category category = new CategoryImpl();
						String ckId = Long.toString(clId);
						
						ItemLocalServiceUtil.deleteItem(item1);
						
						 actionResponse.setRenderParameter("checkId", ckId);
						 actionResponse.setRenderParameter("action","veiwPage");
						
					}
					
					// delete category on drop event with sub category and its item
					 
					@ActionMapping(params ="deletecatform=deletecatformview")
					 public void deletecatformview(ActionRequest actionRequest,
					 			ActionResponse actionResponse) throws Exception {
					long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
					
						Category categorydel = CategoryLocalServiceUtil.getCategory(ParamUtil.getLong(actionRequest, "category2"));
						List<Item> itemdel = ItemLocalServiceUtil.searchbycatId(ParamUtil.getLong(actionRequest, "category2"));	
						List<Category> subcat = CategoryLocalServiceUtil.getBySubClID(clId, ParamUtil.getLong(actionRequest, "category2"));		
						for(Item delItem: itemdel)
						{
							ItemLocalServiceUtil.deleteItem(delItem);
						}
						for(Category delsc: subcat)
						{
							CategoryLocalServiceUtil.deleteCategory(delsc);
							List<Item> sitemdel = ItemLocalServiceUtil.searchbycatId(delsc.getCatId());
							for(Item delItem: sitemdel)
							{
								ItemLocalServiceUtil.deleteItem(delItem);
							}
						}
					    
								
					 	Category category = new CategoryImpl();
						String ckId = Long.toString(clId);
						
						CategoryLocalServiceUtil.deleteCategory(categorydel);
						
								
						 actionResponse.setRenderParameter("checkId", ckId);
						 actionResponse.setRenderParameter("action","veiwPage");
						
					}


					// delete tag on drop event
					
					@ActionMapping(params ="deletetagform=deletetagformview")
					public void deletetagformview(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception{
						
						System.out.println("inside deletetag method");
						
						tag t1 = tagLocalServiceUtil.gettag(ParamUtil.getLong(actionRequest, "tagdel"));
						
						long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));

						Category category = new CategoryImpl();
						String ckId = Long.toString(clId);
						
						tagLocalServiceUtil.deletetag(t1);
						
						actionResponse.setRenderParameter("checkId", ckId);
					 actionResponse.setRenderParameter("action","veiwPage");
						
					}
					
					@ResourceMapping("getcollabuser")
					public void deletecoluser(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, SystemException, PortalException
					{
					
						System.out.println("inside deletetag resourceRequest collab user  method");
						
						CLCollab t1 = CLCollabLocalServiceUtil.getCLCollab(ParamUtil.getLong(resourceRequest, "tagdel"));
						
						long clId = Long.valueOf(ParamUtil.getInteger(resourceRequest, "checklist"));

						CLCollab clCollab =new CLCollabImpl();
						
						String ckId = Long.toString(clId);
						
						CLCollabLocalServiceUtil.deleteCLCollab(t1);
						
						
						resourceRequest.setAttribute("checkId", ckId);
						resourceRequest.setAttribute("action", "addJSP");
					
					}
					
					@ResourceMapping("getActcollabuser")
					public void deleteActcoluser(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, SystemException, PortalException
					{
					
						System.out.println("inside deletetag resourceRequest collab user  method");
						
						ActCLCollab  t1 = ActCLCollabLocalServiceUtil.getActCLCollab(ParamUtil.getLong(resourceRequest, "tagdel"));
						
						long clId = Long.valueOf(ParamUtil.getInteger(resourceRequest, "checklist"));

						ActCLCollab actCLCollab =new ActCLCollabImpl();
						
						
						String ckId = Long.toString(clId);
						
						ActCLCollabLocalServiceUtil.deleteActCLCollab(t1);
						
						
						resourceRequest.setAttribute("checkId", ckId);
						resourceRequest.setAttribute("action", "addNewJSP");
					
					}
					
					@ResourceMapping("updatecollabuser")
					public void updatecoluser(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, SystemException, PortalException
					{
						String colabtype = ParamUtil.getString(resourceRequest, "userType");
						//System.out.println("this is my Colab User Id"+colabtype);
						
						System.out.println("Selectd ID is" + ParamUtil.getLong(resourceRequest, "selectedid"));
						System.out.println("Selectd ID is" + ParamUtil.getString(resourceRequest, "userType"));
						System.out.println("inside update resourceRequest collab user  method");
						
						long id = ParamUtil.getLong(resourceRequest, "selectedid");
						
						System.out.println("this is my Colab User Id"+id);
						
						
						CLCollab t1 = CLCollabLocalServiceUtil.getCLCollab(id);
						t1.setCollabType(colabtype);
						
						CLCollabLocalServiceUtil.updateCLCollab(t1);
												
						
					
					}
					
					@ResourceMapping("updatecollActabuser")
					public void updateActiavtecoluser(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, SystemException, PortalException
					{
						String colabtype = ParamUtil.getString(resourceRequest, "userType");
						//System.out.println("this is my Colab User Id"+colabtype);
						
						System.out.println("Selectd ID is" + ParamUtil.getLong(resourceRequest, "selectedid"));
						System.out.println("Selectd ID is" + ParamUtil.getString(resourceRequest, "userType"));
						System.out.println("inside update resourceRequest collab user  method");
						
						long id = ParamUtil.getLong(resourceRequest, "selectedid");
						
						System.out.println("this is my Colab User Id"+id);
						
						ActCLCollab t1 =ActCLCollabLocalServiceUtil.getActCLCollab(id);
						t1.setActCollabType(colabtype);
						
						ActCLCollabLocalServiceUtil.updateActCLCollab(t1);
						
					}
					
					@ActionMapping(params ="action=deletetagformcollab")
					public void deletecollabuser(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception{
						
						System.out.println("inside deletetag collab user  method");
						
						CLCollab t1 = CLCollabLocalServiceUtil.getCLCollab(ParamUtil.getLong(actionRequest, "tagdel"));
						
						long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));

						CLCollab clCollab =new CLCollabImpl();
						
						String ckId = Long.toString(clId);
						
						CLCollabLocalServiceUtil.deleteCLCollab(t1);
						
						
						actionResponse.setRenderParameter("checkId", ckId);
						actionResponse.setRenderParameter("action","addJSP");
						
					}
					
					// delete subcategory on drop event
				 
					@ActionMapping(params ="deletescform=deletescformview")
					 public void deletescformview(ActionRequest actionRequest,
					 			ActionResponse actionResponse) throws Exception {
					/*System.out.println("inside deletesubcat mthd");*/
						long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "checklist"));
						Category s1 = CategoryLocalServiceUtil.getCategory(ParamUtil.getLong(actionRequest, "scdel"));	
						
						/*List<Category> subcatgry = CategoryLocalServiceUtil.getBySubClID(clId,ParamUtil.getLong(actionRequest, "scdel"));*/
					
							List<Item> scitemdel = ItemLocalServiceUtil.searchbycatId(s1.getCatId());
							for (Item sbctgryitm : scitemdel)
							{
								ItemLocalServiceUtil.deleteItem(sbctgryitm);
								
							}
							CategoryLocalServiceUtil.deleteCategory(s1);
				
						String ckId = Long.toString(clId);

						actionResponse.setRenderParameter("checkId", ckId);
						 actionResponse.setRenderParameter("action","veiwPage");
						
					}
			
	//Active Checklist Page drag method 
	// update categoryId on drop event
	
	@ActionMapping(params ="updateform=updateformactive")
		public void updateformactive(ActionRequest actionRequest,
				ActionResponse actionResponse) throws IOException, PortletException, NumberFormatException, PortalException, SystemException {
						/*System.out.println("enter into update");*/
				
		/*System.out.println("enter into update");*/
		long itemcl =ParamUtil.getLong(actionRequest, "itemchild1");
		
		long catid =ParamUtil.getLong(actionRequest, "category1");
		
		ActItem actItem = ActItemLocalServiceUtil.getActItem(itemcl);
		
		long clId = ParamUtil.getInteger(actionRequest, "ActcheckId");
		/*System.out.println(item);
		System.out.println("==================="+item);*/
		actItem.setCatId(catid);
		
		 //ActCategory actCategory = new ActCategoryImpl();
		 String ckId = Long.toString(clId);
		 
		 System.out.println("actItem update"+actItem);
		 ActItemLocalServiceUtil.updateActItem(actItem);
		 actionResponse.setRenderParameter("checkId", ckId);
		 actionResponse.setRenderParameter("action","addNewJSP");
		
	}
	
	// update subcategoryId on drop event 
					
		@ActionMapping(params ="abc=abcactive")
		 public void abcactive(ActionRequest actionRequest,
				ActionResponse actionResponse) throws Exception,NumberFormatException {
				/*System.out.println("enter into update sc");*/
				ActItem actItem = ActItemLocalServiceUtil.getActItem(ParamUtil.getLong(actionRequest, "scitemchild1"));
								//Item item = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "scitemchild1"));	
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "ActcheckId"));
						actItem.setCatId(Long.valueOf(actionRequest.getParameter("sccategory1")));
								//item.setCatId(Long.valueOf(actionRequest.getParameter("sccategory1")));
					Subcategory sc = new SubcategoryImpl();
					ActCategory actCategory = new ActCategoryImpl();
					String ckId = Long.toString(clId);
					ActItemLocalServiceUtil.updateActItem(actItem);
					actionResponse.setRenderParameter("checkId", ckId);
					actionResponse.setRenderParameter("action","addNewJSP");
					}
	// delete item on drop event
		@ActionMapping(params ="deleteform=deleteformactive")
		 public void deleteformactive(ActionRequest actionRequest,
				 ActionResponse actionResponse) throws Exception {
				/*System.out.println("inside delete mthd");*/
			ActItem actItem1 = ActItemLocalServiceUtil.getActItem(ParamUtil.getLong(actionRequest, "itemchild2"));
			//	Item item1 = ItemLocalServiceUtil.getItem(ParamUtil.getLong(actionRequest, "itemchild2"));
			long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "ActcheckId"));
			ActCategory actCategory = new ActCategoryImpl();
			// Category category = new CategoryImpl();
			String ckId = Long.toString(clId);
			ActItemLocalServiceUtil.deleteActItem(actItem1);
								//ItemLocalServiceUtil.deleteItem(item1);
			actionResponse.setRenderParameter("checkId", ckId);
			actionResponse.setRenderParameter("action","addNewJSP");
}
							
		// delete category on drop event with sub category and its item
							 
	@ActionMapping(params ="deletecatform=deletecatformactive")
		public void deletecatformactive(ActionRequest actionRequest,
				ActionResponse actionResponse) throws Exception {
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "ActcheckId"));
				System.out.println("this is my Active Check list Id"+clId);
				ActCategory actCategorydel = ActCategoryLocalServiceUtil.getActCategory(ParamUtil.getLong(actionRequest, "category2"));
				System.out.println("this is my Active Check list Id"+actCategorydel);

				//Category categorydel = CategoryLocalServiceUtil.getCategory(ParamUtil.getLong(actionRequest, "category2"));
				List<ActItem> actItemdel = ActItemLocalServiceUtil.searchbycatId(ParamUtil.getLong(actionRequest, "category2"));
				//List<Item> itemdel = ItemLocalServiceUtil.searchbycatId(ParamUtil.getLong(actionRequest, "category2"));	
				List<ActCategory> subcat= ActCategoryLocalServiceUtil.getByActClSubID(clId, ParamUtil.getLong(actionRequest, "category2"));
				//	List<Category> subcat = CategoryLocalServiceUtil.getBySubClID(clId, ParamUtil.getLong(actionRequest, "category2"));		
				for(ActItem delItem: actItemdel)
				
				{
				ActItemLocalServiceUtil.deleteActItem(delItem);
				}
				
				for(ActCategory delsc: subcat)
				{
				ActCategoryLocalServiceUtil.deleteActCategory(delsc);
					//CategoryLocalServiceUtil.deleteCategory(delsc);
				List<ActItem> sitemdel=ActItemLocalServiceUtil.searchbycatId(delsc.getActCategoryId());
									//List<Item> sitemdel = ItemLocalServiceUtil.searchbycatId(delsc.getCatId());
				for(ActItem delItem: sitemdel)
				{
				ActItemLocalServiceUtil.deleteActItem(delItem);
										
				//	ItemLocalServiceUtil.deleteItem(delItem);
				}
				}
				//ActCategory actCategory = new ActCategoryImpl();
				String ckId = Long.toString(clId);
				ActCategoryLocalServiceUtil.deleteActCategory(actCategorydel);
				//CategoryLocalServiceUtil.deleteCategory(categorydel);
				actionResponse.setRenderParameter("checkId", ckId);
				actionResponse.setRenderParameter("action","addNewJSP");
								
				}

		// delete subcategory on drop event
	@ActionMapping(params ="deletescform=deletescformactive")
		public void deletescformactive(ActionRequest actionRequest,
				ActionResponse actionResponse) throws Exception {
					/*System.out.println("inside deletesubcat mthd");*/
				long clId = Long.valueOf(ParamUtil.getInteger(actionRequest, "ActcheckId"));
				ActCategory s1 = ActCategoryLocalServiceUtil.getActCategory(ParamUtil.getLong(actionRequest, "scdel"));
				//Category s1 = CategoryLocalServiceUtil.getCategory(ParamUtil.getLong(actionRequest, "scdel"));	
								
								/*List<Category> subcatgry = CategoryLocalServiceUtil.getBySubClID(clId,ParamUtil.getLong(actionRequest, "scdel"));*/
				List<ActItem> scitemdel = ActItemLocalServiceUtil.searchbycatId(s1.getActCategoryId());
									//List<Item> scitemdel = ItemLocalServiceUtil.searchbycatId(s1.getCatId());
				for (ActItem sbctgryitm : scitemdel)
				{
				ActItemLocalServiceUtil.deleteActItem(sbctgryitm);
				//ItemLocalServiceUtil.deleteItem(sbctgryitm);
				}
				ActCategoryLocalServiceUtil.deleteActCategory(s1);
				//CategoryLocalServiceUtil.deleteCategory(s1);
				String ckId = Long.toString(clId);
				actionResponse.setRenderParameter("checkId", ckId);
				actionResponse.setRenderParameter("action","addNewJSP");
				}		
	//Drage Code Finised 
	
	private List<CheckListCommand>  getChecListCommands(RenderRequest request) throws PortalException, SystemException
	{	
		ThemeDisplay themeDisplay =(ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		User user = themeDisplay.getUser();
		long  userId=user.getUserId();
		//String check = ParamUtil.getString(request, "myselectItem");
		
		List<CLTemplate> clTemplates= CLTemplateLocalServiceUtil.getallUser(userId);
		List<CheckListCommand> clcommands = new ArrayList<CheckListCommand>();
		for(CLTemplate clt1:clTemplates){
	    
		//long id1 =clt1.getChecklistId();
		String id11 = Long.toString(clt1.getChecklistId());
		//String id11 =String.valueOf(clt1.getChecklistId());
		//request.setAttribute("chkId", id11);
		Long id1 = Long.parseLong(id11);
		
		CheckListCommand cl = new CheckListCommand();
		CategoryCommand cat = new CategoryCommand();
		CLTemplate clt = CLTemplateLocalServiceUtil.getCLTemplate(id1);
		cl.setId(clt.getChecklistId());
		cl.setName(clt.getClName());
		cl.setDesc(clt.getClDescription());
		List<tag> tags = tagLocalServiceUtil.searchbychecklistId(id1);
		
		
		cl.setTagList(tags);
		List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
		List<Category> categories = CategoryLocalServiceUtil.getBySubClID(id1, 0);
		for (Category category : categories) {
			CategoryCommand cc = new CategoryCommand();
			cc.setId(category.getCatId());
			cc.setName(category.getCatName());

			cc.setSubcatid(category.getSubcategoryId());
			List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
			cc.setItemList(items);
			ccc.add(cc);
		}
		
		cl.setCategoryCommands(ccc);
		clcommands.add(cl);
		
		
		}
		List<CLCollab> clCollabs= CLCollabLocalServiceUtil.searchbyuserId(userId);
		for(CLCollab clcola:clCollabs){
			CLTemplate cluser = CLTemplateLocalServiceUtil.getCLTemplate(clcola.getChecklistId());
			CheckListCommand clUSercomm = new CheckListCommand();
			//SET COMMAND
			clUSercomm.setId(cluser.getChecklistId());
			clUSercomm.setName(cluser.getClName());
			clUSercomm.setDesc(cluser.getClDescription());
			clUSercomm.setUserid(cluser.getClUserId());
			List<tag> tags = tagLocalServiceUtil.searchbychecklistId(cluser.getChecklistId());
			
			
			clUSercomm.setTagList(tags);
			List<CategoryCommand>ccc = new ArrayList<CategoryCommand>();
			List<Category> categories = CategoryLocalServiceUtil.getBySubClID(cluser.getChecklistId(), 0);
			for (Category category : categories) {
				CategoryCommand cc = new CategoryCommand();
				cc.setId(category.getCatId());
				cc.setName(category.getCatName());

				cc.setSubcatid(category.getSubcategoryId());
				List<Item> items = ItemLocalServiceUtil.searchbycatId(category.getCatId());
				cc.setItemList(items);
				ccc.add(cc);
			}
			
			clUSercomm.setCategoryCommands(ccc);
			clcommands.add(clUSercomm);
			
		}
	
		return clcommands;
	}
	
}