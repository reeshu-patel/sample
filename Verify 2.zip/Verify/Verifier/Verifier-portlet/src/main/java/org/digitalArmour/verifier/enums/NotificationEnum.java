package org.digitalArmour.verifier.enums;

public enum NotificationEnum {

		User_Added("I'm added to an organization"),
		Someone_Added("Someone is added to an organization I belong to"),
		Added_toCL("I'm added to a checklist"),
		Someone_toCL("Someone is added to a checklist I belong to"),
		Comments_CL("Someone comments on a checklist I belong to"),
		Added_toACL("I'm added to an activated checklist"),
		Someone_toACL("Someone is added to an activated checklist I belong to"),
		Comments_ACL("Someone comments on an activated checklist I belong to");


		private String noteId;

		NotificationEnum(String noteId) {
		       this.noteId = noteId;
		   }

		   public String getnoteId() {
		       return noteId;
		   }

}
