package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ActCLCollab;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing ActCLCollab in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ActCLCollab
 * @generated
 */
public class ActCLCollabCacheModel implements CacheModel<ActCLCollab>,
    Externalizable {
    public String uuid;
    public long actClCollabId;
    public String actCollabType;
    public long actPrManagerId;
    public long userId;
    public long actChecklistId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", actClCollabId=");
        sb.append(actClCollabId);
        sb.append(", actCollabType=");
        sb.append(actCollabType);
        sb.append(", actPrManagerId=");
        sb.append(actPrManagerId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append(", actChecklistId=");
        sb.append(actChecklistId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ActCLCollab toEntityModel() {
        ActCLCollabImpl actCLCollabImpl = new ActCLCollabImpl();

        if (uuid == null) {
            actCLCollabImpl.setUuid(StringPool.BLANK);
        } else {
            actCLCollabImpl.setUuid(uuid);
        }

        actCLCollabImpl.setActClCollabId(actClCollabId);

        if (actCollabType == null) {
            actCLCollabImpl.setActCollabType(StringPool.BLANK);
        } else {
            actCLCollabImpl.setActCollabType(actCollabType);
        }

        actCLCollabImpl.setActPrManagerId(actPrManagerId);
        actCLCollabImpl.setUserId(userId);
        actCLCollabImpl.setActChecklistId(actChecklistId);

        actCLCollabImpl.resetOriginalValues();

        return actCLCollabImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        actClCollabId = objectInput.readLong();
        actCollabType = objectInput.readUTF();
        actPrManagerId = objectInput.readLong();
        userId = objectInput.readLong();
        actChecklistId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(actClCollabId);

        if (actCollabType == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(actCollabType);
        }

        objectOutput.writeLong(actPrManagerId);
        objectOutput.writeLong(userId);
        objectOutput.writeLong(actChecklistId);
    }
}
