package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ActCategory;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing ActCategory in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ActCategory
 * @generated
 */
public class ActCategoryCacheModel implements CacheModel<ActCategory>,
    Externalizable {
    public String uuid;
    public long ActCategoryId;
    public long ActiveCheckListID;
    public String CategoryName;
    public long SubCatogryId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(11);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", ActCategoryId=");
        sb.append(ActCategoryId);
        sb.append(", ActiveCheckListID=");
        sb.append(ActiveCheckListID);
        sb.append(", CategoryName=");
        sb.append(CategoryName);
        sb.append(", SubCatogryId=");
        sb.append(SubCatogryId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ActCategory toEntityModel() {
        ActCategoryImpl actCategoryImpl = new ActCategoryImpl();

        if (uuid == null) {
            actCategoryImpl.setUuid(StringPool.BLANK);
        } else {
            actCategoryImpl.setUuid(uuid);
        }

        actCategoryImpl.setActCategoryId(ActCategoryId);
        actCategoryImpl.setActiveCheckListID(ActiveCheckListID);

        if (CategoryName == null) {
            actCategoryImpl.setCategoryName(StringPool.BLANK);
        } else {
            actCategoryImpl.setCategoryName(CategoryName);
        }

        actCategoryImpl.setSubCatogryId(SubCatogryId);

        actCategoryImpl.resetOriginalValues();

        return actCategoryImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        ActCategoryId = objectInput.readLong();
        ActiveCheckListID = objectInput.readLong();
        CategoryName = objectInput.readUTF();
        SubCatogryId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(ActCategoryId);
        objectOutput.writeLong(ActiveCheckListID);

        if (CategoryName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(CategoryName);
        }

        objectOutput.writeLong(SubCatogryId);
    }
}
