package org.digitalArmour.verifier.model.impl;

/**
 * The extended model implementation for the ActCategory service. Represents a row in the &quot;Verifier_ActCategory&quot; database table, with each column mapped to a property of this class.
 *
 * <p>
 * Helper methods and all application logic should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.model.ActCategory} interface.
 * </p>
 *
 * @author Brian Wing Shun Chan
 */
public class ActCategoryImpl extends ActCategoryBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this class directly. All methods that expect a act category model instance should use the {@link org.digitalArmour.verifier.model.ActCategory} interface instead.
     */
    public ActCategoryImpl() {
    }
}
