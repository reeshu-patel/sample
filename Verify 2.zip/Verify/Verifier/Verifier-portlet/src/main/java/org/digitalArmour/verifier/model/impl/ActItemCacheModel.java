package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ActItem;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ActItem in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ActItem
 * @generated
 */
public class ActItemCacheModel implements CacheModel<ActItem>, Externalizable {
    public String uuid;
    public long ItemId;
    public String itemName;
    public String itemDesc;
    public boolean ignore;
    public boolean isMajor;
    public long percentage;
    public long completedDate;
    public boolean completed;
    public long ActivateClid;
    public long usergroupId;
    public boolean major;
    public long major_percent;
    public long catId;
    public long userId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(31);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", ItemId=");
        sb.append(ItemId);
        sb.append(", itemName=");
        sb.append(itemName);
        sb.append(", itemDesc=");
        sb.append(itemDesc);
        sb.append(", ignore=");
        sb.append(ignore);
        sb.append(", isMajor=");
        sb.append(isMajor);
        sb.append(", percentage=");
        sb.append(percentage);
        sb.append(", completedDate=");
        sb.append(completedDate);
        sb.append(", completed=");
        sb.append(completed);
        sb.append(", ActivateClid=");
        sb.append(ActivateClid);
        sb.append(", usergroupId=");
        sb.append(usergroupId);
        sb.append(", major=");
        sb.append(major);
        sb.append(", major_percent=");
        sb.append(major_percent);
        sb.append(", catId=");
        sb.append(catId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ActItem toEntityModel() {
        ActItemImpl actItemImpl = new ActItemImpl();

        if (uuid == null) {
            actItemImpl.setUuid(StringPool.BLANK);
        } else {
            actItemImpl.setUuid(uuid);
        }

        actItemImpl.setItemId(ItemId);

        if (itemName == null) {
            actItemImpl.setItemName(StringPool.BLANK);
        } else {
            actItemImpl.setItemName(itemName);
        }

        if (itemDesc == null) {
            actItemImpl.setItemDesc(StringPool.BLANK);
        } else {
            actItemImpl.setItemDesc(itemDesc);
        }

        actItemImpl.setIgnore(ignore);
        actItemImpl.setIsMajor(isMajor);
        actItemImpl.setPercentage(percentage);

        if (completedDate == Long.MIN_VALUE) {
            actItemImpl.setCompletedDate(null);
        } else {
            actItemImpl.setCompletedDate(new Date(completedDate));
        }

        actItemImpl.setCompleted(completed);
        actItemImpl.setActivateClid(ActivateClid);
        actItemImpl.setUsergroupId(usergroupId);
        actItemImpl.setMajor(major);
        actItemImpl.setMajor_percent(major_percent);
        actItemImpl.setCatId(catId);
        actItemImpl.setUserId(userId);

        actItemImpl.resetOriginalValues();

        return actItemImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        ItemId = objectInput.readLong();
        itemName = objectInput.readUTF();
        itemDesc = objectInput.readUTF();
        ignore = objectInput.readBoolean();
        isMajor = objectInput.readBoolean();
        percentage = objectInput.readLong();
        completedDate = objectInput.readLong();
        completed = objectInput.readBoolean();
        ActivateClid = objectInput.readLong();
        usergroupId = objectInput.readLong();
        major = objectInput.readBoolean();
        major_percent = objectInput.readLong();
        catId = objectInput.readLong();
        userId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(ItemId);

        if (itemName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(itemName);
        }

        if (itemDesc == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(itemDesc);
        }

        objectOutput.writeBoolean(ignore);
        objectOutput.writeBoolean(isMajor);
        objectOutput.writeLong(percentage);
        objectOutput.writeLong(completedDate);
        objectOutput.writeBoolean(completed);
        objectOutput.writeLong(ActivateClid);
        objectOutput.writeLong(usergroupId);
        objectOutput.writeBoolean(major);
        objectOutput.writeLong(major_percent);
        objectOutput.writeLong(catId);
        objectOutput.writeLong(userId);
    }
}
