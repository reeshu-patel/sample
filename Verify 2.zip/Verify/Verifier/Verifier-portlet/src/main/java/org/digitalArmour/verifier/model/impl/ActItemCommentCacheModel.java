package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ActItemComment;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ActItemComment in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ActItemComment
 * @generated
 */
public class ActItemCommentCacheModel implements CacheModel<ActItemComment>,
    Externalizable {
    public String uuid;
    public long actCommId;
    public String comment;
    public long createTime;
    public long itemId;
    public long userId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", actCommId=");
        sb.append(actCommId);
        sb.append(", comment=");
        sb.append(comment);
        sb.append(", createTime=");
        sb.append(createTime);
        sb.append(", itemId=");
        sb.append(itemId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ActItemComment toEntityModel() {
        ActItemCommentImpl actItemCommentImpl = new ActItemCommentImpl();

        if (uuid == null) {
            actItemCommentImpl.setUuid(StringPool.BLANK);
        } else {
            actItemCommentImpl.setUuid(uuid);
        }

        actItemCommentImpl.setActCommId(actCommId);

        if (comment == null) {
            actItemCommentImpl.setComment(StringPool.BLANK);
        } else {
            actItemCommentImpl.setComment(comment);
        }

        if (createTime == Long.MIN_VALUE) {
            actItemCommentImpl.setCreateTime(null);
        } else {
            actItemCommentImpl.setCreateTime(new Date(createTime));
        }

        actItemCommentImpl.setItemId(itemId);
        actItemCommentImpl.setUserId(userId);

        actItemCommentImpl.resetOriginalValues();

        return actItemCommentImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        actCommId = objectInput.readLong();
        comment = objectInput.readUTF();
        createTime = objectInput.readLong();
        itemId = objectInput.readLong();
        userId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(actCommId);

        if (comment == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(comment);
        }

        objectOutput.writeLong(createTime);
        objectOutput.writeLong(itemId);
        objectOutput.writeLong(userId);
    }
}
