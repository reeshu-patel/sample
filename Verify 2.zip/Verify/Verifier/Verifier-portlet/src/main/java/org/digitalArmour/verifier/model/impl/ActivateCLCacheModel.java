package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ActivateCL;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ActivateCL in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCL
 * @generated
 */
public class ActivateCLCacheModel implements CacheModel<ActivateCL>,
    Externalizable {
    public String uuid;
    public long activateId;
    public long checklistId;
    public String clName;
    public String clDescription;
    public String organiztion;
    public boolean isPublic;
    public boolean isCompleted;
    public long completedDate;
    public long actClUserId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(21);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", activateId=");
        sb.append(activateId);
        sb.append(", checklistId=");
        sb.append(checklistId);
        sb.append(", clName=");
        sb.append(clName);
        sb.append(", clDescription=");
        sb.append(clDescription);
        sb.append(", organiztion=");
        sb.append(organiztion);
        sb.append(", isPublic=");
        sb.append(isPublic);
        sb.append(", isCompleted=");
        sb.append(isCompleted);
        sb.append(", completedDate=");
        sb.append(completedDate);
        sb.append(", actClUserId=");
        sb.append(actClUserId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ActivateCL toEntityModel() {
        ActivateCLImpl activateCLImpl = new ActivateCLImpl();

        if (uuid == null) {
            activateCLImpl.setUuid(StringPool.BLANK);
        } else {
            activateCLImpl.setUuid(uuid);
        }

        activateCLImpl.setActivateId(activateId);
        activateCLImpl.setChecklistId(checklistId);

        if (clName == null) {
            activateCLImpl.setClName(StringPool.BLANK);
        } else {
            activateCLImpl.setClName(clName);
        }

        if (clDescription == null) {
            activateCLImpl.setClDescription(StringPool.BLANK);
        } else {
            activateCLImpl.setClDescription(clDescription);
        }

        if (organiztion == null) {
            activateCLImpl.setOrganiztion(StringPool.BLANK);
        } else {
            activateCLImpl.setOrganiztion(organiztion);
        }

        activateCLImpl.setIsPublic(isPublic);
        activateCLImpl.setIsCompleted(isCompleted);

        if (completedDate == Long.MIN_VALUE) {
            activateCLImpl.setCompletedDate(null);
        } else {
            activateCLImpl.setCompletedDate(new Date(completedDate));
        }

        activateCLImpl.setActClUserId(actClUserId);

        activateCLImpl.resetOriginalValues();

        return activateCLImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        activateId = objectInput.readLong();
        checklistId = objectInput.readLong();
        clName = objectInput.readUTF();
        clDescription = objectInput.readUTF();
        organiztion = objectInput.readUTF();
        isPublic = objectInput.readBoolean();
        isCompleted = objectInput.readBoolean();
        completedDate = objectInput.readLong();
        actClUserId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(activateId);
        objectOutput.writeLong(checklistId);

        if (clName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(clName);
        }

        if (clDescription == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(clDescription);
        }

        if (organiztion == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(organiztion);
        }

        objectOutput.writeBoolean(isPublic);
        objectOutput.writeBoolean(isCompleted);
        objectOutput.writeLong(completedDate);
        objectOutput.writeLong(actClUserId);
    }
}
