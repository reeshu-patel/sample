package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.CLCollab;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing CLCollab in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see CLCollab
 * @generated
 */
public class CLCollabCacheModel implements CacheModel<CLCollab>, Externalizable {
    public String uuid;
    public long clCollabId;
    public String collabType;
    public long prManagerId;
    public long userId;
    public long checklistId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", clCollabId=");
        sb.append(clCollabId);
        sb.append(", collabType=");
        sb.append(collabType);
        sb.append(", prManagerId=");
        sb.append(prManagerId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append(", checklistId=");
        sb.append(checklistId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public CLCollab toEntityModel() {
        CLCollabImpl clCollabImpl = new CLCollabImpl();

        if (uuid == null) {
            clCollabImpl.setUuid(StringPool.BLANK);
        } else {
            clCollabImpl.setUuid(uuid);
        }

        clCollabImpl.setClCollabId(clCollabId);

        if (collabType == null) {
            clCollabImpl.setCollabType(StringPool.BLANK);
        } else {
            clCollabImpl.setCollabType(collabType);
        }

        clCollabImpl.setPrManagerId(prManagerId);
        clCollabImpl.setUserId(userId);
        clCollabImpl.setChecklistId(checklistId);

        clCollabImpl.resetOriginalValues();

        return clCollabImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        clCollabId = objectInput.readLong();
        collabType = objectInput.readUTF();
        prManagerId = objectInput.readLong();
        userId = objectInput.readLong();
        checklistId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(clCollabId);

        if (collabType == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(collabType);
        }

        objectOutput.writeLong(prManagerId);
        objectOutput.writeLong(userId);
        objectOutput.writeLong(checklistId);
    }
}
