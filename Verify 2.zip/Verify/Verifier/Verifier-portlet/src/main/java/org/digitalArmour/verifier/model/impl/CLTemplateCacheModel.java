package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.CLTemplate;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing CLTemplate in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplate
 * @generated
 */
public class CLTemplateCacheModel implements CacheModel<CLTemplate>,
    Externalizable {
    public String uuid;
    public long checklistId;
    public String clName;
    public String clDescription;
    public String clOrganiztion;
    public long clUserId;
    public boolean isPublic;
    public boolean isPubliccat;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(17);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", checklistId=");
        sb.append(checklistId);
        sb.append(", clName=");
        sb.append(clName);
        sb.append(", clDescription=");
        sb.append(clDescription);
        sb.append(", clOrganiztion=");
        sb.append(clOrganiztion);
        sb.append(", clUserId=");
        sb.append(clUserId);
        sb.append(", isPublic=");
        sb.append(isPublic);
        sb.append(", isPubliccat=");
        sb.append(isPubliccat);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public CLTemplate toEntityModel() {
        CLTemplateImpl clTemplateImpl = new CLTemplateImpl();

        if (uuid == null) {
            clTemplateImpl.setUuid(StringPool.BLANK);
        } else {
            clTemplateImpl.setUuid(uuid);
        }

        clTemplateImpl.setChecklistId(checklistId);

        if (clName == null) {
            clTemplateImpl.setClName(StringPool.BLANK);
        } else {
            clTemplateImpl.setClName(clName);
        }

        if (clDescription == null) {
            clTemplateImpl.setClDescription(StringPool.BLANK);
        } else {
            clTemplateImpl.setClDescription(clDescription);
        }

        if (clOrganiztion == null) {
            clTemplateImpl.setClOrganiztion(StringPool.BLANK);
        } else {
            clTemplateImpl.setClOrganiztion(clOrganiztion);
        }

        clTemplateImpl.setClUserId(clUserId);
        clTemplateImpl.setIsPublic(isPublic);
        clTemplateImpl.setIsPubliccat(isPubliccat);

        clTemplateImpl.resetOriginalValues();

        return clTemplateImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        checklistId = objectInput.readLong();
        clName = objectInput.readUTF();
        clDescription = objectInput.readUTF();
        clOrganiztion = objectInput.readUTF();
        clUserId = objectInput.readLong();
        isPublic = objectInput.readBoolean();
        isPubliccat = objectInput.readBoolean();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(checklistId);

        if (clName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(clName);
        }

        if (clDescription == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(clDescription);
        }

        if (clOrganiztion == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(clOrganiztion);
        }

        objectOutput.writeLong(clUserId);
        objectOutput.writeBoolean(isPublic);
        objectOutput.writeBoolean(isPubliccat);
    }
}
