package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.Category;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Category in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see Category
 * @generated
 */
public class CategoryCacheModel implements CacheModel<Category>, Externalizable {
    public String uuid;
    public long catId;
    public String catName;
    public long subcategoryId;
    public long checklistId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(11);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", catId=");
        sb.append(catId);
        sb.append(", catName=");
        sb.append(catName);
        sb.append(", subcategoryId=");
        sb.append(subcategoryId);
        sb.append(", checklistId=");
        sb.append(checklistId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Category toEntityModel() {
        CategoryImpl categoryImpl = new CategoryImpl();

        if (uuid == null) {
            categoryImpl.setUuid(StringPool.BLANK);
        } else {
            categoryImpl.setUuid(uuid);
        }

        categoryImpl.setCatId(catId);

        if (catName == null) {
            categoryImpl.setCatName(StringPool.BLANK);
        } else {
            categoryImpl.setCatName(catName);
        }

        categoryImpl.setSubcategoryId(subcategoryId);
        categoryImpl.setChecklistId(checklistId);

        categoryImpl.resetOriginalValues();

        return categoryImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        catId = objectInput.readLong();
        catName = objectInput.readUTF();
        subcategoryId = objectInput.readLong();
        checklistId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(catId);

        if (catName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(catName);
        }

        objectOutput.writeLong(subcategoryId);
        objectOutput.writeLong(checklistId);
    }
}
