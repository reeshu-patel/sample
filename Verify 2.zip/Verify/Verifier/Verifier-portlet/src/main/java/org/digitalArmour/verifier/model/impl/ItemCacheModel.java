package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.Item;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Item in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see Item
 * @generated
 */
public class ItemCacheModel implements CacheModel<Item>, Externalizable {
    public String uuid;
    public long itemId;
    public String itemName;
    public String itemDesc;
    public boolean minor;
    public long minor_percent;
    public boolean major;
    public long major_percent;
    public long userGroupId;
    public long catId;
    public long checklistId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(23);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", itemId=");
        sb.append(itemId);
        sb.append(", itemName=");
        sb.append(itemName);
        sb.append(", itemDesc=");
        sb.append(itemDesc);
        sb.append(", minor=");
        sb.append(minor);
        sb.append(", minor_percent=");
        sb.append(minor_percent);
        sb.append(", major=");
        sb.append(major);
        sb.append(", major_percent=");
        sb.append(major_percent);
        sb.append(", userGroupId=");
        sb.append(userGroupId);
        sb.append(", catId=");
        sb.append(catId);
        sb.append(", checklistId=");
        sb.append(checklistId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Item toEntityModel() {
        ItemImpl itemImpl = new ItemImpl();

        if (uuid == null) {
            itemImpl.setUuid(StringPool.BLANK);
        } else {
            itemImpl.setUuid(uuid);
        }

        itemImpl.setItemId(itemId);

        if (itemName == null) {
            itemImpl.setItemName(StringPool.BLANK);
        } else {
            itemImpl.setItemName(itemName);
        }

        if (itemDesc == null) {
            itemImpl.setItemDesc(StringPool.BLANK);
        } else {
            itemImpl.setItemDesc(itemDesc);
        }

        itemImpl.setMinor(minor);
        itemImpl.setMinor_percent(minor_percent);
        itemImpl.setMajor(major);
        itemImpl.setMajor_percent(major_percent);
        itemImpl.setUserGroupId(userGroupId);
        itemImpl.setCatId(catId);
        itemImpl.setChecklistId(checklistId);

        itemImpl.resetOriginalValues();

        return itemImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        itemId = objectInput.readLong();
        itemName = objectInput.readUTF();
        itemDesc = objectInput.readUTF();
        minor = objectInput.readBoolean();
        minor_percent = objectInput.readLong();
        major = objectInput.readBoolean();
        major_percent = objectInput.readLong();
        userGroupId = objectInput.readLong();
        catId = objectInput.readLong();
        checklistId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(itemId);

        if (itemName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(itemName);
        }

        if (itemDesc == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(itemDesc);
        }

        objectOutput.writeBoolean(minor);
        objectOutput.writeLong(minor_percent);
        objectOutput.writeBoolean(major);
        objectOutput.writeLong(major_percent);
        objectOutput.writeLong(userGroupId);
        objectOutput.writeLong(catId);
        objectOutput.writeLong(checklistId);
    }
}
