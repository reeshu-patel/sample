package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ItemComment;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ItemComment in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ItemComment
 * @generated
 */
public class ItemCommentCacheModel implements CacheModel<ItemComment>,
    Externalizable {
    public String uuid;
    public long commId;
    public String comment;
    public long createTime;
    public long itemId;
    public long userId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", commId=");
        sb.append(commId);
        sb.append(", comment=");
        sb.append(comment);
        sb.append(", createTime=");
        sb.append(createTime);
        sb.append(", itemId=");
        sb.append(itemId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ItemComment toEntityModel() {
        ItemCommentImpl itemCommentImpl = new ItemCommentImpl();

        if (uuid == null) {
            itemCommentImpl.setUuid(StringPool.BLANK);
        } else {
            itemCommentImpl.setUuid(uuid);
        }

        itemCommentImpl.setCommId(commId);

        if (comment == null) {
            itemCommentImpl.setComment(StringPool.BLANK);
        } else {
            itemCommentImpl.setComment(comment);
        }

        if (createTime == Long.MIN_VALUE) {
            itemCommentImpl.setCreateTime(null);
        } else {
            itemCommentImpl.setCreateTime(new Date(createTime));
        }

        itemCommentImpl.setItemId(itemId);
        itemCommentImpl.setUserId(userId);

        itemCommentImpl.resetOriginalValues();

        return itemCommentImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        commId = objectInput.readLong();
        comment = objectInput.readUTF();
        createTime = objectInput.readLong();
        itemId = objectInput.readLong();
        userId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(commId);

        if (comment == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(comment);
        }

        objectOutput.writeLong(createTime);
        objectOutput.writeLong(itemId);
        objectOutput.writeLong(userId);
    }
}
