package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ItemFile;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ItemFile in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ItemFile
 * @generated
 */
public class ItemFileCacheModel implements CacheModel<ItemFile>, Externalizable {
    public String uuid;
    public long fileId;
    public String fileName;
    public String filePath;
    public long createTime;
    public long itemId;
    public long userId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(15);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", fileId=");
        sb.append(fileId);
        sb.append(", fileName=");
        sb.append(fileName);
        sb.append(", filePath=");
        sb.append(filePath);
        sb.append(", createTime=");
        sb.append(createTime);
        sb.append(", itemId=");
        sb.append(itemId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ItemFile toEntityModel() {
        ItemFileImpl itemFileImpl = new ItemFileImpl();

        if (uuid == null) {
            itemFileImpl.setUuid(StringPool.BLANK);
        } else {
            itemFileImpl.setUuid(uuid);
        }

        itemFileImpl.setFileId(fileId);

        if (fileName == null) {
            itemFileImpl.setFileName(StringPool.BLANK);
        } else {
            itemFileImpl.setFileName(fileName);
        }

        if (filePath == null) {
            itemFileImpl.setFilePath(StringPool.BLANK);
        } else {
            itemFileImpl.setFilePath(filePath);
        }

        if (createTime == Long.MIN_VALUE) {
            itemFileImpl.setCreateTime(null);
        } else {
            itemFileImpl.setCreateTime(new Date(createTime));
        }

        itemFileImpl.setItemId(itemId);
        itemFileImpl.setUserId(userId);

        itemFileImpl.resetOriginalValues();

        return itemFileImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        fileId = objectInput.readLong();
        fileName = objectInput.readUTF();
        filePath = objectInput.readUTF();
        createTime = objectInput.readLong();
        itemId = objectInput.readLong();
        userId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(fileId);

        if (fileName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(fileName);
        }

        if (filePath == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(filePath);
        }

        objectOutput.writeLong(createTime);
        objectOutput.writeLong(itemId);
        objectOutput.writeLong(userId);
    }
}
