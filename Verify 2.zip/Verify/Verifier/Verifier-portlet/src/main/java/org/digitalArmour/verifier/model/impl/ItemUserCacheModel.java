package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.ItemUser;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ItemUser in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see ItemUser
 * @generated
 */
public class ItemUserCacheModel implements CacheModel<ItemUser>, Externalizable {
    public String uuid;
    public long itemUserId;
    public long createDate;
    public long dueDate;
    public long itemId;
    public long userId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(13);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", itemUserId=");
        sb.append(itemUserId);
        sb.append(", createDate=");
        sb.append(createDate);
        sb.append(", dueDate=");
        sb.append(dueDate);
        sb.append(", itemId=");
        sb.append(itemId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public ItemUser toEntityModel() {
        ItemUserImpl itemUserImpl = new ItemUserImpl();

        if (uuid == null) {
            itemUserImpl.setUuid(StringPool.BLANK);
        } else {
            itemUserImpl.setUuid(uuid);
        }

        itemUserImpl.setItemUserId(itemUserId);

        if (createDate == Long.MIN_VALUE) {
            itemUserImpl.setCreateDate(null);
        } else {
            itemUserImpl.setCreateDate(new Date(createDate));
        }

        if (dueDate == Long.MIN_VALUE) {
            itemUserImpl.setDueDate(null);
        } else {
            itemUserImpl.setDueDate(new Date(dueDate));
        }

        itemUserImpl.setItemId(itemId);
        itemUserImpl.setUserId(userId);

        itemUserImpl.resetOriginalValues();

        return itemUserImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        itemUserId = objectInput.readLong();
        createDate = objectInput.readLong();
        dueDate = objectInput.readLong();
        itemId = objectInput.readLong();
        userId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(itemUserId);
        objectOutput.writeLong(createDate);
        objectOutput.writeLong(dueDate);
        objectOutput.writeLong(itemId);
        objectOutput.writeLong(userId);
    }
}
