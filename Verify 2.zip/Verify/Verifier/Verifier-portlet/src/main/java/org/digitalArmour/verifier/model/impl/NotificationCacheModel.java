package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.Notification;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Notification in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see Notification
 * @generated
 */
public class NotificationCacheModel implements CacheModel<Notification>,
    Externalizable {
    public String uuid;
    public long noteId;
    public String noteName;
    public boolean isMail;
    public boolean isNewsFeed;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(11);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", noteId=");
        sb.append(noteId);
        sb.append(", noteName=");
        sb.append(noteName);
        sb.append(", isMail=");
        sb.append(isMail);
        sb.append(", isNewsFeed=");
        sb.append(isNewsFeed);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Notification toEntityModel() {
        NotificationImpl notificationImpl = new NotificationImpl();

        if (uuid == null) {
            notificationImpl.setUuid(StringPool.BLANK);
        } else {
            notificationImpl.setUuid(uuid);
        }

        notificationImpl.setNoteId(noteId);

        if (noteName == null) {
            notificationImpl.setNoteName(StringPool.BLANK);
        } else {
            notificationImpl.setNoteName(noteName);
        }

        notificationImpl.setIsMail(isMail);
        notificationImpl.setIsNewsFeed(isNewsFeed);

        notificationImpl.resetOriginalValues();

        return notificationImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        noteId = objectInput.readLong();
        noteName = objectInput.readUTF();
        isMail = objectInput.readBoolean();
        isNewsFeed = objectInput.readBoolean();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(noteId);

        if (noteName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(noteName);
        }

        objectOutput.writeBoolean(isMail);
        objectOutput.writeBoolean(isNewsFeed);
    }
}
