package org.digitalArmour.verifier.model.impl;

/**
 * The extended model implementation for the Notification service. Represents a row in the &quot;Verifier_Notification&quot; database table, with each column mapped to a property of this class.
 *
 * <p>
 * Helper methods and all application logic should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.model.Notification} interface.
 * </p>
 *
 * @author Brian Wing Shun Chan
 */
public class NotificationImpl extends NotificationBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this class directly. All methods that expect a notification model instance should use the {@link org.digitalArmour.verifier.model.Notification} interface instead.
     */
    public NotificationImpl() {
    }
}
