package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.Organization;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Organization in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see Organization
 * @generated
 */
public class OrganizationCacheModel implements CacheModel<Organization>,
    Externalizable {
    public String uuid;
    public long orgId;
    public String orgName;
    public boolean type;
    public long userId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(11);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", orgId=");
        sb.append(orgId);
        sb.append(", orgName=");
        sb.append(orgName);
        sb.append(", type=");
        sb.append(type);
        sb.append(", userId=");
        sb.append(userId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Organization toEntityModel() {
        OrganizationImpl organizationImpl = new OrganizationImpl();

        if (uuid == null) {
            organizationImpl.setUuid(StringPool.BLANK);
        } else {
            organizationImpl.setUuid(uuid);
        }

        organizationImpl.setOrgId(orgId);

        if (orgName == null) {
            organizationImpl.setOrgName(StringPool.BLANK);
        } else {
            organizationImpl.setOrgName(orgName);
        }

        organizationImpl.setType(type);
        organizationImpl.setUserId(userId);

        organizationImpl.resetOriginalValues();

        return organizationImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        orgId = objectInput.readLong();
        orgName = objectInput.readUTF();
        type = objectInput.readBoolean();
        userId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(orgId);

        if (orgName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(orgName);
        }

        objectOutput.writeBoolean(type);
        objectOutput.writeLong(userId);
    }
}
