package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.Subcategory;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Subcategory in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see Subcategory
 * @generated
 */
public class SubcategoryCacheModel implements CacheModel<Subcategory>,
    Externalizable {
    public String uuid;
    public long subcatId;
    public String subcatName;
    public long catId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(9);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", subcatId=");
        sb.append(subcatId);
        sb.append(", subcatName=");
        sb.append(subcatName);
        sb.append(", catId=");
        sb.append(catId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Subcategory toEntityModel() {
        SubcategoryImpl subcategoryImpl = new SubcategoryImpl();

        if (uuid == null) {
            subcategoryImpl.setUuid(StringPool.BLANK);
        } else {
            subcategoryImpl.setUuid(uuid);
        }

        subcategoryImpl.setSubcatId(subcatId);

        if (subcatName == null) {
            subcategoryImpl.setSubcatName(StringPool.BLANK);
        } else {
            subcategoryImpl.setSubcatName(subcatName);
        }

        subcategoryImpl.setCatId(catId);

        subcategoryImpl.resetOriginalValues();

        return subcategoryImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        subcatId = objectInput.readLong();
        subcatName = objectInput.readUTF();
        catId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(subcatId);

        if (subcatName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(subcatName);
        }

        objectOutput.writeLong(catId);
    }
}
