package org.digitalArmour.verifier.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import org.digitalArmour.verifier.model.tag;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing tag in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see tag
 * @generated
 */
public class tagCacheModel implements CacheModel<tag>, Externalizable {
    public long Id;
    public long checklistId;
    public String tagName;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(7);

        sb.append("{Id=");
        sb.append(Id);
        sb.append(", checklistId=");
        sb.append(checklistId);
        sb.append(", tagName=");
        sb.append(tagName);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public tag toEntityModel() {
        tagImpl tagImpl = new tagImpl();

        tagImpl.setId(Id);
        tagImpl.setChecklistId(checklistId);

        if (tagName == null) {
            tagImpl.setTagName(StringPool.BLANK);
        } else {
            tagImpl.setTagName(tagName);
        }

        tagImpl.resetOriginalValues();

        return tagImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        Id = objectInput.readLong();
        checklistId = objectInput.readLong();
        tagName = objectInput.readUTF();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        objectOutput.writeLong(Id);
        objectOutput.writeLong(checklistId);

        if (tagName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(tagName);
        }
    }
}
