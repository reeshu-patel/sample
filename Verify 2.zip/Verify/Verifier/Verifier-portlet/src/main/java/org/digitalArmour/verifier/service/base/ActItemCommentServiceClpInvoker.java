package org.digitalArmour.verifier.service.base;

import org.digitalArmour.verifier.service.ActItemCommentServiceUtil;

import java.util.Arrays;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ActItemCommentServiceClpInvoker {
    private String _methodName126;
    private String[] _methodParameterTypes126;
    private String _methodName127;
    private String[] _methodParameterTypes127;
    private String _methodName132;
    private String[] _methodParameterTypes132;
    private String _methodName133;
    private String[] _methodParameterTypes133;
    private String _methodName134;
    private String[] _methodParameterTypes134;
    private String _methodName135;
    private String[] _methodParameterTypes135;
    private String _methodName136;
    private String[] _methodParameterTypes136;

    public ActItemCommentServiceClpInvoker() {
        _methodName126 = "getBeanIdentifier";

        _methodParameterTypes126 = new String[] {  };

        _methodName127 = "setBeanIdentifier";

        _methodParameterTypes127 = new String[] { "java.lang.String" };

        _methodName132 = "AddActTaskComment";

        _methodParameterTypes132 = new String[] {
                "long", "java.lang.String", "long"
            };

        _methodName133 = "updateActTaskComment";

        _methodParameterTypes133 = new String[] { "long", "java.lang.String" };

        _methodName134 = "DeleteActTaskComment";

        _methodParameterTypes134 = new String[] { "long" };

        _methodName135 = "getAllComments";

        _methodParameterTypes135 = new String[] { "long" };

        _methodName136 = "searchbyItemId";

        _methodParameterTypes136 = new String[] { "long" };
    }

    public Object invokeMethod(String name, String[] parameterTypes,
        Object[] arguments) throws Throwable {
        if (_methodName126.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes126, parameterTypes)) {
            return ActItemCommentServiceUtil.getBeanIdentifier();
        }

        if (_methodName127.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes127, parameterTypes)) {
            ActItemCommentServiceUtil.setBeanIdentifier((java.lang.String) arguments[0]);

            return null;
        }

        if (_methodName132.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes132, parameterTypes)) {
            return ActItemCommentServiceUtil.AddActTaskComment(((Long) arguments[0]).longValue(),
                (java.lang.String) arguments[1],
                ((Long) arguments[2]).longValue());
        }

        if (_methodName133.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes133, parameterTypes)) {
            return ActItemCommentServiceUtil.updateActTaskComment(((Long) arguments[0]).longValue(),
                (java.lang.String) arguments[1]);
        }

        if (_methodName134.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes134, parameterTypes)) {
            return ActItemCommentServiceUtil.DeleteActTaskComment(((Long) arguments[0]).longValue());
        }

        if (_methodName135.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes135, parameterTypes)) {
            return ActItemCommentServiceUtil.getAllComments(((Long) arguments[0]).longValue());
        }

        if (_methodName136.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes136, parameterTypes)) {
            return ActItemCommentServiceUtil.searchbyItemId(((Long) arguments[0]).longValue());
        }

        throw new UnsupportedOperationException();
    }
}
