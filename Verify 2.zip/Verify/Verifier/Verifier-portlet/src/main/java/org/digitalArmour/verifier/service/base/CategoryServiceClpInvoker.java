package org.digitalArmour.verifier.service.base;

import org.digitalArmour.verifier.service.CategoryServiceUtil;

import java.util.Arrays;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public class CategoryServiceClpInvoker {
    private String _methodName126;
    private String[] _methodParameterTypes126;
    private String _methodName127;
    private String[] _methodParameterTypes127;
    private String _methodName132;
    private String[] _methodParameterTypes132;
    private String _methodName133;
    private String[] _methodParameterTypes133;
    private String _methodName134;
    private String[] _methodParameterTypes134;
    private String _methodName135;
    private String[] _methodParameterTypes135;
    private String _methodName136;
    private String[] _methodParameterTypes136;
    private String _methodName137;
    private String[] _methodParameterTypes137;
    private String _methodName138;
    private String[] _methodParameterTypes138;
    private String _methodName139;
    private String[] _methodParameterTypes139;

    public CategoryServiceClpInvoker() {
        _methodName126 = "getBeanIdentifier";

        _methodParameterTypes126 = new String[] {  };

        _methodName127 = "setBeanIdentifier";

        _methodParameterTypes127 = new String[] { "java.lang.String" };

        _methodName132 = "AddCategory";

        _methodParameterTypes132 = new String[] { "java.lang.String", "long" };

        _methodName133 = "UpdateCategory";

        _methodParameterTypes133 = new String[] { "java.lang.String", "long" };

        _methodName134 = "DeleteCategory";

        _methodParameterTypes134 = new String[] { "long", "long" };

        _methodName135 = "getAllCategories";

        _methodParameterTypes135 = new String[] {  };

        _methodName136 = "getCatBysubcategoryId";

        _methodParameterTypes136 = new String[] { "java.lang.Long" };

        _methodName137 = "getCatByChecklistId";

        _methodParameterTypes137 = new String[] { "java.lang.Long" };

        _methodName138 = "getBySubClID";

        _methodParameterTypes138 = new String[] { "java.lang.Long", "long" };

        _methodName139 = "getBycatId";

        _methodParameterTypes139 = new String[] { "long" };
    }

    public Object invokeMethod(String name, String[] parameterTypes,
        Object[] arguments) throws Throwable {
        if (_methodName126.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes126, parameterTypes)) {
            return CategoryServiceUtil.getBeanIdentifier();
        }

        if (_methodName127.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes127, parameterTypes)) {
            CategoryServiceUtil.setBeanIdentifier((java.lang.String) arguments[0]);

            return null;
        }

        if (_methodName132.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes132, parameterTypes)) {
            return CategoryServiceUtil.AddCategory((java.lang.String) arguments[0],
                ((Long) arguments[1]).longValue());
        }

        if (_methodName133.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes133, parameterTypes)) {
            return CategoryServiceUtil.UpdateCategory((java.lang.String) arguments[0],
                ((Long) arguments[1]).longValue());
        }

        if (_methodName134.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes134, parameterTypes)) {
            return CategoryServiceUtil.DeleteCategory(((Long) arguments[0]).longValue(),
                ((Long) arguments[1]).longValue());
        }

        if (_methodName135.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes135, parameterTypes)) {
            return CategoryServiceUtil.getAllCategories();
        }

        if (_methodName136.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes136, parameterTypes)) {
            return CategoryServiceUtil.getCatBysubcategoryId((java.lang.Long) arguments[0]);
        }

        if (_methodName137.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes137, parameterTypes)) {
            return CategoryServiceUtil.getCatByChecklistId((java.lang.Long) arguments[0]);
        }

        if (_methodName138.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes138, parameterTypes)) {
            return CategoryServiceUtil.getBySubClID((java.lang.Long) arguments[0],
                ((Long) arguments[1]).longValue());
        }

        if (_methodName139.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes139, parameterTypes)) {
            return CategoryServiceUtil.getBycatId(((Long) arguments[0]).longValue());
        }

        throw new UnsupportedOperationException();
    }
}
