package org.digitalArmour.verifier.service.base;

import org.digitalArmour.verifier.service.ItemCommentServiceUtil;

import java.util.Arrays;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ItemCommentServiceClpInvoker {
    private String _methodName126;
    private String[] _methodParameterTypes126;
    private String _methodName127;
    private String[] _methodParameterTypes127;
    private String _methodName132;
    private String[] _methodParameterTypes132;
    private String _methodName133;
    private String[] _methodParameterTypes133;
    private String _methodName134;
    private String[] _methodParameterTypes134;
    private String _methodName135;
    private String[] _methodParameterTypes135;
    private String _methodName136;
    private String[] _methodParameterTypes136;

    public ItemCommentServiceClpInvoker() {
        _methodName126 = "getBeanIdentifier";

        _methodParameterTypes126 = new String[] {  };

        _methodName127 = "setBeanIdentifier";

        _methodParameterTypes127 = new String[] { "java.lang.String" };

        _methodName132 = "AddComment";

        _methodParameterTypes132 = new String[] {
                "long", "long", "java.lang.String"
            };

        _methodName133 = "UpdateComment";

        _methodParameterTypes133 = new String[] { "long", "java.lang.String" };

        _methodName134 = "DeleteComment";

        _methodParameterTypes134 = new String[] { "long" };

        _methodName135 = "getAllComments";

        _methodParameterTypes135 = new String[] { "long" };

        _methodName136 = "searchbyitemId";

        _methodParameterTypes136 = new String[] { "long" };
    }

    public Object invokeMethod(String name, String[] parameterTypes,
        Object[] arguments) throws Throwable {
        if (_methodName126.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes126, parameterTypes)) {
            return ItemCommentServiceUtil.getBeanIdentifier();
        }

        if (_methodName127.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes127, parameterTypes)) {
            ItemCommentServiceUtil.setBeanIdentifier((java.lang.String) arguments[0]);

            return null;
        }

        if (_methodName132.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes132, parameterTypes)) {
            return ItemCommentServiceUtil.AddComment(((Long) arguments[0]).longValue(),
                ((Long) arguments[1]).longValue(),
                (java.lang.String) arguments[2]);
        }

        if (_methodName133.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes133, parameterTypes)) {
            return ItemCommentServiceUtil.UpdateComment(((Long) arguments[0]).longValue(),
                (java.lang.String) arguments[1]);
        }

        if (_methodName134.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes134, parameterTypes)) {
            return ItemCommentServiceUtil.DeleteComment(((Long) arguments[0]).longValue());
        }

        if (_methodName135.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes135, parameterTypes)) {
            return ItemCommentServiceUtil.getAllComments(((Long) arguments[0]).longValue());
        }

        if (_methodName136.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes136, parameterTypes)) {
            return ItemCommentServiceUtil.searchbyitemId(((Long) arguments[0]).longValue());
        }

        throw new UnsupportedOperationException();
    }
}
