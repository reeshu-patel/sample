package org.digitalArmour.verifier.service.base;

import org.digitalArmour.verifier.service.ItemUserServiceUtil;

import java.util.Arrays;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ItemUserServiceClpInvoker {
    private String _methodName126;
    private String[] _methodParameterTypes126;
    private String _methodName127;
    private String[] _methodParameterTypes127;

    public ItemUserServiceClpInvoker() {
        _methodName126 = "getBeanIdentifier";

        _methodParameterTypes126 = new String[] {  };

        _methodName127 = "setBeanIdentifier";

        _methodParameterTypes127 = new String[] { "java.lang.String" };
    }

    public Object invokeMethod(String name, String[] parameterTypes,
        Object[] arguments) throws Throwable {
        if (_methodName126.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes126, parameterTypes)) {
            return ItemUserServiceUtil.getBeanIdentifier();
        }

        if (_methodName127.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes127, parameterTypes)) {
            ItemUserServiceUtil.setBeanIdentifier((java.lang.String) arguments[0]);

            return null;
        }

        throw new UnsupportedOperationException();
    }
}
