package org.digitalArmour.verifier.service.base;

import org.digitalArmour.verifier.service.tagServiceUtil;

import java.util.Arrays;

/**
 * @author Brian Wing Shun Chan
 * @generated
 */
public class tagServiceClpInvoker {
    private String _methodName114;
    private String[] _methodParameterTypes114;
    private String _methodName115;
    private String[] _methodParameterTypes115;
    private String _methodName120;
    private String[] _methodParameterTypes120;
    private String _methodName121;
    private String[] _methodParameterTypes121;
    private String _methodName122;
    private String[] _methodParameterTypes122;

    public tagServiceClpInvoker() {
        _methodName114 = "getBeanIdentifier";

        _methodParameterTypes114 = new String[] {  };

        _methodName115 = "setBeanIdentifier";

        _methodParameterTypes115 = new String[] { "java.lang.String" };

        _methodName120 = "AddTag";

        _methodParameterTypes120 = new String[] { "java.lang.String", "long" };

        _methodName121 = "DeleteTag";

        _methodParameterTypes121 = new String[] { "long" };

        _methodName122 = "searchbychecklistId";

        _methodParameterTypes122 = new String[] { "long" };
    }

    public Object invokeMethod(String name, String[] parameterTypes,
        Object[] arguments) throws Throwable {
        if (_methodName114.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes114, parameterTypes)) {
            return tagServiceUtil.getBeanIdentifier();
        }

        if (_methodName115.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes115, parameterTypes)) {
            tagServiceUtil.setBeanIdentifier((java.lang.String) arguments[0]);

            return null;
        }

        if (_methodName120.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes120, parameterTypes)) {
            return tagServiceUtil.AddTag((java.lang.String) arguments[0],
                ((Long) arguments[1]).longValue());
        }

        if (_methodName121.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes121, parameterTypes)) {
            return tagServiceUtil.DeleteTag(((Long) arguments[0]).longValue());
        }

        if (_methodName122.equals(name) &&
                Arrays.deepEquals(_methodParameterTypes122, parameterTypes)) {
            return tagServiceUtil.searchbychecklistId(((Long) arguments[0]).longValue());
        }

        throw new UnsupportedOperationException();
    }
}
