package org.digitalArmour.verifier.service.http;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import org.digitalArmour.verifier.service.CLTemplateServiceUtil;

import java.rmi.RemoteException;

/**
 * Provides the SOAP utility for the
 * {@link org.digitalArmour.verifier.service.CLTemplateServiceUtil} service utility. The
 * static methods of this class calls the same methods of the service utility.
 * However, the signatures are different because it is difficult for SOAP to
 * support certain types.
 *
 * <p>
 * ServiceBuilder follows certain rules in translating the methods. For example,
 * if the method in the service utility returns a {@link java.util.List}, that
 * is translated to an array of {@link org.digitalArmour.verifier.model.CLTemplateSoap}.
 * If the method in the service utility returns a
 * {@link org.digitalArmour.verifier.model.CLTemplate}, that is translated to a
 * {@link org.digitalArmour.verifier.model.CLTemplateSoap}. Methods that SOAP cannot
 * safely wire are skipped.
 * </p>
 *
 * <p>
 * The benefits of using the SOAP utility is that it is cross platform
 * compatible. SOAP allows different languages like Java, .NET, C++, PHP, and
 * even Perl, to call the generated services. One drawback of SOAP is that it is
 * slow because it needs to serialize all calls into a text format (XML).
 * </p>
 *
 * <p>
 * You can see a list of services at http://localhost:8080/api/axis. Set the
 * property <b>axis.servlet.hosts.allowed</b> in portal.properties to configure
 * security.
 * </p>
 *
 * <p>
 * The SOAP utility is only generated for remote services.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplateServiceHttp
 * @see org.digitalArmour.verifier.model.CLTemplateSoap
 * @see org.digitalArmour.verifier.service.CLTemplateServiceUtil
 * @generated
 */
public class CLTemplateServiceSoap {
    private static Log _log = LogFactoryUtil.getLog(CLTemplateServiceSoap.class);

    public static org.digitalArmour.verifier.model.CLTemplateSoap AddchecklistTemplate(
        long userId, java.lang.String ttile, java.lang.String description)
        throws RemoteException {
        try {
            org.digitalArmour.verifier.model.CLTemplate returnValue = CLTemplateServiceUtil.AddchecklistTemplate(userId,
                    ttile, description);

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModel(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }

    public static org.digitalArmour.verifier.model.CLTemplateSoap updateChecklistTemplate(
        long checkId, java.lang.String ttile, java.lang.String description)
        throws RemoteException {
        try {
            org.digitalArmour.verifier.model.CLTemplate returnValue = CLTemplateServiceUtil.updateChecklistTemplate(checkId,
                    ttile, description);

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModel(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }

    public static org.digitalArmour.verifier.model.CLTemplateSoap deletChecklistTemplate(
        long id1) throws RemoteException {
        try {
            org.digitalArmour.verifier.model.CLTemplate returnValue = CLTemplateServiceUtil.deletChecklistTemplate(id1);

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModel(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }

    public static org.digitalArmour.verifier.model.CLTemplateSoap[] searchbychecklistId(
        java.lang.String checklistId) throws RemoteException {
        try {
            java.util.List<org.digitalArmour.verifier.model.CLTemplate> returnValue =
                CLTemplateServiceUtil.searchbychecklistId(checklistId);

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModels(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }

    public static org.digitalArmour.verifier.model.CLTemplateSoap[] getallCLs()
        throws RemoteException {
        try {
            java.util.List<org.digitalArmour.verifier.model.CLTemplate> returnValue =
                CLTemplateServiceUtil.getallCLs();

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModels(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }

    public static org.digitalArmour.verifier.model.CLTemplateSoap[] getallUser(
        long id) throws RemoteException {
        try {
            java.util.List<org.digitalArmour.verifier.model.CLTemplate> returnValue =
                CLTemplateServiceUtil.getallUser(id);

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModels(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }

    public static org.digitalArmour.verifier.model.CLTemplateSoap[] searchbyisPublic(
        boolean isPublic) throws RemoteException {
        try {
            java.util.List<org.digitalArmour.verifier.model.CLTemplate> returnValue =
                CLTemplateServiceUtil.searchbyisPublic(isPublic);

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModels(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }

    public static org.digitalArmour.verifier.model.CLTemplateSoap[] searchbyisPubliccat(
        boolean isPubliccat) throws RemoteException {
        try {
            java.util.List<org.digitalArmour.verifier.model.CLTemplate> returnValue =
                CLTemplateServiceUtil.searchbyisPubliccat(isPubliccat);

            return org.digitalArmour.verifier.model.CLTemplateSoap.toSoapModels(returnValue);
        } catch (Exception e) {
            _log.error(e, e);

            throw new RemoteException(e.getMessage());
        }
    }
}
