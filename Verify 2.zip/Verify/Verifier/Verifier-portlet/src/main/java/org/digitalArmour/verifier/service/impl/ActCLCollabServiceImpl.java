package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActCLCollab;
import org.digitalArmour.verifier.model.ActivateCL;
import org.digitalArmour.verifier.model.impl.ActCLCollabImpl;
import org.digitalArmour.verifier.service.ActCLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ActCLCollabServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;

/**
 * The implementation of the act c l collab remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActCLCollabService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActCLCollabServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActCLCollabServiceUtil
 */
public class ActCLCollabServiceImpl extends ActCLCollabServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActCLCollabServiceUtil} to access the act c l collab remote service.
     */
	
	public ActCLCollab AddActClCollab(long checklistId,long userid,String collabtype) throws SystemException {
		
		 long collId=CounterLocalServiceUtil.increment();
		 ActCLCollab collab = new ActCLCollabImpl();
		 
		 collab.setActCollabType(collabtype);
		 collab.setUserId(userid);
		 collab.setActChecklistId(checklistId);
		 collab = ActCLCollabLocalServiceUtil.createActCLCollab(collId);
		 return ActCLCollabLocalServiceUtil.addActCLCollab(collab);

	}
	public ActCLCollab DeleteActClCollab(long collabId) throws SystemException, PortalException {
	
	ActCLCollab  t1 = ActCLCollabLocalServiceUtil.getActCLCollab(collabId);
		return ActCLCollabLocalServiceUtil.deleteActCLCollab(t1);
	}
	public List<ActCLCollab> getCollabByActiveCL(Long id) throws SystemException
	{
		List<ActCLCollab> cols = ActCLCollabLocalServiceUtil.getCollabByActiveCL(id);
		return cols;
	}
	
	public List<ActCLCollab> searchByuserId(long userId) throws SystemException
	{
		List<ActCLCollab> abcd = ActCLCollabLocalServiceUtil.searchByuserId(userId);
		return abcd;
	}
}
