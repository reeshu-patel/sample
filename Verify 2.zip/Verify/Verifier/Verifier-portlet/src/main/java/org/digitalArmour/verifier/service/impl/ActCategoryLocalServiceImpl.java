package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.service.base.ActCategoryLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the act category local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActCategoryLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActCategoryLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil
 */
public class ActCategoryLocalServiceImpl extends ActCategoryLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil} to access the act category local service.
     */
	public  List<ActCategory>  searchbyActiveClId(long ActiveClId) throws SystemException,PortalException
    	{
		List<ActCategory> catts = actCategoryPersistence.findByActiveClId(ActiveClId);
		return catts;
	}

	@Override
	public List<Item> searchbyActiveCatId(long ActiveCatId)
			throws PortalException, SystemException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	//FIND BY ACTIVECL AND ACTIVECATEGORY
	public List<ActCategory> getByActClSubID(long clid, long sid) throws SystemException
	{
		List<ActCategory> cats = actCategoryPersistence.findByActiveClSubId(clid, sid);
		return cats;
	}
	
	
}
