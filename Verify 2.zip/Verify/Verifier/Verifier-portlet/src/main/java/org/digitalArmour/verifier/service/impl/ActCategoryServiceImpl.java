package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.model.ActItem;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.impl.ActCategoryImpl;
import org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ActCategoryServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;

/**
 * The implementation of the act category remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActCategoryService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActCategoryServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActCategoryServiceUtil
 */
public class ActCategoryServiceImpl extends ActCategoryServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActCategoryServiceUtil} to access the act category remote service.
     */
	
	public ActCategory AddActivatecategory(String categotyName,long activeChecklistId) throws SystemException {
		
		long verifyId=CounterLocalServiceUtil.increment();
	 	 ActCategory ActCategory=null;
		 ActCategory = new ActCategoryImpl();
		 
	 	 ActCategory = ActCategoryLocalServiceUtil.createActCategory(verifyId);
	 		
	 	 ActCategory.setActiveCheckListID(activeChecklistId);
	 	 ActCategory.setCategoryName(categotyName);
	 	 ActCategory.setSubCatogryId(0);
	 		
	 	 	
	    return ActCategoryLocalServiceUtil.addActCategory(ActCategory);	
	 
	}
     public ActCategory updateActCategory(String categoryName,long catid) throws PortalException, SystemException {
		
		
		 ActCategory actCategory=ActCategoryLocalServiceUtil.getActCategory(catid);
		 actCategory.setCategoryName(categoryName);
	 	
		 return ActCategoryLocalServiceUtil.updateActCategory(actCategory);	
	}
    
    public ActCategory DeleteActCategory(long ActchecklistId,long catid) throws PortalException, SystemException {

    	    
			List<ActItem> actItemdel = ActItemLocalServiceUtil.searchbycatId(catid);
			List<ActCategory> subcat= ActCategoryLocalServiceUtil.getByActClSubID(ActchecklistId, catid);
			
			for(ActItem delItem: actItemdel)
			
			{
			ActItemLocalServiceUtil.deleteActItem(delItem);
			}
			
			for(ActCategory delsc: subcat)
			{
			ActCategoryLocalServiceUtil.deleteActCategory(delsc);
				//CategoryLocalServiceUtil.deleteCategory(delsc);
			List<ActItem> sitemdel=ActItemLocalServiceUtil.searchbycatId(delsc.getActCategoryId());
								//List<Item> sitemdel = ItemLocalServiceUtil.searchbycatId(delsc.getCatId());
			for(ActItem delItem: sitemdel)
			{
			ActItemLocalServiceUtil.deleteActItem(delItem);
									
			//	ItemLocalServiceUtil.deleteItem(delItem);
			}
			}
			return ActCategoryLocalServiceUtil.deleteActCategory(catid);
    	}
public ActCategory AddSubcategory(String subCategoryName,long categoryId,long activeChecklistId) throws SystemException {
		
		 long verifyId=CounterLocalServiceUtil.increment();
	 	 ActCategory ActCategory=null;
		 ActCategory = new ActCategoryImpl();
		 
	 	 ActCategory = ActCategoryLocalServiceUtil.createActCategory(verifyId);
	 		
	 	 ActCategory.setActiveCheckListID(activeChecklistId);
	 	 ActCategory.setCategoryName(subCategoryName);
	 	 ActCategory.setSubCatogryId(categoryId);
	 		
	 	 	
	    return ActCategoryLocalServiceUtil.addActCategory(ActCategory);	
	 
	}
public ActCategory UpdateSubcategory(String subCategoryName,long categoryId) throws SystemException, PortalException {
	
		ActCategory ecat = ActCategoryLocalServiceUtil.getActCategory(categoryId);
		
		ecat.setCategoryName(subCategoryName);
		ActCategoryLocalServiceUtil.updateActCategory(ecat);
		
	 	
   return ActCategoryLocalServiceUtil.updateActCategory(ecat);

}

public ActCategory DeleteSubcategory(long SubcategoryId) throws SystemException, PortalException {
	
	ActCategory s1 = ActCategoryLocalServiceUtil.getActCategory(SubcategoryId);
	List<ActItem> scitemdel = ActItemLocalServiceUtil.searchbycatId(s1.getActCategoryId());
	for (ActItem sbctgryitm : scitemdel)
	{
	ActItemLocalServiceUtil.deleteActItem(sbctgryitm);
	}
	ActCategoryLocalServiceUtil.deleteActCategory(s1);
	
 	
return ActCategoryLocalServiceUtil.deleteActCategory(s1);

}

public  List<ActCategory>  searchbyActiveClId(long ActiveClId) throws SystemException,PortalException
{
List<ActCategory> catts = ActCategoryLocalServiceUtil.searchbyActiveClId(ActiveClId);
return catts;
}



//FIND BY ACTIVECL AND ACTIVECATEGORY
public List<ActCategory> getByActClSubID(long clid, long sid) throws SystemException
{
List<ActCategory> cats = ActCategoryLocalServiceUtil.getByActClSubID(clid, sid);
return cats;
}


}
