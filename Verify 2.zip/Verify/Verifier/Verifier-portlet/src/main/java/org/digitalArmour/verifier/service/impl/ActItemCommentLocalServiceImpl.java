package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActItemComment;
import org.digitalArmour.verifier.model.ActItemFile;
import org.digitalArmour.verifier.service.base.ActItemCommentLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the act item comment local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActItemCommentLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActItemCommentLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActItemCommentLocalServiceUtil
 */
public class ActItemCommentLocalServiceImpl
    extends ActItemCommentLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActItemCommentLocalServiceUtil} to access the act item comment local service.
     */
	

	public List<ActItemComment> getAllComments(long itemId) throws SystemException
	{
	List<ActItemComment> items = actItemCommentPersistence.findByItemId(itemId);
	
	return items;
	}
	public  List<ActItemComment>  searchbyItemId(long ItemId) throws SystemException,PortalException
	{
	List<ActItemComment> catts = actItemCommentPersistence.findByItemId(ItemId);
	return catts;
}	
	
	
}
