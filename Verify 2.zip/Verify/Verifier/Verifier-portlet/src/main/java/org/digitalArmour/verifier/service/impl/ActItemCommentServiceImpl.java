package org.digitalArmour.verifier.service.impl;

import java.util.Date;
import java.util.List;

import org.digitalArmour.verifier.model.ActItemComment;
import org.digitalArmour.verifier.model.impl.ActItemCommentImpl;
import org.digitalArmour.verifier.service.ActItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ActItemCommentServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;


/**
 * The implementation of the act item comment remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActItemCommentService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActItemCommentServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActItemCommentServiceUtil
 */
public class ActItemCommentServiceImpl extends ActItemCommentServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActItemCommentServiceUtil} to access the act item comment remote service.
     */
	public ActItemComment AddActTaskComment(long taskId, String commentMassage,long userId) throws SystemException {
	
		
			ActItemComment comment=new ActItemCommentImpl();
			comment.setActCommId(Long.valueOf(CounterLocalServiceUtil.increment()));
			comment.setComment(commentMassage);
			comment.setCreateTime(new Date());
			/*System.out.println(ParamUtil.getLong(actionRequest, "itemid"));*/
			comment.setItemId(taskId);
			comment.setUserId(userId);
			return ActItemCommentLocalServiceUtil.addActItemComment(comment);
		
		
	}
	public ActItemComment updateActTaskComment(long commentId, String commentMassage) throws SystemException, PortalException {
		
		
		 
		 ActItemComment itemComm=ActItemCommentLocalServiceUtil.getActItemComment(commentId);
		 
		 itemComm.setComment(commentMassage);
		 return ActItemCommentLocalServiceUtil.updateActItemComment(itemComm);
	
}
	public ActItemComment DeleteActTaskComment(long commentId) throws SystemException, PortalException {
		
		ActItemComment actItemComment =ActItemCommentLocalServiceUtil.getActItemComment(commentId);
		 
		 
		 return ActItemCommentLocalServiceUtil.deleteActItemComment(actItemComment);
		
		
	
}
	public List<ActItemComment> getAllComments(long itemId) throws SystemException
	{
	List<ActItemComment> items = ActItemCommentLocalServiceUtil.getAllComments(itemId);
	
	return items;
	}
	public  List<ActItemComment>  searchbyItemId(long ItemId) throws SystemException,PortalException
	{
	List<ActItemComment> catts = ActItemCommentLocalServiceUtil.searchbyItemId(ItemId);
	return catts;
}	
	
}
