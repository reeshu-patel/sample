package org.digitalArmour.verifier.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;

import javax.portlet.PortletRequest;

import org.apache.commons.io.FileUtils;
import org.digitalArmour.verifier.model.ActItemFile;
import org.digitalArmour.verifier.model.impl.ActItemFileImpl;
import org.digitalArmour.verifier.service.ActItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ActItemFileServiceBaseImpl;
import org.springframework.web.multipart.MultipartFile;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.jsonwebservice.JSONWebService;
import com.liferay.portal.kernel.jsonwebservice.JSONWebServiceMode;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.util.PortalUtil;


/**
 * The implementation of the act item file remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActItemFileService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @param <MultipartFormDataInput>
 * @see org.digitalArmour.verifier.service.base.ActItemFileServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActItemFileServiceUtil
 */
public class ActItemFileServiceImpl extends ActItemFileServiceBaseImpl {

	/*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActItemFileServiceUtil} to access the act item file remote service.
     */
	
	@JSONWebService(method="Get")
    public ActItemFile AddTaskFile(long taskId ,String sourceFileName,long userId,String file) throws SystemException, IOException {

    	//UploadPortletRequest  ureq=PortalUtil.getUploadPortletRequest(arq);
		//File folderFile = new File(file.toString());
		// This is our final file path.
		File file2 = new File(file);
    	//System.out.println("call fuction");
		//File filePath = new File(file + File.separator + sourceFileName);
		File folder = new File("/tmp/upload");
		File filePath = new File(folder.getAbsolutePath() + File.separator + sourceFileName);
		FileUtils.copyFile(file2, filePath, true);
		
		//writeToFile(file, filePath);
		
		ActItemFile file1=new ActItemFileImpl();
		file1.setActItemFileId(Long.valueOf(CounterLocalServiceUtil.increment()));
		file1.setFileName(sourceFileName);
		file1.setFilePath(filePath.toString());
		
		file1.setCreateTime(new Date());
		
		file1.setItemId(taskId);
		file1.setUserId(userId);
		
		return ActItemFileLocalServiceUtil.addActItemFile(file1);
    	
	
	}
	
	private void writeToFile(String file, File filePath) {
		// TODO Auto-generated method stub
		
	}

	public ActItemFile DeleteFile(long fileId) throws PortalException, SystemException {
		 ActItemFile tr =ActItemFileLocalServiceUtil.getActItemFile(fileId);
		 return ActItemFileLocalServiceUtil.deleteActItemFile(tr);
		
	}
	
	
}
