package org.digitalArmour.verifier.service.impl;

import java.sql.Date;
import java.util.List;

import org.digitalArmour.verifier.model.ActItem;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.service.base.ActItemLocalServiceBaseImpl;
import org.digitalArmour.verifier.service.persistence.ActItemPersistence;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the act item local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActItemLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActItemLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActItemLocalServiceUtil
 */
public class ActItemLocalServiceImpl extends ActItemLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActItemLocalServiceUtil} to access the act item local service.
     */
	public  List<ActItem>  searchbycatId(long catId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActItem> catid1= actItemPersistence.findBycatId(catId);
return catid1;
    
    }
	public  List<ActItem>  searchbycompletedDate(Date completedDate) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActItem> complate_id= actItemPersistence.findBycompletedDate(completedDate);
return complate_id;
    
    }
	
	public  List<ActItem>  searchbyActivateClid(long ActivateClid) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActItem> complate_i= actItemPersistence.findByActivateClid(ActivateClid);
return complate_i;
    
    }
	public  List<ActItem>  searchbyActidcompleted(long ActivateClid ,boolean completed) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActItem> complate_ac= actItemPersistence.findByActidcompleted(ActivateClid,completed);
return complate_ac;
    
    }
	
	
	public List<ActItem> searchUnActItem(long aclid) throws SystemException
	{
		List<ActItem> check_id = actItemPersistence.findByactCLUncat(aclid, 0);
		return check_id;
	}
	
}
