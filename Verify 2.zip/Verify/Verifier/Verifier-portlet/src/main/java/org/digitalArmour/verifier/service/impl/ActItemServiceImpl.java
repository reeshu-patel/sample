package org.digitalArmour.verifier.service.impl;

import java.sql.Date;
import java.util.List;

import org.digitalArmour.verifier.model.ActItem;
import org.digitalArmour.verifier.model.impl.ActItemImpl;
import org.digitalArmour.verifier.service.ActItemLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ActItemServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;

/**
 * The implementation of the act item remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActItemService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActItemServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActItemServiceUtil
 */
public class ActItemServiceImpl extends ActItemServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActItemServiceUtil} to access the act item remote service.
     */
	
	
	public ActItem AddActiveTask(String taskName,long catId,long checklistId,long userGroupId,long majorPer, boolean major) throws SystemException {
	
		long ActitemId = CounterLocalServiceUtil.increment();
		ActItem ActItem =new ActItemImpl();
		ActItem = ActItemLocalServiceUtil.createActItem(ActitemId);
		ActItem.setCatId(catId);
		ActItem.setActivateClid(checklistId);
		ActItem.setUsergroupId(userGroupId);
		ActItem.setItemName(taskName);
		ActItem.setIsMajor(major);
		ActItem.setPercentage(majorPer);
		return ActItem = ActItemLocalServiceUtil.addActItem(ActItem);
		
	}
	public ActItem UpdateActiveTask(String taskName,long taskId) throws SystemException, PortalException {
		
		
		ActItem a =ActItemLocalServiceUtil.getActItem(taskId);
		a.setItemName(taskName);
		return a=ActItemLocalServiceUtil.updateActItem(a);
	}
	
	public ActItem UpdateTaskdetailDescription(String description,long taskId) throws SystemException, PortalException {
		
	 ActItem   item = ActItemLocalServiceUtil.getActItem(taskId);
		if(item !=null)
		{
    	item.setItemName(item.getItemName());
    	item.setItemDesc(description);
    	item.setCatId(item.getCatId());
    	ActItemLocalServiceUtil.updateActItem(item);
    }
	return item;
	
	}
	
	public ActItem IgnoreTask(long IgnoreItem,long taskId) throws SystemException, PortalException {
		
			
		ActItem  ActItem = ActItemLocalServiceUtil.getActItem(IgnoreItem);
				
		
		if(ActItem!=null){
			//fill update information
			ActItem.setItemName(ActItem.getItemName());
			ActItem.setCatId(ActItem.getCatId());
			ActItem.setIgnore(true);
/*					ActItem.setUserId(currentUser.getUserId());
*/					
			ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
			}
		return ActItem;
		
	}
	
	public ActItem UnIgnoreTask(long IgnoreItem) throws SystemException, PortalException {
		
		
			
		ActItem  ActItem = ActItemLocalServiceUtil.getActItem(IgnoreItem);
				
		
		if(ActItem!=null){
			//fill update information
			ActItem.setItemName(ActItem.getItemName());
			ActItem.setCatId(ActItem.getCatId());
			ActItem.setIgnore(false);
/*					ActItem.setUserId(currentUser.getUserId());
*/					
			ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
			}
		return ActItem;
		
	}
	
	public ActItem ActivatetaskTask(long taskId,long userId, Date date) throws SystemException, PortalException {
		
		ActItem  ActItem = ActItemLocalServiceUtil.getActItem(taskId);
				
		
		if(ActItem!=null){
			//fill update information
			ActItem.setItemName(ActItem.getItemName());
			ActItem.setCatId(ActItem.getCatId());
			ActItem.setCompleted(true);
			ActItem.setCompletedDate(date);
			ActItem.setUserId(userId);
					
			ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
			}
		return ActItem;
		
	
		
	}
	public ActItem DeActivateTask(long taskId,long userId) throws SystemException, PortalException {
		
		ActItem  ActItem = ActItemLocalServiceUtil.getActItem(taskId);
				
		
		if(ActItem!=null){
			ActItem.setItemName(ActItem.getItemName());
			ActItem.setCatId(ActItem.getCatId());
			ActItem.setCompleted(false);
			ActItem =ActItemLocalServiceUtil.updateActItem(ActItem);
			}
		return ActItem;
		
		}
	
		public ActItem DeleteActiveTask(long taskId) throws PortalException, SystemException {
		
			return ActItemLocalServiceUtil.deleteActItem(taskId);
		}
	   
		public  List<ActItem>  searchbycatId(long catId) throws SystemException,PortalException
	    {
	                 
			List<ActItem> cat_id= ActItemLocalServiceUtil.searchbycatId(catId);
			return cat_id;
	    
	    }
		public  List<ActItem>  searchbycompletedDate(Date completedDate) throws SystemException,PortalException
	    {
	                 
			// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.
			//Return search result in List<>
	     List<ActItem> complate_id= ActItemLocalServiceUtil.searchbycompletedDate(completedDate);
	        return complate_id;
	    
	    }
		
		public  List<ActItem>  searchbyActivateClid(long ActivateClid) throws SystemException,PortalException
	    {
	                 
		List<ActItem> complate_i= ActItemLocalServiceUtil.searchbyActivateClid(ActivateClid);
	        return complate_i;
	    
	    }
		public  List<ActItem>  searchbyActidcompleted(long ActivateClid ,boolean completed) throws SystemException,PortalException
	    {
	                 
			List<ActItem> complate_ac= ActItemLocalServiceUtil.searchbyActidcompleted(ActivateClid, completed);
	      return complate_ac;
	    
	    }
		
		public List<ActItem> searchUnActItem(long aclid) throws SystemException
		{
			List<ActItem> check_id = ActItemLocalServiceUtil.searchUnActItem(aclid);
			return check_id;
		}
	
}


