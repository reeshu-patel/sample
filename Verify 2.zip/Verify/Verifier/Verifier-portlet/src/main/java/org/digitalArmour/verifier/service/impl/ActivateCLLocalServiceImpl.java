package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActivateCL;
import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.service.base.ActivateCLLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the activate c l local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActivateCLLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActivateCLLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil
 */
public class ActivateCLLocalServiceImpl extends ActivateCLLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil} to access the activate c l local service.
     */
	
	public  List<ActivateCL>  searchbychecklistId(String checklistId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActivateCL> a= activateCLPersistence.findByclName(checklistId);                 
return a;
    
    }
	
	
 public  List<ActivateCL>  searchbyisCompleted(boolean isCompleted) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActivateCL> ac= activateCLPersistence.findByisCompleted(isCompleted);         
return ac;
    
    }
	
	public  List<ActivateCL>  searchbyactivateId(long activateId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActivateCL> acd= activateCLPersistence.findByactivateId(activateId);         
return acd;
    
    }
	
	
	public List<ActivateCL> getActCLByCL(long id) throws SystemException
	{
		List<ActivateCL> abc = activateCLPersistence.findBycheckListId(id);
		return abc;
	}
	
	public List<ActivateCL> getByCompCL(boolean bol, long id) throws SystemException
	{
		List<ActivateCL> abc = activateCLPersistence.findByisCompCheck(bol, id);
		return abc;
	}
	
	public List<ActivateCL> searchByCompUserId(boolean iscompleted,long actClUserId) throws SystemException
	{
		List<ActivateCL> abc = activateCLPersistence.findByisCompUser(iscompleted,actClUserId);
		return abc;
	}
}
