package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActCLCollab;
import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.model.ActItem;
import org.digitalArmour.verifier.model.ActivateCL;
import org.digitalArmour.verifier.service.ActCLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.ActCategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ActItemLocalServiceUtil;
import org.digitalArmour.verifier.service.ActivateCLLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ActivateCLServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;

/**
 * The implementation of the activate c l remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ActivateCLService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ActivateCLServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ActivateCLServiceUtil
 */
public class ActivateCLServiceImpl extends ActivateCLServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ActivateCLServiceUtil} to access the activate c l remote service.
     */
	public ActivateCL UpdateActivatechecklist(long checklistId,String checklistName) throws PortalException, SystemException {
		
		
		ActivateCL activateCL =ActivateCLLocalServiceUtil.getActivateCL(checklistId);
		
	    if(activateCL !=null)
	    {
	    	activateCL.setClName(checklistName);
	    	
	    	ActivateCLLocalServiceUtil.updateActivateCL(activateCL);
	    	
	    	
	    	
	    }
		return activateCL;
		 

	}
	
	
	public ActivateCL UpdateDescription(long checklistId,String description) throws SystemException, PortalException {
		
		
		
		ActivateCL activateCL =ActivateCLLocalServiceUtil.getActivateCL(checklistId);
		
	    if(activateCL !=null)
	    {
	    	
	    	activateCL.setClName(activateCL.getClName());
	    	activateCL.setClDescription(description);
	    	
	    	
	    	ActivateCLLocalServiceUtil.updateActivateCL(activateCL);

	    	
	    	
	    	
	    }
		return activateCL;
	}
	
	
	
	public ActivateCL DeletActivateCl(long activechecklistId) throws PortalException, SystemException {
		
		List<ActCategory> actCategories= ActCategoryLocalServiceUtil.searchbyActiveClId(activechecklistId);
		for(ActCategory actcat:actCategories){
			long catid =actcat.getActCategoryId();
			ActCategoryLocalServiceUtil.deleteActCategory(catid);
			List<ActItem> actItems =ActItemLocalServiceUtil.searchbycatId(catid);
			for(ActItem Actr:actItems){
				long actItemId = Actr.getItemId();
				
/*					List<ActItemFile> actItemFiles = ActItemFileLocalServiceUtil.g
*/					ActItemLocalServiceUtil.deleteActItem(actItemId);
				
			}
		}
		
		List<ActCLCollab> actCLCollabs =ActCLCollabLocalServiceUtil.getCollabByActiveCL(activechecklistId);
		for(ActCLCollab clx:actCLCollabs){
			long checkid =clx.getActClCollabId();
			if(checkid !=0){
				ActCLCollab actCLCollab =ActCLCollabLocalServiceUtil.deleteActCLCollab(checkid);
			}
		}
		
		ActivateCL activateCL12 =ActivateCLLocalServiceUtil.getActivateCL(activechecklistId);
		ActivateCL activateCL=ActivateCLLocalServiceUtil.deleteActivateCL(activateCL12);
		return activateCL;
		
	}
	

	public  List<ActivateCL>  searchbychecklistId(String checklistId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActivateCL> a= ActivateCLLocalServiceUtil.searchbychecklistId(checklistId);                
return a;
    
    }
	
	
 public  List<ActivateCL>  searchbyisCompleted(boolean isCompleted) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActivateCL> ac= ActivateCLLocalServiceUtil.searchbyisCompleted(isCompleted);    
return ac;
    
    }
	
	public  List<ActivateCL>  searchbyactivateId(long activateId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<ActivateCL> acd= ActivateCLLocalServiceUtil.searchbyactivateId(activateId);      
return acd;
    
    }
	
	
	public List<ActivateCL> getActCLByCL(long id) throws SystemException
	{
		List<ActivateCL> abc = ActivateCLLocalServiceUtil.getActCLByCL(id);
		return abc;
	}
	
	public List<ActivateCL> getByCompCL(boolean bol, long id) throws SystemException
	{
		List<ActivateCL> abc = ActivateCLLocalServiceUtil.getByCompCL(bol, id);
		return abc;
	}
	
	public List<ActivateCL> searchByCompUserId(boolean iscompleted,long actClUserId) throws SystemException
	{
		List<ActivateCL> abc = ActivateCLLocalServiceUtil.searchByCompUserId(iscompleted, actClUserId);
		return abc;
	}
}
