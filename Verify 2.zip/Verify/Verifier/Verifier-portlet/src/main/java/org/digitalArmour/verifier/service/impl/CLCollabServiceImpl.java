package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.CLCollab;
import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.impl.CLCollabImpl;
import org.digitalArmour.verifier.service.CLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;
import org.digitalArmour.verifier.service.base.CLCollabServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;

/**
 * The implementation of the c l collab remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.CLCollabService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.CLCollabServiceBaseImpl
 * @see org.digitalArmour.verifier.service.CLCollabServiceUtil
 */
public class CLCollabServiceImpl extends CLCollabServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.CLCollabServiceUtil} to access the c l collab remote service.
     */
	public CLCollab AddCollaboratorUser(String collaboratorType,long userId,long checklistId) throws SystemException {
		
		 long collId=CounterLocalServiceUtil.increment();
		 CLCollab collab = new CLCollabImpl();
		 collab = CLCollabLocalServiceUtil.createCLCollab(collId);
		 
		 collab.setCollabType(collaboratorType);
		 collab.setUserId(userId);
		 collab.setChecklistId(checklistId);
	
		 return CLCollabLocalServiceUtil.addCLCollab(collab);
	}
	public CLCollab DeleteCollaboratorUser(long collaboratorId) throws SystemException, PortalException {
		
		CLCollab clCollabid =CLCollabLocalServiceUtil.getCLCollab(collaboratorId);
		
		return CLCollabLocalServiceUtil.deleteCLCollab(clCollabid);
	
	}
	
	public List<CLCollab> getCollabByCL(Long id) throws SystemException
	{
		List<CLCollab> cols = CLCollabLocalServiceUtil.getCollabByCL(id);
		return cols;
	}
	
	public  List<CLCollab>  searchbyuserId(long userId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
      List<CLCollab> a= CLCollabLocalServiceUtil.searchbyuserId(userId);            
      return a;
    
    }
	
}
