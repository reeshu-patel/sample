package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.service.base.CLTemplateLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the c l template local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.CLTemplateLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.CLTemplateLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil
 */
public class CLTemplateLocalServiceImpl extends CLTemplateLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil} to access the c l template local service.
     */
	public  List<CLTemplate>  searchbychecklistId(String checklistId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<CLTemplate> a= clTemplatePersistence.findByclName(checklistId);                 
return a;
    
    }
	
public List<CLTemplate> getallCLs() throws SystemException
	{
		List<CLTemplate> temp = clTemplatePersistence.findAll();
		return temp;
	}
	public List<CLTemplate> getallUser(long id) throws SystemException
	{
		List<CLTemplate> temp = clTemplatePersistence.findByclUserId(id);
		return temp;
	}
	
	public  List<CLTemplate>  searchbyisPublic(boolean isPublic) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<CLTemplate> ad= clTemplatePersistence.findByisPublic(isPublic);              
return ad;
    
    }
	
	public  List<CLTemplate>  searchbyisPubliccat(boolean isPubliccat) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<CLTemplate> adc= clTemplatePersistence.findByisPubliccat(isPubliccat);              
return adc;
    
    }
	
	
}