package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.CLCollab;
import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.ItemComment;
import org.digitalArmour.verifier.model.ItemFile;
import org.digitalArmour.verifier.model.tag;
import org.digitalArmour.verifier.model.impl.CLTemplateImpl;
import org.digitalArmour.verifier.service.CLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;
import org.digitalArmour.verifier.service.CategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;
import org.digitalArmour.verifier.service.tagLocalServiceUtil;
import org.digitalArmour.verifier.service.base.CLTemplateServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;


/**
 * The implementation of the c l template remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.CLTemplateService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.CLTemplateServiceBaseImpl
 * @see org.digitalArmour.verifier.service.CLTemplateServiceUtil
 */
public class CLTemplateServiceImpl extends CLTemplateServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.CLTemplateServiceUtil} to access the c l template remote service.
     */
	
	public  CLTemplate AddchecklistTemplate(long userId,String ttile,String description) throws PortalException, SystemException
	{
			System.out.println("Comming in Add Check list Add");
			long verifyId=CounterLocalServiceUtil.increment();
	 		CLTemplate CLTemplate =null;
	 		CLTemplate = new CLTemplateImpl();
	 		CLTemplate =CLTemplateLocalServiceUtil.createCLTemplate(verifyId);
	 		
	 		
	 		CLTemplate.setClName(ttile);
	 		CLTemplate.setClDescription(description);
	 	 	CLTemplate.setClOrganiztion(CLTemplate.getClOrganiztion());
	 		CLTemplate.setClUserId(userId);
	 
	 		//String myString = Long.toString(checklistId);
	 		
		return CLTemplateLocalServiceUtil.addCLTemplate(CLTemplate);
	}
	
	public  CLTemplate updateChecklistTemplate(long checkId,String ttile,String description) throws PortalException, SystemException
	{
		
		
		CLTemplate clTemplate=CLTemplateLocalServiceUtil.getCLTemplate(checkId);
		if(clTemplate !=null)
	    {
	    	clTemplate.setClName(ttile);
	    	clTemplate.setClDescription(description);
	    	CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
	    }
		
		return CLTemplateLocalServiceUtil.updateCLTemplate(clTemplate);
	}
	public  CLTemplate deletChecklistTemplate(long id1) throws PortalException, SystemException
	{
	
	
		CLTemplate clTemplateId =CLTemplateLocalServiceUtil.getCLTemplate(id1);
			List<Category> categories= CategoryLocalServiceUtil.getCatByChecklistId(id1);
			
			for(Category cat:categories){
				long catid =cat.getCatId();
				
				List<Item> items =ItemLocalServiceUtil.searchbycatId(catid);
				for(Item Itemx:items){
					long itemid =Itemx.getItemId();
					
					List<ItemFile> itemFiles =ItemFileLocalServiceUtil.searchbyItemId(itemid);
					
					for(ItemFile If:itemFiles){
						long ItemFile =If.getFileId();
						ItemFileLocalServiceUtil.deleteItemFile(ItemFile);
						
					}
					
					List<ItemComment> itemComments = ItemCommentLocalServiceUtil.searchbyitemId(itemid);
					
					for(ItemComment ItemComm:itemComments){
						long Itemcomid =ItemComm.getCommId();
						ItemCommentLocalServiceUtil.deleteItemComment(Itemcomid);
						
					}
					ItemLocalServiceUtil.deleteItem(itemid);
					
				}
				
				CategoryLocalServiceUtil.deleteCategory(catid);
				
			}
			List<tag> tags =tagLocalServiceUtil.searchbychecklistId(id1);
			for(tag tag1:tags){
				long tagid =tag1.getId();
				if(tagid !=0){
					tag tag = tagLocalServiceUtil.deletetag(tagid);
				}
				
			}
			List<CLCollab> clCollabs =CLCollabLocalServiceUtil.getCollabByCL(id1);
			for(CLCollab clx:clCollabs){
				long checkid =clx.getClCollabId();
				if(checkid !=0){
					CLCollab clCollab =CLCollabLocalServiceUtil.deleteCLCollab(checkid);
				}
			}
			return CLTemplateLocalServiceUtil.deleteCLTemplate(clTemplateId);
	}
	
	public  List<CLTemplate>  searchbychecklistId(String checklistId) throws SystemException,PortalException
    	{
                 
        List<CLTemplate> a= CLTemplateLocalServiceUtil.searchbychecklistId(checklistId);               
        return a;
    
    	}
	
	public List<CLTemplate> getallCLs() throws SystemException
		{
			List<CLTemplate> temp = CLTemplateLocalServiceUtil.getallCLs();
			return temp;
		}
	public List<CLTemplate> getallUser(long id) throws SystemException
		{
		List<CLTemplate> temp = CLTemplateLocalServiceUtil.getallUser(id);
		return temp;
	}
	
	public  List<CLTemplate>  searchbyisPublic(boolean isPublic) throws SystemException,PortalException
		{
                 
        List<CLTemplate> ad= CLTemplateLocalServiceUtil.searchbyisPublic(isPublic);         
        return ad;
    
    }
		
	public  List<CLTemplate>  searchbyisPubliccat(boolean isPubliccat) throws SystemException,PortalException
    	{
        List<CLTemplate> adc= CLTemplateLocalServiceUtil.searchbyisPubliccat(isPubliccat);             
        return adc;
    
    	}
	}
