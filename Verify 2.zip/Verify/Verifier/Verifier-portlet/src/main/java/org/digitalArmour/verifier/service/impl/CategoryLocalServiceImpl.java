package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.service.base.CategoryLocalServiceBaseImpl;
import org.digitalArmour.verifier.service.persistence.CategoryPersistence;
import org.digitalArmour.verifier.service.persistence.CategoryPersistenceImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the category local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.CategoryLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.CategoryLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.CategoryLocalServiceUtil
 */
public class CategoryLocalServiceImpl extends CategoryLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.CategoryLocalServiceUtil} to access the category local service.
     */
	//ADD CATEGORY
		/*public Category addCategory(Category newCat) throws SystemException
		{
			Category cat = categoryPersistence.create(counterLocalService.increment(Category.class.getName()));
			cat.setCatName(newCat.getCatName());
			cat.setChecklistId(newCat.getChecklistId());
			return categoryPersistence.update(cat, false);
		}
		*/
		//GET ALL CATEGORIES
		public List<Category> getAllCategories() throws SystemException
		{
			List<Category> cats = categoryPersistence.findAll();
			return cats;
		}
		
		//FIND BY CHECKLIST ID
		public List<Category> getCatBysubcategoryId(Long subcategoryId) throws SystemException
		{
			List<Category> catsd = categoryPersistence.findBysubcategoryId(subcategoryId);
			return catsd;
		}
		
		public List<Category> getCatByChecklistId(Long id) throws SystemException
		{
			List<Category> cats = categoryPersistence.findByCL_Id(id);
			return cats;
		}
		
		//FIND BY SUBCATID AND CHECKLISTID
		public List<Category> getBySubClID(Long clid, long sid) throws SystemException
		{
			List<Category> cats = categoryPersistence.findByCL_subcatID(clid, sid);
			return cats;
		}
		
		public List<Category> getBycatId(long catId) throws SystemException
		{
			List<Category> catss = categoryPersistence.findBycatId(catId);
			return catss;
		}
		
		/*public List<Category> getBysubcategoryId(long subcategoryId) throws SystemException
		{
			List<Category> catssd = categoryPersistence.findBycatId(subcategoryId);
			return catssd;
		}*/
		
}
