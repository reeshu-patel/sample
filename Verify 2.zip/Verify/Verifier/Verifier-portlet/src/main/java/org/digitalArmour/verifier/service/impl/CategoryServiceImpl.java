package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.impl.ActCategoryImpl;
import org.digitalArmour.verifier.model.impl.CategoryImpl;
import org.digitalArmour.verifier.service.CategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;
import org.digitalArmour.verifier.service.base.CategoryServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;

/**
 * The implementation of the category remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.CategoryService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.CategoryServiceBaseImpl
 * @see org.digitalArmour.verifier.service.CategoryServiceUtil
 */
public class CategoryServiceImpl extends CategoryServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.CategoryServiceUtil} to access the category remote service.
     */
	
	
	public Category AddCategory(String categoryName,long checklistId) throws SystemException {
		 long catId=CounterLocalServiceUtil.increment();
		 Category category=null;
		 category =CategoryLocalServiceUtil.createCategory(catId);
		 category = new CategoryImpl();
		 category.setCatId(CounterLocalServiceUtil.increment(Category.class.getName()));
		 category.setCatName(categoryName);
		 category.setSubcategoryId(0);
		 category.setChecklistId(checklistId);
		 return CategoryLocalServiceUtil.addCategory(category);

		 //navigate to checlist jsp page
		}
	public Category UpdateCategory(String categoryName,long categoryId) throws SystemException, PortalException {
		 
		
 		Category ecat = CategoryLocalServiceUtil.getCategory(categoryId);
 		ecat.setCatName(categoryName);
 		
 		return CategoryLocalServiceUtil.updateCategory(ecat);
 		

		 //navigate to checlist jsp page
		 
		

	}
	
	public Category DeleteCategory(long checklistId,long categoryId) throws SystemException, PortalException {
		 
		
		
		Category categorydel = CategoryLocalServiceUtil.getCategory(categoryId);
		List<Item> itemdel = ItemLocalServiceUtil.searchbycatId(categoryId);	
		List<Category> subcat = CategoryLocalServiceUtil.getBySubClID(checklistId, categoryId);		
		for(Item delItem: itemdel)
		{
			ItemLocalServiceUtil.deleteItem(delItem);
		}
		for(Category delsc: subcat)
		{
			CategoryLocalServiceUtil.deleteCategory(delsc);
			List<Item> sitemdel = ItemLocalServiceUtil.searchbycatId(delsc.getCatId());
			for(Item delItem: sitemdel)
			{
				ItemLocalServiceUtil.deleteItem(delItem);
			}
		}
	    
				
		
		return CategoryLocalServiceUtil.deleteCategory(categorydel);
		
	}
	
	public List<Category> getAllCategories() throws SystemException
	{
		List<Category> cats = CategoryLocalServiceUtil.getAllCategories();
		return cats;
	}
	
	//FIND BY CHECKLIST ID
	public List<Category> getCatBysubcategoryId(Long subcategoryId) throws SystemException
	{
		List<Category> catsd = CategoryLocalServiceUtil.getCatBysubcategoryId(subcategoryId);
		return catsd;
	}
	
	public List<Category> getCatByChecklistId(Long id) throws SystemException
	{
		List<Category> cats = CategoryLocalServiceUtil.getCatByChecklistId(id);
		return cats;
	}
	
	//FIND BY SUBCATID AND CHECKLISTID
	public List<Category> getBySubClID(Long clid, long sid) throws SystemException
	{
		List<Category> cats = CategoryLocalServiceUtil.getBySubClID(clid, sid);
		return cats;
	}
	
	public List<Category> getBycatId(long catId) throws SystemException
	{
		List<Category> catss = CategoryLocalServiceUtil.getBycatId(catId);
		return catss;
	}
	
	
	
}
