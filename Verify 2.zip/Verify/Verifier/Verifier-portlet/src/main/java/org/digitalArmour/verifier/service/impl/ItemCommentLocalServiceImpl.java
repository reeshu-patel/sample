package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.model.ItemComment;
import org.digitalArmour.verifier.service.base.ItemCommentLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the item comment local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ItemCommentLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ItemCommentLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil
 */
public class ItemCommentLocalServiceImpl extends ItemCommentLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil} to access the item comment local service.
     */
	public List<ItemComment> getAllComments(long itemId) throws SystemException
	{
	List<ItemComment> items = itemCommentPersistence.findByItemId(itemId);
	return items;
	}
	
	public  List<ItemComment>  searchbyitemId(long itemId) throws SystemException,PortalException
	{
	List<ItemComment> catts = itemCommentPersistence.findByItemId(itemId);
	return catts;
}
	
}
