package org.digitalArmour.verifier.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletMode;
import javax.portlet.PortletRequest;
import javax.portlet.PortletURL;
import javax.portlet.WindowState;

import org.digitalArmour.verifier.controller.DockBarUserNotificationHandler;
import org.digitalArmour.verifier.model.CLCollab;
import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.ItemComment;
import org.digitalArmour.verifier.model.Notification;
import org.digitalArmour.verifier.model.impl.ItemCommentImpl;
import org.digitalArmour.verifier.service.CLCollabLocalServiceUtil;
import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.NotificationLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ItemCommentServiceBaseImpl;
import org.springframework.web.portlet.bind.annotation.ActionMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PrefsPropsUtil;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Portlet;
import com.liferay.portal.model.User;
import com.liferay.portal.model.UserNotificationEvent;
import com.liferay.portal.service.PortletLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.UserNotificationEventLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.PortletURLFactoryUtil;

/**
 * The implementation of the item comment remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ItemCommentService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ItemCommentServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ItemCommentServiceUtil
 */
public class ItemCommentServiceImpl extends ItemCommentServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ItemCommentServiceUtil} to access the item comment remote service.
     */
	
	public ItemComment AddComment(long userId,long taskId,String commMassage) throws PortalException, SystemException {
		 
			ItemComment items=new ItemCommentImpl();
			items.setCommId(Long.valueOf(CounterLocalServiceUtil.increment()));
			items.setComment(commMassage);
			items.setCreateTime(new Date());
			/*System.out.println(ParamUtil.getLong(actionRequest, "itemid"));*/
			items.setItemId(taskId);
			items.setUserId(userId);
			return ItemCommentLocalServiceUtil.addItemComment(items);
		}
	
	public ItemComment UpdateComment(long commentId,String commMassage) throws PortalException, SystemException {
		
		 
			
			 ItemComment itemComm = ItemCommentLocalServiceUtil.getItemComment(commentId);
			 itemComm.setComment(commMassage);
			 return ItemCommentLocalServiceUtil.updateItemComment(itemComm);
			
		 }
		
	public ItemComment DeleteComment(long commentId) throws PortalException, SystemException {
		
		ItemComment ietComment =ItemCommentLocalServiceUtil.getItemComment(commentId);
		
		 return ItemCommentLocalServiceUtil.deleteItemComment(ietComment);
		 
	 }
	
	public List<ItemComment> getAllComments(long itemId) throws SystemException
	{
	List<ItemComment> items = ItemCommentLocalServiceUtil.getAllComments(itemId);
	return items;
	}
	
	public  List<ItemComment>  searchbyitemId(long itemId) throws SystemException,PortalException
	{
	List<ItemComment> catts = ItemCommentLocalServiceUtil.searchbyitemId(itemId);
	return catts;
}
	
}
