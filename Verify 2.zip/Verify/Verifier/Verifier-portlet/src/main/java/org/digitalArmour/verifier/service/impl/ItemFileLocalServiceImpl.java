package org.digitalArmour.verifier.service.impl;


import java.util.List;

import org.digitalArmour.verifier.model.ActCategory;
import org.digitalArmour.verifier.model.ItemFile;
import org.digitalArmour.verifier.service.base.ItemFileLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;




/**
 * The implementation of the item file local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ItemFileLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ItemFileLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ItemFileLocalServiceUtil
 */
public class ItemFileLocalServiceImpl extends ItemFileLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ItemFileLocalServiceUtil} to access the item file local service.
     */
	public List<ItemFile> getAllFiles(long itemId) throws com.liferay.portal.kernel.exception.SystemException
	{
	List<ItemFile> images = itemFilePersistence.findByItemId(itemId);
	return images;
	}
	
	public  List<ItemFile>  searchbyItemId(long ItemId) throws SystemException,PortalException
	{
	List<ItemFile> catts = itemFilePersistence.findByItemId(ItemId);
	return catts;
}
	
	
}
