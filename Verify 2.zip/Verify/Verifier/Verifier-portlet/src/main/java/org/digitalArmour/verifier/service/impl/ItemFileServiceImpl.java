package org.digitalArmour.verifier.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.digitalArmour.verifier.model.ItemFile;
import org.digitalArmour.verifier.model.impl.ItemFileImpl;
import org.digitalArmour.verifier.service.ItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ItemFileServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;

/**
 * The implementation of the item file remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ItemFileService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ItemFileServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ItemFileServiceUtil
 */
public class ItemFileServiceImpl extends ItemFileServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ItemFileServiceUtil} to access the item file remote service.
     */
	
	
public ItemFile AddTaskFile(long taskId ,String sourceFileName,long userId,String file) throws SystemException, IOException {
	

		//UploadPortletRequest  ureq=PortalUtil.getUploadPortletRequest(arq);
		//File folderFile = new File(file.toString());
		// This is our final file path.
		File file2 = new File(file);
		//System.out.println("call fuction");
		//File filePath = new File(file + File.separator + sourceFileName);
	    File folder = new File("/tmp/upload");
		File filePath = new File(folder.getAbsolutePath() + File.separator + sourceFileName);
		FileUtils.copyFile(file2, filePath, true);
		ItemFile file1=new ItemFileImpl();
		file1.setFileId(Long.valueOf(CounterLocalServiceUtil.increment()));
		file1.setFileName(sourceFileName);
		
		file1.setFilePath(filePath.toString());
		
		file1.setCreateTime(new Date());
		
		file1.setItemId(taskId);
		file1.setUserId(userId);
		
		return ItemFileLocalServiceUtil.addItemFile(file1);
	}

public ItemFile DeleteTaskFile(long fileId) throws SystemException, PortalException {

	 ItemFile itefFile= ItemFileLocalServiceUtil.getItemFile(fileId);
	
	 return ItemFileLocalServiceUtil.deleteItemFile(itefFile);
	 
	/* response.setRenderParameter("remove", "removefile");*/
	 
}
public List<ItemFile> getAllFiles(long itemId) throws com.liferay.portal.kernel.exception.SystemException
{
List<ItemFile> images = ItemFileLocalServiceUtil.getAllFiles(itemId);
return images;
}

public  List<ItemFile>  searchbyItemId(long ItemId) throws SystemException,PortalException
{
List<ItemFile> catts = ItemFileLocalServiceUtil.searchbyItemId(ItemId);
return catts;
}

}
