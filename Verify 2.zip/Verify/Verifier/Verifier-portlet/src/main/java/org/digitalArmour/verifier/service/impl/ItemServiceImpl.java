package org.digitalArmour.verifier.service.impl;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.ItemComment;
import org.digitalArmour.verifier.model.ItemFile;
import org.digitalArmour.verifier.model.impl.CategoryImpl;
import org.digitalArmour.verifier.model.impl.ItemImpl;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemFileLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;
import org.digitalArmour.verifier.service.base.ItemServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;

/**
 * The implementation of the item remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ItemService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ItemServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ItemServiceUtil
 */
public class ItemServiceImpl extends ItemServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ItemServiceUtil} to access the item remote service.
     */
	
	public Item AddTask(long checklistId,String taskName,long catId,long userGoupid,String major,long majorweight) throws SystemException {
	
			long itemId = CounterLocalServiceUtil.increment();

				Item verify = new ItemImpl();
			    verify = ItemLocalServiceUtil.createItem(itemId);

				verify.setItemName(taskName);
				verify.setChecklistId(checklistId);
				verify.setCatId(catId);
				verify.setUserGroupId(userGoupid);
				if(major == null || major.equals("")){
				verify.setMajor(false);
				}else{
					verify.setMajor(true);
				}
				verify.setMajor_percent(majorweight);
				

				return ItemLocalServiceUtil.addItem(verify);
				
		
	}
	
public Item UpdateTask(long taskId,String taskName) throws SystemException, PortalException {
		
	

	Item m = ItemLocalServiceUtil.getItem(taskId);
	m.setItemName(taskName);
	m = ItemLocalServiceUtil.updateItem(m);
	return ItemLocalServiceUtil.updateItem(m);
}
	
public Item DeleteTask(long taskId) throws SystemException, PortalException {
	
	Item item1 = ItemLocalServiceUtil.getItem(taskId);
 	List<ItemFile>  itemFiles =ItemFileLocalServiceUtil.getAllFiles(taskId);
 	for(ItemFile itemf:itemFiles){
 		long fileif =itemf.getFileId();
 		ItemFileLocalServiceUtil.deleteItemFile(fileif);
 		
 		List<ItemComment> itemComments =ItemCommentLocalServiceUtil.getAllComments(taskId);
 		for(ItemComment itemcomm:itemComments){
 			
 			long itemcommId =itemcomm.getCommId();
 			ItemCommentLocalServiceUtil.deleteItemComment(itemcommId);
 		}
 	}
	return ItemLocalServiceUtil.deleteItem(item1);
}

public Item UpdateDiscriptionTask(long taskId,String taskDescription) throws SystemException, PortalException {
	
	
	 Item itemDesc = ItemLocalServiceUtil.getItem(taskId);
	 itemDesc.setItemDesc(taskDescription);
	 return ItemLocalServiceUtil.updateItem(itemDesc);
	 

}

public  List<Item>  searchbycatId(long catId) throws SystemException,PortalException
{
             
//searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
List<Item> cat_id= ItemLocalServiceUtil.searchbycatId(catId);
return cat_id;

}

public List<Item> getAllitems() throws SystemException
{
List<Item> items = ItemLocalServiceUtil.getAllitems();
return items;
}

public List<Item> searchByCheckId(long ckid) throws SystemException
{
	List<Item> check_id = ItemLocalServiceUtil.searchByCheckId(ckid);
	return check_id;
}

}
