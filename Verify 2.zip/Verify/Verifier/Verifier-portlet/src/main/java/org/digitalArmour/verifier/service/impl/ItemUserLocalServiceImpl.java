package org.digitalArmour.verifier.service.impl;

import org.digitalArmour.verifier.service.base.ItemUserLocalServiceBaseImpl;

/**
 * The implementation of the item user local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ItemUserLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ItemUserLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ItemUserLocalServiceUtil
 */
public class ItemUserLocalServiceImpl extends ItemUserLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ItemUserLocalServiceUtil} to access the item user local service.
     */
}
