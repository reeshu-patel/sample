package org.digitalArmour.verifier.service.impl;

import org.digitalArmour.verifier.service.base.ItemUserServiceBaseImpl;

/**
 * The implementation of the item user remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.ItemUserService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.ItemUserServiceBaseImpl
 * @see org.digitalArmour.verifier.service.ItemUserServiceUtil
 */
public class ItemUserServiceImpl extends ItemUserServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.ItemUserServiceUtil} to access the item user remote service.
     */
}
