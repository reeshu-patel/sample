package org.digitalArmour.verifier.service.impl;

import org.digitalArmour.verifier.service.base.NotificationLocalServiceBaseImpl;

/**
 * The implementation of the notification local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.NotificationLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.NotificationLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.NotificationLocalServiceUtil
 */
public class NotificationLocalServiceImpl
    extends NotificationLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.NotificationLocalServiceUtil} to access the notification local service.
     */
}
