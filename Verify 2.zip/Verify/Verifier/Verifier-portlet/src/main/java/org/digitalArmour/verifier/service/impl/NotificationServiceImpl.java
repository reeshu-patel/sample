package org.digitalArmour.verifier.service.impl;

import org.digitalArmour.verifier.service.base.NotificationServiceBaseImpl;

/**
 * The implementation of the notification remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.NotificationService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.NotificationServiceBaseImpl
 * @see org.digitalArmour.verifier.service.NotificationServiceUtil
 */
public class NotificationServiceImpl extends NotificationServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.NotificationServiceUtil} to access the notification remote service.
     */
}
