package org.digitalArmour.verifier.service.impl;

import org.digitalArmour.verifier.service.base.OrganizationLocalServiceBaseImpl;

/**
 * The implementation of the organization local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.OrganizationLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.OrganizationLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.OrganizationLocalServiceUtil
 */
public class OrganizationLocalServiceImpl
    extends OrganizationLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.OrganizationLocalServiceUtil} to access the organization local service.
     */
}
