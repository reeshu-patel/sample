package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.Subcategory;
import org.digitalArmour.verifier.service.base.SubcategoryLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the subcategory local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.SubcategoryLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.SubcategoryLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.SubcategoryLocalServiceUtil
 */
public class SubcategoryLocalServiceImpl extends SubcategoryLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.SubcategoryLocalServiceUtil} to access the subcategory local service.
     */
	
	//FIND BY CATEGORY ID
			public List<Subcategory> getSubcatByCatid(Long id) throws SystemException
			{
				List<Subcategory> subcats = subcategoryPersistence.findByCategId(id);
				return subcats;
			}
			
}
