package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.tag;
import org.digitalArmour.verifier.service.base.tagLocalServiceBaseImpl;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the tag local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.tagLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.tagLocalServiceBaseImpl
 * @see org.digitalArmour.verifier.service.tagLocalServiceUtil
 */
public class tagLocalServiceImpl extends tagLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.tagLocalServiceUtil} to access the tag local service.
     */
	public  List<tag>  searchbychecklistId(long checklistId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<tag> clist= tagPersistence.findBychecklistId(checklistId);                 
return clist;
    
    }


}
