package org.digitalArmour.verifier.service.impl;

import java.util.List;

import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.tag;
import org.digitalArmour.verifier.model.impl.CategoryImpl;
import org.digitalArmour.verifier.model.impl.tagImpl;
import org.digitalArmour.verifier.service.tagLocalServiceUtil;
import org.digitalArmour.verifier.service.base.tagServiceBaseImpl;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;

/**
 * The implementation of the tag remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link org.digitalArmour.verifier.service.tagService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see org.digitalArmour.verifier.service.base.tagServiceBaseImpl
 * @see org.digitalArmour.verifier.service.tagServiceUtil
 */
public class tagServiceImpl extends tagServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link org.digitalArmour.verifier.service.tagServiceUtil} to access the tag remote service.
     */
	
	public tag AddTag(String tag,long checklistId) throws SystemException {
		

 		long tagId=CounterLocalServiceUtil.increment();
 		tag tag1=null;
 		tag1 = new tagImpl();
 		
 		tag1 = tagLocalServiceUtil.createtag(tagId);
 		tag1.setTagName(tag);
 		tag1.setChecklistId(checklistId);
 		return tagLocalServiceUtil.addtag(tag1);
 	}
	
	public tag DeleteTag(long tagid) throws PortalException, SystemException {
		tag tag1 =tagLocalServiceUtil.gettag(tagid);
		
		return tagLocalServiceUtil.deletetag(tag1);
	}
	public  List<tag>  searchbychecklistId(long checklistId) throws SystemException,PortalException
    {
                 
// searchPersistence.findByItemname(name) method created by <finder> tag write in servicr.xml file.

//Return search result in List<>
        List<tag> clist= tagLocalServiceUtil.searchbychecklistId(checklistId);             
        return clist;
    
    }

}
