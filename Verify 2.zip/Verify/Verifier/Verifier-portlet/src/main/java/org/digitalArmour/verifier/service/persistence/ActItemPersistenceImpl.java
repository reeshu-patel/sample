package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.CalendarUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchActItemException;
import org.digitalArmour.verifier.model.ActItem;
import org.digitalArmour.verifier.model.impl.ActItemImpl;
import org.digitalArmour.verifier.model.impl.ActItemModelImpl;
import org.digitalArmour.verifier.service.persistence.ActItemPersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the act item service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActItemPersistence
 * @see ActItemUtil
 * @generated
 */
public class ActItemPersistenceImpl extends BasePersistenceImpl<ActItem>
    implements ActItemPersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link ActItemUtil} to access the act item persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = ActItemImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            ActItemModelImpl.UUID_COLUMN_BITMASK |
            ActItemModelImpl.COMPLETEDDATE_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "actItem.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "actItem.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(actItem.uuid IS NULL OR actItem.uuid = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPLETEDDATE =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycompletedDate",
            new String[] {
                Date.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPLETEDDATE =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycompletedDate",
            new String[] { Date.class.getName() },
            ActItemModelImpl.COMPLETEDDATE_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_COMPLETEDDATE = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycompletedDate",
            new String[] { Date.class.getName() });
    private static final String _FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_1 = "actItem.completedDate IS NULL";
    private static final String _FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_2 = "actItem.completedDate = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTIVATECLID =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByActivateClid",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATECLID =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByActivateClid",
            new String[] { Long.class.getName() },
            ActItemModelImpl.ACTIVATECLID_COLUMN_BITMASK |
            ActItemModelImpl.COMPLETEDDATE_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ACTIVATECLID = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByActivateClid",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_ACTIVATECLID_ACTIVATECLID_2 = "actItem.ActivateClid = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CATID = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycatId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycatId",
            new String[] { Long.class.getName() },
            ActItemModelImpl.CATID_COLUMN_BITMASK |
            ActItemModelImpl.COMPLETEDDATE_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CATID = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycatId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_CATID_CATID_2 = "actItem.catId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTIDCOMPLETED =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByActidcompleted",
            new String[] {
                Long.class.getName(), Boolean.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIDCOMPLETED =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByActidcompleted",
            new String[] { Long.class.getName(), Boolean.class.getName() },
            ActItemModelImpl.ACTIVATECLID_COLUMN_BITMASK |
            ActItemModelImpl.COMPLETED_COLUMN_BITMASK |
            ActItemModelImpl.COMPLETEDDATE_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ACTIDCOMPLETED = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByActidcompleted",
            new String[] { Long.class.getName(), Boolean.class.getName() });
    private static final String _FINDER_COLUMN_ACTIDCOMPLETED_ACTIVATECLID_2 = "actItem.ActivateClid = ? AND ";
    private static final String _FINDER_COLUMN_ACTIDCOMPLETED_COMPLETED_2 = "actItem.completed = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTCLUNCAT =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByactCLUncat",
            new String[] {
                Long.class.getName(), Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTCLUNCAT =
        new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, ActItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByactCLUncat",
            new String[] { Long.class.getName(), Long.class.getName() },
            ActItemModelImpl.ACTIVATECLID_COLUMN_BITMASK |
            ActItemModelImpl.CATID_COLUMN_BITMASK |
            ActItemModelImpl.COMPLETEDDATE_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ACTCLUNCAT = new FinderPath(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByactCLUncat",
            new String[] { Long.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_ACTCLUNCAT_ACTIVATECLID_2 = "actItem.ActivateClid = ? AND ";
    private static final String _FINDER_COLUMN_ACTCLUNCAT_CATID_2 = "actItem.catId = ?";
    private static final String _SQL_SELECT_ACTITEM = "SELECT actItem FROM ActItem actItem";
    private static final String _SQL_SELECT_ACTITEM_WHERE = "SELECT actItem FROM ActItem actItem WHERE ";
    private static final String _SQL_COUNT_ACTITEM = "SELECT COUNT(actItem) FROM ActItem actItem";
    private static final String _SQL_COUNT_ACTITEM_WHERE = "SELECT COUNT(actItem) FROM ActItem actItem WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "actItem.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No ActItem exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No ActItem exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(ActItemPersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid", "ignore"
            });
    private static ActItem _nullActItem = new ActItemImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<ActItem> toCacheModel() {
                return _nullActItemCacheModel;
            }
        };

    private static CacheModel<ActItem> _nullActItemCacheModel = new CacheModel<ActItem>() {
            @Override
            public ActItem toEntityModel() {
                return _nullActItem;
            }
        };

    public ActItemPersistenceImpl() {
        setModelClass(ActItem.class);
    }

    /**
     * Returns all the act items where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the act items where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @return the range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the act items where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<ActItem> list = (List<ActItem>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActItem actItem : list) {
                if (!Validator.equals(uuid, actItem.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTITEM_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActItem>(list);
                } else {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first act item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByUuid_First(uuid, orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the first act item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActItem> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last act item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByUuid_Last(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByUuid_Last(uuid, orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the last act item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<ActItem> list = findByUuid(uuid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the act items before and after the current act item in the ordered set where uuid = &#63;.
     *
     * @param ItemId the primary key of the current act item
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem[] findByUuid_PrevAndNext(long ItemId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = findByPrimaryKey(ItemId);

        Session session = null;

        try {
            session = openSession();

            ActItem[] array = new ActItemImpl[3];

            array[0] = getByUuid_PrevAndNext(session, actItem, uuid,
                    orderByComparator, true);

            array[1] = actItem;

            array[2] = getByUuid_PrevAndNext(session, actItem, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActItem getByUuid_PrevAndNext(Session session, ActItem actItem,
        String uuid, OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTITEM_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(actItem);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActItem> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the act items where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (ActItem actItem : findByUuid(uuid, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(actItem);
        }
    }

    /**
     * Returns the number of act items where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTITEM_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the act items where completedDate = &#63;.
     *
     * @param completedDate the completed date
     * @return the matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findBycompletedDate(Date completedDate)
        throws SystemException {
        return findBycompletedDate(completedDate, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the act items where completedDate = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param completedDate the completed date
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @return the range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findBycompletedDate(Date completedDate, int start,
        int end) throws SystemException {
        return findBycompletedDate(completedDate, start, end, null);
    }

    /**
     * Returns an ordered range of all the act items where completedDate = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param completedDate the completed date
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findBycompletedDate(Date completedDate, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPLETEDDATE;
            finderArgs = new Object[] { completedDate };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPLETEDDATE;
            finderArgs = new Object[] {
                    completedDate,
                    
                    start, end, orderByComparator
                };
        }

        List<ActItem> list = (List<ActItem>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActItem actItem : list) {
                if (!Validator.equals(completedDate, actItem.getCompletedDate())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTITEM_WHERE);

            boolean bindCompletedDate = false;

            if (completedDate == null) {
                query.append(_FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_1);
            } else {
                bindCompletedDate = true;

                query.append(_FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindCompletedDate) {
                    qPos.add(CalendarUtil.getTimestamp(completedDate));
                }

                if (!pagination) {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActItem>(list);
                } else {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first act item in the ordered set where completedDate = &#63;.
     *
     * @param completedDate the completed date
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findBycompletedDate_First(Date completedDate,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchBycompletedDate_First(completedDate,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("completedDate=");
        msg.append(completedDate);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the first act item in the ordered set where completedDate = &#63;.
     *
     * @param completedDate the completed date
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchBycompletedDate_First(Date completedDate,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActItem> list = findBycompletedDate(completedDate, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last act item in the ordered set where completedDate = &#63;.
     *
     * @param completedDate the completed date
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findBycompletedDate_Last(Date completedDate,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchBycompletedDate_Last(completedDate,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("completedDate=");
        msg.append(completedDate);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the last act item in the ordered set where completedDate = &#63;.
     *
     * @param completedDate the completed date
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchBycompletedDate_Last(Date completedDate,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countBycompletedDate(completedDate);

        if (count == 0) {
            return null;
        }

        List<ActItem> list = findBycompletedDate(completedDate, count - 1,
                count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the act items before and after the current act item in the ordered set where completedDate = &#63;.
     *
     * @param ItemId the primary key of the current act item
     * @param completedDate the completed date
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem[] findBycompletedDate_PrevAndNext(long ItemId,
        Date completedDate, OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = findByPrimaryKey(ItemId);

        Session session = null;

        try {
            session = openSession();

            ActItem[] array = new ActItemImpl[3];

            array[0] = getBycompletedDate_PrevAndNext(session, actItem,
                    completedDate, orderByComparator, true);

            array[1] = actItem;

            array[2] = getBycompletedDate_PrevAndNext(session, actItem,
                    completedDate, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActItem getBycompletedDate_PrevAndNext(Session session,
        ActItem actItem, Date completedDate,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTITEM_WHERE);

        boolean bindCompletedDate = false;

        if (completedDate == null) {
            query.append(_FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_1);
        } else {
            bindCompletedDate = true;

            query.append(_FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindCompletedDate) {
            qPos.add(CalendarUtil.getTimestamp(completedDate));
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(actItem);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActItem> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the act items where completedDate = &#63; from the database.
     *
     * @param completedDate the completed date
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeBycompletedDate(Date completedDate)
        throws SystemException {
        for (ActItem actItem : findBycompletedDate(completedDate,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(actItem);
        }
    }

    /**
     * Returns the number of act items where completedDate = &#63;.
     *
     * @param completedDate the completed date
     * @return the number of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countBycompletedDate(Date completedDate)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_COMPLETEDDATE;

        Object[] finderArgs = new Object[] { completedDate };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTITEM_WHERE);

            boolean bindCompletedDate = false;

            if (completedDate == null) {
                query.append(_FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_1);
            } else {
                bindCompletedDate = true;

                query.append(_FINDER_COLUMN_COMPLETEDDATE_COMPLETEDDATE_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindCompletedDate) {
                    qPos.add(CalendarUtil.getTimestamp(completedDate));
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the act items where ActivateClid = &#63;.
     *
     * @param ActivateClid the activate clid
     * @return the matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByActivateClid(long ActivateClid)
        throws SystemException {
        return findByActivateClid(ActivateClid, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the act items where ActivateClid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param ActivateClid the activate clid
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @return the range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByActivateClid(long ActivateClid, int start,
        int end) throws SystemException {
        return findByActivateClid(ActivateClid, start, end, null);
    }

    /**
     * Returns an ordered range of all the act items where ActivateClid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param ActivateClid the activate clid
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByActivateClid(long ActivateClid, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATECLID;
            finderArgs = new Object[] { ActivateClid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTIVATECLID;
            finderArgs = new Object[] {
                    ActivateClid,
                    
                    start, end, orderByComparator
                };
        }

        List<ActItem> list = (List<ActItem>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActItem actItem : list) {
                if ((ActivateClid != actItem.getActivateClid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_ACTIVATECLID_ACTIVATECLID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(ActivateClid);

                if (!pagination) {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActItem>(list);
                } else {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first act item in the ordered set where ActivateClid = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByActivateClid_First(long ActivateClid,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByActivateClid_First(ActivateClid,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("ActivateClid=");
        msg.append(ActivateClid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the first act item in the ordered set where ActivateClid = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByActivateClid_First(long ActivateClid,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActItem> list = findByActivateClid(ActivateClid, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last act item in the ordered set where ActivateClid = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByActivateClid_Last(long ActivateClid,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByActivateClid_Last(ActivateClid,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("ActivateClid=");
        msg.append(ActivateClid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the last act item in the ordered set where ActivateClid = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByActivateClid_Last(long ActivateClid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByActivateClid(ActivateClid);

        if (count == 0) {
            return null;
        }

        List<ActItem> list = findByActivateClid(ActivateClid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63;.
     *
     * @param ItemId the primary key of the current act item
     * @param ActivateClid the activate clid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem[] findByActivateClid_PrevAndNext(long ItemId,
        long ActivateClid, OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = findByPrimaryKey(ItemId);

        Session session = null;

        try {
            session = openSession();

            ActItem[] array = new ActItemImpl[3];

            array[0] = getByActivateClid_PrevAndNext(session, actItem,
                    ActivateClid, orderByComparator, true);

            array[1] = actItem;

            array[2] = getByActivateClid_PrevAndNext(session, actItem,
                    ActivateClid, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActItem getByActivateClid_PrevAndNext(Session session,
        ActItem actItem, long ActivateClid,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTITEM_WHERE);

        query.append(_FINDER_COLUMN_ACTIVATECLID_ACTIVATECLID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(ActivateClid);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(actItem);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActItem> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the act items where ActivateClid = &#63; from the database.
     *
     * @param ActivateClid the activate clid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByActivateClid(long ActivateClid)
        throws SystemException {
        for (ActItem actItem : findByActivateClid(ActivateClid,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(actItem);
        }
    }

    /**
     * Returns the number of act items where ActivateClid = &#63;.
     *
     * @param ActivateClid the activate clid
     * @return the number of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByActivateClid(long ActivateClid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ACTIVATECLID;

        Object[] finderArgs = new Object[] { ActivateClid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_ACTIVATECLID_ACTIVATECLID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(ActivateClid);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the act items where catId = &#63;.
     *
     * @param catId the cat ID
     * @return the matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findBycatId(long catId) throws SystemException {
        return findBycatId(catId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the act items where catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param catId the cat ID
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @return the range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findBycatId(long catId, int start, int end)
        throws SystemException {
        return findBycatId(catId, start, end, null);
    }

    /**
     * Returns an ordered range of all the act items where catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param catId the cat ID
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findBycatId(long catId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID;
            finderArgs = new Object[] { catId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CATID;
            finderArgs = new Object[] { catId, start, end, orderByComparator };
        }

        List<ActItem> list = (List<ActItem>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActItem actItem : list) {
                if ((catId != actItem.getCatId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_CATID_CATID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(catId);

                if (!pagination) {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActItem>(list);
                } else {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first act item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findBycatId_First(long catId,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchBycatId_First(catId, orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the first act item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchBycatId_First(long catId,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActItem> list = findBycatId(catId, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last act item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findBycatId_Last(long catId,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchBycatId_Last(catId, orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the last act item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchBycatId_Last(long catId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countBycatId(catId);

        if (count == 0) {
            return null;
        }

        List<ActItem> list = findBycatId(catId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the act items before and after the current act item in the ordered set where catId = &#63;.
     *
     * @param ItemId the primary key of the current act item
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem[] findBycatId_PrevAndNext(long ItemId, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = findByPrimaryKey(ItemId);

        Session session = null;

        try {
            session = openSession();

            ActItem[] array = new ActItemImpl[3];

            array[0] = getBycatId_PrevAndNext(session, actItem, catId,
                    orderByComparator, true);

            array[1] = actItem;

            array[2] = getBycatId_PrevAndNext(session, actItem, catId,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActItem getBycatId_PrevAndNext(Session session, ActItem actItem,
        long catId, OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTITEM_WHERE);

        query.append(_FINDER_COLUMN_CATID_CATID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(catId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(actItem);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActItem> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the act items where catId = &#63; from the database.
     *
     * @param catId the cat ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeBycatId(long catId) throws SystemException {
        for (ActItem actItem : findBycatId(catId, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(actItem);
        }
    }

    /**
     * Returns the number of act items where catId = &#63;.
     *
     * @param catId the cat ID
     * @return the number of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countBycatId(long catId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CATID;

        Object[] finderArgs = new Object[] { catId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_CATID_CATID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(catId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the act items where ActivateClid = &#63; and completed = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @return the matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByActidcompleted(long ActivateClid,
        boolean completed) throws SystemException {
        return findByActidcompleted(ActivateClid, completed, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the act items where ActivateClid = &#63; and completed = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @return the range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByActidcompleted(long ActivateClid,
        boolean completed, int start, int end) throws SystemException {
        return findByActidcompleted(ActivateClid, completed, start, end, null);
    }

    /**
     * Returns an ordered range of all the act items where ActivateClid = &#63; and completed = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByActidcompleted(long ActivateClid,
        boolean completed, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIDCOMPLETED;
            finderArgs = new Object[] { ActivateClid, completed };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTIDCOMPLETED;
            finderArgs = new Object[] {
                    ActivateClid, completed,
                    
                    start, end, orderByComparator
                };
        }

        List<ActItem> list = (List<ActItem>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActItem actItem : list) {
                if ((ActivateClid != actItem.getActivateClid()) ||
                        (completed != actItem.getCompleted())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_ACTIDCOMPLETED_ACTIVATECLID_2);

            query.append(_FINDER_COLUMN_ACTIDCOMPLETED_COMPLETED_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(ActivateClid);

                qPos.add(completed);

                if (!pagination) {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActItem>(list);
                } else {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByActidcompleted_First(long ActivateClid,
        boolean completed, OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByActidcompleted_First(ActivateClid, completed,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("ActivateClid=");
        msg.append(ActivateClid);

        msg.append(", completed=");
        msg.append(completed);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the first act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByActidcompleted_First(long ActivateClid,
        boolean completed, OrderByComparator orderByComparator)
        throws SystemException {
        List<ActItem> list = findByActidcompleted(ActivateClid, completed, 0,
                1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByActidcompleted_Last(long ActivateClid,
        boolean completed, OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByActidcompleted_Last(ActivateClid, completed,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("ActivateClid=");
        msg.append(ActivateClid);

        msg.append(", completed=");
        msg.append(completed);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the last act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByActidcompleted_Last(long ActivateClid,
        boolean completed, OrderByComparator orderByComparator)
        throws SystemException {
        int count = countByActidcompleted(ActivateClid, completed);

        if (count == 0) {
            return null;
        }

        List<ActItem> list = findByActidcompleted(ActivateClid, completed,
                count - 1, count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63; and completed = &#63;.
     *
     * @param ItemId the primary key of the current act item
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem[] findByActidcompleted_PrevAndNext(long ItemId,
        long ActivateClid, boolean completed,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = findByPrimaryKey(ItemId);

        Session session = null;

        try {
            session = openSession();

            ActItem[] array = new ActItemImpl[3];

            array[0] = getByActidcompleted_PrevAndNext(session, actItem,
                    ActivateClid, completed, orderByComparator, true);

            array[1] = actItem;

            array[2] = getByActidcompleted_PrevAndNext(session, actItem,
                    ActivateClid, completed, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActItem getByActidcompleted_PrevAndNext(Session session,
        ActItem actItem, long ActivateClid, boolean completed,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTITEM_WHERE);

        query.append(_FINDER_COLUMN_ACTIDCOMPLETED_ACTIVATECLID_2);

        query.append(_FINDER_COLUMN_ACTIDCOMPLETED_COMPLETED_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(ActivateClid);

        qPos.add(completed);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(actItem);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActItem> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the act items where ActivateClid = &#63; and completed = &#63; from the database.
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByActidcompleted(long ActivateClid, boolean completed)
        throws SystemException {
        for (ActItem actItem : findByActidcompleted(ActivateClid, completed,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(actItem);
        }
    }

    /**
     * Returns the number of act items where ActivateClid = &#63; and completed = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param completed the completed
     * @return the number of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByActidcompleted(long ActivateClid, boolean completed)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ACTIDCOMPLETED;

        Object[] finderArgs = new Object[] { ActivateClid, completed };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_ACTIDCOMPLETED_ACTIVATECLID_2);

            query.append(_FINDER_COLUMN_ACTIDCOMPLETED_COMPLETED_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(ActivateClid);

                qPos.add(completed);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the act items where ActivateClid = &#63; and catId = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @return the matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByactCLUncat(long ActivateClid, long catId)
        throws SystemException {
        return findByactCLUncat(ActivateClid, catId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the act items where ActivateClid = &#63; and catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @return the range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByactCLUncat(long ActivateClid, long catId,
        int start, int end) throws SystemException {
        return findByactCLUncat(ActivateClid, catId, start, end, null);
    }

    /**
     * Returns an ordered range of all the act items where ActivateClid = &#63; and catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findByactCLUncat(long ActivateClid, long catId,
        int start, int end, OrderByComparator orderByComparator)
        throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTCLUNCAT;
            finderArgs = new Object[] { ActivateClid, catId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTCLUNCAT;
            finderArgs = new Object[] {
                    ActivateClid, catId,
                    
                    start, end, orderByComparator
                };
        }

        List<ActItem> list = (List<ActItem>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActItem actItem : list) {
                if ((ActivateClid != actItem.getActivateClid()) ||
                        (catId != actItem.getCatId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_ACTCLUNCAT_ACTIVATECLID_2);

            query.append(_FINDER_COLUMN_ACTCLUNCAT_CATID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(ActivateClid);

                qPos.add(catId);

                if (!pagination) {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActItem>(list);
                } else {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByactCLUncat_First(long ActivateClid, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByactCLUncat_First(ActivateClid, catId,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("ActivateClid=");
        msg.append(ActivateClid);

        msg.append(", catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the first act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByactCLUncat_First(long ActivateClid, long catId,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActItem> list = findByactCLUncat(ActivateClid, catId, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByactCLUncat_Last(long ActivateClid, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByactCLUncat_Last(ActivateClid, catId,
                orderByComparator);

        if (actItem != null) {
            return actItem;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("ActivateClid=");
        msg.append(ActivateClid);

        msg.append(", catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActItemException(msg.toString());
    }

    /**
     * Returns the last act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching act item, or <code>null</code> if a matching act item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByactCLUncat_Last(long ActivateClid, long catId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByactCLUncat(ActivateClid, catId);

        if (count == 0) {
            return null;
        }

        List<ActItem> list = findByactCLUncat(ActivateClid, catId, count - 1,
                count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the act items before and after the current act item in the ordered set where ActivateClid = &#63; and catId = &#63;.
     *
     * @param ItemId the primary key of the current act item
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem[] findByactCLUncat_PrevAndNext(long ItemId,
        long ActivateClid, long catId, OrderByComparator orderByComparator)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = findByPrimaryKey(ItemId);

        Session session = null;

        try {
            session = openSession();

            ActItem[] array = new ActItemImpl[3];

            array[0] = getByactCLUncat_PrevAndNext(session, actItem,
                    ActivateClid, catId, orderByComparator, true);

            array[1] = actItem;

            array[2] = getByactCLUncat_PrevAndNext(session, actItem,
                    ActivateClid, catId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActItem getByactCLUncat_PrevAndNext(Session session,
        ActItem actItem, long ActivateClid, long catId,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTITEM_WHERE);

        query.append(_FINDER_COLUMN_ACTCLUNCAT_ACTIVATECLID_2);

        query.append(_FINDER_COLUMN_ACTCLUNCAT_CATID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(ActivateClid);

        qPos.add(catId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(actItem);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActItem> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the act items where ActivateClid = &#63; and catId = &#63; from the database.
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByactCLUncat(long ActivateClid, long catId)
        throws SystemException {
        for (ActItem actItem : findByactCLUncat(ActivateClid, catId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(actItem);
        }
    }

    /**
     * Returns the number of act items where ActivateClid = &#63; and catId = &#63;.
     *
     * @param ActivateClid the activate clid
     * @param catId the cat ID
     * @return the number of matching act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByactCLUncat(long ActivateClid, long catId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ACTCLUNCAT;

        Object[] finderArgs = new Object[] { ActivateClid, catId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_ACTITEM_WHERE);

            query.append(_FINDER_COLUMN_ACTCLUNCAT_ACTIVATECLID_2);

            query.append(_FINDER_COLUMN_ACTCLUNCAT_CATID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(ActivateClid);

                qPos.add(catId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the act item in the entity cache if it is enabled.
     *
     * @param actItem the act item
     */
    @Override
    public void cacheResult(ActItem actItem) {
        EntityCacheUtil.putResult(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemImpl.class, actItem.getPrimaryKey(), actItem);

        actItem.resetOriginalValues();
    }

    /**
     * Caches the act items in the entity cache if it is enabled.
     *
     * @param actItems the act items
     */
    @Override
    public void cacheResult(List<ActItem> actItems) {
        for (ActItem actItem : actItems) {
            if (EntityCacheUtil.getResult(
                        ActItemModelImpl.ENTITY_CACHE_ENABLED,
                        ActItemImpl.class, actItem.getPrimaryKey()) == null) {
                cacheResult(actItem);
            } else {
                actItem.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all act items.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(ActItemImpl.class.getName());
        }

        EntityCacheUtil.clearCache(ActItemImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the act item.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(ActItem actItem) {
        EntityCacheUtil.removeResult(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemImpl.class, actItem.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    @Override
    public void clearCache(List<ActItem> actItems) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (ActItem actItem : actItems) {
            EntityCacheUtil.removeResult(ActItemModelImpl.ENTITY_CACHE_ENABLED,
                ActItemImpl.class, actItem.getPrimaryKey());
        }
    }

    /**
     * Creates a new act item with the primary key. Does not add the act item to the database.
     *
     * @param ItemId the primary key for the new act item
     * @return the new act item
     */
    @Override
    public ActItem create(long ItemId) {
        ActItem actItem = new ActItemImpl();

        actItem.setNew(true);
        actItem.setPrimaryKey(ItemId);

        String uuid = PortalUUIDUtil.generate();

        actItem.setUuid(uuid);

        return actItem;
    }

    /**
     * Removes the act item with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param ItemId the primary key of the act item
     * @return the act item that was removed
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem remove(long ItemId)
        throws NoSuchActItemException, SystemException {
        return remove((Serializable) ItemId);
    }

    /**
     * Removes the act item with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the act item
     * @return the act item that was removed
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem remove(Serializable primaryKey)
        throws NoSuchActItemException, SystemException {
        Session session = null;

        try {
            session = openSession();

            ActItem actItem = (ActItem) session.get(ActItemImpl.class,
                    primaryKey);

            if (actItem == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchActItemException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(actItem);
        } catch (NoSuchActItemException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected ActItem removeImpl(ActItem actItem) throws SystemException {
        actItem = toUnwrappedModel(actItem);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(actItem)) {
                actItem = (ActItem) session.get(ActItemImpl.class,
                        actItem.getPrimaryKeyObj());
            }

            if (actItem != null) {
                session.delete(actItem);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (actItem != null) {
            clearCache(actItem);
        }

        return actItem;
    }

    @Override
    public ActItem updateImpl(org.digitalArmour.verifier.model.ActItem actItem)
        throws SystemException {
        actItem = toUnwrappedModel(actItem);

        boolean isNew = actItem.isNew();

        ActItemModelImpl actItemModelImpl = (ActItemModelImpl) actItem;

        if (Validator.isNull(actItem.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            actItem.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (actItem.isNew()) {
                session.save(actItem);

                actItem.setNew(false);
            } else {
                session.merge(actItem);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !ActItemModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((actItemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { actItemModelImpl.getOriginalUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { actItemModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }

            if ((actItemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPLETEDDATE.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        actItemModelImpl.getOriginalCompletedDate()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPLETEDDATE,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPLETEDDATE,
                    args);

                args = new Object[] { actItemModelImpl.getCompletedDate() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPLETEDDATE,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPLETEDDATE,
                    args);
            }

            if ((actItemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATECLID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        actItemModelImpl.getOriginalActivateClid()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTIVATECLID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATECLID,
                    args);

                args = new Object[] { actItemModelImpl.getActivateClid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTIVATECLID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATECLID,
                    args);
            }

            if ((actItemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { actItemModelImpl.getOriginalCatId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CATID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID,
                    args);

                args = new Object[] { actItemModelImpl.getCatId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CATID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID,
                    args);
            }

            if ((actItemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIDCOMPLETED.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        actItemModelImpl.getOriginalActivateClid(),
                        actItemModelImpl.getOriginalCompleted()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTIDCOMPLETED,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIDCOMPLETED,
                    args);

                args = new Object[] {
                        actItemModelImpl.getActivateClid(),
                        actItemModelImpl.getCompleted()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTIDCOMPLETED,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIDCOMPLETED,
                    args);
            }

            if ((actItemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTCLUNCAT.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        actItemModelImpl.getOriginalActivateClid(),
                        actItemModelImpl.getOriginalCatId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTCLUNCAT,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTCLUNCAT,
                    args);

                args = new Object[] {
                        actItemModelImpl.getActivateClid(),
                        actItemModelImpl.getCatId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTCLUNCAT,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTCLUNCAT,
                    args);
            }
        }

        EntityCacheUtil.putResult(ActItemModelImpl.ENTITY_CACHE_ENABLED,
            ActItemImpl.class, actItem.getPrimaryKey(), actItem);

        return actItem;
    }

    protected ActItem toUnwrappedModel(ActItem actItem) {
        if (actItem instanceof ActItemImpl) {
            return actItem;
        }

        ActItemImpl actItemImpl = new ActItemImpl();

        actItemImpl.setNew(actItem.isNew());
        actItemImpl.setPrimaryKey(actItem.getPrimaryKey());

        actItemImpl.setUuid(actItem.getUuid());
        actItemImpl.setItemId(actItem.getItemId());
        actItemImpl.setItemName(actItem.getItemName());
        actItemImpl.setItemDesc(actItem.getItemDesc());
        actItemImpl.setIgnore(actItem.isIgnore());
        actItemImpl.setIsMajor(actItem.isIsMajor());
        actItemImpl.setPercentage(actItem.getPercentage());
        actItemImpl.setCompletedDate(actItem.getCompletedDate());
        actItemImpl.setCompleted(actItem.isCompleted());
        actItemImpl.setActivateClid(actItem.getActivateClid());
        actItemImpl.setUsergroupId(actItem.getUsergroupId());
        actItemImpl.setMajor(actItem.isMajor());
        actItemImpl.setMajor_percent(actItem.getMajor_percent());
        actItemImpl.setCatId(actItem.getCatId());
        actItemImpl.setUserId(actItem.getUserId());

        return actItemImpl;
    }

    /**
     * Returns the act item with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the act item
     * @return the act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByPrimaryKey(Serializable primaryKey)
        throws NoSuchActItemException, SystemException {
        ActItem actItem = fetchByPrimaryKey(primaryKey);

        if (actItem == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchActItemException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return actItem;
    }

    /**
     * Returns the act item with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActItemException} if it could not be found.
     *
     * @param ItemId the primary key of the act item
     * @return the act item
     * @throws org.digitalArmour.verifier.NoSuchActItemException if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem findByPrimaryKey(long ItemId)
        throws NoSuchActItemException, SystemException {
        return findByPrimaryKey((Serializable) ItemId);
    }

    /**
     * Returns the act item with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the act item
     * @return the act item, or <code>null</code> if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        ActItem actItem = (ActItem) EntityCacheUtil.getResult(ActItemModelImpl.ENTITY_CACHE_ENABLED,
                ActItemImpl.class, primaryKey);

        if (actItem == _nullActItem) {
            return null;
        }

        if (actItem == null) {
            Session session = null;

            try {
                session = openSession();

                actItem = (ActItem) session.get(ActItemImpl.class, primaryKey);

                if (actItem != null) {
                    cacheResult(actItem);
                } else {
                    EntityCacheUtil.putResult(ActItemModelImpl.ENTITY_CACHE_ENABLED,
                        ActItemImpl.class, primaryKey, _nullActItem);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(ActItemModelImpl.ENTITY_CACHE_ENABLED,
                    ActItemImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return actItem;
    }

    /**
     * Returns the act item with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param ItemId the primary key of the act item
     * @return the act item, or <code>null</code> if a act item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActItem fetchByPrimaryKey(long ItemId) throws SystemException {
        return fetchByPrimaryKey((Serializable) ItemId);
    }

    /**
     * Returns all the act items.
     *
     * @return the act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the act items.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @return the range of act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findAll(int start, int end) throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the act items.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of act items
     * @param end the upper bound of the range of act items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActItem> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<ActItem> list = (List<ActItem>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_ACTITEM);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_ACTITEM;

                if (pagination) {
                    sql = sql.concat(ActItemModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActItem>(list);
                } else {
                    list = (List<ActItem>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the act items from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (ActItem actItem : findAll()) {
            remove(actItem);
        }
    }

    /**
     * Returns the number of act items.
     *
     * @return the number of act items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_ACTITEM);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the act item persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.ActItem")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<ActItem>> listenersList = new ArrayList<ModelListener<ActItem>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<ActItem>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(ActItemImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
