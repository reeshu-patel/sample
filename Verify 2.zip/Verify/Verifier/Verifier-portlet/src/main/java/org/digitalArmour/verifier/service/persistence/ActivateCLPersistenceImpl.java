package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchActivateCLException;
import org.digitalArmour.verifier.model.ActivateCL;
import org.digitalArmour.verifier.model.impl.ActivateCLImpl;
import org.digitalArmour.verifier.model.impl.ActivateCLModelImpl;
import org.digitalArmour.verifier.service.persistence.ActivateCLPersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the activate c l service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ActivateCLPersistence
 * @see ActivateCLUtil
 * @generated
 */
public class ActivateCLPersistenceImpl extends BasePersistenceImpl<ActivateCL>
    implements ActivateCLPersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link ActivateCLUtil} to access the activate c l persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = ActivateCLImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            ActivateCLModelImpl.UUID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "activateCL.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "activateCL.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(activateCL.uuid IS NULL OR activateCL.uuid = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKLISTID =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycheckListId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycheckListId",
            new String[] { Long.class.getName() },
            ActivateCLModelImpl.CHECKLISTID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CHECKLISTID = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycheckListId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2 = "activateCL.checklistId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CLNAME = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByclName",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByclName",
            new String[] { String.class.getName() },
            ActivateCLModelImpl.CLNAME_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CLNAME = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByclName",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_CLNAME_CLNAME_1 = "activateCL.clName IS NULL";
    private static final String _FINDER_COLUMN_CLNAME_CLNAME_2 = "activateCL.clName = ?";
    private static final String _FINDER_COLUMN_CLNAME_CLNAME_3 = "(activateCL.clName IS NULL OR activateCL.clName = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ISCOMPLETED =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByisCompleted",
            new String[] {
                Boolean.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPLETED =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByisCompleted",
            new String[] { Boolean.class.getName() },
            ActivateCLModelImpl.ISCOMPLETED_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ISCOMPLETED = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByisCompleted",
            new String[] { Boolean.class.getName() });
    private static final String _FINDER_COLUMN_ISCOMPLETED_ISCOMPLETED_2 = "activateCL.isCompleted = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTIVATEID =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByactivateId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATEID =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByactivateId",
            new String[] { Long.class.getName() },
            ActivateCLModelImpl.ACTIVATEID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ACTIVATEID = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByactivateId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_ACTIVATEID_ACTIVATEID_2 = "activateCL.activateId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ISCOMPCHECK =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByisCompCheck",
            new String[] {
                Boolean.class.getName(), Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPCHECK =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByisCompCheck",
            new String[] { Boolean.class.getName(), Long.class.getName() },
            ActivateCLModelImpl.ISCOMPLETED_COLUMN_BITMASK |
            ActivateCLModelImpl.CHECKLISTID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ISCOMPCHECK = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByisCompCheck",
            new String[] { Boolean.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_ISCOMPCHECK_ISCOMPLETED_2 = "activateCL.isCompleted = ? AND ";
    private static final String _FINDER_COLUMN_ISCOMPCHECK_CHECKLISTID_2 = "activateCL.checklistId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ISCOMPUSER =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByisCompUser",
            new String[] {
                Boolean.class.getName(), Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPUSER =
        new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, ActivateCLImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByisCompUser",
            new String[] { Boolean.class.getName(), Long.class.getName() },
            ActivateCLModelImpl.ISCOMPLETED_COLUMN_BITMASK |
            ActivateCLModelImpl.ACTCLUSERID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ISCOMPUSER = new FinderPath(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByisCompUser",
            new String[] { Boolean.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_ISCOMPUSER_ISCOMPLETED_2 = "activateCL.isCompleted = ? AND ";
    private static final String _FINDER_COLUMN_ISCOMPUSER_ACTCLUSERID_2 = "activateCL.actClUserId = ?";
    private static final String _SQL_SELECT_ACTIVATECL = "SELECT activateCL FROM ActivateCL activateCL";
    private static final String _SQL_SELECT_ACTIVATECL_WHERE = "SELECT activateCL FROM ActivateCL activateCL WHERE ";
    private static final String _SQL_COUNT_ACTIVATECL = "SELECT COUNT(activateCL) FROM ActivateCL activateCL";
    private static final String _SQL_COUNT_ACTIVATECL_WHERE = "SELECT COUNT(activateCL) FROM ActivateCL activateCL WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "activateCL.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No ActivateCL exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No ActivateCL exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(ActivateCLPersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid"
            });
    private static ActivateCL _nullActivateCL = new ActivateCLImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<ActivateCL> toCacheModel() {
                return _nullActivateCLCacheModel;
            }
        };

    private static CacheModel<ActivateCL> _nullActivateCLCacheModel = new CacheModel<ActivateCL>() {
            @Override
            public ActivateCL toEntityModel() {
                return _nullActivateCL;
            }
        };

    public ActivateCLPersistenceImpl() {
        setModelClass(ActivateCL.class);
    }

    /**
     * Returns all the activate c ls where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActivateCL activateCL : list) {
                if (!Validator.equals(uuid, activateCL.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTIVATECL_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first activate c l in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByUuid_First(uuid, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the first activate c l in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActivateCL> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last activate c l in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByUuid_Last(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByUuid_Last(uuid, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the last activate c l in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<ActivateCL> list = findByUuid(uuid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the activate c ls before and after the current activate c l in the ordered set where uuid = &#63;.
     *
     * @param activateId the primary key of the current activate c l
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL[] findByUuid_PrevAndNext(long activateId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = findByPrimaryKey(activateId);

        Session session = null;

        try {
            session = openSession();

            ActivateCL[] array = new ActivateCLImpl[3];

            array[0] = getByUuid_PrevAndNext(session, activateCL, uuid,
                    orderByComparator, true);

            array[1] = activateCL;

            array[2] = getByUuid_PrevAndNext(session, activateCL, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActivateCL getByUuid_PrevAndNext(Session session,
        ActivateCL activateCL, String uuid,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTIVATECL_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(activateCL);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActivateCL> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the activate c ls where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (ActivateCL activateCL : findByUuid(uuid, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTIVATECL_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the activate c ls where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @return the matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findBycheckListId(long checklistId)
        throws SystemException {
        return findBycheckListId(checklistId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls where checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findBycheckListId(long checklistId, int start,
        int end) throws SystemException {
        return findBycheckListId(checklistId, start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls where checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findBycheckListId(long checklistId, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID;
            finderArgs = new Object[] { checklistId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKLISTID;
            finderArgs = new Object[] { checklistId, start, end, orderByComparator };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActivateCL activateCL : list) {
                if ((checklistId != activateCL.getChecklistId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first activate c l in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findBycheckListId_First(long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchBycheckListId_First(checklistId,
                orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the first activate c l in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchBycheckListId_First(long checklistId,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActivateCL> list = findBycheckListId(checklistId, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last activate c l in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findBycheckListId_Last(long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchBycheckListId_Last(checklistId,
                orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the last activate c l in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchBycheckListId_Last(long checklistId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countBycheckListId(checklistId);

        if (count == 0) {
            return null;
        }

        List<ActivateCL> list = findBycheckListId(checklistId, count - 1,
                count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the activate c ls before and after the current activate c l in the ordered set where checklistId = &#63;.
     *
     * @param activateId the primary key of the current activate c l
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL[] findBycheckListId_PrevAndNext(long activateId,
        long checklistId, OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = findByPrimaryKey(activateId);

        Session session = null;

        try {
            session = openSession();

            ActivateCL[] array = new ActivateCLImpl[3];

            array[0] = getBycheckListId_PrevAndNext(session, activateCL,
                    checklistId, orderByComparator, true);

            array[1] = activateCL;

            array[2] = getBycheckListId_PrevAndNext(session, activateCL,
                    checklistId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActivateCL getBycheckListId_PrevAndNext(Session session,
        ActivateCL activateCL, long checklistId,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTIVATECL_WHERE);

        query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(checklistId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(activateCL);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActivateCL> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the activate c ls where checklistId = &#63; from the database.
     *
     * @param checklistId the checklist ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeBycheckListId(long checklistId) throws SystemException {
        for (ActivateCL activateCL : findBycheckListId(checklistId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @return the number of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countBycheckListId(long checklistId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CHECKLISTID;

        Object[] finderArgs = new Object[] { checklistId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the activate c ls where clName = &#63;.
     *
     * @param clName the cl name
     * @return the matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByclName(String clName)
        throws SystemException {
        return findByclName(clName, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls where clName = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param clName the cl name
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByclName(String clName, int start, int end)
        throws SystemException {
        return findByclName(clName, start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls where clName = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param clName the cl name
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByclName(String clName, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME;
            finderArgs = new Object[] { clName };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CLNAME;
            finderArgs = new Object[] { clName, start, end, orderByComparator };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActivateCL activateCL : list) {
                if (!Validator.equals(clName, activateCL.getClName())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTIVATECL_WHERE);

            boolean bindClName = false;

            if (clName == null) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_1);
            } else if (clName.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_3);
            } else {
                bindClName = true;

                query.append(_FINDER_COLUMN_CLNAME_CLNAME_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindClName) {
                    qPos.add(clName);
                }

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first activate c l in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByclName_First(String clName,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByclName_First(clName, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("clName=");
        msg.append(clName);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the first activate c l in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByclName_First(String clName,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActivateCL> list = findByclName(clName, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last activate c l in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByclName_Last(String clName,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByclName_Last(clName, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("clName=");
        msg.append(clName);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the last activate c l in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByclName_Last(String clName,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByclName(clName);

        if (count == 0) {
            return null;
        }

        List<ActivateCL> list = findByclName(clName, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the activate c ls before and after the current activate c l in the ordered set where clName = &#63;.
     *
     * @param activateId the primary key of the current activate c l
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL[] findByclName_PrevAndNext(long activateId,
        String clName, OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = findByPrimaryKey(activateId);

        Session session = null;

        try {
            session = openSession();

            ActivateCL[] array = new ActivateCLImpl[3];

            array[0] = getByclName_PrevAndNext(session, activateCL, clName,
                    orderByComparator, true);

            array[1] = activateCL;

            array[2] = getByclName_PrevAndNext(session, activateCL, clName,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActivateCL getByclName_PrevAndNext(Session session,
        ActivateCL activateCL, String clName,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTIVATECL_WHERE);

        boolean bindClName = false;

        if (clName == null) {
            query.append(_FINDER_COLUMN_CLNAME_CLNAME_1);
        } else if (clName.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_CLNAME_CLNAME_3);
        } else {
            bindClName = true;

            query.append(_FINDER_COLUMN_CLNAME_CLNAME_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindClName) {
            qPos.add(clName);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(activateCL);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActivateCL> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the activate c ls where clName = &#63; from the database.
     *
     * @param clName the cl name
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByclName(String clName) throws SystemException {
        for (ActivateCL activateCL : findByclName(clName, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls where clName = &#63;.
     *
     * @param clName the cl name
     * @return the number of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByclName(String clName) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CLNAME;

        Object[] finderArgs = new Object[] { clName };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTIVATECL_WHERE);

            boolean bindClName = false;

            if (clName == null) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_1);
            } else if (clName.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_3);
            } else {
                bindClName = true;

                query.append(_FINDER_COLUMN_CLNAME_CLNAME_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindClName) {
                    qPos.add(clName);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the activate c ls where isCompleted = &#63;.
     *
     * @param isCompleted the is completed
     * @return the matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompleted(boolean isCompleted)
        throws SystemException {
        return findByisCompleted(isCompleted, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls where isCompleted = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isCompleted the is completed
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompleted(boolean isCompleted, int start,
        int end) throws SystemException {
        return findByisCompleted(isCompleted, start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls where isCompleted = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isCompleted the is completed
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompleted(boolean isCompleted, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPLETED;
            finderArgs = new Object[] { isCompleted };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ISCOMPLETED;
            finderArgs = new Object[] { isCompleted, start, end, orderByComparator };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActivateCL activateCL : list) {
                if ((isCompleted != activateCL.getIsCompleted())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ISCOMPLETED_ISCOMPLETED_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isCompleted);

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first activate c l in the ordered set where isCompleted = &#63;.
     *
     * @param isCompleted the is completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByisCompleted_First(boolean isCompleted,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByisCompleted_First(isCompleted,
                orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isCompleted=");
        msg.append(isCompleted);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the first activate c l in the ordered set where isCompleted = &#63;.
     *
     * @param isCompleted the is completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByisCompleted_First(boolean isCompleted,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActivateCL> list = findByisCompleted(isCompleted, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last activate c l in the ordered set where isCompleted = &#63;.
     *
     * @param isCompleted the is completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByisCompleted_Last(boolean isCompleted,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByisCompleted_Last(isCompleted,
                orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isCompleted=");
        msg.append(isCompleted);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the last activate c l in the ordered set where isCompleted = &#63;.
     *
     * @param isCompleted the is completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByisCompleted_Last(boolean isCompleted,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByisCompleted(isCompleted);

        if (count == 0) {
            return null;
        }

        List<ActivateCL> list = findByisCompleted(isCompleted, count - 1,
                count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63;.
     *
     * @param activateId the primary key of the current activate c l
     * @param isCompleted the is completed
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL[] findByisCompleted_PrevAndNext(long activateId,
        boolean isCompleted, OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = findByPrimaryKey(activateId);

        Session session = null;

        try {
            session = openSession();

            ActivateCL[] array = new ActivateCLImpl[3];

            array[0] = getByisCompleted_PrevAndNext(session, activateCL,
                    isCompleted, orderByComparator, true);

            array[1] = activateCL;

            array[2] = getByisCompleted_PrevAndNext(session, activateCL,
                    isCompleted, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActivateCL getByisCompleted_PrevAndNext(Session session,
        ActivateCL activateCL, boolean isCompleted,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTIVATECL_WHERE);

        query.append(_FINDER_COLUMN_ISCOMPLETED_ISCOMPLETED_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(isCompleted);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(activateCL);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActivateCL> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the activate c ls where isCompleted = &#63; from the database.
     *
     * @param isCompleted the is completed
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByisCompleted(boolean isCompleted)
        throws SystemException {
        for (ActivateCL activateCL : findByisCompleted(isCompleted,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls where isCompleted = &#63;.
     *
     * @param isCompleted the is completed
     * @return the number of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByisCompleted(boolean isCompleted)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ISCOMPLETED;

        Object[] finderArgs = new Object[] { isCompleted };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ISCOMPLETED_ISCOMPLETED_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isCompleted);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the activate c ls where activateId = &#63;.
     *
     * @param activateId the activate ID
     * @return the matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByactivateId(long activateId)
        throws SystemException {
        return findByactivateId(activateId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls where activateId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param activateId the activate ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByactivateId(long activateId, int start, int end)
        throws SystemException {
        return findByactivateId(activateId, start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls where activateId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param activateId the activate ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByactivateId(long activateId, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATEID;
            finderArgs = new Object[] { activateId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ACTIVATEID;
            finderArgs = new Object[] { activateId, start, end, orderByComparator };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActivateCL activateCL : list) {
                if ((activateId != activateCL.getActivateId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ACTIVATEID_ACTIVATEID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(activateId);

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first activate c l in the ordered set where activateId = &#63;.
     *
     * @param activateId the activate ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByactivateId_First(long activateId,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByactivateId_First(activateId,
                orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("activateId=");
        msg.append(activateId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the first activate c l in the ordered set where activateId = &#63;.
     *
     * @param activateId the activate ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByactivateId_First(long activateId,
        OrderByComparator orderByComparator) throws SystemException {
        List<ActivateCL> list = findByactivateId(activateId, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last activate c l in the ordered set where activateId = &#63;.
     *
     * @param activateId the activate ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByactivateId_Last(long activateId,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByactivateId_Last(activateId,
                orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("activateId=");
        msg.append(activateId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the last activate c l in the ordered set where activateId = &#63;.
     *
     * @param activateId the activate ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByactivateId_Last(long activateId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByactivateId(activateId);

        if (count == 0) {
            return null;
        }

        List<ActivateCL> list = findByactivateId(activateId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Removes all the activate c ls where activateId = &#63; from the database.
     *
     * @param activateId the activate ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByactivateId(long activateId) throws SystemException {
        for (ActivateCL activateCL : findByactivateId(activateId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls where activateId = &#63;.
     *
     * @param activateId the activate ID
     * @return the number of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByactivateId(long activateId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ACTIVATEID;

        Object[] finderArgs = new Object[] { activateId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ACTIVATEID_ACTIVATEID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(activateId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @return the matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompCheck(boolean isCompleted,
        long checklistId) throws SystemException {
        return findByisCompCheck(isCompleted, checklistId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompCheck(boolean isCompleted,
        long checklistId, int start, int end) throws SystemException {
        return findByisCompCheck(isCompleted, checklistId, start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls where isCompleted = &#63; and checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompCheck(boolean isCompleted,
        long checklistId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPCHECK;
            finderArgs = new Object[] { isCompleted, checklistId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ISCOMPCHECK;
            finderArgs = new Object[] {
                    isCompleted, checklistId,
                    
                    start, end, orderByComparator
                };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActivateCL activateCL : list) {
                if ((isCompleted != activateCL.getIsCompleted()) ||
                        (checklistId != activateCL.getChecklistId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ISCOMPCHECK_ISCOMPLETED_2);

            query.append(_FINDER_COLUMN_ISCOMPCHECK_CHECKLISTID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isCompleted);

                qPos.add(checklistId);

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByisCompCheck_First(boolean isCompleted,
        long checklistId, OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByisCompCheck_First(isCompleted,
                checklistId, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isCompleted=");
        msg.append(isCompleted);

        msg.append(", checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the first activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByisCompCheck_First(boolean isCompleted,
        long checklistId, OrderByComparator orderByComparator)
        throws SystemException {
        List<ActivateCL> list = findByisCompCheck(isCompleted, checklistId, 0,
                1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByisCompCheck_Last(boolean isCompleted,
        long checklistId, OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByisCompCheck_Last(isCompleted,
                checklistId, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isCompleted=");
        msg.append(isCompleted);

        msg.append(", checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the last activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByisCompCheck_Last(boolean isCompleted,
        long checklistId, OrderByComparator orderByComparator)
        throws SystemException {
        int count = countByisCompCheck(isCompleted, checklistId);

        if (count == 0) {
            return null;
        }

        List<ActivateCL> list = findByisCompCheck(isCompleted, checklistId,
                count - 1, count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63; and checklistId = &#63;.
     *
     * @param activateId the primary key of the current activate c l
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL[] findByisCompCheck_PrevAndNext(long activateId,
        boolean isCompleted, long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = findByPrimaryKey(activateId);

        Session session = null;

        try {
            session = openSession();

            ActivateCL[] array = new ActivateCLImpl[3];

            array[0] = getByisCompCheck_PrevAndNext(session, activateCL,
                    isCompleted, checklistId, orderByComparator, true);

            array[1] = activateCL;

            array[2] = getByisCompCheck_PrevAndNext(session, activateCL,
                    isCompleted, checklistId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActivateCL getByisCompCheck_PrevAndNext(Session session,
        ActivateCL activateCL, boolean isCompleted, long checklistId,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTIVATECL_WHERE);

        query.append(_FINDER_COLUMN_ISCOMPCHECK_ISCOMPLETED_2);

        query.append(_FINDER_COLUMN_ISCOMPCHECK_CHECKLISTID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(isCompleted);

        qPos.add(checklistId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(activateCL);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActivateCL> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the activate c ls where isCompleted = &#63; and checklistId = &#63; from the database.
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByisCompCheck(boolean isCompleted, long checklistId)
        throws SystemException {
        for (ActivateCL activateCL : findByisCompCheck(isCompleted,
                checklistId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls where isCompleted = &#63; and checklistId = &#63;.
     *
     * @param isCompleted the is completed
     * @param checklistId the checklist ID
     * @return the number of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByisCompCheck(boolean isCompleted, long checklistId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ISCOMPCHECK;

        Object[] finderArgs = new Object[] { isCompleted, checklistId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ISCOMPCHECK_ISCOMPLETED_2);

            query.append(_FINDER_COLUMN_ISCOMPCHECK_CHECKLISTID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isCompleted);

                qPos.add(checklistId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @return the matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompUser(boolean isCompleted,
        long actClUserId) throws SystemException {
        return findByisCompUser(isCompleted, actClUserId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompUser(boolean isCompleted,
        long actClUserId, int start, int end) throws SystemException {
        return findByisCompUser(isCompleted, actClUserId, start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls where isCompleted = &#63; and actClUserId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findByisCompUser(boolean isCompleted,
        long actClUserId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPUSER;
            finderArgs = new Object[] { isCompleted, actClUserId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ISCOMPUSER;
            finderArgs = new Object[] {
                    isCompleted, actClUserId,
                    
                    start, end, orderByComparator
                };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ActivateCL activateCL : list) {
                if ((isCompleted != activateCL.getIsCompleted()) ||
                        (actClUserId != activateCL.getActClUserId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ISCOMPUSER_ISCOMPLETED_2);

            query.append(_FINDER_COLUMN_ISCOMPUSER_ACTCLUSERID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isCompleted);

                qPos.add(actClUserId);

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByisCompUser_First(boolean isCompleted,
        long actClUserId, OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByisCompUser_First(isCompleted,
                actClUserId, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isCompleted=");
        msg.append(isCompleted);

        msg.append(", actClUserId=");
        msg.append(actClUserId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the first activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByisCompUser_First(boolean isCompleted,
        long actClUserId, OrderByComparator orderByComparator)
        throws SystemException {
        List<ActivateCL> list = findByisCompUser(isCompleted, actClUserId, 0,
                1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByisCompUser_Last(boolean isCompleted,
        long actClUserId, OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByisCompUser_Last(isCompleted,
                actClUserId, orderByComparator);

        if (activateCL != null) {
            return activateCL;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isCompleted=");
        msg.append(isCompleted);

        msg.append(", actClUserId=");
        msg.append(actClUserId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchActivateCLException(msg.toString());
    }

    /**
     * Returns the last activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching activate c l, or <code>null</code> if a matching activate c l could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByisCompUser_Last(boolean isCompleted,
        long actClUserId, OrderByComparator orderByComparator)
        throws SystemException {
        int count = countByisCompUser(isCompleted, actClUserId);

        if (count == 0) {
            return null;
        }

        List<ActivateCL> list = findByisCompUser(isCompleted, actClUserId,
                count - 1, count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the activate c ls before and after the current activate c l in the ordered set where isCompleted = &#63; and actClUserId = &#63;.
     *
     * @param activateId the primary key of the current activate c l
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL[] findByisCompUser_PrevAndNext(long activateId,
        boolean isCompleted, long actClUserId,
        OrderByComparator orderByComparator)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = findByPrimaryKey(activateId);

        Session session = null;

        try {
            session = openSession();

            ActivateCL[] array = new ActivateCLImpl[3];

            array[0] = getByisCompUser_PrevAndNext(session, activateCL,
                    isCompleted, actClUserId, orderByComparator, true);

            array[1] = activateCL;

            array[2] = getByisCompUser_PrevAndNext(session, activateCL,
                    isCompleted, actClUserId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ActivateCL getByisCompUser_PrevAndNext(Session session,
        ActivateCL activateCL, boolean isCompleted, long actClUserId,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ACTIVATECL_WHERE);

        query.append(_FINDER_COLUMN_ISCOMPUSER_ISCOMPLETED_2);

        query.append(_FINDER_COLUMN_ISCOMPUSER_ACTCLUSERID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ActivateCLModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(isCompleted);

        qPos.add(actClUserId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(activateCL);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ActivateCL> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the activate c ls where isCompleted = &#63; and actClUserId = &#63; from the database.
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByisCompUser(boolean isCompleted, long actClUserId)
        throws SystemException {
        for (ActivateCL activateCL : findByisCompUser(isCompleted, actClUserId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls where isCompleted = &#63; and actClUserId = &#63;.
     *
     * @param isCompleted the is completed
     * @param actClUserId the act cl user ID
     * @return the number of matching activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByisCompUser(boolean isCompleted, long actClUserId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ISCOMPUSER;

        Object[] finderArgs = new Object[] { isCompleted, actClUserId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_ACTIVATECL_WHERE);

            query.append(_FINDER_COLUMN_ISCOMPUSER_ISCOMPLETED_2);

            query.append(_FINDER_COLUMN_ISCOMPUSER_ACTCLUSERID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isCompleted);

                qPos.add(actClUserId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the activate c l in the entity cache if it is enabled.
     *
     * @param activateCL the activate c l
     */
    @Override
    public void cacheResult(ActivateCL activateCL) {
        EntityCacheUtil.putResult(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLImpl.class, activateCL.getPrimaryKey(), activateCL);

        activateCL.resetOriginalValues();
    }

    /**
     * Caches the activate c ls in the entity cache if it is enabled.
     *
     * @param activateCLs the activate c ls
     */
    @Override
    public void cacheResult(List<ActivateCL> activateCLs) {
        for (ActivateCL activateCL : activateCLs) {
            if (EntityCacheUtil.getResult(
                        ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
                        ActivateCLImpl.class, activateCL.getPrimaryKey()) == null) {
                cacheResult(activateCL);
            } else {
                activateCL.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all activate c ls.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(ActivateCLImpl.class.getName());
        }

        EntityCacheUtil.clearCache(ActivateCLImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the activate c l.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(ActivateCL activateCL) {
        EntityCacheUtil.removeResult(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLImpl.class, activateCL.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    @Override
    public void clearCache(List<ActivateCL> activateCLs) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (ActivateCL activateCL : activateCLs) {
            EntityCacheUtil.removeResult(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
                ActivateCLImpl.class, activateCL.getPrimaryKey());
        }
    }

    /**
     * Creates a new activate c l with the primary key. Does not add the activate c l to the database.
     *
     * @param activateId the primary key for the new activate c l
     * @return the new activate c l
     */
    @Override
    public ActivateCL create(long activateId) {
        ActivateCL activateCL = new ActivateCLImpl();

        activateCL.setNew(true);
        activateCL.setPrimaryKey(activateId);

        String uuid = PortalUUIDUtil.generate();

        activateCL.setUuid(uuid);

        return activateCL;
    }

    /**
     * Removes the activate c l with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param activateId the primary key of the activate c l
     * @return the activate c l that was removed
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL remove(long activateId)
        throws NoSuchActivateCLException, SystemException {
        return remove((Serializable) activateId);
    }

    /**
     * Removes the activate c l with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the activate c l
     * @return the activate c l that was removed
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL remove(Serializable primaryKey)
        throws NoSuchActivateCLException, SystemException {
        Session session = null;

        try {
            session = openSession();

            ActivateCL activateCL = (ActivateCL) session.get(ActivateCLImpl.class,
                    primaryKey);

            if (activateCL == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchActivateCLException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(activateCL);
        } catch (NoSuchActivateCLException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected ActivateCL removeImpl(ActivateCL activateCL)
        throws SystemException {
        activateCL = toUnwrappedModel(activateCL);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(activateCL)) {
                activateCL = (ActivateCL) session.get(ActivateCLImpl.class,
                        activateCL.getPrimaryKeyObj());
            }

            if (activateCL != null) {
                session.delete(activateCL);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (activateCL != null) {
            clearCache(activateCL);
        }

        return activateCL;
    }

    @Override
    public ActivateCL updateImpl(
        org.digitalArmour.verifier.model.ActivateCL activateCL)
        throws SystemException {
        activateCL = toUnwrappedModel(activateCL);

        boolean isNew = activateCL.isNew();

        ActivateCLModelImpl activateCLModelImpl = (ActivateCLModelImpl) activateCL;

        if (Validator.isNull(activateCL.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            activateCL.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (activateCL.isNew()) {
                session.save(activateCL);

                activateCL.setNew(false);
            } else {
                session.merge(activateCL);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !ActivateCLModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((activateCLModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        activateCLModelImpl.getOriginalUuid()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { activateCLModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }

            if ((activateCLModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        activateCLModelImpl.getOriginalChecklistId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKLISTID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID,
                    args);

                args = new Object[] { activateCLModelImpl.getChecklistId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKLISTID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID,
                    args);
            }

            if ((activateCLModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        activateCLModelImpl.getOriginalClName()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CLNAME, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME,
                    args);

                args = new Object[] { activateCLModelImpl.getClName() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CLNAME, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME,
                    args);
            }

            if ((activateCLModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPLETED.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        activateCLModelImpl.getOriginalIsCompleted()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISCOMPLETED,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPLETED,
                    args);

                args = new Object[] { activateCLModelImpl.getIsCompleted() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISCOMPLETED,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPLETED,
                    args);
            }

            if ((activateCLModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATEID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        activateCLModelImpl.getOriginalActivateId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTIVATEID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATEID,
                    args);

                args = new Object[] { activateCLModelImpl.getActivateId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ACTIVATEID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ACTIVATEID,
                    args);
            }

            if ((activateCLModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPCHECK.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        activateCLModelImpl.getOriginalIsCompleted(),
                        activateCLModelImpl.getOriginalChecklistId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISCOMPCHECK,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPCHECK,
                    args);

                args = new Object[] {
                        activateCLModelImpl.getIsCompleted(),
                        activateCLModelImpl.getChecklistId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISCOMPCHECK,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPCHECK,
                    args);
            }

            if ((activateCLModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPUSER.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        activateCLModelImpl.getOriginalIsCompleted(),
                        activateCLModelImpl.getOriginalActClUserId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISCOMPUSER,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPUSER,
                    args);

                args = new Object[] {
                        activateCLModelImpl.getIsCompleted(),
                        activateCLModelImpl.getActClUserId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISCOMPUSER,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISCOMPUSER,
                    args);
            }
        }

        EntityCacheUtil.putResult(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
            ActivateCLImpl.class, activateCL.getPrimaryKey(), activateCL);

        return activateCL;
    }

    protected ActivateCL toUnwrappedModel(ActivateCL activateCL) {
        if (activateCL instanceof ActivateCLImpl) {
            return activateCL;
        }

        ActivateCLImpl activateCLImpl = new ActivateCLImpl();

        activateCLImpl.setNew(activateCL.isNew());
        activateCLImpl.setPrimaryKey(activateCL.getPrimaryKey());

        activateCLImpl.setUuid(activateCL.getUuid());
        activateCLImpl.setActivateId(activateCL.getActivateId());
        activateCLImpl.setChecklistId(activateCL.getChecklistId());
        activateCLImpl.setClName(activateCL.getClName());
        activateCLImpl.setClDescription(activateCL.getClDescription());
        activateCLImpl.setOrganiztion(activateCL.getOrganiztion());
        activateCLImpl.setIsPublic(activateCL.isIsPublic());
        activateCLImpl.setIsCompleted(activateCL.isIsCompleted());
        activateCLImpl.setCompletedDate(activateCL.getCompletedDate());
        activateCLImpl.setActClUserId(activateCL.getActClUserId());

        return activateCLImpl;
    }

    /**
     * Returns the activate c l with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the activate c l
     * @return the activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByPrimaryKey(Serializable primaryKey)
        throws NoSuchActivateCLException, SystemException {
        ActivateCL activateCL = fetchByPrimaryKey(primaryKey);

        if (activateCL == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchActivateCLException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return activateCL;
    }

    /**
     * Returns the activate c l with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchActivateCLException} if it could not be found.
     *
     * @param activateId the primary key of the activate c l
     * @return the activate c l
     * @throws org.digitalArmour.verifier.NoSuchActivateCLException if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL findByPrimaryKey(long activateId)
        throws NoSuchActivateCLException, SystemException {
        return findByPrimaryKey((Serializable) activateId);
    }

    /**
     * Returns the activate c l with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the activate c l
     * @return the activate c l, or <code>null</code> if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        ActivateCL activateCL = (ActivateCL) EntityCacheUtil.getResult(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
                ActivateCLImpl.class, primaryKey);

        if (activateCL == _nullActivateCL) {
            return null;
        }

        if (activateCL == null) {
            Session session = null;

            try {
                session = openSession();

                activateCL = (ActivateCL) session.get(ActivateCLImpl.class,
                        primaryKey);

                if (activateCL != null) {
                    cacheResult(activateCL);
                } else {
                    EntityCacheUtil.putResult(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
                        ActivateCLImpl.class, primaryKey, _nullActivateCL);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(ActivateCLModelImpl.ENTITY_CACHE_ENABLED,
                    ActivateCLImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return activateCL;
    }

    /**
     * Returns the activate c l with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param activateId the primary key of the activate c l
     * @return the activate c l, or <code>null</code> if a activate c l with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ActivateCL fetchByPrimaryKey(long activateId)
        throws SystemException {
        return fetchByPrimaryKey((Serializable) activateId);
    }

    /**
     * Returns all the activate c ls.
     *
     * @return the activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the activate c ls.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @return the range of activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findAll(int start, int end)
        throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the activate c ls.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ActivateCLModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of activate c ls
     * @param end the upper bound of the range of activate c ls (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ActivateCL> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<ActivateCL> list = (List<ActivateCL>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_ACTIVATECL);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_ACTIVATECL;

                if (pagination) {
                    sql = sql.concat(ActivateCLModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ActivateCL>(list);
                } else {
                    list = (List<ActivateCL>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the activate c ls from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (ActivateCL activateCL : findAll()) {
            remove(activateCL);
        }
    }

    /**
     * Returns the number of activate c ls.
     *
     * @return the number of activate c ls
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_ACTIVATECL);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the activate c l persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.ActivateCL")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<ActivateCL>> listenersList = new ArrayList<ModelListener<ActivateCL>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<ActivateCL>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(ActivateCLImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
