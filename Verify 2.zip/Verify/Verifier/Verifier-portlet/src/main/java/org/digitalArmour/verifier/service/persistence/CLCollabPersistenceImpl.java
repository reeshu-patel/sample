package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchCLCollabException;
import org.digitalArmour.verifier.model.CLCollab;
import org.digitalArmour.verifier.model.impl.CLCollabImpl;
import org.digitalArmour.verifier.model.impl.CLCollabModelImpl;
import org.digitalArmour.verifier.service.persistence.CLCollabPersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the c l collab service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CLCollabPersistence
 * @see CLCollabUtil
 * @generated
 */
public class CLCollabPersistenceImpl extends BasePersistenceImpl<CLCollab>
    implements CLCollabPersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link CLCollabUtil} to access the c l collab persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = CLCollabImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            CLCollabModelImpl.UUID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "clCollab.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "clCollab.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(clCollab.uuid IS NULL OR clCollab.uuid = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_COLLAB_CL =
        new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCollab_CL",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COLLAB_CL =
        new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCollab_CL",
            new String[] { Long.class.getName() },
            CLCollabModelImpl.CHECKLISTID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_COLLAB_CL = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCollab_CL",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_COLLAB_CL_CHECKLISTID_2 = "clCollab.checklistId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_USERID = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByuserId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID =
        new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, CLCollabImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByuserId",
            new String[] { Long.class.getName() },
            CLCollabModelImpl.USERID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_USERID = new FinderPath(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByuserId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_USERID_USERID_2 = "clCollab.userId = ?";
    private static final String _SQL_SELECT_CLCOLLAB = "SELECT clCollab FROM CLCollab clCollab";
    private static final String _SQL_SELECT_CLCOLLAB_WHERE = "SELECT clCollab FROM CLCollab clCollab WHERE ";
    private static final String _SQL_COUNT_CLCOLLAB = "SELECT COUNT(clCollab) FROM CLCollab clCollab";
    private static final String _SQL_COUNT_CLCOLLAB_WHERE = "SELECT COUNT(clCollab) FROM CLCollab clCollab WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "clCollab.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No CLCollab exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No CLCollab exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(CLCollabPersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid"
            });
    private static CLCollab _nullCLCollab = new CLCollabImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<CLCollab> toCacheModel() {
                return _nullCLCollabCacheModel;
            }
        };

    private static CacheModel<CLCollab> _nullCLCollabCacheModel = new CacheModel<CLCollab>() {
            @Override
            public CLCollab toEntityModel() {
                return _nullCLCollab;
            }
        };

    public CLCollabPersistenceImpl() {
        setModelClass(CLCollab.class);
    }

    /**
     * Returns all the c l collabs where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l collabs where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @return the range of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l collabs where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<CLCollab> list = (List<CLCollab>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLCollab clCollab : list) {
                if (!Validator.equals(uuid, clCollab.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLCOLLAB_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLCollabModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLCollab>(list);
                } else {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l collab in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = fetchByUuid_First(uuid, orderByComparator);

        if (clCollab != null) {
            return clCollab;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLCollabException(msg.toString());
    }

    /**
     * Returns the first c l collab in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l collab, or <code>null</code> if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLCollab> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l collab in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByUuid_Last(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = fetchByUuid_Last(uuid, orderByComparator);

        if (clCollab != null) {
            return clCollab;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLCollabException(msg.toString());
    }

    /**
     * Returns the last c l collab in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l collab, or <code>null</code> if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<CLCollab> list = findByUuid(uuid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l collabs before and after the current c l collab in the ordered set where uuid = &#63;.
     *
     * @param clCollabId the primary key of the current c l collab
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab[] findByUuid_PrevAndNext(long clCollabId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = findByPrimaryKey(clCollabId);

        Session session = null;

        try {
            session = openSession();

            CLCollab[] array = new CLCollabImpl[3];

            array[0] = getByUuid_PrevAndNext(session, clCollab, uuid,
                    orderByComparator, true);

            array[1] = clCollab;

            array[2] = getByUuid_PrevAndNext(session, clCollab, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLCollab getByUuid_PrevAndNext(Session session,
        CLCollab clCollab, String uuid, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLCOLLAB_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLCollabModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clCollab);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLCollab> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l collabs where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (CLCollab clCollab : findByUuid(uuid, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(clCollab);
        }
    }

    /**
     * Returns the number of c l collabs where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLCOLLAB_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the c l collabs where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @return the matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByCollab_CL(long checklistId)
        throws SystemException {
        return findByCollab_CL(checklistId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l collabs where checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @return the range of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByCollab_CL(long checklistId, int start, int end)
        throws SystemException {
        return findByCollab_CL(checklistId, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l collabs where checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByCollab_CL(long checklistId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COLLAB_CL;
            finderArgs = new Object[] { checklistId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_COLLAB_CL;
            finderArgs = new Object[] { checklistId, start, end, orderByComparator };
        }

        List<CLCollab> list = (List<CLCollab>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLCollab clCollab : list) {
                if ((checklistId != clCollab.getChecklistId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLCOLLAB_WHERE);

            query.append(_FINDER_COLUMN_COLLAB_CL_CHECKLISTID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLCollabModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                if (!pagination) {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLCollab>(list);
                } else {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l collab in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByCollab_CL_First(long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = fetchByCollab_CL_First(checklistId,
                orderByComparator);

        if (clCollab != null) {
            return clCollab;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLCollabException(msg.toString());
    }

    /**
     * Returns the first c l collab in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l collab, or <code>null</code> if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByCollab_CL_First(long checklistId,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLCollab> list = findByCollab_CL(checklistId, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l collab in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByCollab_CL_Last(long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = fetchByCollab_CL_Last(checklistId, orderByComparator);

        if (clCollab != null) {
            return clCollab;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLCollabException(msg.toString());
    }

    /**
     * Returns the last c l collab in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l collab, or <code>null</code> if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByCollab_CL_Last(long checklistId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByCollab_CL(checklistId);

        if (count == 0) {
            return null;
        }

        List<CLCollab> list = findByCollab_CL(checklistId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l collabs before and after the current c l collab in the ordered set where checklistId = &#63;.
     *
     * @param clCollabId the primary key of the current c l collab
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab[] findByCollab_CL_PrevAndNext(long clCollabId,
        long checklistId, OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = findByPrimaryKey(clCollabId);

        Session session = null;

        try {
            session = openSession();

            CLCollab[] array = new CLCollabImpl[3];

            array[0] = getByCollab_CL_PrevAndNext(session, clCollab,
                    checklistId, orderByComparator, true);

            array[1] = clCollab;

            array[2] = getByCollab_CL_PrevAndNext(session, clCollab,
                    checklistId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLCollab getByCollab_CL_PrevAndNext(Session session,
        CLCollab clCollab, long checklistId,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLCOLLAB_WHERE);

        query.append(_FINDER_COLUMN_COLLAB_CL_CHECKLISTID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLCollabModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(checklistId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clCollab);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLCollab> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l collabs where checklistId = &#63; from the database.
     *
     * @param checklistId the checklist ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByCollab_CL(long checklistId) throws SystemException {
        for (CLCollab clCollab : findByCollab_CL(checklistId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(clCollab);
        }
    }

    /**
     * Returns the number of c l collabs where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @return the number of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByCollab_CL(long checklistId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_COLLAB_CL;

        Object[] finderArgs = new Object[] { checklistId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLCOLLAB_WHERE);

            query.append(_FINDER_COLUMN_COLLAB_CL_CHECKLISTID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the c l collabs where userId = &#63;.
     *
     * @param userId the user ID
     * @return the matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByuserId(long userId) throws SystemException {
        return findByuserId(userId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l collabs where userId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param userId the user ID
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @return the range of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByuserId(long userId, int start, int end)
        throws SystemException {
        return findByuserId(userId, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l collabs where userId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param userId the user ID
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findByuserId(long userId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID;
            finderArgs = new Object[] { userId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_USERID;
            finderArgs = new Object[] { userId, start, end, orderByComparator };
        }

        List<CLCollab> list = (List<CLCollab>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLCollab clCollab : list) {
                if ((userId != clCollab.getUserId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLCOLLAB_WHERE);

            query.append(_FINDER_COLUMN_USERID_USERID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLCollabModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(userId);

                if (!pagination) {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLCollab>(list);
                } else {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l collab in the ordered set where userId = &#63;.
     *
     * @param userId the user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByuserId_First(long userId,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = fetchByuserId_First(userId, orderByComparator);

        if (clCollab != null) {
            return clCollab;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("userId=");
        msg.append(userId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLCollabException(msg.toString());
    }

    /**
     * Returns the first c l collab in the ordered set where userId = &#63;.
     *
     * @param userId the user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l collab, or <code>null</code> if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByuserId_First(long userId,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLCollab> list = findByuserId(userId, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l collab in the ordered set where userId = &#63;.
     *
     * @param userId the user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByuserId_Last(long userId,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = fetchByuserId_Last(userId, orderByComparator);

        if (clCollab != null) {
            return clCollab;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("userId=");
        msg.append(userId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLCollabException(msg.toString());
    }

    /**
     * Returns the last c l collab in the ordered set where userId = &#63;.
     *
     * @param userId the user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l collab, or <code>null</code> if a matching c l collab could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByuserId_Last(long userId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByuserId(userId);

        if (count == 0) {
            return null;
        }

        List<CLCollab> list = findByuserId(userId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l collabs before and after the current c l collab in the ordered set where userId = &#63;.
     *
     * @param clCollabId the primary key of the current c l collab
     * @param userId the user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab[] findByuserId_PrevAndNext(long clCollabId, long userId,
        OrderByComparator orderByComparator)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = findByPrimaryKey(clCollabId);

        Session session = null;

        try {
            session = openSession();

            CLCollab[] array = new CLCollabImpl[3];

            array[0] = getByuserId_PrevAndNext(session, clCollab, userId,
                    orderByComparator, true);

            array[1] = clCollab;

            array[2] = getByuserId_PrevAndNext(session, clCollab, userId,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLCollab getByuserId_PrevAndNext(Session session,
        CLCollab clCollab, long userId, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLCOLLAB_WHERE);

        query.append(_FINDER_COLUMN_USERID_USERID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLCollabModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(userId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clCollab);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLCollab> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l collabs where userId = &#63; from the database.
     *
     * @param userId the user ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByuserId(long userId) throws SystemException {
        for (CLCollab clCollab : findByuserId(userId, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(clCollab);
        }
    }

    /**
     * Returns the number of c l collabs where userId = &#63;.
     *
     * @param userId the user ID
     * @return the number of matching c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByuserId(long userId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_USERID;

        Object[] finderArgs = new Object[] { userId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLCOLLAB_WHERE);

            query.append(_FINDER_COLUMN_USERID_USERID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(userId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the c l collab in the entity cache if it is enabled.
     *
     * @param clCollab the c l collab
     */
    @Override
    public void cacheResult(CLCollab clCollab) {
        EntityCacheUtil.putResult(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabImpl.class, clCollab.getPrimaryKey(), clCollab);

        clCollab.resetOriginalValues();
    }

    /**
     * Caches the c l collabs in the entity cache if it is enabled.
     *
     * @param clCollabs the c l collabs
     */
    @Override
    public void cacheResult(List<CLCollab> clCollabs) {
        for (CLCollab clCollab : clCollabs) {
            if (EntityCacheUtil.getResult(
                        CLCollabModelImpl.ENTITY_CACHE_ENABLED,
                        CLCollabImpl.class, clCollab.getPrimaryKey()) == null) {
                cacheResult(clCollab);
            } else {
                clCollab.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all c l collabs.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(CLCollabImpl.class.getName());
        }

        EntityCacheUtil.clearCache(CLCollabImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the c l collab.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(CLCollab clCollab) {
        EntityCacheUtil.removeResult(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabImpl.class, clCollab.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    @Override
    public void clearCache(List<CLCollab> clCollabs) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (CLCollab clCollab : clCollabs) {
            EntityCacheUtil.removeResult(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
                CLCollabImpl.class, clCollab.getPrimaryKey());
        }
    }

    /**
     * Creates a new c l collab with the primary key. Does not add the c l collab to the database.
     *
     * @param clCollabId the primary key for the new c l collab
     * @return the new c l collab
     */
    @Override
    public CLCollab create(long clCollabId) {
        CLCollab clCollab = new CLCollabImpl();

        clCollab.setNew(true);
        clCollab.setPrimaryKey(clCollabId);

        String uuid = PortalUUIDUtil.generate();

        clCollab.setUuid(uuid);

        return clCollab;
    }

    /**
     * Removes the c l collab with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param clCollabId the primary key of the c l collab
     * @return the c l collab that was removed
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab remove(long clCollabId)
        throws NoSuchCLCollabException, SystemException {
        return remove((Serializable) clCollabId);
    }

    /**
     * Removes the c l collab with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the c l collab
     * @return the c l collab that was removed
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab remove(Serializable primaryKey)
        throws NoSuchCLCollabException, SystemException {
        Session session = null;

        try {
            session = openSession();

            CLCollab clCollab = (CLCollab) session.get(CLCollabImpl.class,
                    primaryKey);

            if (clCollab == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchCLCollabException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(clCollab);
        } catch (NoSuchCLCollabException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected CLCollab removeImpl(CLCollab clCollab) throws SystemException {
        clCollab = toUnwrappedModel(clCollab);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(clCollab)) {
                clCollab = (CLCollab) session.get(CLCollabImpl.class,
                        clCollab.getPrimaryKeyObj());
            }

            if (clCollab != null) {
                session.delete(clCollab);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (clCollab != null) {
            clearCache(clCollab);
        }

        return clCollab;
    }

    @Override
    public CLCollab updateImpl(
        org.digitalArmour.verifier.model.CLCollab clCollab)
        throws SystemException {
        clCollab = toUnwrappedModel(clCollab);

        boolean isNew = clCollab.isNew();

        CLCollabModelImpl clCollabModelImpl = (CLCollabModelImpl) clCollab;

        if (Validator.isNull(clCollab.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            clCollab.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (clCollab.isNew()) {
                session.save(clCollab);

                clCollab.setNew(false);
            } else {
                session.merge(clCollab);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !CLCollabModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((clCollabModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { clCollabModelImpl.getOriginalUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { clCollabModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }

            if ((clCollabModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COLLAB_CL.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        clCollabModelImpl.getOriginalChecklistId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COLLAB_CL,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COLLAB_CL,
                    args);

                args = new Object[] { clCollabModelImpl.getChecklistId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COLLAB_CL,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COLLAB_CL,
                    args);
            }

            if ((clCollabModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        clCollabModelImpl.getOriginalUserId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID,
                    args);

                args = new Object[] { clCollabModelImpl.getUserId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID,
                    args);
            }
        }

        EntityCacheUtil.putResult(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
            CLCollabImpl.class, clCollab.getPrimaryKey(), clCollab);

        return clCollab;
    }

    protected CLCollab toUnwrappedModel(CLCollab clCollab) {
        if (clCollab instanceof CLCollabImpl) {
            return clCollab;
        }

        CLCollabImpl clCollabImpl = new CLCollabImpl();

        clCollabImpl.setNew(clCollab.isNew());
        clCollabImpl.setPrimaryKey(clCollab.getPrimaryKey());

        clCollabImpl.setUuid(clCollab.getUuid());
        clCollabImpl.setClCollabId(clCollab.getClCollabId());
        clCollabImpl.setCollabType(clCollab.getCollabType());
        clCollabImpl.setPrManagerId(clCollab.getPrManagerId());
        clCollabImpl.setUserId(clCollab.getUserId());
        clCollabImpl.setChecklistId(clCollab.getChecklistId());

        return clCollabImpl;
    }

    /**
     * Returns the c l collab with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the c l collab
     * @return the c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByPrimaryKey(Serializable primaryKey)
        throws NoSuchCLCollabException, SystemException {
        CLCollab clCollab = fetchByPrimaryKey(primaryKey);

        if (clCollab == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchCLCollabException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return clCollab;
    }

    /**
     * Returns the c l collab with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchCLCollabException} if it could not be found.
     *
     * @param clCollabId the primary key of the c l collab
     * @return the c l collab
     * @throws org.digitalArmour.verifier.NoSuchCLCollabException if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab findByPrimaryKey(long clCollabId)
        throws NoSuchCLCollabException, SystemException {
        return findByPrimaryKey((Serializable) clCollabId);
    }

    /**
     * Returns the c l collab with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the c l collab
     * @return the c l collab, or <code>null</code> if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        CLCollab clCollab = (CLCollab) EntityCacheUtil.getResult(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
                CLCollabImpl.class, primaryKey);

        if (clCollab == _nullCLCollab) {
            return null;
        }

        if (clCollab == null) {
            Session session = null;

            try {
                session = openSession();

                clCollab = (CLCollab) session.get(CLCollabImpl.class, primaryKey);

                if (clCollab != null) {
                    cacheResult(clCollab);
                } else {
                    EntityCacheUtil.putResult(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
                        CLCollabImpl.class, primaryKey, _nullCLCollab);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(CLCollabModelImpl.ENTITY_CACHE_ENABLED,
                    CLCollabImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return clCollab;
    }

    /**
     * Returns the c l collab with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param clCollabId the primary key of the c l collab
     * @return the c l collab, or <code>null</code> if a c l collab with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLCollab fetchByPrimaryKey(long clCollabId)
        throws SystemException {
        return fetchByPrimaryKey((Serializable) clCollabId);
    }

    /**
     * Returns all the c l collabs.
     *
     * @return the c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l collabs.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @return the range of c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findAll(int start, int end) throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the c l collabs.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLCollabModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of c l collabs
     * @param end the upper bound of the range of c l collabs (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLCollab> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<CLCollab> list = (List<CLCollab>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_CLCOLLAB);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_CLCOLLAB;

                if (pagination) {
                    sql = sql.concat(CLCollabModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLCollab>(list);
                } else {
                    list = (List<CLCollab>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the c l collabs from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (CLCollab clCollab : findAll()) {
            remove(clCollab);
        }
    }

    /**
     * Returns the number of c l collabs.
     *
     * @return the number of c l collabs
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_CLCOLLAB);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the c l collab persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.CLCollab")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<CLCollab>> listenersList = new ArrayList<ModelListener<CLCollab>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<CLCollab>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(CLCollabImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
