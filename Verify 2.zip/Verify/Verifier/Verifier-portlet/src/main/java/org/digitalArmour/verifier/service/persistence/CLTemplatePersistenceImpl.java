package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchCLTemplateException;
import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.impl.CLTemplateImpl;
import org.digitalArmour.verifier.model.impl.CLTemplateModelImpl;
import org.digitalArmour.verifier.service.persistence.CLTemplatePersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the c l template service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CLTemplatePersistence
 * @see CLTemplateUtil
 * @generated
 */
public class CLTemplatePersistenceImpl extends BasePersistenceImpl<CLTemplate>
    implements CLTemplatePersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link CLTemplateUtil} to access the c l template persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = CLTemplateImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            CLTemplateModelImpl.UUID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "clTemplate.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "clTemplate.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(clTemplate.uuid IS NULL OR clTemplate.uuid = '')";
    public static final FinderPath FINDER_PATH_FETCH_BY_CHECKLISTID = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_ENTITY, "fetchBychecklistId",
            new String[] { Long.class.getName() },
            CLTemplateModelImpl.CHECKLISTID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CHECKLISTID = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBychecklistId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2 = "clTemplate.checklistId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CLNAME = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByclName",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME =
        new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByclName",
            new String[] { String.class.getName() },
            CLTemplateModelImpl.CLNAME_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CLNAME = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByclName",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_CLNAME_CLNAME_1 = "clTemplate.clName IS NULL";
    private static final String _FINDER_COLUMN_CLNAME_CLNAME_2 = "clTemplate.clName = ?";
    private static final String _FINDER_COLUMN_CLNAME_CLNAME_3 = "(clTemplate.clName IS NULL OR clTemplate.clName = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CLUSERID = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByclUserId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLUSERID =
        new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByclUserId",
            new String[] { Long.class.getName() },
            CLTemplateModelImpl.CLUSERID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CLUSERID = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByclUserId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_CLUSERID_CLUSERID_2 = "clTemplate.clUserId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ISPUBLIC = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByisPublic",
            new String[] {
                Boolean.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLIC =
        new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByisPublic",
            new String[] { Boolean.class.getName() },
            CLTemplateModelImpl.ISPUBLIC_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ISPUBLIC = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByisPublic",
            new String[] { Boolean.class.getName() });
    private static final String _FINDER_COLUMN_ISPUBLIC_ISPUBLIC_2 = "clTemplate.isPublic = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ISPUBLICCAT =
        new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByisPubliccat",
            new String[] {
                Boolean.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLICCAT =
        new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, CLTemplateImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByisPubliccat",
            new String[] { Boolean.class.getName() },
            CLTemplateModelImpl.ISPUBLICCAT_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ISPUBLICCAT = new FinderPath(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByisPubliccat",
            new String[] { Boolean.class.getName() });
    private static final String _FINDER_COLUMN_ISPUBLICCAT_ISPUBLICCAT_2 = "clTemplate.isPubliccat = ?";
    private static final String _SQL_SELECT_CLTEMPLATE = "SELECT clTemplate FROM CLTemplate clTemplate";
    private static final String _SQL_SELECT_CLTEMPLATE_WHERE = "SELECT clTemplate FROM CLTemplate clTemplate WHERE ";
    private static final String _SQL_COUNT_CLTEMPLATE = "SELECT COUNT(clTemplate) FROM CLTemplate clTemplate";
    private static final String _SQL_COUNT_CLTEMPLATE_WHERE = "SELECT COUNT(clTemplate) FROM CLTemplate clTemplate WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "clTemplate.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No CLTemplate exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No CLTemplate exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(CLTemplatePersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid"
            });
    private static CLTemplate _nullCLTemplate = new CLTemplateImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<CLTemplate> toCacheModel() {
                return _nullCLTemplateCacheModel;
            }
        };

    private static CacheModel<CLTemplate> _nullCLTemplateCacheModel = new CacheModel<CLTemplate>() {
            @Override
            public CLTemplate toEntityModel() {
                return _nullCLTemplate;
            }
        };

    public CLTemplatePersistenceImpl() {
        setModelClass(CLTemplate.class);
    }

    /**
     * Returns all the c l templates where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l templates where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @return the range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l templates where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<CLTemplate> list = (List<CLTemplate>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLTemplate clTemplate : list) {
                if (!Validator.equals(uuid, clTemplate.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLTemplate>(list);
                } else {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l template in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByUuid_First(uuid, orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the first c l template in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLTemplate> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l template in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByUuid_Last(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByUuid_Last(uuid, orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the last c l template in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<CLTemplate> list = findByUuid(uuid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l templates before and after the current c l template in the ordered set where uuid = &#63;.
     *
     * @param checklistId the primary key of the current c l template
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate[] findByUuid_PrevAndNext(long checklistId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = findByPrimaryKey(checklistId);

        Session session = null;

        try {
            session = openSession();

            CLTemplate[] array = new CLTemplateImpl[3];

            array[0] = getByUuid_PrevAndNext(session, clTemplate, uuid,
                    orderByComparator, true);

            array[1] = clTemplate;

            array[2] = getByUuid_PrevAndNext(session, clTemplate, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLTemplate getByUuid_PrevAndNext(Session session,
        CLTemplate clTemplate, String uuid,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clTemplate);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLTemplate> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l templates where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (CLTemplate clTemplate : findByUuid(uuid, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(clTemplate);
        }
    }

    /**
     * Returns the number of c l templates where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLTEMPLATE_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns the c l template where checklistId = &#63; or throws a {@link org.digitalArmour.verifier.NoSuchCLTemplateException} if it could not be found.
     *
     * @param checklistId the checklist ID
     * @return the matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findBychecklistId(long checklistId)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchBychecklistId(checklistId);

        if (clTemplate == null) {
            StringBundler msg = new StringBundler(4);

            msg.append(_NO_SUCH_ENTITY_WITH_KEY);

            msg.append("checklistId=");
            msg.append(checklistId);

            msg.append(StringPool.CLOSE_CURLY_BRACE);

            if (_log.isWarnEnabled()) {
                _log.warn(msg.toString());
            }

            throw new NoSuchCLTemplateException(msg.toString());
        }

        return clTemplate;
    }

    /**
     * Returns the c l template where checklistId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
     *
     * @param checklistId the checklist ID
     * @return the matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchBychecklistId(long checklistId)
        throws SystemException {
        return fetchBychecklistId(checklistId, true);
    }

    /**
     * Returns the c l template where checklistId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
     *
     * @param checklistId the checklist ID
     * @param retrieveFromCache whether to use the finder cache
     * @return the matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchBychecklistId(long checklistId,
        boolean retrieveFromCache) throws SystemException {
        Object[] finderArgs = new Object[] { checklistId };

        Object result = null;

        if (retrieveFromCache) {
            result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_CHECKLISTID,
                    finderArgs, this);
        }

        if (result instanceof CLTemplate) {
            CLTemplate clTemplate = (CLTemplate) result;

            if ((checklistId != clTemplate.getChecklistId())) {
                result = null;
            }
        }

        if (result == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                List<CLTemplate> list = q.list();

                if (list.isEmpty()) {
                    FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CHECKLISTID,
                        finderArgs, list);
                } else {
                    if ((list.size() > 1) && _log.isWarnEnabled()) {
                        _log.warn(
                            "CLTemplatePersistenceImpl.fetchBychecklistId(long, boolean) with parameters (" +
                            StringUtil.merge(finderArgs) +
                            ") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
                    }

                    CLTemplate clTemplate = list.get(0);

                    result = clTemplate;

                    cacheResult(clTemplate);

                    if ((clTemplate.getChecklistId() != checklistId)) {
                        FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CHECKLISTID,
                            finderArgs, clTemplate);
                    }
                }
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CHECKLISTID,
                    finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        if (result instanceof List<?>) {
            return null;
        } else {
            return (CLTemplate) result;
        }
    }

    /**
     * Removes the c l template where checklistId = &#63; from the database.
     *
     * @param checklistId the checklist ID
     * @return the c l template that was removed
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate removeBychecklistId(long checklistId)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = findBychecklistId(checklistId);

        return remove(clTemplate);
    }

    /**
     * Returns the number of c l templates where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @return the number of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countBychecklistId(long checklistId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CHECKLISTID;

        Object[] finderArgs = new Object[] { checklistId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the c l templates where clName = &#63;.
     *
     * @param clName the cl name
     * @return the matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByclName(String clName)
        throws SystemException {
        return findByclName(clName, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l templates where clName = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param clName the cl name
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @return the range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByclName(String clName, int start, int end)
        throws SystemException {
        return findByclName(clName, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l templates where clName = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param clName the cl name
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByclName(String clName, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME;
            finderArgs = new Object[] { clName };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CLNAME;
            finderArgs = new Object[] { clName, start, end, orderByComparator };
        }

        List<CLTemplate> list = (List<CLTemplate>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLTemplate clTemplate : list) {
                if (!Validator.equals(clName, clTemplate.getClName())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

            boolean bindClName = false;

            if (clName == null) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_1);
            } else if (clName.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_3);
            } else {
                bindClName = true;

                query.append(_FINDER_COLUMN_CLNAME_CLNAME_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindClName) {
                    qPos.add(clName);
                }

                if (!pagination) {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLTemplate>(list);
                } else {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l template in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByclName_First(String clName,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByclName_First(clName, orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("clName=");
        msg.append(clName);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the first c l template in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByclName_First(String clName,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLTemplate> list = findByclName(clName, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l template in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByclName_Last(String clName,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByclName_Last(clName, orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("clName=");
        msg.append(clName);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the last c l template in the ordered set where clName = &#63;.
     *
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByclName_Last(String clName,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByclName(clName);

        if (count == 0) {
            return null;
        }

        List<CLTemplate> list = findByclName(clName, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l templates before and after the current c l template in the ordered set where clName = &#63;.
     *
     * @param checklistId the primary key of the current c l template
     * @param clName the cl name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate[] findByclName_PrevAndNext(long checklistId,
        String clName, OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = findByPrimaryKey(checklistId);

        Session session = null;

        try {
            session = openSession();

            CLTemplate[] array = new CLTemplateImpl[3];

            array[0] = getByclName_PrevAndNext(session, clTemplate, clName,
                    orderByComparator, true);

            array[1] = clTemplate;

            array[2] = getByclName_PrevAndNext(session, clTemplate, clName,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLTemplate getByclName_PrevAndNext(Session session,
        CLTemplate clTemplate, String clName,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

        boolean bindClName = false;

        if (clName == null) {
            query.append(_FINDER_COLUMN_CLNAME_CLNAME_1);
        } else if (clName.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_CLNAME_CLNAME_3);
        } else {
            bindClName = true;

            query.append(_FINDER_COLUMN_CLNAME_CLNAME_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindClName) {
            qPos.add(clName);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clTemplate);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLTemplate> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l templates where clName = &#63; from the database.
     *
     * @param clName the cl name
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByclName(String clName) throws SystemException {
        for (CLTemplate clTemplate : findByclName(clName, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(clTemplate);
        }
    }

    /**
     * Returns the number of c l templates where clName = &#63;.
     *
     * @param clName the cl name
     * @return the number of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByclName(String clName) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CLNAME;

        Object[] finderArgs = new Object[] { clName };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLTEMPLATE_WHERE);

            boolean bindClName = false;

            if (clName == null) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_1);
            } else if (clName.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_CLNAME_CLNAME_3);
            } else {
                bindClName = true;

                query.append(_FINDER_COLUMN_CLNAME_CLNAME_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindClName) {
                    qPos.add(clName);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the c l templates where clUserId = &#63;.
     *
     * @param clUserId the cl user ID
     * @return the matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByclUserId(long clUserId)
        throws SystemException {
        return findByclUserId(clUserId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
            null);
    }

    /**
     * Returns a range of all the c l templates where clUserId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param clUserId the cl user ID
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @return the range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByclUserId(long clUserId, int start, int end)
        throws SystemException {
        return findByclUserId(clUserId, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l templates where clUserId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param clUserId the cl user ID
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByclUserId(long clUserId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLUSERID;
            finderArgs = new Object[] { clUserId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CLUSERID;
            finderArgs = new Object[] { clUserId, start, end, orderByComparator };
        }

        List<CLTemplate> list = (List<CLTemplate>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLTemplate clTemplate : list) {
                if ((clUserId != clTemplate.getClUserId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_CLUSERID_CLUSERID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(clUserId);

                if (!pagination) {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLTemplate>(list);
                } else {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l template in the ordered set where clUserId = &#63;.
     *
     * @param clUserId the cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByclUserId_First(long clUserId,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByclUserId_First(clUserId,
                orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("clUserId=");
        msg.append(clUserId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the first c l template in the ordered set where clUserId = &#63;.
     *
     * @param clUserId the cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByclUserId_First(long clUserId,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLTemplate> list = findByclUserId(clUserId, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l template in the ordered set where clUserId = &#63;.
     *
     * @param clUserId the cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByclUserId_Last(long clUserId,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByclUserId_Last(clUserId, orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("clUserId=");
        msg.append(clUserId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the last c l template in the ordered set where clUserId = &#63;.
     *
     * @param clUserId the cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByclUserId_Last(long clUserId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByclUserId(clUserId);

        if (count == 0) {
            return null;
        }

        List<CLTemplate> list = findByclUserId(clUserId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l templates before and after the current c l template in the ordered set where clUserId = &#63;.
     *
     * @param checklistId the primary key of the current c l template
     * @param clUserId the cl user ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate[] findByclUserId_PrevAndNext(long checklistId,
        long clUserId, OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = findByPrimaryKey(checklistId);

        Session session = null;

        try {
            session = openSession();

            CLTemplate[] array = new CLTemplateImpl[3];

            array[0] = getByclUserId_PrevAndNext(session, clTemplate, clUserId,
                    orderByComparator, true);

            array[1] = clTemplate;

            array[2] = getByclUserId_PrevAndNext(session, clTemplate, clUserId,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLTemplate getByclUserId_PrevAndNext(Session session,
        CLTemplate clTemplate, long clUserId,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

        query.append(_FINDER_COLUMN_CLUSERID_CLUSERID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(clUserId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clTemplate);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLTemplate> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l templates where clUserId = &#63; from the database.
     *
     * @param clUserId the cl user ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByclUserId(long clUserId) throws SystemException {
        for (CLTemplate clTemplate : findByclUserId(clUserId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(clTemplate);
        }
    }

    /**
     * Returns the number of c l templates where clUserId = &#63;.
     *
     * @param clUserId the cl user ID
     * @return the number of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByclUserId(long clUserId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CLUSERID;

        Object[] finderArgs = new Object[] { clUserId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_CLUSERID_CLUSERID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(clUserId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the c l templates where isPublic = &#63;.
     *
     * @param isPublic the is public
     * @return the matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByisPublic(boolean isPublic)
        throws SystemException {
        return findByisPublic(isPublic, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
            null);
    }

    /**
     * Returns a range of all the c l templates where isPublic = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isPublic the is public
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @return the range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByisPublic(boolean isPublic, int start, int end)
        throws SystemException {
        return findByisPublic(isPublic, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l templates where isPublic = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isPublic the is public
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByisPublic(boolean isPublic, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLIC;
            finderArgs = new Object[] { isPublic };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ISPUBLIC;
            finderArgs = new Object[] { isPublic, start, end, orderByComparator };
        }

        List<CLTemplate> list = (List<CLTemplate>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLTemplate clTemplate : list) {
                if ((isPublic != clTemplate.getIsPublic())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_ISPUBLIC_ISPUBLIC_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isPublic);

                if (!pagination) {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLTemplate>(list);
                } else {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l template in the ordered set where isPublic = &#63;.
     *
     * @param isPublic the is public
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByisPublic_First(boolean isPublic,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByisPublic_First(isPublic,
                orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isPublic=");
        msg.append(isPublic);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the first c l template in the ordered set where isPublic = &#63;.
     *
     * @param isPublic the is public
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByisPublic_First(boolean isPublic,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLTemplate> list = findByisPublic(isPublic, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l template in the ordered set where isPublic = &#63;.
     *
     * @param isPublic the is public
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByisPublic_Last(boolean isPublic,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByisPublic_Last(isPublic, orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isPublic=");
        msg.append(isPublic);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the last c l template in the ordered set where isPublic = &#63;.
     *
     * @param isPublic the is public
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByisPublic_Last(boolean isPublic,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByisPublic(isPublic);

        if (count == 0) {
            return null;
        }

        List<CLTemplate> list = findByisPublic(isPublic, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l templates before and after the current c l template in the ordered set where isPublic = &#63;.
     *
     * @param checklistId the primary key of the current c l template
     * @param isPublic the is public
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate[] findByisPublic_PrevAndNext(long checklistId,
        boolean isPublic, OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = findByPrimaryKey(checklistId);

        Session session = null;

        try {
            session = openSession();

            CLTemplate[] array = new CLTemplateImpl[3];

            array[0] = getByisPublic_PrevAndNext(session, clTemplate, isPublic,
                    orderByComparator, true);

            array[1] = clTemplate;

            array[2] = getByisPublic_PrevAndNext(session, clTemplate, isPublic,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLTemplate getByisPublic_PrevAndNext(Session session,
        CLTemplate clTemplate, boolean isPublic,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

        query.append(_FINDER_COLUMN_ISPUBLIC_ISPUBLIC_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(isPublic);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clTemplate);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLTemplate> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l templates where isPublic = &#63; from the database.
     *
     * @param isPublic the is public
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByisPublic(boolean isPublic) throws SystemException {
        for (CLTemplate clTemplate : findByisPublic(isPublic,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(clTemplate);
        }
    }

    /**
     * Returns the number of c l templates where isPublic = &#63;.
     *
     * @param isPublic the is public
     * @return the number of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByisPublic(boolean isPublic) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ISPUBLIC;

        Object[] finderArgs = new Object[] { isPublic };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_ISPUBLIC_ISPUBLIC_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isPublic);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the c l templates where isPubliccat = &#63;.
     *
     * @param isPubliccat the is publiccat
     * @return the matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByisPubliccat(boolean isPubliccat)
        throws SystemException {
        return findByisPubliccat(isPubliccat, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l templates where isPubliccat = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isPubliccat the is publiccat
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @return the range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByisPubliccat(boolean isPubliccat, int start,
        int end) throws SystemException {
        return findByisPubliccat(isPubliccat, start, end, null);
    }

    /**
     * Returns an ordered range of all the c l templates where isPubliccat = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param isPubliccat the is publiccat
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findByisPubliccat(boolean isPubliccat, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLICCAT;
            finderArgs = new Object[] { isPubliccat };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ISPUBLICCAT;
            finderArgs = new Object[] { isPubliccat, start, end, orderByComparator };
        }

        List<CLTemplate> list = (List<CLTemplate>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (CLTemplate clTemplate : list) {
                if ((isPubliccat != clTemplate.getIsPubliccat())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_ISPUBLICCAT_ISPUBLICCAT_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isPubliccat);

                if (!pagination) {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLTemplate>(list);
                } else {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first c l template in the ordered set where isPubliccat = &#63;.
     *
     * @param isPubliccat the is publiccat
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByisPubliccat_First(boolean isPubliccat,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByisPubliccat_First(isPubliccat,
                orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isPubliccat=");
        msg.append(isPubliccat);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the first c l template in the ordered set where isPubliccat = &#63;.
     *
     * @param isPubliccat the is publiccat
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByisPubliccat_First(boolean isPubliccat,
        OrderByComparator orderByComparator) throws SystemException {
        List<CLTemplate> list = findByisPubliccat(isPubliccat, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last c l template in the ordered set where isPubliccat = &#63;.
     *
     * @param isPubliccat the is publiccat
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByisPubliccat_Last(boolean isPubliccat,
        OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByisPubliccat_Last(isPubliccat,
                orderByComparator);

        if (clTemplate != null) {
            return clTemplate;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("isPubliccat=");
        msg.append(isPubliccat);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCLTemplateException(msg.toString());
    }

    /**
     * Returns the last c l template in the ordered set where isPubliccat = &#63;.
     *
     * @param isPubliccat the is publiccat
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching c l template, or <code>null</code> if a matching c l template could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByisPubliccat_Last(boolean isPubliccat,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByisPubliccat(isPubliccat);

        if (count == 0) {
            return null;
        }

        List<CLTemplate> list = findByisPubliccat(isPubliccat, count - 1,
                count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the c l templates before and after the current c l template in the ordered set where isPubliccat = &#63;.
     *
     * @param checklistId the primary key of the current c l template
     * @param isPubliccat the is publiccat
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate[] findByisPubliccat_PrevAndNext(long checklistId,
        boolean isPubliccat, OrderByComparator orderByComparator)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = findByPrimaryKey(checklistId);

        Session session = null;

        try {
            session = openSession();

            CLTemplate[] array = new CLTemplateImpl[3];

            array[0] = getByisPubliccat_PrevAndNext(session, clTemplate,
                    isPubliccat, orderByComparator, true);

            array[1] = clTemplate;

            array[2] = getByisPubliccat_PrevAndNext(session, clTemplate,
                    isPubliccat, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected CLTemplate getByisPubliccat_PrevAndNext(Session session,
        CLTemplate clTemplate, boolean isPubliccat,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_CLTEMPLATE_WHERE);

        query.append(_FINDER_COLUMN_ISPUBLICCAT_ISPUBLICCAT_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CLTemplateModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(isPubliccat);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(clTemplate);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<CLTemplate> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the c l templates where isPubliccat = &#63; from the database.
     *
     * @param isPubliccat the is publiccat
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByisPubliccat(boolean isPubliccat)
        throws SystemException {
        for (CLTemplate clTemplate : findByisPubliccat(isPubliccat,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(clTemplate);
        }
    }

    /**
     * Returns the number of c l templates where isPubliccat = &#63;.
     *
     * @param isPubliccat the is publiccat
     * @return the number of matching c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByisPubliccat(boolean isPubliccat)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ISPUBLICCAT;

        Object[] finderArgs = new Object[] { isPubliccat };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_CLTEMPLATE_WHERE);

            query.append(_FINDER_COLUMN_ISPUBLICCAT_ISPUBLICCAT_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(isPubliccat);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the c l template in the entity cache if it is enabled.
     *
     * @param clTemplate the c l template
     */
    @Override
    public void cacheResult(CLTemplate clTemplate) {
        EntityCacheUtil.putResult(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateImpl.class, clTemplate.getPrimaryKey(), clTemplate);

        FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CHECKLISTID,
            new Object[] { clTemplate.getChecklistId() }, clTemplate);

        clTemplate.resetOriginalValues();
    }

    /**
     * Caches the c l templates in the entity cache if it is enabled.
     *
     * @param clTemplates the c l templates
     */
    @Override
    public void cacheResult(List<CLTemplate> clTemplates) {
        for (CLTemplate clTemplate : clTemplates) {
            if (EntityCacheUtil.getResult(
                        CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
                        CLTemplateImpl.class, clTemplate.getPrimaryKey()) == null) {
                cacheResult(clTemplate);
            } else {
                clTemplate.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all c l templates.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(CLTemplateImpl.class.getName());
        }

        EntityCacheUtil.clearCache(CLTemplateImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the c l template.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(CLTemplate clTemplate) {
        EntityCacheUtil.removeResult(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateImpl.class, clTemplate.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        clearUniqueFindersCache(clTemplate);
    }

    @Override
    public void clearCache(List<CLTemplate> clTemplates) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (CLTemplate clTemplate : clTemplates) {
            EntityCacheUtil.removeResult(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
                CLTemplateImpl.class, clTemplate.getPrimaryKey());

            clearUniqueFindersCache(clTemplate);
        }
    }

    protected void cacheUniqueFindersCache(CLTemplate clTemplate) {
        if (clTemplate.isNew()) {
            Object[] args = new Object[] { clTemplate.getChecklistId() };

            FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_CHECKLISTID, args,
                Long.valueOf(1));
            FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CHECKLISTID, args,
                clTemplate);
        } else {
            CLTemplateModelImpl clTemplateModelImpl = (CLTemplateModelImpl) clTemplate;

            if ((clTemplateModelImpl.getColumnBitmask() &
                    FINDER_PATH_FETCH_BY_CHECKLISTID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { clTemplate.getChecklistId() };

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_CHECKLISTID,
                    args, Long.valueOf(1));
                FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_CHECKLISTID,
                    args, clTemplate);
            }
        }
    }

    protected void clearUniqueFindersCache(CLTemplate clTemplate) {
        CLTemplateModelImpl clTemplateModelImpl = (CLTemplateModelImpl) clTemplate;

        Object[] args = new Object[] { clTemplate.getChecklistId() };

        FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKLISTID, args);
        FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CHECKLISTID, args);

        if ((clTemplateModelImpl.getColumnBitmask() &
                FINDER_PATH_FETCH_BY_CHECKLISTID.getColumnBitmask()) != 0) {
            args = new Object[] { clTemplateModelImpl.getOriginalChecklistId() };

            FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKLISTID, args);
            FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_CHECKLISTID, args);
        }
    }

    /**
     * Creates a new c l template with the primary key. Does not add the c l template to the database.
     *
     * @param checklistId the primary key for the new c l template
     * @return the new c l template
     */
    @Override
    public CLTemplate create(long checklistId) {
        CLTemplate clTemplate = new CLTemplateImpl();

        clTemplate.setNew(true);
        clTemplate.setPrimaryKey(checklistId);

        String uuid = PortalUUIDUtil.generate();

        clTemplate.setUuid(uuid);

        return clTemplate;
    }

    /**
     * Removes the c l template with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param checklistId the primary key of the c l template
     * @return the c l template that was removed
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate remove(long checklistId)
        throws NoSuchCLTemplateException, SystemException {
        return remove((Serializable) checklistId);
    }

    /**
     * Removes the c l template with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the c l template
     * @return the c l template that was removed
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate remove(Serializable primaryKey)
        throws NoSuchCLTemplateException, SystemException {
        Session session = null;

        try {
            session = openSession();

            CLTemplate clTemplate = (CLTemplate) session.get(CLTemplateImpl.class,
                    primaryKey);

            if (clTemplate == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchCLTemplateException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(clTemplate);
        } catch (NoSuchCLTemplateException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected CLTemplate removeImpl(CLTemplate clTemplate)
        throws SystemException {
        clTemplate = toUnwrappedModel(clTemplate);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(clTemplate)) {
                clTemplate = (CLTemplate) session.get(CLTemplateImpl.class,
                        clTemplate.getPrimaryKeyObj());
            }

            if (clTemplate != null) {
                session.delete(clTemplate);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (clTemplate != null) {
            clearCache(clTemplate);
        }

        return clTemplate;
    }

    @Override
    public CLTemplate updateImpl(
        org.digitalArmour.verifier.model.CLTemplate clTemplate)
        throws SystemException {
        clTemplate = toUnwrappedModel(clTemplate);

        boolean isNew = clTemplate.isNew();

        CLTemplateModelImpl clTemplateModelImpl = (CLTemplateModelImpl) clTemplate;

        if (Validator.isNull(clTemplate.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            clTemplate.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (clTemplate.isNew()) {
                session.save(clTemplate);

                clTemplate.setNew(false);
            } else {
                session.merge(clTemplate);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !CLTemplateModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((clTemplateModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        clTemplateModelImpl.getOriginalUuid()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { clTemplateModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }

            if ((clTemplateModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        clTemplateModelImpl.getOriginalClName()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CLNAME, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME,
                    args);

                args = new Object[] { clTemplateModelImpl.getClName() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CLNAME, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLNAME,
                    args);
            }

            if ((clTemplateModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLUSERID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        clTemplateModelImpl.getOriginalClUserId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CLUSERID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLUSERID,
                    args);

                args = new Object[] { clTemplateModelImpl.getClUserId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CLUSERID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CLUSERID,
                    args);
            }

            if ((clTemplateModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLIC.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        clTemplateModelImpl.getOriginalIsPublic()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISPUBLIC, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLIC,
                    args);

                args = new Object[] { clTemplateModelImpl.getIsPublic() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISPUBLIC, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLIC,
                    args);
            }

            if ((clTemplateModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLICCAT.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        clTemplateModelImpl.getOriginalIsPubliccat()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISPUBLICCAT,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLICCAT,
                    args);

                args = new Object[] { clTemplateModelImpl.getIsPubliccat() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ISPUBLICCAT,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ISPUBLICCAT,
                    args);
            }
        }

        EntityCacheUtil.putResult(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
            CLTemplateImpl.class, clTemplate.getPrimaryKey(), clTemplate);

        clearUniqueFindersCache(clTemplate);
        cacheUniqueFindersCache(clTemplate);

        return clTemplate;
    }

    protected CLTemplate toUnwrappedModel(CLTemplate clTemplate) {
        if (clTemplate instanceof CLTemplateImpl) {
            return clTemplate;
        }

        CLTemplateImpl clTemplateImpl = new CLTemplateImpl();

        clTemplateImpl.setNew(clTemplate.isNew());
        clTemplateImpl.setPrimaryKey(clTemplate.getPrimaryKey());

        clTemplateImpl.setUuid(clTemplate.getUuid());
        clTemplateImpl.setChecklistId(clTemplate.getChecklistId());
        clTemplateImpl.setClName(clTemplate.getClName());
        clTemplateImpl.setClDescription(clTemplate.getClDescription());
        clTemplateImpl.setClOrganiztion(clTemplate.getClOrganiztion());
        clTemplateImpl.setClUserId(clTemplate.getClUserId());
        clTemplateImpl.setIsPublic(clTemplate.isIsPublic());
        clTemplateImpl.setIsPubliccat(clTemplate.isIsPubliccat());

        return clTemplateImpl;
    }

    /**
     * Returns the c l template with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the c l template
     * @return the c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByPrimaryKey(Serializable primaryKey)
        throws NoSuchCLTemplateException, SystemException {
        CLTemplate clTemplate = fetchByPrimaryKey(primaryKey);

        if (clTemplate == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchCLTemplateException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return clTemplate;
    }

    /**
     * Returns the c l template with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchCLTemplateException} if it could not be found.
     *
     * @param checklistId the primary key of the c l template
     * @return the c l template
     * @throws org.digitalArmour.verifier.NoSuchCLTemplateException if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate findByPrimaryKey(long checklistId)
        throws NoSuchCLTemplateException, SystemException {
        return findByPrimaryKey((Serializable) checklistId);
    }

    /**
     * Returns the c l template with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the c l template
     * @return the c l template, or <code>null</code> if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        CLTemplate clTemplate = (CLTemplate) EntityCacheUtil.getResult(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
                CLTemplateImpl.class, primaryKey);

        if (clTemplate == _nullCLTemplate) {
            return null;
        }

        if (clTemplate == null) {
            Session session = null;

            try {
                session = openSession();

                clTemplate = (CLTemplate) session.get(CLTemplateImpl.class,
                        primaryKey);

                if (clTemplate != null) {
                    cacheResult(clTemplate);
                } else {
                    EntityCacheUtil.putResult(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
                        CLTemplateImpl.class, primaryKey, _nullCLTemplate);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(CLTemplateModelImpl.ENTITY_CACHE_ENABLED,
                    CLTemplateImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return clTemplate;
    }

    /**
     * Returns the c l template with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param checklistId the primary key of the c l template
     * @return the c l template, or <code>null</code> if a c l template with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public CLTemplate fetchByPrimaryKey(long checklistId)
        throws SystemException {
        return fetchByPrimaryKey((Serializable) checklistId);
    }

    /**
     * Returns all the c l templates.
     *
     * @return the c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the c l templates.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @return the range of c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findAll(int start, int end)
        throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the c l templates.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.CLTemplateModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of c l templates
     * @param end the upper bound of the range of c l templates (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<CLTemplate> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<CLTemplate> list = (List<CLTemplate>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_CLTEMPLATE);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_CLTEMPLATE;

                if (pagination) {
                    sql = sql.concat(CLTemplateModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<CLTemplate>(list);
                } else {
                    list = (List<CLTemplate>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the c l templates from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (CLTemplate clTemplate : findAll()) {
            remove(clTemplate);
        }
    }

    /**
     * Returns the number of c l templates.
     *
     * @return the number of c l templates
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_CLTEMPLATE);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the c l template persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.CLTemplate")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<CLTemplate>> listenersList = new ArrayList<ModelListener<CLTemplate>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<CLTemplate>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(CLTemplateImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
