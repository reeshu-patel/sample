package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchItemFileException;
import org.digitalArmour.verifier.model.ItemFile;
import org.digitalArmour.verifier.model.impl.ItemFileImpl;
import org.digitalArmour.verifier.model.impl.ItemFileModelImpl;
import org.digitalArmour.verifier.service.persistence.ItemFilePersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the item file service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ItemFilePersistence
 * @see ItemFileUtil
 * @generated
 */
public class ItemFilePersistenceImpl extends BasePersistenceImpl<ItemFile>
    implements ItemFilePersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link ItemFileUtil} to access the item file persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = ItemFileImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, ItemFileImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, ItemFileImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, ItemFileImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, ItemFileImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            ItemFileModelImpl.UUID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "itemFile.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "itemFile.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(itemFile.uuid IS NULL OR itemFile.uuid = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ITEMID = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, ItemFileImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByItemId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMID =
        new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, ItemFileImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByItemId",
            new String[] { Long.class.getName() },
            ItemFileModelImpl.ITEMID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ITEMID = new FinderPath(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByItemId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_ITEMID_ITEMID_2 = "itemFile.itemId = ?";
    private static final String _SQL_SELECT_ITEMFILE = "SELECT itemFile FROM ItemFile itemFile";
    private static final String _SQL_SELECT_ITEMFILE_WHERE = "SELECT itemFile FROM ItemFile itemFile WHERE ";
    private static final String _SQL_COUNT_ITEMFILE = "SELECT COUNT(itemFile) FROM ItemFile itemFile";
    private static final String _SQL_COUNT_ITEMFILE_WHERE = "SELECT COUNT(itemFile) FROM ItemFile itemFile WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "itemFile.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No ItemFile exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No ItemFile exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(ItemFilePersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid"
            });
    private static ItemFile _nullItemFile = new ItemFileImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<ItemFile> toCacheModel() {
                return _nullItemFileCacheModel;
            }
        };

    private static CacheModel<ItemFile> _nullItemFileCacheModel = new CacheModel<ItemFile>() {
            @Override
            public ItemFile toEntityModel() {
                return _nullItemFile;
            }
        };

    public ItemFilePersistenceImpl() {
        setModelClass(ItemFile.class);
    }

    /**
     * Returns all the item files where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the item files where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of item files
     * @param end the upper bound of the range of item files (not inclusive)
     * @return the range of matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the item files where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of item files
     * @param end the upper bound of the range of item files (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<ItemFile> list = (List<ItemFile>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ItemFile itemFile : list) {
                if (!Validator.equals(uuid, itemFile.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ITEMFILE_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ItemFileModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<ItemFile>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ItemFile>(list);
                } else {
                    list = (List<ItemFile>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first item file in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemFileException, SystemException {
        ItemFile itemFile = fetchByUuid_First(uuid, orderByComparator);

        if (itemFile != null) {
            return itemFile;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemFileException(msg.toString());
    }

    /**
     * Returns the first item file in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item file, or <code>null</code> if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<ItemFile> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last item file in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile findByUuid_Last(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemFileException, SystemException {
        ItemFile itemFile = fetchByUuid_Last(uuid, orderByComparator);

        if (itemFile != null) {
            return itemFile;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemFileException(msg.toString());
    }

    /**
     * Returns the last item file in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item file, or <code>null</code> if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<ItemFile> list = findByUuid(uuid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the item files before and after the current item file in the ordered set where uuid = &#63;.
     *
     * @param fileId the primary key of the current item file
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile[] findByUuid_PrevAndNext(long fileId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemFileException, SystemException {
        ItemFile itemFile = findByPrimaryKey(fileId);

        Session session = null;

        try {
            session = openSession();

            ItemFile[] array = new ItemFileImpl[3];

            array[0] = getByUuid_PrevAndNext(session, itemFile, uuid,
                    orderByComparator, true);

            array[1] = itemFile;

            array[2] = getByUuid_PrevAndNext(session, itemFile, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ItemFile getByUuid_PrevAndNext(Session session,
        ItemFile itemFile, String uuid, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ITEMFILE_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ItemFileModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(itemFile);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ItemFile> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the item files where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (ItemFile itemFile : findByUuid(uuid, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(itemFile);
        }
    }

    /**
     * Returns the number of item files where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ITEMFILE_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the item files where itemId = &#63;.
     *
     * @param itemId the item ID
     * @return the matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findByItemId(long itemId) throws SystemException {
        return findByItemId(itemId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the item files where itemId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param itemId the item ID
     * @param start the lower bound of the range of item files
     * @param end the upper bound of the range of item files (not inclusive)
     * @return the range of matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findByItemId(long itemId, int start, int end)
        throws SystemException {
        return findByItemId(itemId, start, end, null);
    }

    /**
     * Returns an ordered range of all the item files where itemId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param itemId the item ID
     * @param start the lower bound of the range of item files
     * @param end the upper bound of the range of item files (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findByItemId(long itemId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMID;
            finderArgs = new Object[] { itemId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ITEMID;
            finderArgs = new Object[] { itemId, start, end, orderByComparator };
        }

        List<ItemFile> list = (List<ItemFile>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ItemFile itemFile : list) {
                if ((itemId != itemFile.getItemId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ITEMFILE_WHERE);

            query.append(_FINDER_COLUMN_ITEMID_ITEMID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ItemFileModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(itemId);

                if (!pagination) {
                    list = (List<ItemFile>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ItemFile>(list);
                } else {
                    list = (List<ItemFile>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first item file in the ordered set where itemId = &#63;.
     *
     * @param itemId the item ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile findByItemId_First(long itemId,
        OrderByComparator orderByComparator)
        throws NoSuchItemFileException, SystemException {
        ItemFile itemFile = fetchByItemId_First(itemId, orderByComparator);

        if (itemFile != null) {
            return itemFile;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("itemId=");
        msg.append(itemId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemFileException(msg.toString());
    }

    /**
     * Returns the first item file in the ordered set where itemId = &#63;.
     *
     * @param itemId the item ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item file, or <code>null</code> if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile fetchByItemId_First(long itemId,
        OrderByComparator orderByComparator) throws SystemException {
        List<ItemFile> list = findByItemId(itemId, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last item file in the ordered set where itemId = &#63;.
     *
     * @param itemId the item ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile findByItemId_Last(long itemId,
        OrderByComparator orderByComparator)
        throws NoSuchItemFileException, SystemException {
        ItemFile itemFile = fetchByItemId_Last(itemId, orderByComparator);

        if (itemFile != null) {
            return itemFile;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("itemId=");
        msg.append(itemId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemFileException(msg.toString());
    }

    /**
     * Returns the last item file in the ordered set where itemId = &#63;.
     *
     * @param itemId the item ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item file, or <code>null</code> if a matching item file could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile fetchByItemId_Last(long itemId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByItemId(itemId);

        if (count == 0) {
            return null;
        }

        List<ItemFile> list = findByItemId(itemId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the item files before and after the current item file in the ordered set where itemId = &#63;.
     *
     * @param fileId the primary key of the current item file
     * @param itemId the item ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile[] findByItemId_PrevAndNext(long fileId, long itemId,
        OrderByComparator orderByComparator)
        throws NoSuchItemFileException, SystemException {
        ItemFile itemFile = findByPrimaryKey(fileId);

        Session session = null;

        try {
            session = openSession();

            ItemFile[] array = new ItemFileImpl[3];

            array[0] = getByItemId_PrevAndNext(session, itemFile, itemId,
                    orderByComparator, true);

            array[1] = itemFile;

            array[2] = getByItemId_PrevAndNext(session, itemFile, itemId,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ItemFile getByItemId_PrevAndNext(Session session,
        ItemFile itemFile, long itemId, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ITEMFILE_WHERE);

        query.append(_FINDER_COLUMN_ITEMID_ITEMID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ItemFileModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(itemId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(itemFile);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ItemFile> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the item files where itemId = &#63; from the database.
     *
     * @param itemId the item ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByItemId(long itemId) throws SystemException {
        for (ItemFile itemFile : findByItemId(itemId, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(itemFile);
        }
    }

    /**
     * Returns the number of item files where itemId = &#63;.
     *
     * @param itemId the item ID
     * @return the number of matching item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByItemId(long itemId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ITEMID;

        Object[] finderArgs = new Object[] { itemId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ITEMFILE_WHERE);

            query.append(_FINDER_COLUMN_ITEMID_ITEMID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(itemId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the item file in the entity cache if it is enabled.
     *
     * @param itemFile the item file
     */
    @Override
    public void cacheResult(ItemFile itemFile) {
        EntityCacheUtil.putResult(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileImpl.class, itemFile.getPrimaryKey(), itemFile);

        itemFile.resetOriginalValues();
    }

    /**
     * Caches the item files in the entity cache if it is enabled.
     *
     * @param itemFiles the item files
     */
    @Override
    public void cacheResult(List<ItemFile> itemFiles) {
        for (ItemFile itemFile : itemFiles) {
            if (EntityCacheUtil.getResult(
                        ItemFileModelImpl.ENTITY_CACHE_ENABLED,
                        ItemFileImpl.class, itemFile.getPrimaryKey()) == null) {
                cacheResult(itemFile);
            } else {
                itemFile.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all item files.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(ItemFileImpl.class.getName());
        }

        EntityCacheUtil.clearCache(ItemFileImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the item file.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(ItemFile itemFile) {
        EntityCacheUtil.removeResult(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileImpl.class, itemFile.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    @Override
    public void clearCache(List<ItemFile> itemFiles) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (ItemFile itemFile : itemFiles) {
            EntityCacheUtil.removeResult(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
                ItemFileImpl.class, itemFile.getPrimaryKey());
        }
    }

    /**
     * Creates a new item file with the primary key. Does not add the item file to the database.
     *
     * @param fileId the primary key for the new item file
     * @return the new item file
     */
    @Override
    public ItemFile create(long fileId) {
        ItemFile itemFile = new ItemFileImpl();

        itemFile.setNew(true);
        itemFile.setPrimaryKey(fileId);

        String uuid = PortalUUIDUtil.generate();

        itemFile.setUuid(uuid);

        return itemFile;
    }

    /**
     * Removes the item file with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param fileId the primary key of the item file
     * @return the item file that was removed
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile remove(long fileId)
        throws NoSuchItemFileException, SystemException {
        return remove((Serializable) fileId);
    }

    /**
     * Removes the item file with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the item file
     * @return the item file that was removed
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile remove(Serializable primaryKey)
        throws NoSuchItemFileException, SystemException {
        Session session = null;

        try {
            session = openSession();

            ItemFile itemFile = (ItemFile) session.get(ItemFileImpl.class,
                    primaryKey);

            if (itemFile == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchItemFileException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(itemFile);
        } catch (NoSuchItemFileException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected ItemFile removeImpl(ItemFile itemFile) throws SystemException {
        itemFile = toUnwrappedModel(itemFile);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(itemFile)) {
                itemFile = (ItemFile) session.get(ItemFileImpl.class,
                        itemFile.getPrimaryKeyObj());
            }

            if (itemFile != null) {
                session.delete(itemFile);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (itemFile != null) {
            clearCache(itemFile);
        }

        return itemFile;
    }

    @Override
    public ItemFile updateImpl(
        org.digitalArmour.verifier.model.ItemFile itemFile)
        throws SystemException {
        itemFile = toUnwrappedModel(itemFile);

        boolean isNew = itemFile.isNew();

        ItemFileModelImpl itemFileModelImpl = (ItemFileModelImpl) itemFile;

        if (Validator.isNull(itemFile.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            itemFile.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (itemFile.isNew()) {
                session.save(itemFile);

                itemFile.setNew(false);
            } else {
                session.merge(itemFile);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !ItemFileModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((itemFileModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { itemFileModelImpl.getOriginalUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { itemFileModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }

            if ((itemFileModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        itemFileModelImpl.getOriginalItemId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ITEMID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMID,
                    args);

                args = new Object[] { itemFileModelImpl.getItemId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ITEMID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMID,
                    args);
            }
        }

        EntityCacheUtil.putResult(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
            ItemFileImpl.class, itemFile.getPrimaryKey(), itemFile);

        return itemFile;
    }

    protected ItemFile toUnwrappedModel(ItemFile itemFile) {
        if (itemFile instanceof ItemFileImpl) {
            return itemFile;
        }

        ItemFileImpl itemFileImpl = new ItemFileImpl();

        itemFileImpl.setNew(itemFile.isNew());
        itemFileImpl.setPrimaryKey(itemFile.getPrimaryKey());

        itemFileImpl.setUuid(itemFile.getUuid());
        itemFileImpl.setFileId(itemFile.getFileId());
        itemFileImpl.setFileName(itemFile.getFileName());
        itemFileImpl.setFilePath(itemFile.getFilePath());
        itemFileImpl.setCreateTime(itemFile.getCreateTime());
        itemFileImpl.setItemId(itemFile.getItemId());
        itemFileImpl.setUserId(itemFile.getUserId());

        return itemFileImpl;
    }

    /**
     * Returns the item file with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the item file
     * @return the item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile findByPrimaryKey(Serializable primaryKey)
        throws NoSuchItemFileException, SystemException {
        ItemFile itemFile = fetchByPrimaryKey(primaryKey);

        if (itemFile == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchItemFileException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return itemFile;
    }

    /**
     * Returns the item file with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchItemFileException} if it could not be found.
     *
     * @param fileId the primary key of the item file
     * @return the item file
     * @throws org.digitalArmour.verifier.NoSuchItemFileException if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile findByPrimaryKey(long fileId)
        throws NoSuchItemFileException, SystemException {
        return findByPrimaryKey((Serializable) fileId);
    }

    /**
     * Returns the item file with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the item file
     * @return the item file, or <code>null</code> if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        ItemFile itemFile = (ItemFile) EntityCacheUtil.getResult(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
                ItemFileImpl.class, primaryKey);

        if (itemFile == _nullItemFile) {
            return null;
        }

        if (itemFile == null) {
            Session session = null;

            try {
                session = openSession();

                itemFile = (ItemFile) session.get(ItemFileImpl.class, primaryKey);

                if (itemFile != null) {
                    cacheResult(itemFile);
                } else {
                    EntityCacheUtil.putResult(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
                        ItemFileImpl.class, primaryKey, _nullItemFile);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(ItemFileModelImpl.ENTITY_CACHE_ENABLED,
                    ItemFileImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return itemFile;
    }

    /**
     * Returns the item file with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param fileId the primary key of the item file
     * @return the item file, or <code>null</code> if a item file with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemFile fetchByPrimaryKey(long fileId) throws SystemException {
        return fetchByPrimaryKey((Serializable) fileId);
    }

    /**
     * Returns all the item files.
     *
     * @return the item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the item files.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of item files
     * @param end the upper bound of the range of item files (not inclusive)
     * @return the range of item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findAll(int start, int end) throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the item files.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemFileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of item files
     * @param end the upper bound of the range of item files (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemFile> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<ItemFile> list = (List<ItemFile>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_ITEMFILE);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_ITEMFILE;

                if (pagination) {
                    sql = sql.concat(ItemFileModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<ItemFile>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ItemFile>(list);
                } else {
                    list = (List<ItemFile>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the item files from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (ItemFile itemFile : findAll()) {
            remove(itemFile);
        }
    }

    /**
     * Returns the number of item files.
     *
     * @return the number of item files
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_ITEMFILE);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the item file persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.ItemFile")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<ItemFile>> listenersList = new ArrayList<ModelListener<ItemFile>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<ItemFile>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(ItemFileImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
