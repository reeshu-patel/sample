package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchItemException;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.impl.ItemImpl;
import org.digitalArmour.verifier.model.impl.ItemModelImpl;
import org.digitalArmour.verifier.service.persistence.ItemPersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the item service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ItemPersistence
 * @see ItemUtil
 * @generated
 */
public class ItemPersistenceImpl extends BasePersistenceImpl<Item>
    implements ItemPersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link ItemUtil} to access the item persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = ItemImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            ItemModelImpl.UUID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "item.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "item.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(item.uuid IS NULL OR item.uuid = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CATID = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBycatId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBycatId",
            new String[] { Long.class.getName() },
            ItemModelImpl.CATID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CATID = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycatId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_CATID_CATID_2 = "item.catId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ITEMCLCATID =
        new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByitemCLcatid",
            new String[] {
                Long.class.getName(), Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMCLCATID =
        new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByitemCLcatid",
            new String[] { Long.class.getName(), Long.class.getName() },
            ItemModelImpl.CHECKLISTID_COLUMN_BITMASK |
            ItemModelImpl.CATID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ITEMCLCATID = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByitemCLcatid",
            new String[] { Long.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_ITEMCLCATID_CHECKLISTID_2 = "item.checklistId = ? AND ";
    private static final String _FINDER_COLUMN_ITEMCLCATID_CATID_2 = "item.catId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ITEMMEJOR =
        new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByItemMejor",
            new String[] {
                Boolean.class.getName(), Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMMEJOR =
        new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, ItemImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByItemMejor",
            new String[] { Boolean.class.getName(), Long.class.getName() },
            ItemModelImpl.MAJOR_COLUMN_BITMASK |
            ItemModelImpl.CATID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_ITEMMEJOR = new FinderPath(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByItemMejor",
            new String[] { Boolean.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_ITEMMEJOR_MAJOR_2 = "item.major = ? AND ";
    private static final String _FINDER_COLUMN_ITEMMEJOR_CATID_2 = "item.catId = ?";
    private static final String _SQL_SELECT_ITEM = "SELECT item FROM Item item";
    private static final String _SQL_SELECT_ITEM_WHERE = "SELECT item FROM Item item WHERE ";
    private static final String _SQL_COUNT_ITEM = "SELECT COUNT(item) FROM Item item";
    private static final String _SQL_COUNT_ITEM_WHERE = "SELECT COUNT(item) FROM Item item WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "item.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Item exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Item exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(ItemPersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid"
            });
    private static Item _nullItem = new ItemImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<Item> toCacheModel() {
                return _nullItemCacheModel;
            }
        };

    private static CacheModel<Item> _nullItemCacheModel = new CacheModel<Item>() {
            @Override
            public Item toEntityModel() {
                return _nullItem;
            }
        };

    public ItemPersistenceImpl() {
        setModelClass(Item.class);
    }

    /**
     * Returns all the items where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the items where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @return the range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the items where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<Item> list = (List<Item>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (Item item : list) {
                if (!Validator.equals(uuid, item.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ITEM_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Item>(list);
                } else {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchByUuid_First(uuid, orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the first item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<Item> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByUuid_Last(String uuid, OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchByUuid_Last(uuid, orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the last item in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<Item> list = findByUuid(uuid, count - 1, count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the items before and after the current item in the ordered set where uuid = &#63;.
     *
     * @param itemId the primary key of the current item
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item[] findByUuid_PrevAndNext(long itemId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = findByPrimaryKey(itemId);

        Session session = null;

        try {
            session = openSession();

            Item[] array = new ItemImpl[3];

            array[0] = getByUuid_PrevAndNext(session, item, uuid,
                    orderByComparator, true);

            array[1] = item;

            array[2] = getByUuid_PrevAndNext(session, item, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected Item getByUuid_PrevAndNext(Session session, Item item,
        String uuid, OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ITEM_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(item);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<Item> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the items where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (Item item : findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
                null)) {
            remove(item);
        }
    }

    /**
     * Returns the number of items where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ITEM_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the items where catId = &#63;.
     *
     * @param catId the cat ID
     * @return the matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findBycatId(long catId) throws SystemException {
        return findBycatId(catId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the items where catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param catId the cat ID
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @return the range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findBycatId(long catId, int start, int end)
        throws SystemException {
        return findBycatId(catId, start, end, null);
    }

    /**
     * Returns an ordered range of all the items where catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param catId the cat ID
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findBycatId(long catId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID;
            finderArgs = new Object[] { catId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CATID;
            finderArgs = new Object[] { catId, start, end, orderByComparator };
        }

        List<Item> list = (List<Item>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (Item item : list) {
                if ((catId != item.getCatId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ITEM_WHERE);

            query.append(_FINDER_COLUMN_CATID_CATID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(catId);

                if (!pagination) {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Item>(list);
                } else {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findBycatId_First(long catId,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchBycatId_First(catId, orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the first item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchBycatId_First(long catId,
        OrderByComparator orderByComparator) throws SystemException {
        List<Item> list = findBycatId(catId, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findBycatId_Last(long catId, OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchBycatId_Last(catId, orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the last item in the ordered set where catId = &#63;.
     *
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchBycatId_Last(long catId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countBycatId(catId);

        if (count == 0) {
            return null;
        }

        List<Item> list = findBycatId(catId, count - 1, count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the items before and after the current item in the ordered set where catId = &#63;.
     *
     * @param itemId the primary key of the current item
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item[] findBycatId_PrevAndNext(long itemId, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = findByPrimaryKey(itemId);

        Session session = null;

        try {
            session = openSession();

            Item[] array = new ItemImpl[3];

            array[0] = getBycatId_PrevAndNext(session, item, catId,
                    orderByComparator, true);

            array[1] = item;

            array[2] = getBycatId_PrevAndNext(session, item, catId,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected Item getBycatId_PrevAndNext(Session session, Item item,
        long catId, OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ITEM_WHERE);

        query.append(_FINDER_COLUMN_CATID_CATID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(catId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(item);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<Item> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the items where catId = &#63; from the database.
     *
     * @param catId the cat ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeBycatId(long catId) throws SystemException {
        for (Item item : findBycatId(catId, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(item);
        }
    }

    /**
     * Returns the number of items where catId = &#63;.
     *
     * @param catId the cat ID
     * @return the number of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countBycatId(long catId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CATID;

        Object[] finderArgs = new Object[] { catId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ITEM_WHERE);

            query.append(_FINDER_COLUMN_CATID_CATID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(catId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the items where checklistId = &#63; and catId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @return the matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByitemCLcatid(long checklistId, long catId)
        throws SystemException {
        return findByitemCLcatid(checklistId, catId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the items where checklistId = &#63; and catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @return the range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByitemCLcatid(long checklistId, long catId,
        int start, int end) throws SystemException {
        return findByitemCLcatid(checklistId, catId, start, end, null);
    }

    /**
     * Returns an ordered range of all the items where checklistId = &#63; and catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByitemCLcatid(long checklistId, long catId,
        int start, int end, OrderByComparator orderByComparator)
        throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMCLCATID;
            finderArgs = new Object[] { checklistId, catId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ITEMCLCATID;
            finderArgs = new Object[] {
                    checklistId, catId,
                    
                    start, end, orderByComparator
                };
        }

        List<Item> list = (List<Item>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (Item item : list) {
                if ((checklistId != item.getChecklistId()) ||
                        (catId != item.getCatId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_ITEM_WHERE);

            query.append(_FINDER_COLUMN_ITEMCLCATID_CHECKLISTID_2);

            query.append(_FINDER_COLUMN_ITEMCLCATID_CATID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                qPos.add(catId);

                if (!pagination) {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Item>(list);
                } else {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first item in the ordered set where checklistId = &#63; and catId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByitemCLcatid_First(long checklistId, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchByitemCLcatid_First(checklistId, catId,
                orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(", catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the first item in the ordered set where checklistId = &#63; and catId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByitemCLcatid_First(long checklistId, long catId,
        OrderByComparator orderByComparator) throws SystemException {
        List<Item> list = findByitemCLcatid(checklistId, catId, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last item in the ordered set where checklistId = &#63; and catId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByitemCLcatid_Last(long checklistId, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchByitemCLcatid_Last(checklistId, catId,
                orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(", catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the last item in the ordered set where checklistId = &#63; and catId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByitemCLcatid_Last(long checklistId, long catId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByitemCLcatid(checklistId, catId);

        if (count == 0) {
            return null;
        }

        List<Item> list = findByitemCLcatid(checklistId, catId, count - 1,
                count, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the items before and after the current item in the ordered set where checklistId = &#63; and catId = &#63;.
     *
     * @param itemId the primary key of the current item
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item[] findByitemCLcatid_PrevAndNext(long itemId, long checklistId,
        long catId, OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = findByPrimaryKey(itemId);

        Session session = null;

        try {
            session = openSession();

            Item[] array = new ItemImpl[3];

            array[0] = getByitemCLcatid_PrevAndNext(session, item, checklistId,
                    catId, orderByComparator, true);

            array[1] = item;

            array[2] = getByitemCLcatid_PrevAndNext(session, item, checklistId,
                    catId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected Item getByitemCLcatid_PrevAndNext(Session session, Item item,
        long checklistId, long catId, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ITEM_WHERE);

        query.append(_FINDER_COLUMN_ITEMCLCATID_CHECKLISTID_2);

        query.append(_FINDER_COLUMN_ITEMCLCATID_CATID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(checklistId);

        qPos.add(catId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(item);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<Item> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the items where checklistId = &#63; and catId = &#63; from the database.
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByitemCLcatid(long checklistId, long catId)
        throws SystemException {
        for (Item item : findByitemCLcatid(checklistId, catId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(item);
        }
    }

    /**
     * Returns the number of items where checklistId = &#63; and catId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param catId the cat ID
     * @return the number of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByitemCLcatid(long checklistId, long catId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ITEMCLCATID;

        Object[] finderArgs = new Object[] { checklistId, catId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_ITEM_WHERE);

            query.append(_FINDER_COLUMN_ITEMCLCATID_CHECKLISTID_2);

            query.append(_FINDER_COLUMN_ITEMCLCATID_CATID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                qPos.add(catId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the items where major = &#63; and catId = &#63;.
     *
     * @param major the major
     * @param catId the cat ID
     * @return the matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByItemMejor(boolean major, long catId)
        throws SystemException {
        return findByItemMejor(major, catId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the items where major = &#63; and catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param major the major
     * @param catId the cat ID
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @return the range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByItemMejor(boolean major, long catId, int start,
        int end) throws SystemException {
        return findByItemMejor(major, catId, start, end, null);
    }

    /**
     * Returns an ordered range of all the items where major = &#63; and catId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param major the major
     * @param catId the cat ID
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findByItemMejor(boolean major, long catId, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMMEJOR;
            finderArgs = new Object[] { major, catId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ITEMMEJOR;
            finderArgs = new Object[] {
                    major, catId,
                    
                    start, end, orderByComparator
                };
        }

        List<Item> list = (List<Item>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (Item item : list) {
                if ((major != item.getMajor()) || (catId != item.getCatId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_ITEM_WHERE);

            query.append(_FINDER_COLUMN_ITEMMEJOR_MAJOR_2);

            query.append(_FINDER_COLUMN_ITEMMEJOR_CATID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ItemModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(major);

                qPos.add(catId);

                if (!pagination) {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Item>(list);
                } else {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first item in the ordered set where major = &#63; and catId = &#63;.
     *
     * @param major the major
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByItemMejor_First(boolean major, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchByItemMejor_First(major, catId, orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("major=");
        msg.append(major);

        msg.append(", catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the first item in the ordered set where major = &#63; and catId = &#63;.
     *
     * @param major the major
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByItemMejor_First(boolean major, long catId,
        OrderByComparator orderByComparator) throws SystemException {
        List<Item> list = findByItemMejor(major, catId, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last item in the ordered set where major = &#63; and catId = &#63;.
     *
     * @param major the major
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByItemMejor_Last(boolean major, long catId,
        OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = fetchByItemMejor_Last(major, catId, orderByComparator);

        if (item != null) {
            return item;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("major=");
        msg.append(major);

        msg.append(", catId=");
        msg.append(catId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemException(msg.toString());
    }

    /**
     * Returns the last item in the ordered set where major = &#63; and catId = &#63;.
     *
     * @param major the major
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item, or <code>null</code> if a matching item could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByItemMejor_Last(boolean major, long catId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByItemMejor(major, catId);

        if (count == 0) {
            return null;
        }

        List<Item> list = findByItemMejor(major, catId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the items before and after the current item in the ordered set where major = &#63; and catId = &#63;.
     *
     * @param itemId the primary key of the current item
     * @param major the major
     * @param catId the cat ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item[] findByItemMejor_PrevAndNext(long itemId, boolean major,
        long catId, OrderByComparator orderByComparator)
        throws NoSuchItemException, SystemException {
        Item item = findByPrimaryKey(itemId);

        Session session = null;

        try {
            session = openSession();

            Item[] array = new ItemImpl[3];

            array[0] = getByItemMejor_PrevAndNext(session, item, major, catId,
                    orderByComparator, true);

            array[1] = item;

            array[2] = getByItemMejor_PrevAndNext(session, item, major, catId,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected Item getByItemMejor_PrevAndNext(Session session, Item item,
        boolean major, long catId, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ITEM_WHERE);

        query.append(_FINDER_COLUMN_ITEMMEJOR_MAJOR_2);

        query.append(_FINDER_COLUMN_ITEMMEJOR_CATID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ItemModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(major);

        qPos.add(catId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(item);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<Item> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the items where major = &#63; and catId = &#63; from the database.
     *
     * @param major the major
     * @param catId the cat ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByItemMejor(boolean major, long catId)
        throws SystemException {
        for (Item item : findByItemMejor(major, catId, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(item);
        }
    }

    /**
     * Returns the number of items where major = &#63; and catId = &#63;.
     *
     * @param major the major
     * @param catId the cat ID
     * @return the number of matching items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByItemMejor(boolean major, long catId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_ITEMMEJOR;

        Object[] finderArgs = new Object[] { major, catId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_ITEM_WHERE);

            query.append(_FINDER_COLUMN_ITEMMEJOR_MAJOR_2);

            query.append(_FINDER_COLUMN_ITEMMEJOR_CATID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(major);

                qPos.add(catId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the item in the entity cache if it is enabled.
     *
     * @param item the item
     */
    @Override
    public void cacheResult(Item item) {
        EntityCacheUtil.putResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemImpl.class, item.getPrimaryKey(), item);

        item.resetOriginalValues();
    }

    /**
     * Caches the items in the entity cache if it is enabled.
     *
     * @param items the items
     */
    @Override
    public void cacheResult(List<Item> items) {
        for (Item item : items) {
            if (EntityCacheUtil.getResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
                        ItemImpl.class, item.getPrimaryKey()) == null) {
                cacheResult(item);
            } else {
                item.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all items.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(ItemImpl.class.getName());
        }

        EntityCacheUtil.clearCache(ItemImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the item.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(Item item) {
        EntityCacheUtil.removeResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemImpl.class, item.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    @Override
    public void clearCache(List<Item> items) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (Item item : items) {
            EntityCacheUtil.removeResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
                ItemImpl.class, item.getPrimaryKey());
        }
    }

    /**
     * Creates a new item with the primary key. Does not add the item to the database.
     *
     * @param itemId the primary key for the new item
     * @return the new item
     */
    @Override
    public Item create(long itemId) {
        Item item = new ItemImpl();

        item.setNew(true);
        item.setPrimaryKey(itemId);

        String uuid = PortalUUIDUtil.generate();

        item.setUuid(uuid);

        return item;
    }

    /**
     * Removes the item with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param itemId the primary key of the item
     * @return the item that was removed
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item remove(long itemId) throws NoSuchItemException, SystemException {
        return remove((Serializable) itemId);
    }

    /**
     * Removes the item with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the item
     * @return the item that was removed
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item remove(Serializable primaryKey)
        throws NoSuchItemException, SystemException {
        Session session = null;

        try {
            session = openSession();

            Item item = (Item) session.get(ItemImpl.class, primaryKey);

            if (item == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchItemException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(item);
        } catch (NoSuchItemException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected Item removeImpl(Item item) throws SystemException {
        item = toUnwrappedModel(item);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(item)) {
                item = (Item) session.get(ItemImpl.class,
                        item.getPrimaryKeyObj());
            }

            if (item != null) {
                session.delete(item);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (item != null) {
            clearCache(item);
        }

        return item;
    }

    @Override
    public Item updateImpl(org.digitalArmour.verifier.model.Item item)
        throws SystemException {
        item = toUnwrappedModel(item);

        boolean isNew = item.isNew();

        ItemModelImpl itemModelImpl = (ItemModelImpl) item;

        if (Validator.isNull(item.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            item.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (item.isNew()) {
                session.save(item);

                item.setNew(false);
            } else {
                session.merge(item);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !ItemModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((itemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { itemModelImpl.getOriginalUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { itemModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }

            if ((itemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { itemModelImpl.getOriginalCatId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CATID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID,
                    args);

                args = new Object[] { itemModelImpl.getCatId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CATID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CATID,
                    args);
            }

            if ((itemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMCLCATID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        itemModelImpl.getOriginalChecklistId(),
                        itemModelImpl.getOriginalCatId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ITEMCLCATID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMCLCATID,
                    args);

                args = new Object[] {
                        itemModelImpl.getChecklistId(), itemModelImpl.getCatId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ITEMCLCATID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMCLCATID,
                    args);
            }

            if ((itemModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMMEJOR.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        itemModelImpl.getOriginalMajor(),
                        itemModelImpl.getOriginalCatId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ITEMMEJOR,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMMEJOR,
                    args);

                args = new Object[] {
                        itemModelImpl.getMajor(), itemModelImpl.getCatId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ITEMMEJOR,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ITEMMEJOR,
                    args);
            }
        }

        EntityCacheUtil.putResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
            ItemImpl.class, item.getPrimaryKey(), item);

        return item;
    }

    protected Item toUnwrappedModel(Item item) {
        if (item instanceof ItemImpl) {
            return item;
        }

        ItemImpl itemImpl = new ItemImpl();

        itemImpl.setNew(item.isNew());
        itemImpl.setPrimaryKey(item.getPrimaryKey());

        itemImpl.setUuid(item.getUuid());
        itemImpl.setItemId(item.getItemId());
        itemImpl.setItemName(item.getItemName());
        itemImpl.setItemDesc(item.getItemDesc());
        itemImpl.setMinor(item.isMinor());
        itemImpl.setMinor_percent(item.getMinor_percent());
        itemImpl.setMajor(item.isMajor());
        itemImpl.setMajor_percent(item.getMajor_percent());
        itemImpl.setUserGroupId(item.getUserGroupId());
        itemImpl.setCatId(item.getCatId());
        itemImpl.setChecklistId(item.getChecklistId());

        return itemImpl;
    }

    /**
     * Returns the item with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the item
     * @return the item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByPrimaryKey(Serializable primaryKey)
        throws NoSuchItemException, SystemException {
        Item item = fetchByPrimaryKey(primaryKey);

        if (item == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchItemException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return item;
    }

    /**
     * Returns the item with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchItemException} if it could not be found.
     *
     * @param itemId the primary key of the item
     * @return the item
     * @throws org.digitalArmour.verifier.NoSuchItemException if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item findByPrimaryKey(long itemId)
        throws NoSuchItemException, SystemException {
        return findByPrimaryKey((Serializable) itemId);
    }

    /**
     * Returns the item with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the item
     * @return the item, or <code>null</code> if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        Item item = (Item) EntityCacheUtil.getResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
                ItemImpl.class, primaryKey);

        if (item == _nullItem) {
            return null;
        }

        if (item == null) {
            Session session = null;

            try {
                session = openSession();

                item = (Item) session.get(ItemImpl.class, primaryKey);

                if (item != null) {
                    cacheResult(item);
                } else {
                    EntityCacheUtil.putResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
                        ItemImpl.class, primaryKey, _nullItem);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(ItemModelImpl.ENTITY_CACHE_ENABLED,
                    ItemImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return item;
    }

    /**
     * Returns the item with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param itemId the primary key of the item
     * @return the item, or <code>null</code> if a item with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Item fetchByPrimaryKey(long itemId) throws SystemException {
        return fetchByPrimaryKey((Serializable) itemId);
    }

    /**
     * Returns all the items.
     *
     * @return the items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the items.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @return the range of items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findAll(int start, int end) throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the items.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of items
     * @param end the upper bound of the range of items (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Item> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<Item> list = (List<Item>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_ITEM);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_ITEM;

                if (pagination) {
                    sql = sql.concat(ItemModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Item>(list);
                } else {
                    list = (List<Item>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the items from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (Item item : findAll()) {
            remove(item);
        }
    }

    /**
     * Returns the number of items.
     *
     * @return the number of items
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_ITEM);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the item persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.Item")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<Item>> listenersList = new ArrayList<ModelListener<Item>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<Item>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(ItemImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
