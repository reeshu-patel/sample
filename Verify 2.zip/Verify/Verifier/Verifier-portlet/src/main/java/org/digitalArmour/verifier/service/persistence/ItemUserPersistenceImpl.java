package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchItemUserException;
import org.digitalArmour.verifier.model.ItemUser;
import org.digitalArmour.verifier.model.impl.ItemUserImpl;
import org.digitalArmour.verifier.model.impl.ItemUserModelImpl;
import org.digitalArmour.verifier.service.persistence.ItemUserPersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the item user service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ItemUserPersistence
 * @see ItemUserUtil
 * @generated
 */
public class ItemUserPersistenceImpl extends BasePersistenceImpl<ItemUser>
    implements ItemUserPersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link ItemUserUtil} to access the item user persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = ItemUserImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserModelImpl.FINDER_CACHE_ENABLED, ItemUserImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserModelImpl.FINDER_CACHE_ENABLED, ItemUserImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserModelImpl.FINDER_CACHE_ENABLED, ItemUserImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserModelImpl.FINDER_CACHE_ENABLED, ItemUserImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            ItemUserModelImpl.UUID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "itemUser.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "itemUser.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(itemUser.uuid IS NULL OR itemUser.uuid = '')";
    private static final String _SQL_SELECT_ITEMUSER = "SELECT itemUser FROM ItemUser itemUser";
    private static final String _SQL_SELECT_ITEMUSER_WHERE = "SELECT itemUser FROM ItemUser itemUser WHERE ";
    private static final String _SQL_COUNT_ITEMUSER = "SELECT COUNT(itemUser) FROM ItemUser itemUser";
    private static final String _SQL_COUNT_ITEMUSER_WHERE = "SELECT COUNT(itemUser) FROM ItemUser itemUser WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "itemUser.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No ItemUser exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No ItemUser exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(ItemUserPersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid"
            });
    private static ItemUser _nullItemUser = new ItemUserImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<ItemUser> toCacheModel() {
                return _nullItemUserCacheModel;
            }
        };

    private static CacheModel<ItemUser> _nullItemUserCacheModel = new CacheModel<ItemUser>() {
            @Override
            public ItemUser toEntityModel() {
                return _nullItemUser;
            }
        };

    public ItemUserPersistenceImpl() {
        setModelClass(ItemUser.class);
    }

    /**
     * Returns all the item users where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemUser> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the item users where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of item users
     * @param end the upper bound of the range of item users (not inclusive)
     * @return the range of matching item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemUser> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the item users where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of item users
     * @param end the upper bound of the range of item users (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemUser> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<ItemUser> list = (List<ItemUser>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (ItemUser itemUser : list) {
                if (!Validator.equals(uuid, itemUser.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_ITEMUSER_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(ItemUserModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<ItemUser>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ItemUser>(list);
                } else {
                    list = (List<ItemUser>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first item user in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item user
     * @throws org.digitalArmour.verifier.NoSuchItemUserException if a matching item user could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemUserException, SystemException {
        ItemUser itemUser = fetchByUuid_First(uuid, orderByComparator);

        if (itemUser != null) {
            return itemUser;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemUserException(msg.toString());
    }

    /**
     * Returns the first item user in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching item user, or <code>null</code> if a matching item user could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<ItemUser> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last item user in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item user
     * @throws org.digitalArmour.verifier.NoSuchItemUserException if a matching item user could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser findByUuid_Last(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemUserException, SystemException {
        ItemUser itemUser = fetchByUuid_Last(uuid, orderByComparator);

        if (itemUser != null) {
            return itemUser;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchItemUserException(msg.toString());
    }

    /**
     * Returns the last item user in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching item user, or <code>null</code> if a matching item user could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<ItemUser> list = findByUuid(uuid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the item users before and after the current item user in the ordered set where uuid = &#63;.
     *
     * @param itemUserId the primary key of the current item user
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next item user
     * @throws org.digitalArmour.verifier.NoSuchItemUserException if a item user with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser[] findByUuid_PrevAndNext(long itemUserId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchItemUserException, SystemException {
        ItemUser itemUser = findByPrimaryKey(itemUserId);

        Session session = null;

        try {
            session = openSession();

            ItemUser[] array = new ItemUserImpl[3];

            array[0] = getByUuid_PrevAndNext(session, itemUser, uuid,
                    orderByComparator, true);

            array[1] = itemUser;

            array[2] = getByUuid_PrevAndNext(session, itemUser, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected ItemUser getByUuid_PrevAndNext(Session session,
        ItemUser itemUser, String uuid, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_ITEMUSER_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(ItemUserModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(itemUser);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<ItemUser> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the item users where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (ItemUser itemUser : findByUuid(uuid, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(itemUser);
        }
    }

    /**
     * Returns the number of item users where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_ITEMUSER_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the item user in the entity cache if it is enabled.
     *
     * @param itemUser the item user
     */
    @Override
    public void cacheResult(ItemUser itemUser) {
        EntityCacheUtil.putResult(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserImpl.class, itemUser.getPrimaryKey(), itemUser);

        itemUser.resetOriginalValues();
    }

    /**
     * Caches the item users in the entity cache if it is enabled.
     *
     * @param itemUsers the item users
     */
    @Override
    public void cacheResult(List<ItemUser> itemUsers) {
        for (ItemUser itemUser : itemUsers) {
            if (EntityCacheUtil.getResult(
                        ItemUserModelImpl.ENTITY_CACHE_ENABLED,
                        ItemUserImpl.class, itemUser.getPrimaryKey()) == null) {
                cacheResult(itemUser);
            } else {
                itemUser.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all item users.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(ItemUserImpl.class.getName());
        }

        EntityCacheUtil.clearCache(ItemUserImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the item user.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(ItemUser itemUser) {
        EntityCacheUtil.removeResult(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserImpl.class, itemUser.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    @Override
    public void clearCache(List<ItemUser> itemUsers) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (ItemUser itemUser : itemUsers) {
            EntityCacheUtil.removeResult(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
                ItemUserImpl.class, itemUser.getPrimaryKey());
        }
    }

    /**
     * Creates a new item user with the primary key. Does not add the item user to the database.
     *
     * @param itemUserId the primary key for the new item user
     * @return the new item user
     */
    @Override
    public ItemUser create(long itemUserId) {
        ItemUser itemUser = new ItemUserImpl();

        itemUser.setNew(true);
        itemUser.setPrimaryKey(itemUserId);

        String uuid = PortalUUIDUtil.generate();

        itemUser.setUuid(uuid);

        return itemUser;
    }

    /**
     * Removes the item user with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param itemUserId the primary key of the item user
     * @return the item user that was removed
     * @throws org.digitalArmour.verifier.NoSuchItemUserException if a item user with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser remove(long itemUserId)
        throws NoSuchItemUserException, SystemException {
        return remove((Serializable) itemUserId);
    }

    /**
     * Removes the item user with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the item user
     * @return the item user that was removed
     * @throws org.digitalArmour.verifier.NoSuchItemUserException if a item user with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser remove(Serializable primaryKey)
        throws NoSuchItemUserException, SystemException {
        Session session = null;

        try {
            session = openSession();

            ItemUser itemUser = (ItemUser) session.get(ItemUserImpl.class,
                    primaryKey);

            if (itemUser == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchItemUserException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(itemUser);
        } catch (NoSuchItemUserException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected ItemUser removeImpl(ItemUser itemUser) throws SystemException {
        itemUser = toUnwrappedModel(itemUser);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(itemUser)) {
                itemUser = (ItemUser) session.get(ItemUserImpl.class,
                        itemUser.getPrimaryKeyObj());
            }

            if (itemUser != null) {
                session.delete(itemUser);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (itemUser != null) {
            clearCache(itemUser);
        }

        return itemUser;
    }

    @Override
    public ItemUser updateImpl(
        org.digitalArmour.verifier.model.ItemUser itemUser)
        throws SystemException {
        itemUser = toUnwrappedModel(itemUser);

        boolean isNew = itemUser.isNew();

        ItemUserModelImpl itemUserModelImpl = (ItemUserModelImpl) itemUser;

        if (Validator.isNull(itemUser.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            itemUser.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (itemUser.isNew()) {
                session.save(itemUser);

                itemUser.setNew(false);
            } else {
                session.merge(itemUser);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !ItemUserModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((itemUserModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { itemUserModelImpl.getOriginalUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { itemUserModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }
        }

        EntityCacheUtil.putResult(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
            ItemUserImpl.class, itemUser.getPrimaryKey(), itemUser);

        return itemUser;
    }

    protected ItemUser toUnwrappedModel(ItemUser itemUser) {
        if (itemUser instanceof ItemUserImpl) {
            return itemUser;
        }

        ItemUserImpl itemUserImpl = new ItemUserImpl();

        itemUserImpl.setNew(itemUser.isNew());
        itemUserImpl.setPrimaryKey(itemUser.getPrimaryKey());

        itemUserImpl.setUuid(itemUser.getUuid());
        itemUserImpl.setItemUserId(itemUser.getItemUserId());
        itemUserImpl.setCreateDate(itemUser.getCreateDate());
        itemUserImpl.setDueDate(itemUser.getDueDate());
        itemUserImpl.setItemId(itemUser.getItemId());
        itemUserImpl.setUserId(itemUser.getUserId());

        return itemUserImpl;
    }

    /**
     * Returns the item user with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the item user
     * @return the item user
     * @throws org.digitalArmour.verifier.NoSuchItemUserException if a item user with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser findByPrimaryKey(Serializable primaryKey)
        throws NoSuchItemUserException, SystemException {
        ItemUser itemUser = fetchByPrimaryKey(primaryKey);

        if (itemUser == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchItemUserException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return itemUser;
    }

    /**
     * Returns the item user with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchItemUserException} if it could not be found.
     *
     * @param itemUserId the primary key of the item user
     * @return the item user
     * @throws org.digitalArmour.verifier.NoSuchItemUserException if a item user with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser findByPrimaryKey(long itemUserId)
        throws NoSuchItemUserException, SystemException {
        return findByPrimaryKey((Serializable) itemUserId);
    }

    /**
     * Returns the item user with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the item user
     * @return the item user, or <code>null</code> if a item user with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        ItemUser itemUser = (ItemUser) EntityCacheUtil.getResult(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
                ItemUserImpl.class, primaryKey);

        if (itemUser == _nullItemUser) {
            return null;
        }

        if (itemUser == null) {
            Session session = null;

            try {
                session = openSession();

                itemUser = (ItemUser) session.get(ItemUserImpl.class, primaryKey);

                if (itemUser != null) {
                    cacheResult(itemUser);
                } else {
                    EntityCacheUtil.putResult(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
                        ItemUserImpl.class, primaryKey, _nullItemUser);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(ItemUserModelImpl.ENTITY_CACHE_ENABLED,
                    ItemUserImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return itemUser;
    }

    /**
     * Returns the item user with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param itemUserId the primary key of the item user
     * @return the item user, or <code>null</code> if a item user with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public ItemUser fetchByPrimaryKey(long itemUserId)
        throws SystemException {
        return fetchByPrimaryKey((Serializable) itemUserId);
    }

    /**
     * Returns all the item users.
     *
     * @return the item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemUser> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the item users.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of item users
     * @param end the upper bound of the range of item users (not inclusive)
     * @return the range of item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemUser> findAll(int start, int end) throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the item users.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.ItemUserModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of item users
     * @param end the upper bound of the range of item users (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<ItemUser> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<ItemUser> list = (List<ItemUser>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_ITEMUSER);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_ITEMUSER;

                if (pagination) {
                    sql = sql.concat(ItemUserModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<ItemUser>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<ItemUser>(list);
                } else {
                    list = (List<ItemUser>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the item users from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (ItemUser itemUser : findAll()) {
            remove(itemUser);
        }
    }

    /**
     * Returns the number of item users.
     *
     * @return the number of item users
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_ITEMUSER);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the item user persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.ItemUser")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<ItemUser>> listenersList = new ArrayList<ModelListener<ItemUser>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<ItemUser>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(ItemUserImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
