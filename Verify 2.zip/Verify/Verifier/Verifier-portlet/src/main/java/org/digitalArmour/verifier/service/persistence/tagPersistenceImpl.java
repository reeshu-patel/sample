package org.digitalArmour.verifier.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import org.digitalArmour.verifier.NoSuchtagException;
import org.digitalArmour.verifier.model.impl.tagImpl;
import org.digitalArmour.verifier.model.impl.tagModelImpl;
import org.digitalArmour.verifier.model.tag;
import org.digitalArmour.verifier.service.persistence.tagPersistence;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the tag service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see tagPersistence
 * @see tagUtil
 * @generated
 */
public class tagPersistenceImpl extends BasePersistenceImpl<tag>
    implements tagPersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link tagUtil} to access the tag persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = tagImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, tagImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, tagImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_TAGTAGNAME =
        new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, tagImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBytagtagName",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TAGTAGNAME =
        new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, tagImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBytagtagName",
            new String[] { String.class.getName() },
            tagModelImpl.TAGNAME_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_TAGTAGNAME = new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBytagtagName",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_TAGTAGNAME_TAGNAME_1 = "tag.tagName IS NULL";
    private static final String _FINDER_COLUMN_TAGTAGNAME_TAGNAME_2 = "tag.tagName = ?";
    private static final String _FINDER_COLUMN_TAGTAGNAME_TAGNAME_3 = "(tag.tagName IS NULL OR tag.tagName = '')";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKLISTID =
        new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, tagImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBychecklistId",
            new String[] {
                Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID =
        new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, tagImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBychecklistId",
            new String[] { Long.class.getName() },
            tagModelImpl.CHECKLISTID_COLUMN_BITMASK |
            tagModelImpl.TAGNAME_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_CHECKLISTID = new FinderPath(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBychecklistId",
            new String[] { Long.class.getName() });
    private static final String _FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2 = "tag.checklistId = ?";
    private static final String _SQL_SELECT_TAG = "SELECT tag FROM tag tag";
    private static final String _SQL_SELECT_TAG_WHERE = "SELECT tag FROM tag tag WHERE ";
    private static final String _SQL_COUNT_TAG = "SELECT COUNT(tag) FROM tag tag";
    private static final String _SQL_COUNT_TAG_WHERE = "SELECT COUNT(tag) FROM tag tag WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "tag.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No tag exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No tag exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(tagPersistenceImpl.class);
    private static tag _nulltag = new tagImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<tag> toCacheModel() {
                return _nulltagCacheModel;
            }
        };

    private static CacheModel<tag> _nulltagCacheModel = new CacheModel<tag>() {
            @Override
            public tag toEntityModel() {
                return _nulltag;
            }
        };

    public tagPersistenceImpl() {
        setModelClass(tag.class);
    }

    /**
     * Returns all the tags where tagName = &#63;.
     *
     * @param tagName the tag name
     * @return the matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findBytagtagName(String tagName) throws SystemException {
        return findBytagtagName(tagName, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
            null);
    }

    /**
     * Returns a range of all the tags where tagName = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param tagName the tag name
     * @param start the lower bound of the range of tags
     * @param end the upper bound of the range of tags (not inclusive)
     * @return the range of matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findBytagtagName(String tagName, int start, int end)
        throws SystemException {
        return findBytagtagName(tagName, start, end, null);
    }

    /**
     * Returns an ordered range of all the tags where tagName = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param tagName the tag name
     * @param start the lower bound of the range of tags
     * @param end the upper bound of the range of tags (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findBytagtagName(String tagName, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TAGTAGNAME;
            finderArgs = new Object[] { tagName };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_TAGTAGNAME;
            finderArgs = new Object[] { tagName, start, end, orderByComparator };
        }

        List<tag> list = (List<tag>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (tag tag : list) {
                if (!Validator.equals(tagName, tag.getTagName())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_TAG_WHERE);

            boolean bindTagName = false;

            if (tagName == null) {
                query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_1);
            } else if (tagName.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_3);
            } else {
                bindTagName = true;

                query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(tagModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindTagName) {
                    qPos.add(tagName);
                }

                if (!pagination) {
                    list = (List<tag>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<tag>(list);
                } else {
                    list = (List<tag>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first tag in the ordered set where tagName = &#63;.
     *
     * @param tagName the tag name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag findBytagtagName_First(String tagName,
        OrderByComparator orderByComparator)
        throws NoSuchtagException, SystemException {
        tag tag = fetchBytagtagName_First(tagName, orderByComparator);

        if (tag != null) {
            return tag;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("tagName=");
        msg.append(tagName);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchtagException(msg.toString());
    }

    /**
     * Returns the first tag in the ordered set where tagName = &#63;.
     *
     * @param tagName the tag name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching tag, or <code>null</code> if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag fetchBytagtagName_First(String tagName,
        OrderByComparator orderByComparator) throws SystemException {
        List<tag> list = findBytagtagName(tagName, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last tag in the ordered set where tagName = &#63;.
     *
     * @param tagName the tag name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag findBytagtagName_Last(String tagName,
        OrderByComparator orderByComparator)
        throws NoSuchtagException, SystemException {
        tag tag = fetchBytagtagName_Last(tagName, orderByComparator);

        if (tag != null) {
            return tag;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("tagName=");
        msg.append(tagName);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchtagException(msg.toString());
    }

    /**
     * Returns the last tag in the ordered set where tagName = &#63;.
     *
     * @param tagName the tag name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching tag, or <code>null</code> if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag fetchBytagtagName_Last(String tagName,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countBytagtagName(tagName);

        if (count == 0) {
            return null;
        }

        List<tag> list = findBytagtagName(tagName, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the tags before and after the current tag in the ordered set where tagName = &#63;.
     *
     * @param Id the primary key of the current tag
     * @param tagName the tag name
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag[] findBytagtagName_PrevAndNext(long Id, String tagName,
        OrderByComparator orderByComparator)
        throws NoSuchtagException, SystemException {
        tag tag = findByPrimaryKey(Id);

        Session session = null;

        try {
            session = openSession();

            tag[] array = new tagImpl[3];

            array[0] = getBytagtagName_PrevAndNext(session, tag, tagName,
                    orderByComparator, true);

            array[1] = tag;

            array[2] = getBytagtagName_PrevAndNext(session, tag, tagName,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected tag getBytagtagName_PrevAndNext(Session session, tag tag,
        String tagName, OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_TAG_WHERE);

        boolean bindTagName = false;

        if (tagName == null) {
            query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_1);
        } else if (tagName.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_3);
        } else {
            bindTagName = true;

            query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(tagModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindTagName) {
            qPos.add(tagName);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(tag);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<tag> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the tags where tagName = &#63; from the database.
     *
     * @param tagName the tag name
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeBytagtagName(String tagName) throws SystemException {
        for (tag tag : findBytagtagName(tagName, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(tag);
        }
    }

    /**
     * Returns the number of tags where tagName = &#63;.
     *
     * @param tagName the tag name
     * @return the number of matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countBytagtagName(String tagName) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_TAGTAGNAME;

        Object[] finderArgs = new Object[] { tagName };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_TAG_WHERE);

            boolean bindTagName = false;

            if (tagName == null) {
                query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_1);
            } else if (tagName.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_3);
            } else {
                bindTagName = true;

                query.append(_FINDER_COLUMN_TAGTAGNAME_TAGNAME_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindTagName) {
                    qPos.add(tagName);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the tags where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @return the matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findBychecklistId(long checklistId)
        throws SystemException {
        return findBychecklistId(checklistId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the tags where checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of tags
     * @param end the upper bound of the range of tags (not inclusive)
     * @return the range of matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findBychecklistId(long checklistId, int start, int end)
        throws SystemException {
        return findBychecklistId(checklistId, start, end, null);
    }

    /**
     * Returns an ordered range of all the tags where checklistId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param checklistId the checklist ID
     * @param start the lower bound of the range of tags
     * @param end the upper bound of the range of tags (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findBychecklistId(long checklistId, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID;
            finderArgs = new Object[] { checklistId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CHECKLISTID;
            finderArgs = new Object[] { checklistId, start, end, orderByComparator };
        }

        List<tag> list = (List<tag>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (tag tag : list) {
                if ((checklistId != tag.getChecklistId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_TAG_WHERE);

            query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(tagModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                if (!pagination) {
                    list = (List<tag>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<tag>(list);
                } else {
                    list = (List<tag>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first tag in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag findBychecklistId_First(long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchtagException, SystemException {
        tag tag = fetchBychecklistId_First(checklistId, orderByComparator);

        if (tag != null) {
            return tag;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchtagException(msg.toString());
    }

    /**
     * Returns the first tag in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching tag, or <code>null</code> if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag fetchBychecklistId_First(long checklistId,
        OrderByComparator orderByComparator) throws SystemException {
        List<tag> list = findBychecklistId(checklistId, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last tag in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag findBychecklistId_Last(long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchtagException, SystemException {
        tag tag = fetchBychecklistId_Last(checklistId, orderByComparator);

        if (tag != null) {
            return tag;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("checklistId=");
        msg.append(checklistId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchtagException(msg.toString());
    }

    /**
     * Returns the last tag in the ordered set where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching tag, or <code>null</code> if a matching tag could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag fetchBychecklistId_Last(long checklistId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countBychecklistId(checklistId);

        if (count == 0) {
            return null;
        }

        List<tag> list = findBychecklistId(checklistId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the tags before and after the current tag in the ordered set where checklistId = &#63;.
     *
     * @param Id the primary key of the current tag
     * @param checklistId the checklist ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag[] findBychecklistId_PrevAndNext(long Id, long checklistId,
        OrderByComparator orderByComparator)
        throws NoSuchtagException, SystemException {
        tag tag = findByPrimaryKey(Id);

        Session session = null;

        try {
            session = openSession();

            tag[] array = new tagImpl[3];

            array[0] = getBychecklistId_PrevAndNext(session, tag, checklistId,
                    orderByComparator, true);

            array[1] = tag;

            array[2] = getBychecklistId_PrevAndNext(session, tag, checklistId,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected tag getBychecklistId_PrevAndNext(Session session, tag tag,
        long checklistId, OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_TAG_WHERE);

        query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(tagModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(checklistId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(tag);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<tag> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the tags where checklistId = &#63; from the database.
     *
     * @param checklistId the checklist ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeBychecklistId(long checklistId) throws SystemException {
        for (tag tag : findBychecklistId(checklistId, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(tag);
        }
    }

    /**
     * Returns the number of tags where checklistId = &#63;.
     *
     * @param checklistId the checklist ID
     * @return the number of matching tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countBychecklistId(long checklistId) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_CHECKLISTID;

        Object[] finderArgs = new Object[] { checklistId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_TAG_WHERE);

            query.append(_FINDER_COLUMN_CHECKLISTID_CHECKLISTID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(checklistId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the tag in the entity cache if it is enabled.
     *
     * @param tag the tag
     */
    @Override
    public void cacheResult(tag tag) {
        EntityCacheUtil.putResult(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagImpl.class, tag.getPrimaryKey(), tag);

        tag.resetOriginalValues();
    }

    /**
     * Caches the tags in the entity cache if it is enabled.
     *
     * @param tags the tags
     */
    @Override
    public void cacheResult(List<tag> tags) {
        for (tag tag : tags) {
            if (EntityCacheUtil.getResult(tagModelImpl.ENTITY_CACHE_ENABLED,
                        tagImpl.class, tag.getPrimaryKey()) == null) {
                cacheResult(tag);
            } else {
                tag.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all tags.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(tagImpl.class.getName());
        }

        EntityCacheUtil.clearCache(tagImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the tag.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(tag tag) {
        EntityCacheUtil.removeResult(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagImpl.class, tag.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    @Override
    public void clearCache(List<tag> tags) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (tag tag : tags) {
            EntityCacheUtil.removeResult(tagModelImpl.ENTITY_CACHE_ENABLED,
                tagImpl.class, tag.getPrimaryKey());
        }
    }

    /**
     * Creates a new tag with the primary key. Does not add the tag to the database.
     *
     * @param Id the primary key for the new tag
     * @return the new tag
     */
    @Override
    public tag create(long Id) {
        tag tag = new tagImpl();

        tag.setNew(true);
        tag.setPrimaryKey(Id);

        return tag;
    }

    /**
     * Removes the tag with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param Id the primary key of the tag
     * @return the tag that was removed
     * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag remove(long Id) throws NoSuchtagException, SystemException {
        return remove((Serializable) Id);
    }

    /**
     * Removes the tag with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the tag
     * @return the tag that was removed
     * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag remove(Serializable primaryKey)
        throws NoSuchtagException, SystemException {
        Session session = null;

        try {
            session = openSession();

            tag tag = (tag) session.get(tagImpl.class, primaryKey);

            if (tag == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchtagException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(tag);
        } catch (NoSuchtagException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected tag removeImpl(tag tag) throws SystemException {
        tag = toUnwrappedModel(tag);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(tag)) {
                tag = (tag) session.get(tagImpl.class, tag.getPrimaryKeyObj());
            }

            if (tag != null) {
                session.delete(tag);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (tag != null) {
            clearCache(tag);
        }

        return tag;
    }

    @Override
    public tag updateImpl(org.digitalArmour.verifier.model.tag tag)
        throws SystemException {
        tag = toUnwrappedModel(tag);

        boolean isNew = tag.isNew();

        tagModelImpl tagModelImpl = (tagModelImpl) tag;

        Session session = null;

        try {
            session = openSession();

            if (tag.isNew()) {
                session.save(tag);

                tag.setNew(false);
            } else {
                session.merge(tag);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !tagModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((tagModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TAGTAGNAME.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { tagModelImpl.getOriginalTagName() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TAGTAGNAME,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TAGTAGNAME,
                    args);

                args = new Object[] { tagModelImpl.getTagName() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TAGTAGNAME,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TAGTAGNAME,
                    args);
            }

            if ((tagModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        tagModelImpl.getOriginalChecklistId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKLISTID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID,
                    args);

                args = new Object[] { tagModelImpl.getChecklistId() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CHECKLISTID,
                    args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CHECKLISTID,
                    args);
            }
        }

        EntityCacheUtil.putResult(tagModelImpl.ENTITY_CACHE_ENABLED,
            tagImpl.class, tag.getPrimaryKey(), tag);

        return tag;
    }

    protected tag toUnwrappedModel(tag tag) {
        if (tag instanceof tagImpl) {
            return tag;
        }

        tagImpl tagImpl = new tagImpl();

        tagImpl.setNew(tag.isNew());
        tagImpl.setPrimaryKey(tag.getPrimaryKey());

        tagImpl.setId(tag.getId());
        tagImpl.setChecklistId(tag.getChecklistId());
        tagImpl.setTagName(tag.getTagName());

        return tagImpl;
    }

    /**
     * Returns the tag with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the tag
     * @return the tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag findByPrimaryKey(Serializable primaryKey)
        throws NoSuchtagException, SystemException {
        tag tag = fetchByPrimaryKey(primaryKey);

        if (tag == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchtagException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return tag;
    }

    /**
     * Returns the tag with the primary key or throws a {@link org.digitalArmour.verifier.NoSuchtagException} if it could not be found.
     *
     * @param Id the primary key of the tag
     * @return the tag
     * @throws org.digitalArmour.verifier.NoSuchtagException if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag findByPrimaryKey(long Id)
        throws NoSuchtagException, SystemException {
        return findByPrimaryKey((Serializable) Id);
    }

    /**
     * Returns the tag with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the tag
     * @return the tag, or <code>null</code> if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        tag tag = (tag) EntityCacheUtil.getResult(tagModelImpl.ENTITY_CACHE_ENABLED,
                tagImpl.class, primaryKey);

        if (tag == _nulltag) {
            return null;
        }

        if (tag == null) {
            Session session = null;

            try {
                session = openSession();

                tag = (tag) session.get(tagImpl.class, primaryKey);

                if (tag != null) {
                    cacheResult(tag);
                } else {
                    EntityCacheUtil.putResult(tagModelImpl.ENTITY_CACHE_ENABLED,
                        tagImpl.class, primaryKey, _nulltag);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(tagModelImpl.ENTITY_CACHE_ENABLED,
                    tagImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return tag;
    }

    /**
     * Returns the tag with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param Id the primary key of the tag
     * @return the tag, or <code>null</code> if a tag with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public tag fetchByPrimaryKey(long Id) throws SystemException {
        return fetchByPrimaryKey((Serializable) Id);
    }

    /**
     * Returns all the tags.
     *
     * @return the tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the tags.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of tags
     * @param end the upper bound of the range of tags (not inclusive)
     * @return the range of tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findAll(int start, int end) throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the tags.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link org.digitalArmour.verifier.model.impl.tagModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of tags
     * @param end the upper bound of the range of tags (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<tag> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<tag> list = (List<tag>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_TAG);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_TAG;

                if (pagination) {
                    sql = sql.concat(tagModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<tag>) QueryUtil.list(q, getDialect(), start,
                            end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<tag>(list);
                } else {
                    list = (List<tag>) QueryUtil.list(q, getDialect(), start,
                            end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the tags from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (tag tag : findAll()) {
            remove(tag);
        }
    }

    /**
     * Returns the number of tags.
     *
     * @return the number of tags
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_TAG);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Initializes the tag persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.org.digitalArmour.verifier.model.tag")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<tag>> listenersList = new ArrayList<ModelListener<tag>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<tag>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(tagImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
