package org.digitalArmour.verifier.utils;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;















import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;

import org.digitalArmour.verifier.model.CLTemplate;
import org.digitalArmour.verifier.model.Category;
import org.digitalArmour.verifier.model.Item;
import org.digitalArmour.verifier.model.ItemComment;
import org.digitalArmour.verifier.service.CLTemplateLocalServiceUtil;
import org.digitalArmour.verifier.service.CategoryLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemCommentLocalServiceUtil;
import org.digitalArmour.verifier.service.ItemLocalServiceUtil;

public class ActionUtil {
	
	//STATIC METOHD TO FIND ALL CHECKLIST
	public static List<CLTemplate> findallChecklist(RenderRequest request) throws SystemException
	{
		List<CLTemplate> tempResults = CLTemplateLocalServiceUtil.getallCLs();
		return tempResults;
	}
	//STATIC METHOD TO FIND ALL CATEGORIES
	public static List<Category> getAllCategories(RenderRequest request) throws SystemException
	{
		List<Category> tempCat = CategoryLocalServiceUtil.getAllCategories();
		return tempCat;
	}

	//STATIC METHOD TO FIND CATEGORIES BY CHECKLIST
	public static List<Category> findByCheckId(RenderRequest request) throws SystemException
	{
		long id1 = (Long)request.getAttribute("chkId");
		List<Category> cats = CategoryLocalServiceUtil.getCatByChecklistId(id1);
		return cats;
	}
	
	 public static List<Item> getItems(RenderRequest request) throws SystemException {
	       List<Item> tempResults;
	       tempResults = ItemLocalServiceUtil.getAllitems();
	       return tempResults;

	   }
	 /*public static List<ItemComment> getComments(RenderRequest request) throws SystemException
	 {
		
		 
		 List<ItemComment> tempresult1;
		 tempresult1=ItemCommentLocalServiceUtil.getAllComments();
		 return tempresult1;
		 
		 
	 }*/
	 
	 public static List<Item> getverify(ActionRequest actionRequest, ActionResponse actionResponse) throws IOException, PortletException, SystemException
		{

			List<Item> tempResults = new ArrayList<Item>();
	    
			tempResults = ItemLocalServiceUtil.getAllitems();
			return tempResults;

			
		}
	 
	 

	  public static List<Item> getitem(RenderRequest request) throws SystemException
	  {
		  List<Item> l1 = ItemLocalServiceUtil.getAllitems();
		return l1;
		  
	  }
	  
	  //GET COMMENT USER
	  public static String getCmntUser(Long cuid) throws PortalException, SystemException
		{
			Long ctuid = Long.valueOf(cuid);
			User u=UserLocalServiceUtil.getUserById(ctuid);
			String cName= u.getFullName();
			return cName;
		}
}
