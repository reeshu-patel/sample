create index IX_73AFE1A8 on Verifier_ActCLCollab (actChecklistId);
create index IX_6ECF63BF on Verifier_ActCLCollab (userId);
create index IX_8B50198F on Verifier_ActCLCollab (uuid_);

create index IX_D6F5554E on Verifier_ActCategory (ActCategoryId);
create index IX_8434AA5E on Verifier_ActCategory (ActiveCheckListID);
create index IX_F8FAB482 on Verifier_ActCategory (ActiveCheckListID, SubCatogryId);
create index IX_C3DAB9B1 on Verifier_ActCategory (SubCatogryId);
create index IX_B0EB9B47 on Verifier_ActCategory (uuid_);

create index IX_18D70ACD on Verifier_ActItem (ActivateClid);
create index IX_7B7C8694 on Verifier_ActItem (ActivateClid, catId);
create index IX_F8495A4E on Verifier_ActItem (ActivateClid, completed);
create index IX_32E1E09F on Verifier_ActItem (catId);
create index IX_6A0CB6D9 on Verifier_ActItem (completed);
create index IX_C51433A7 on Verifier_ActItem (completedDate);
create index IX_CA42852 on Verifier_ActItem (uuid_);

create index IX_88F42DEB on Verifier_ActItemComment (itemId);
create index IX_B2AB8E2B on Verifier_ActItemComment (uuid_);

create index IX_FD5AE140 on Verifier_ActItemFile (itemId);
create index IX_9DA69C36 on Verifier_ActItemFile (uuid_);

create index IX_A4B5880D on Verifier_ActivateCL (activateId);
create index IX_6E689F06 on Verifier_ActivateCL (checklistId);
create index IX_F8BD8633 on Verifier_ActivateCL (clName);
create index IX_561795E6 on Verifier_ActivateCL (isCompleted);
create index IX_717A28B on Verifier_ActivateCL (isCompleted, actClUserId);
create index IX_A255E52B on Verifier_ActivateCL (isCompleted, checklistId);
create index IX_B0073F29 on Verifier_ActivateCL (uuid_);

create index IX_E4ECF06C on Verifier_CLCollab (checklistId);
create index IX_3DF8D83F on Verifier_CLCollab (userId);
create index IX_2EE6150F on Verifier_CLCollab (uuid_);

create index IX_8B9DD0DF on Verifier_CLTemplate (checklistId);
create index IX_8E4D0BA on Verifier_CLTemplate (clName);
create index IX_E56B8675 on Verifier_CLTemplate (clUserId);
create index IX_A053D99 on Verifier_CLTemplate (isPublic);
create index IX_1B1F81C1 on Verifier_CLTemplate (isPubliccat);
create index IX_E21907C2 on Verifier_CLTemplate (uuid_);

create index IX_7ABF4F14 on Verifier_Category (catId);
create index IX_339E4824 on Verifier_Category (checklistId);
create index IX_42A036C5 on Verifier_Category (checklistId, subcategoryId);
create index IX_F008F57C on Verifier_Category (subcategoryId);
create index IX_548196C7 on Verifier_Category (uuid_);

create index IX_BC19C1F on Verifier_Item (catId);
create index IX_4776632 on Verifier_Item (checklistId, catId);
create index IX_198D57DA on Verifier_Item (major, catId);
create index IX_E583E3D2 on Verifier_Item (uuid_);

create index IX_3220696B on Verifier_ItemComment (itemId);
create index IX_5D49E2AB on Verifier_ItemComment (uuid_);

create index IX_CC8455C0 on Verifier_ItemFile (itemId);
create index IX_413C97B6 on Verifier_ItemFile (uuid_);

create index IX_B362F54F on Verifier_ItemUser (itemId);
create index IX_DD544A47 on Verifier_ItemUser (uuid_);

create index IX_3154A1FA on Verifier_Notification (uuid_);

create index IX_F6A28EB2 on Verifier_Organization (uuid_);

create index IX_D97F1FC6 on Verifier_Subcategory (catId);
create index IX_B3416779 on Verifier_Subcategory (uuid_);

create index IX_29DF605A on Verifier_tag (checklistId);
create index IX_C4515ABE on Verifier_tag (tagName);