create table Verifier_ActCLCollab (
	uuid_ VARCHAR(75) null,
	actClCollabId LONG not null primary key,
	actCollabType VARCHAR(75) null,
	actPrManagerId LONG,
	userId LONG,
	actChecklistId LONG
);

create table Verifier_ActCategory (
	uuid_ VARCHAR(75) null,
	ActCategoryId LONG not null primary key,
	ActiveCheckListID LONG,
	CategoryName TEXT null,
	SubCatogryId LONG
);

create table Verifier_ActItem (
	uuid_ VARCHAR(75) null,
	ItemId LONG not null primary key,
	itemName TEXT null,
	itemDesc TEXT null,
	ignore_ BOOLEAN,
	isMajor BOOLEAN,
	percentage LONG,
	completedDate DATE null,
	completed BOOLEAN,
	ActivateClid LONG,
	usergroupId LONG,
	major BOOLEAN,
	major_percent LONG,
	catId LONG,
	userId LONG
);

create table Verifier_ActItemComment (
	uuid_ VARCHAR(75) null,
	actCommId LONG not null primary key,
	comment_ TEXT null,
	createTime DATE null,
	itemId LONG,
	userId LONG
);

create table Verifier_ActItemFile (
	uuid_ VARCHAR(75) null,
	actItemFileId LONG not null primary key,
	fileName VARCHAR(75) null,
	filePath VARCHAR(75) null,
	createTime DATE null,
	itemId LONG,
	userId LONG
);

create table Verifier_ActivateCL (
	uuid_ VARCHAR(75) null,
	activateId LONG not null primary key,
	checklistId LONG,
	clName TEXT null,
	clDescription TEXT null,
	organiztion VARCHAR(75) null,
	isPublic BOOLEAN,
	isCompleted BOOLEAN,
	completedDate DATE null,
	actClUserId LONG
);

create table Verifier_CLCollab (
	uuid_ VARCHAR(75) null,
	clCollabId LONG not null primary key,
	collabType VARCHAR(75) null,
	prManagerId LONG,
	userId LONG,
	checklistId LONG
);

create table Verifier_CLTemplate (
	uuid_ VARCHAR(75) null,
	checklistId LONG not null primary key,
	clName TEXT null,
	clDescription TEXT null,
	clOrganiztion VARCHAR(75) null,
	clUserId LONG,
	isPublic BOOLEAN,
	isPubliccat BOOLEAN
);

create table Verifier_Category (
	uuid_ VARCHAR(75) null,
	catId LONG not null primary key,
	catName TEXT null,
	subcategoryId LONG,
	checklistId LONG
);

create table Verifier_Item (
	uuid_ VARCHAR(75) null,
	itemId LONG not null primary key,
	itemName TEXT null,
	itemDesc TEXT null,
	minor BOOLEAN,
	minor_percent LONG,
	major BOOLEAN,
	major_percent LONG,
	userGroupId LONG,
	catId LONG,
	checklistId LONG
);

create table Verifier_ItemComment (
	uuid_ VARCHAR(75) null,
	commId LONG not null primary key,
	comment_ TEXT null,
	createTime DATE null,
	itemId LONG,
	userId LONG
);

create table Verifier_ItemFile (
	uuid_ VARCHAR(75) null,
	fileId LONG not null primary key,
	fileName TEXT null,
	filePath VARCHAR(75) null,
	createTime DATE null,
	itemId LONG,
	userId LONG
);

create table Verifier_ItemUser (
	uuid_ VARCHAR(75) null,
	itemUserId LONG not null primary key,
	createDate DATE null,
	dueDate DATE null,
	itemId LONG,
	userId LONG
);

create table Verifier_Notification (
	uuid_ VARCHAR(75) null,
	noteId LONG not null primary key,
	noteName VARCHAR(75) null,
	isMail BOOLEAN,
	isNewsFeed BOOLEAN
);

create table Verifier_Organization (
	uuid_ VARCHAR(75) null,
	orgId LONG not null primary key,
	orgName TEXT null,
	type_ BOOLEAN,
	userId LONG
);

create table Verifier_Subcategory (
	uuid_ VARCHAR(75) null,
	subcatId LONG not null primary key,
	subcatName TEXT null,
	catId LONG
);

create table Verifier_tag (
	Id LONG not null primary key,
	checklistId LONG,
	tagName VARCHAR(75) null
);