var global = 0;
var edit = 0;
var commdes = 0;
var Itemcookee=0;
var Itemcookee = document.cookie;
myparameter(Itemcookee);
window.onload = myparameter;
window.onload = bodyOnLoad;
//window.onclick= toggle_print(id);

document.getElementById("selectchekid").value = Itemcookee;

function viewform() {
	var formid = document.getElementById("catdiv");
	var cattext = document.getElementById("categorytext1");
	if(formid.style.display=="none")
		{
			formid.style.display="";
			cattext.value = '';
		}
}

function viewformview(vf) {
	var formid = document.getElementById("catdiv_"+vf);
	var cattext = document.getElementById("categorytext1");
	if(formid.style.display=="none")
		{
			formid.style.display="";
			cattext.value = '';
		}
}

function cancelform1(vf) {
	
	var formid = document.getElementById("catdiv_"+vf);
	var cattxt = document.getElementById("categorytext1");
	if(formid.style.display=="")
		{
			cattxt.value = '';
			formid.style.display="none";
			cattxt.style.border = "1px solid #ccc";
		}
}

function viewformA(rp) {
	var formid = document.getElementById("catdiv");
	var cattext = document.getElementById("categorytext1");
	if(formid.style.display=="none")
		{
			formid.style.display="";
			cattext.value = '';
		}
}

function cancelform() {
	
	var formid = document.getElementById("catdiv");
	var cattxt = document.getElementById("categorytext1");
	if(formid.style.display=="")
		{
			cattxt.value = '';
			formid.style.display="none";
			cattxt.style.border = "1px solid #ccc";
		}
}

function checkval() {
	
	var txtval = document.getElementById("categorytext1");
	if(txtval.value=='' && global==1)
		{
			txtval.style.border = "1px solid red";
		}
	else
		{
			txtval.style.border = "1px solid #ccc";
		}
}

function checkval1(x) {
	
	var txtval = document.getElementById("subcattext_"+x);
	if(txtval.value=='' && global==1)
		{
			txtval.style.border = "1px solid red";
		}
	else
		{
			txtval.style.border = "1px solid #ccc";
		}
}

/*function editcat()
{
	var a1 = document.getElementById("catcon");
	var a2 = document.getElementById("editcatdiv");
	a1.style.display = "none";
	a2.style.display = "";
}*/

function editing(a){
	if(edit==0)
		{
		var a= x.id;
		edit = a;
		var con  = document.getElementById("catcon_"+a);
		var hde = document.getElementById("cathide_"+a);
		hde.style.display = "block";
		con.style.display = "none";
		}
	

	/*else
		{
		var a= x.id;
		var con  = document.getElementById("catcon_"+a);
		var hde = document.getElementById("cathide_"+a);
		var con1  = document.getElementById("catcon_"+edit);
		var hde1 = document.getElementById("cathide_"+edit);
		hde1.style.display="none";
		con1,style.display = "block";
		hde.style.display = "block";
		con.style.display = "none";
		edit=x.id;
		}*/
		}

function editinggrid(x){
	var con  = document.getElementById("catcongrid_"+x);
	var hde = document.getElementById("cathidegrid_"+x);
	hde.style.display = "block";
	con.style.display = "none";
	}

function editinggridbox1(x){
	var con  = document.getElementById("catck1_"+x);
	var hde = document.getElementById("cathidegrid_"+x);
	hde.style.display = "block";
	con.style.display = "none";
	}

function editingceck(x){
	var con  = document.getElementById("catck_"+x);
	var hde = document.getElementById("cathideck_"+x);
	hde.style.display = "block";
	con.style.display = "none";
	}

function editingall(x){
	var con  = document.getElementById("catall_"+x);
	var hde = document.getElementById("cathideall_"+x);
	hde.style.display = "block";
	con.style.display = "none";
	}

function editing1(x){
		var con  = document.getElementById("actcat_"+x);
		var hde = document.getElementById("catacthid_"+x);
		hde.style.display = "block";
		con.style.display = "none";
		}


function subcatdisplay(dyId)
{
	var i = dyId;
	global = i;
	var subform = document.getElementById("subcatdiv_"+i);
	var subbut = document.getElementById("addsub_"+i);
	
			subform.style.display="";
			subbut.style.display="none";
		
}

function cansub(subdivid)
{
	var subd = subdivid;
	var subform1 = document.getElementById("subcatdiv_"+subd);
	var subbut1 = document.getElementById("addsub_"+subd);
	var subtext = document.getElementById("subcattext_"+subd);
	

		subtext.value = '';
		subform1.style.display="none";
		subbut1.style.display="";
		global = 0;

}
function cancelprev(pre,cd,df)
{
	var cal = pre;
	var cd1 = document.getElementById(cd);
	var df1 = document.getElementById(df);
	cd1.style.display="none";
	df1.style.display="none";
	if(global!=0)
		{
	var pid = global;
	
	var subform1 = document.getElementById("subcatdiv_"+pid);
	var subbut1 = document.getElementById("addsub_"+pid);
	var subtext = document.getElementById("subcattext_"+pid);
	
		subtext.value = '';
		subform1.style.display="none";
		subbut1.style.display="";
		subcatdisplay(cal);
		}
	else
		{
		subcatdisplay(cal);
		}

}

function addsubcategory(pid)
{
	var subform1 = document.getElementById("subcatdiv_"+pid);
    if(subform1.style.display="none")
		{
			
		
			subform1.style.display="";
			
			
		}

}

function func(x)
{
	var a11=document.getElementById("main_"+x);
	var d=document.getElementById("itemtitle_"+x);
	var e=document.getElementById("change_"+x);
	var f=document.getElementById("change1_"+x);
	var n1=document.getElementById("ed_"+x);
	
	if(a11.style.display=="none")
		{
		a11.style.display="";
		d.style.backgroundColor = "#80bd01";
		e.style.backgroundPosition = "center center";
		f.style.backgroundPosition = "center bottom";
		n1.style.backgroundColor =  "#80bd01";
		}
	else
		{
		a11.style.display="none";
		d.style.backgroundColor = "#e1e4e3";
		e.style.backgroundPosition = "center top";
		f.style.backgroundPosition = "center top";
		n1.style.backgroundColor =  "#e1e4e3";
		}
	
	
	}


function cancelFunction(x)
{
	var a=document.getElementById("edit_"+x);
	var b=document.getElementById("desc_"+x);
	a.style.display="none";
	b.style.display="";
	
	
}
function myfunctionactive(x)
{
	

	var a=document.getElementById("edit1_"+x);
	var b=document.getElementById("desc_"+x);
	var c=document.getElementById("descdiv_"+x);
	
	b.style.display="none";
	a.style.display="block";
	c.style.border="0px";
	
	var e=document.getElementById("sometext");
	e.value=" ";

}

function descDisplay(x)
{
	var a =document.getElementById("Desc_"+x);
	var b = document.getElementById("hidDesc_"+x);
	a.style.display = "none";
	b.style.display = "block";
}

function cancelupdes(x)
{
	var Id = "UpdtComm_"+x;
	var a =document.getElementById("Desc_"+x);
	var b = document.getElementById("hidDesc_"+x);
	//var c = document.getElementById("UpdtComm_"+x).value;
	//alert(c);
	a.style.display = "block";
	b.style.display = "none";
	document.getElementById(Id).innerHTML = '';
	//c.innerHTML='';
	
	//document.getElementById('UpdtComm_'+x).value = "";
	
}


function cancelFunctionactive(x)
{
	var a=document.getElementById("edit1_"+x);
	var b=document.getElementById("desc_"+x);
	a.style.display="none";
	b.style.display="";
	
	
}

function toggleedit()
{
	
	var a=document.getElementById("toolset_deseble");
	var n=document.getElementById("wholediv");
	var b=document.getElementsByName("IgnoreI");
	var c=document.getElementsByName("toolset_image1");
	var d=document.getElementsByName("toolset_image2");	
	var e=document.getElementsByName("ActItem1");
	var f=document.getElementById("toggle-mode");
	var g=document.getElementsByName("cateightdots");
	
	var i;
	
	
	if(a.style.display == "")
		{
		a.style.display="none";
		n.style.border="0px";
		f.style.backgroundPosition = "center top";
		for (i = 0; i < b.length && i< e.length && i<c.length && i< d.length && i< g.length; i++) 
			
        {
		
		var z=document.getElementById(b[i].id);
		z.style.display="";
		var y=document.getElementById(e[i].id);
		y.style.display="";
		var x=document.getElementById(c[i].id);
		x.style.display="none";
		var w=document.getElementById(d[i].id);
		w.style.display="none";
		var p=document.getElementById(g[i].id);
		p.style.display="none";	
        }
	
		
		}
	else
	{
		a.style.display="";
		n.style.border="5px solid red";
		f.style.backgroundPosition = "center center";
		for (i = 0; i < b.length && i< e.length && i<c.length && i< d.length && i < g.length; i++) 
			
        {
		var z=document.getElementById(b[i].id);
		z.style.display="none";
		var y=document.getElementById(e[i].id);
		y.style.display="none";
		var x=document.getElementById(c[i].id);
		x.style.display="";
		var w=document.getElementById(d[i].id);
		w.style.display="";
		var p=document.getElementById(g[i].id);
		p.style.display="";	
			
        }
		
		
	}
}






function editcomm(x)
{
	var a = document.getElementById("hidComDiv_"+x);
	var b = document.getElementById("hidComm_"+x);
	a.style.display="none";
	b.style.display="block";
}

function cmnt(x)
{
	
	var a=document.getElementById("butn_"+x);
	var b=document.getElementById("item__new_comment_"+x);
	a.style.display="block";
	//b.value=" ";

}
function cancelcmnt(x)
{
	
	var b=document.getElementById("item__new_comment_"+x);
	var a=document.getElementById("butn_"+x);
	a.style.display="none";
	b.value=" ";
	}




function funcactivate(x)
{
	
	
	var a=document.getElementById("mainactive_"+x);
	var d=document.getElementById("itemtitle_"+x);
	var e=document.getElementById("change_"+x);
	var f=document.getElementById("change1_"+x);
	
	if(a.style.display=="none")
	{
	a.style.display="";
	d.style.backgroundColor = "#80bd01";
	e.style.backgroundPosition = "center center";
	f.style.backgroundPosition = "center bottom";
	}
else
	{
	a.style.display="none";
	d.style.backgroundColor = "white";
	e.style.backgroundPosition = "center top";
	f.style.backgroundPosition = "center top";
	}


	
	
	
	}

function expandallA()
{
	
	//var b=document.getElementById("main_"+x);
	var ad=document.getElementsByName("main_all");
	
	var bd=document.getElementsByName("titleexpand");
	
	
	

	for (i = 0; i < ad.length &&  i < bd.length; i++) 
	    				
        {
	
		var z=document.getElementById(ad[i].id);
		z.style.display="block";
		var y=document.getElementById(bd[i].id);
		y.style.backgroundColor = "#80bd01";
		
        }
}


function contractallA()
{
	var a=document.getElementsByName("main_all");
	var b=document.getElementsByName("titleexpand");

	var i;
	
	for (i = 0; i < a.length && i < b.length; i++) 
	    				
        {
		
		var z=document.getElementById(a[i].id);
		z.style.display="none";
		var y=document.getElementById(b[i].id);
		y.style.backgroundColor = "white";
		
			
        }
}

function expandall()
{
	
	//var b=document.getElementById("main_"+x);
	var a=document.getElementsByName("main_all");
	var b=document.getElementsByName("titleexpand");
	all = a.length;
	var i;
	
	for (i = 0; i < a.length &&  i < b.length; i++) 
	    				
        {
		//alert(a[i].id);
		var z=document.getElementById(a[i].id);
		z.style.display="block";
		var y=document.getElementById(b[i].id);
		y.style.backgroundColor = "#80bd01";
		
        }
}


function contractall()
{
	var a=document.getElementsByName("main_all");
	var b=document.getElementsByName("titleexpand");

	var i;
	
	for (i = 0; i < a.length && i < b.length; i++) 
	    				
        {
		
		var z=document.getElementById(a[i].id);
		z.style.display="none";
		var y=document.getElementById(b[i].id);
		y.style.backgroundColor = "white";
		
			
        }
}
/*function custom() {
	
	var formNewid = document.getElementById("divform");
	var itemtext = document.getElementById("categorytext");
	if(formNewid.style.display=="none")
		{
		formNewid.style.display="";
		itemtext.value = '';
			
		}
}*/

function custom1(x) {
	
	var formNewid = document.getElementById("divform_"+x);
	//var itemtext = document.getElementById("catdiv_"+x);
	if(formNewid.style.display=="none")
		{
		formNewid.style.display="";
//		itemtext.style.display="none";
			
		}
}

function customA(px) {
	
	var formNewidA = document.getElementById("divformA_"+px);
	//var itemtext = document.getElementById("catdiv_"+x);
	if(formNewidA.style.display=="none")
		{
		formNewidA.style.display="";
//		itemtext.style.display="none";
			
		}
}


function fncancelA(px) {
	
	var formNewidA = document.getElementById("divformA_"+px);
	var itemtext = document.getElementById("categorytext");
	if(formNewidA.style.display=="")
		{
			
			itemtext.value = '';
			formNewidA.style.display="none";
			itemtext.style.border = "1px solid #ccc";
		}
}	
		
		
function fncancel(x) {
			
			var formNewid = document.getElementById("divform_"+x);
			var itemtext = document.getElementById("categorytext");
			if(formNewid.style.display=="")
				{
					
					itemtext.value = '';
					formNewid.style.display="none";
					itemtext.style.border = "1px solid #ccc";
				}
		}



/*function fn1() {
	
	var formNewid = document.getElementById("divform");
	var itemtext = document.getElementById("categorytext");
	if(formNewid.style.display=="")
		{
			itemtext.value = '';
			formNewid.style.display="none";
			itemtext.style.border = "1px solid #ccc";
		}
}*/

/*
function custom()
{
	var a=document.getElementById("divform");
	a.style.display = a.style.display == "none" ? "block" : "none";
	
	  if(a.style.display == "none")
		  
		  a.style.display = "";
       else
    	   a.style.display = "none";
    
}

function fn1() {

	var formid = document.getElementById("trying");

	if (formid.style.display=="")
	{

	formid.style.display="none";

	}
	}*/
function tagall(xc){
	
	var formid = document.getElementById("tag_"+xc);
	var cattext = document.getElementById("tagall_"+xc);
	if(cattext.style.display== 'none')
	        {
	                formid.style.display="none";
	                cattext.style.display = "block";
	                
	        }
	}

	function cancelall(xc){
		
		var formid = document.getElementById("tag_"+xc);
		var cattext = document.getElementById("tagall_"+xc);
		if(cattext.style.display=='block')
		        {
		               formid.style.display="block";
		                cattext.style.display = "none";
		                
		        }
		}


	
function tag(){
	
	var formid = document.getElementById("tag");
	var cattext = document.getElementById("tag1");
	if(cattext.style.display== 'none')
	        {
	                formid.style.display="none";
	                cattext.style.display = "block";
	                
	        }
	}

	function cancel(){
		
		var formid = document.getElementById("tag");
		var cattext = document.getElementById("tag1");
		if(cattext.style.display=='block')
		        {
		               formid.style.display="block";
		                cattext.style.display = "none";
		                
		        }
		}

	$( document ).ready(function() {	
	$("input").keypress(function(event) {
	    if (event.which == 13) {
	        event.preventDefault();
	        $("tagf").submit();
	    }
	});
	});

	function toggle_visibility(id) {
	       var e = document.getElementById(id);
	       if(e.style.display == 'block'|| e.style.display=='')
	          e.style.display = 'none';
	       else
	          e.style.display = 'block';
	    }
	
	/*function toggle_visibility(p ,d ) {
	       var AddItem = document.getElementById("divformA_"+p);
	       var category = document.getElementById(d);
	       if(AddItem.style.display == 'block'|| e.style.display=='' && category.style.display == 'block'||category.style.display=='')
	    	   
	       {
	    	   AddItem.style.display = 'none';
	    	   category.style.display = 'none';
	    	   
	    	   
	       }
	           
	        else {
	    	   
	    	   AddItem.style.display = 'block';
	           category.style.display = 'block';
	    	   
	       }
	    	   
	       
	    }*/
	
	function Item_form(id){
		
		if(global!=0)
		{
			var pid = global;
			var subform1 = document.getElementById("subcatdiv_"+pid);
			var subbut1 = document.getElementById("addsub_"+pid);
			var subtext = document.getElementById("subcattext");

			subtext.value = '';
			subform1.style.display="none";
			subbut1.style.display="";
		}
		var e = document.getElementById(id);
	       if(e.style.display == 'none')
	          e.style.display = 'none';
	       else if(e.style.display = 'block')
	          e.style.display = 'none';
	       else if(e.style.display = 'none')
		          e.style.display = 'block';
		
	}
	
	function Cat_form(id){
		
		if(global!=0)
		{
			var pid = global;
			var subform1 = document.getElementById("subcatdiv_"+pid);
			var subbut1 = document.getElementById("addsub_"+pid);
			var subtext = document.getElementById("subcattext");

			subtext.value = '';
			subform1.style.display="none";
			subbut1.style.display="";
		}
		var e = document.getElementById(id);
	       if(e.style.display == 'none')
	          e.style.display = 'none';
	      else if ( e.style.display = 'block')
	          e.style.display = 'none';
	      else if ( e.style.display = 'none')
	          e.style.display = 'block';
		
	}
	
	
	function toggle_icon(id) {
	       var e = document.getElementById(id);
	       if(e.style.display == 'block'|| e.style.display=='')
	          e.style.display = 'none';
	       else
	          e.style.display = 'block';
	    }
	function toggle_checkicon(id) {
	       var e = document.getElementById(id);
	       if(e.style.display == 'block'|| e.style.display=='')
	          e.style.display = 'none';
	       else
	          e.style.display = 'block';
	    }
	function toggle_check_display(id) {
	       var e = document.getElementById(id);
	       if(e.style.display == 'block'|| e.style.display=='')
	          e.style.display = 'none';
	       else
	          e.style.display = 'block';
	    }
	
	
	
	$(document).ready(function ($) {
	    $(".flip").click(function () {
	        $(this).nextAll(".flippanel").toggle();
	    });
	});
	
	
	
	
	function test(a)
	{
	var x=document.getElementById("ed_"+a);
	var y=document.getElementById("itemfont_"+a);
	var enm=document.getElementsByClassName("taskdrag");
	//var elem = document.getElementById('div1');
	
	if(y.style.display==""){
	x.style.display="";
	y.style.display="none";
	}

 }

	      
	function m(a)
	{
	var e=document.getElementById("ed_"+a);
	var r=document.getElementById("itemtitle_"+a);

	r.style.display="";
	e.style.display="none";

	}
		
		
	function ActItemUpdate(a)
		{
		var e=document.getElementById("edit_"+a);
		var r=document.getElementById("ed_"+a);

		r.style.display="";
		e.style.display="none";

		}

		function checklist(a)
		{
		var x=document.getElementById("ed_"+a);
		var y=document.getElementById("checktitle_"+a);
		if(y.style.display==""){
		x.style.display="";
		y.style.display="none";
		}

	   }
		function checklistdesc(b)
		{
		var x=document.getElementById("desc_"+b);
		var y=document.getElementById("desctitle_"+b);
		if(y.style.display==""){
		x.style.display="";
		y.style.display="none";
		}

	  }
		
		function Actchecklist(ac)
		{
		var xx=document.getElementById("aced_"+ac);
		var yy=document.getElementById("acchecktitle_"+ac);
		if(yy.style.display=="block"){
		xx.style.display="block";
		yy.style.display="none";
		}

	   }
		function Actchecklistdesc(ac)
		{
		var x=document.getElementById("desc_"+ac);
		var y=document.getElementById("desctitle_"+ac);
		if(y.style.display==""){
		x.style.display="";
		y.style.display="none";
		}

	  }
		
		function allchecklist(a)
		{
		var x=document.getElementById("ed_"+a);
		var y=document.getElementById("checktitle_"+a);
		if(y.style.display==""){
		x.style.display="";
		y.style.display="none";
		}

	   }
		function allchecklistdesc(b)
		{
		var x=document.getElementById("desc_"+b);
		var y=document.getElementById("desctitle_"+b);
		if(y.style.display==""){
		x.style.display="";
		y.style.display="none";
		}

	  }	
		
			
		function myprintchecklist() {
		    window.print();
		}
		
		function myprintactivecheck() {
		    window.print();
		}
		
		
		function myFunction(x)
		{
			
			var a=document.getElementById("edit_"+x);
			var b=document.getElementById("desc_"+x);
			var c=document.getElementById("descdiv_"+x);
			
			b.style.display="none";
			a.style.display="";
			c.style.border="0px";
			
			var e=document.getElementById("sometext");
			e.value=" ";

		}
		
	function toggle_Gare(xp) {
			var pop1 = document.getElementById("popup_"+xp);
			var openbtn = document.getElementById("tools_"+xp);
			var closedbtn = document.getElementById("toolsgere_"+xp);
		
			var pop = document.getElementsByName("popupbox")
			var open = document.getElementsByName("togelbtn")
			var closed = document.getElementsByName("closebtn")

			for(i = 0; i < pop.length  && open.length; ++i){
				
					var z=document.getElementById(pop[i].id);
					var as=document.getElementById(open[i].id);
					
					if(z.style.display == "block"){
					   z.style.display ="none";
					   as.style.display="block";
					  
					   
					for(j = 0; j < closed.length; j++){
						   
					var closed =document.getElementById(closed[j].id);
					var as=document.getElementById(open[i].id);
					if(closed.style.display ="block" ||closed.style.display ==''){
					closed.style.display ="none";
							
									  
							}
							
					   }
					  
					}
					
				}
			if(pop1.style.display == 'none')
				{
				
				  pop1.style.display = 'block';
				  openbtn.style.display = 'none';
				  closedbtn.style.display = 'block';
				}
			else{
				
				pop1.style.display = 'none';
			}
		          
		    }
		
	
	
	
	function toggle_Gareclosed(xp) {
			var pop = document.getElementById("popup_"+xp);
			var openbtn = document.getElementById("tools_"+xp);
			var closedbtn = document.getElementById("toolsgere_"+xp);
			
			
	       if(pop.style.display == 'block')
	    	   pop.style.display = 'none';
	    	   openbtn.style.display = 'block';
	    	   closedbtn.style.display = 'none';
	    	}
	
	function toggle_GareAct(xp) {
		var pop1 = document.getElementById("popup_"+xp);
		var openbtn = document.getElementById("tools_"+xp);
		var closedbtn = document.getElementById("toolsgere_"+xp);
	
		var pop = document.getElementsByName("popupbox")
		var open = document.getElementsByName("togelbtn")
		var closed = document.getElementsByName("closebtn")

		for(i = 0; i < pop.length  && open.length; ++i){
			
				var z=document.getElementById(pop[i].id);
				var as=document.getElementById(open[i].id);
				
				if(z.style.display == "block"){
				   z.style.display ="none";
				   as.style.display="block";
				  
				}
				
			}
		if(pop1.style.display == 'none')
			{
			
			  pop1.style.display = 'block';
			  openbtn.style.display = 'none';
			  closedbtn.style.display = 'block';
			}
		else{
			
			pop1.style.display = 'none';
		}
	          
	    }
	



function toggle_GareclosedAct(xp) {
		var pop = document.getElementById("popup_"+xp);
		var openbtn = document.getElementById("tools_"+xp);
		var closedbtn = document.getElementById("toolsgere_"+xp);
		
		
       if(pop.style.display == 'block')
    	   pop.style.display = 'none';
    	   openbtn.style.display = 'block';
    	   closedbtn.style.display = 'none';
    	}


function toggle_Garerect(xp) {
	var pop1 = document.getElementById("popup_"+xp);
	var openbtn = document.getElementById("tools_"+xp);
	var closedbtn = document.getElementById("toolsgere_"+xp);

	var pop = document.getElementsByName("popupbox")
	var open = document.getElementsByName("togelbtn")
	var closed = document.getElementsByName("closebtn")

	for(i = 0; i < pop.length  && open.length; ++i){
		
			var z=document.getElementById(pop[i].id);
			var as=document.getElementById(open[i].id);
			
			if(z.style.display == "block"){
			   z.style.display ="none";
			   as.style.display="block";
			  
			}
			
		}
	if(pop1.style.display == 'none')
		{
		
		  pop1.style.display = 'block';
		  openbtn.style.display = 'none';
		  closedbtn.style.display = 'block';
		}
	else{
		
		pop1.style.display = 'none';
	}
          
    }




function toggle_Gareclosedrect(xp) {
	var pop = document.getElementById("popup_"+xp);
	var openbtn = document.getElementById("tools_"+xp);
	var closedbtn = document.getElementById("toolsgere_"+xp);
	
	
   if(pop.style.display == 'block')
	   pop.style.display = 'none';
	   openbtn.style.display = 'block';
	   closedbtn.style.display = 'none';
	}
	
		function toggle_print(id) {
		       var e = document.getElementById(id);
		       if(e.style.display == 'block'|| e.style.display=='')
		          e.style.display = 'none';
		       else
		          e.style.display = 'block';
		    }
		

	/*	function Reopen() {
			var menuid = document.getElementById("hidemenu");
			var expandid = document.getElementById("hidexpand");
			//var divid = document.getElementById("flad");
			var buttonid = document.getElementById("reopen");
			document.getElementById("wholediv").disabled = false;

			  //This will disable all the children of the div
		      var nodes = document.getElementById("wholediv").getElementsByTagName('*');
			  for(var i = 0; i < nodes.length; i++)
			  {
			       nodes[i].disabled = false;
			  }
			if(buttonid.style.display="block")
				{
					buttonid.style.display="none"
					menuid.style.display="block";
					expandid.style.display="block";
					
				}
			
		}
		
		*/
		
		function bodyOnLoad() {
			

			  var divff = document.getElementById("reloaddiv");
			  // something with myDiv
			  var menuid = document.getElementById("hidemenu");
			  var expandid = document.getElementById("hidexpand");
			//  var divid = document.getElementById("flad");
			  document.getElementById("wholediv").disabled = true;
			  document.getElementById('wholediv').setAttribute('draggable', false);
			  //This will disable all the children of the div
			  var nodes = document.getElementById("wholediv").getElementsByTagName('*');
			 
			 
			 if(divff.style.display=="")
				{
				 
					menuid.style.display="none";
					expandid.style.display="none";

					 for(var i = 0; i < nodes.length; i++)
					  {
					       nodes[i].disabled = true;
					  }
				}
			 else{
				
				   alert("Button is loaded");

				
			}

			 
			}
		
		

		
   function mychecklist() {
	var x1 = document.getElementById("selectchekid").value;
	var actiid = document.getElementById("activeid");
	var rclosedid = document.getElementById("recentid");
	var checkId = document.getElementById("checklistid");
	var checkId1 = document.getElementById("checklistid1");
	var item = x1.toString();
	
	document.cookie=item;
	var x = document.cookie;
	document.getElementById("selectchekid").value = x;
	
	if (item == 0) {
		checkId1.style.display = "block"
		checkId.style.display = "block"
		rclosedid.style.display = "none";
		actiid.style.display = "none";
		

	} else if (item == 1) {
		checkId1.style.display = "none"
		checkId.style.display = "none"
		actiid.style.display = "block";
		rclosedid.style.display = "none";
		
		


	} else if (item == 2) {
		checkId1.style.display = "none"
		checkId.style.display = "none";
		rclosedid.style.display = "block"
		actiid.style.display = "none";
		
		

		

	}
}

    function myparameter(c){
    	var actiid = document.getElementById("activeid");
    	var rclosedid = document.getElementById("recentid");
    	var checkId = document.getElementById("checklistid");
    	var checkId1 = document.getElementById("checklistid1");
    	var Itemcookee = c;
    	

    	
    	if (Itemcookee == 0) {
    		checkId1.style.display = "block"
    		checkId.style.display = "block"
    		rclosedid.style.display = "none";
    		actiid.style.display = "none";
    		

    	} else if (Itemcookee == 1) {
    		checkId1.style.display = "none"
    		checkId.style.display = "none"
    		actiid.style.display = "block";
    		rclosedid.style.display = "none";
    		
    		


    	} else if (Itemcookee == 2) {
    		checkId1.style.display = "none"
    		checkId.style.display = "none";
    		rclosedid.style.display = "block"
    		actiid.style.display = "none";
    		
    		

    		

    	}
	}
   
    
    
    function dispSubItem(x)
    {
    	var a = document.getElementById("subitemdiv_"+x);
    	var b = document.getElementById("addsubitem_"+x);
    	var c = document.getElementById("categorytext1");
    	if(a.style.display=="none")
    		{
    			a.style.display="block";
    			b.style.display="none";
    		}
    	else 
    		{
    			a.style.display="none";
    			b.style.display="block";
    			c.value='';
    		}
    	
    }

    function dispActSubItem(x)
    {
    	var a = document.getElementById("divactsub_"+x);
    	var b = document.getElementById("addactsubitem_"+x);
    	var c = document.getElementById("categorytext");
    	if(a.style.display=="none")
    		{
    			a.style.display="block";
    			b.style.display="none";
    		}
    	else 
    		{
    			a.style.display="none";
    			b.style.display="block";
    			c.value='';
    		}
    }

 function actsubitem(x)
    {
    	var a = document.getElementById("divactsub_"+x);
    	var b = document.getElementById("addactsubitem_"+x);
    	var c = document.getElementById("categorytext");
    	if(a.style.display=="block")
    		{
    			a.style.display="none";
    			b.style.display="block";
    			c.value='';
    		}
    
    } 
    function viewusr()
    {
    	var a = document.getElementById("colform");
    	var b = document.getElementById("colusrdisplay");
    	var c = document.getElementById("newcol");
    	var d = document.getElementById("usercol");
    	a.style.display="none";
    	b.style.display="block";
    	c.style.backgroundColor = "#118ade";
    	c.style.color = "white";
    	d.style.backgroundColor = "white";
    	d.style.color = "black";
    }

  function viewcolform()
    {
    	var a = document.getElementById("colform");
    	var b = document.getElementById("colusrdisplay");
    	var c = document.getElementById("usercol");
    	var d = document.getElementById("newcol");
    	a.style.display="block";
    	b.style.display="none";
    	c.style.backgroundColor = "#118ade";
    	c.style.color = "white";
    	d.style.backgroundColor = "white";
    	d.style.color = "black";
    }
  
  function editingSub(x){
		
		//var a= x.id;
	
		var con  = document.getElementById("sub_"+x);
		var hde = document.getElementById("cathide_"+x);
		hde.style.display = "block";
		con.style.display = "none";
		}
  
  function editingSuball(x){
		
		//var a= x.id;
	
		var con  = document.getElementById("allsub_"+x);
		var hde = document.getElementById("cathideall_"+x);
		hde.style.display = "block";
		con.style.display = "none";
		}
  function editingActSub(x){
		
		//var a= x.id;
	
		var con  = document.getElementById("sub_"+x);
		var hde = document.getElementById("cathide_"+x);
		hde.style.display = "block";
		con.style.display = "none";
		}
  
  function editingun(x)
  {
  	var a = x.id;
  	var con  = document.getElementById(a);
  	var hde = document.getElementById("edun_"+a);
  	hde.style.display = "block";
  	con.style.display = "none";
  }
  
  /*function descDisplay(x)
  {
  	var a =document.getElementById("Desc_"+x);
  	var b = document.getElementById("hidDesc_"+x);
  	a.style.display = "none";
  	b.style.display = "block";
  }*/

  function cancelupcmnt(x)
  {
  	var a =document.getElementById("Desc_"+x);
  	var b = document.getElementById("hidDesc_"+x);
  	
  	a.style.display = "block";
  	b.style.display = "none";
  	
  }
  
  function cancelupcmnt1(x)
  {
  	var a =document.getElementById("hidComDiv_"+x);
  	var b = document.getElementById("hidComm_"+x);
  	a.style.display = "block";
  	b.style.display = "none";
  }

  function cancelupcmntact(x)
  {
	var comm =document.getElementById("hidComDiv_"+x);
	var upcomm = document.getElementById("hidComm_"+x);
	comm.style.display = "block";
  	upcomm.style.display = "none";
  }
  
  function cancelupcmnt(x)
  {
	var comm =document.getElementById("hidComDiv_"+x);
	var upcomm = document.getElementById("hidComm_"+x);
	comm.style.display = "block";
  	upcomm.style.display = "none";
  }
  function cancelupcmntall(x)
  {
	var comm =document.getElementById("hidComDiv_"+x);
	var upcomm = document.getElementById("hidComm_"+x);
	comm.style.display = "block";
  	upcomm.style.display = "none";
  }
 /* function editcomm(x)
  {
  	var a = document.getElementById("hidComDiv_"+x);
  	var b = document.getElementById("hidComm_"+x);
  	a.style.display="none";
  	b.style.display="block";
  }
*/
  function viewnotification()
	{

		//var a=document.getElementById("activatechecklist");
		var a=document.getElementsByName("activatechk");
		//var b=document.getElementById("closedchecklist_");
		var b=document.getElementsByName("closecheck");
		
		var i;
		var c = document.getElementById("activchk");
		var d = document.getElementById("clsechk");
		c.style.backgroundColor = "#118ade";
		c.style.color = "white";
		d.style.backgroundColor = "white";
		d.style.color = "black";
		for (i = 0; i < b.length && i< a.length; i++) 
			
      {
			
		var y=document.getElementById(a[i].id);
		var z=document.getElementById(b[i].id);
	
		
		y.style.display="block";
		z.style.display="none";
		
      }
		
		
	}
	function viewclosechecklist()
	{
	
		//var a=document.getElementById("activatechecklist");
		//var b=document.getElementById("closedchecklist");
		var a=document.getElementsByName("activatechk");
		//var b=document.getElementById("closedchecklist");
		var b=document.getElementsByName("closecheck");
		var c = document.getElementById("activchk");
		var d = document.getElementById("clsechk");
		c.style.backgroundColor = "#118ade";
		c.style.color = "white";
		d.style.backgroundColor = "white";
		d.style.color = "black";
		var i;
		
		for (i = 0; i < b.length && i< a.length; i++) 
			
		{
		var y=document.getElementById(a[i].id);
		var z=document.getElementById(b[i].id);
	
		y.style.display="none";
		z.style.display="block";
		
      }
		
	}
 
	
	function cqleft()
	{
	var p=document.getElementById("mainboxid");
	var left=document.getElementById("leftclickbtn");
	var right=document.getElementById("rightclickbtn");
	var leftbox =document.getElementById("allchecklistright");
	
	if (p.style.display =="none") {

		p.style.display = "block";
		left.style.display = "none";
		right.style.display = "block";
		leftbox.style.marginLeft="275px";
	 } 
 }
	
	function cqright()
	{
	var p=document.getElementById("mainboxid");
	var left=document.getElementById("leftclickbtn");
	var right=document.getElementById("rightclickbtn");
	
	var leftbox =document.getElementById("allchecklistright");
	if (p.style.display =="block") {

		p.style.display = "none";
		left.style.display="block";
		right.style.display="none"
		leftbox.style.marginLeft="12px";
		

	
	} 
}	
	
function openchecklist()
	{
	var p=document.getElementById("checkmainboxid");
	var open=document.getElementById("opencheckbtn");
	var closed=document.getElementById("closedcheckbtn");
	
	if (p.style.display =="none") {

		p.style.display = "block";
		open.style.display = "none";
		closed.style.display = "block";
	 } 
 }
	
function closedchecklist()
	{
	var p=document.getElementById("checkmainboxid");
	var open=document.getElementById("opencheckbtn");
	var closed=document.getElementById("closedcheckbtn");
	
	if (p.style.display =="block") {

		p.style.display = "none";
		open.style.display="block";
		closed.style.display="none"
	
	} 
}	



/*function openchecklistview()
{
var p=document.getElementById("viewmainbox");
var o=document.getElementById("openchecklist");
var c=document.getElementById("closedchecklist");
var i;
alert("this is My msg1");
for (i = 0; i < p.length && i< o.length; i++) 
    				
    {
		alert("this is My msg");
		var z=document.getElementById(p[i].id);
		//z.style.display="none";
		document.getElementById(p[i].id).style.display = "none"; 
		alert("this is My runing  msg");
		var o=document.getElementById(open[i].id);
		o.style.display="block";
}
	
if (p.style.display =="none") {
	
	p.style.display = "block";
	open.style.display = "none";
	closed.style.display = "block";
 } 
}*/



function openchecklistview(op)
{
var p=document.getElementById("viewmainboxid_"+op);
var open=document.getElementById("opencheckbtnview_"+op);
var closed=document.getElementById("closedcheckbtnview_"+op);
var i;


var ab = document.getElementsByName("viewmainbox")
var ad = document.getElementsByName("openchecklist")

for(i = 0; i < ab.length && ad.length; ++i){
	
		var z=document.getElementById(ab[i].id);
		var as=document.getElementById(ad[i].id);
		
		if(z.style.display=="block"){
			z.style.display="none"
			as.style.display="block"
			
			break;
		}
		//document.getElementById(ab[i].id).style.display = 'none';
	}
if (p.style.display =="none") {
	
	p.style.display = "block";
	open.style.display = "none";
	closed.style.display = "block";
 } 
}



function closedchecklistview(op)
{
var p=document.getElementById("viewmainboxid_"+op);
var open=document.getElementById("opencheckbtnview_"+op);
var closed=document.getElementById("closedcheckbtnview_"+op);

if (p.style.display =="block") {

	p.style.display = "none";
	open.style.display="block";
	closed.style.display="none"

} 
}	
	
	
	
function viewnotification1()
{

	//var a=document.getElementById("activatechecklist");
	var a=document.getElementsByName("activatechk");
	//var b=document.getElementById("closedchecklist_");
	var b=document.getElementsByName("closecheck");
	
	var i;
	var c = document.getElementById("activchk");
	var d = document.getElementById("clsechk");
	c.style.backgroundColor = "#118ade";
	c.style.color = "white";
	d.style.backgroundColor = "white";
	d.style.color = "black";
	for (i = 0; i < b.length && i< a.length; i++) 
		
  {
		
	var y=document.getElementById(a[i].id);
	var z=document.getElementById(b[i].id);

	
	y.style.display="block";
	z.style.display="none";
	
  }
}
function viewclosechecklist1()
{

//var a=document.getElementById("activatechecklist");
//var b=document.getElementById("closedchecklist");
var a=document.getElementsByName("activatechk");
//var b=document.getElementById("closedchecklist");
var b=document.getElementsByName("closecheck");
var c = document.getElementById("activchk");
var d = document.getElementById("clsechk");
c.style.backgroundColor = "#118ade";
c.style.color = "white";
d.style.backgroundColor = "white";
d.style.color = "black";
var i;

for (i = 0; i < b.length && i< a.length; i++) 
	
{
var y=document.getElementById(a[i].id);
var z=document.getElementById(b[i].id);

y.style.display="none";
z.style.display="block";

}

}



function submiselect(){
	select = document.getElementById('selecthh');
	if (select.value) {
	  
	  return true;
	}
	
	return false;
}



function uploadfilck(y){
    var x = document.getElementById("fileuploada_"+y);
    //var filenameId = document.getElementById("filenameu_"+y);
    var txt = "";
    //var filenameId = "filenameu_"+y;
  //  alert(filenameId);

    if ('files' in x) {
        if (x.files.length == 0) {
            txt = "Select one files.";
        } else {
            for (var i = 0; i < x.files.length; i++) {
             
            	var file = x.files[i];
                if ('name' in file) {
                    txt += "" + file.name + "<br>";
                  
                }
                
            }
        }
    } 
    else {
        if (x.value == "") {
            txt += "Select one or more files.";
        } else {
            txt += "The files property is not supported by your browser!";
            txt  += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead. 
        }
    }
    
    document.getElementById('uploadfilename_'+y).innerHTML = txt;
}

function uploadfileAct(a){
    var x = document.getElementById("actfileupload_"+a);
    //var filenameId = document.getElementById("filenameu_"+y);
    var txt = "";
    //var filenameId = "filenameu_"+y;
    if ('files' in x) {
        if (x.files.length == 0) {
            txt = "Select one files.";
        } else {
            for (var i = 0; i < x.files.length; i++) {
                var file = x.files[i];
                if ('name' in file) {
                    txt += "" + file.name + "<br>";
                }
                
            }
        }
    } 
    else {
        if (x.value == "") {
            txt += "Select one or more files.";
        } else {
            txt += "The files property is not supported by your browser!";
            txt  += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead. 
        }
    }
    document.getElementById('actfilename_'+a).innerHTML = txt;
}

function fileuploadallcheck(yz){
	
	var id ="fileuploadaall_"+yz;

    var x = document.getElementById("uploadfileall_"+yz);
    //var filenameId = document.getElementById("filenameu_"+y);
  
    var txt = "";
    //var filenameId = "filenameu_"+y;
  //  alert(filenameId);

    if ('files' in x) {
        if (x.files.length == 0) {
            txt = "Select one files.";
        } else {
            for (var i = 0; i < x.files.length; i++) {
             
            	var file = x.files[i];
                if ('name' in file) {
                    txt += "" + file.name + "<br>";
                    
                }
                
            }
        }
    } 
    else {
        if (x.value == "") {
            txt += "Select one or more files.";
        } else {
            txt += "The files property is not supported by your browser!";
            txt  += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead. 
        }
    }
   
    document.getElementById('uploadfilenameall_'+yz).innerHTML = txt;
}


	
function uploadfilckgrid(ab){
    var x = document.getElementById("fileuploadall_"+ab);
    //var filenameId = document.getElementById("filenameu_"+y);
   
    var txt = "";
    //var filenameId = "filenameu_"+y;
  //  alert(filenameId);

    if ('files' in x) {
        if (x.files.length == 0) {
            txt = "Select one files.";
        } else {
            for (var i = 0; i < x.files.length; i++) {
             
            	var file = x.files[i];
                if ('name' in file) {
                    txt += "" + file.name + "<br>";
                    
                }
                
            }
        }
    } 
    else {
        if (x.value == "") {
            txt += "Select one or more files.";
        } else {
            txt += "The files property is not supported by your browser!";
            txt  += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead. 
        }
    }
    
    document.getElementById('uploadfilenameall_'+ab).innerHTML = txt;
}