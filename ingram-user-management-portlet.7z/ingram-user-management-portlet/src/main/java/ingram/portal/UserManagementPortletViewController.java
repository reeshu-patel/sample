package ingram.portal;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.expando.kernel.model.ExpandoBridge;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONSerializer;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.Contact;
import com.liferay.portal.kernel.model.Country;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.search.Indexer;
import com.liferay.portal.kernel.search.IndexerRegistryUtil;
import com.liferay.portal.kernel.search.SearchException;
import com.liferay.portal.kernel.service.CountryServiceUtil;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.service.UserServiceUtil;
import com.liferay.portal.kernel.servlet.ServletResponseUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.CalendarFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
/*import com.liferay.portal.model.Company;
import com.liferay.portal.model.Contact;
import com.liferay.portal.model.Country;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.CountryServiceUtil;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.UserServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.expando.model.ExpandoBridge;*/
import com.liferay.util.Encryptor;
import com.liferay.util.EncryptorException;

import ingram.portal.constants.PeopleConstants;
import ingram.portal.dto.PartnerDTO;
import ingram.portal.dto.UserDTO;
import ingram.portal.service.impl.UserManagementServiceImpl;

/**
 * @author samir.gami (INGAMS01)
 *
 */
@Controller
@RequestMapping("VIEW")
public class UserManagementPortletViewController {
	
	private static final Log LOGGER = LogFactoryUtil.getLog(UserManagementPortletViewController.class);
	@Autowired
	private UserManagementServiceImpl userManagementService;
	
	@RenderMapping
	public String doView(RenderRequest renderRequest) throws SystemException {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		User user = themeDisplay.getUser();
		String countryKeyword = StringPool.BLANK;
		
		if(user != null){
			for (Role role : user.getRoles()) {
				String roleName = role.getName();
				
				if (PeopleConstants.IM_COUNTRY_READONLY.equalsIgnoreCase(roleName)
						/*|| PeopleConstants.IM_COUNTRY_EDIT.equalsIgnoreCase(roleName)
						|| PeopleConstants.IM_COUNTRY_ADMIN.equalsIgnoreCase(roleName)*/){
					
					Serializable userCountry = user.getExpandoBridge().getAttribute("User Country");
					System.out.println("userCounttry ============="+userCountry);
					
					if(userCountry != null){
						countryKeyword = userCountry.toString();
					}else{
						LOGGER.warn("User "+user.getUserId()+" with country role, don't have any country assigned to custom field.");
					}
				}
			}
		}
		renderRequest.setAttribute("keywords",ParamUtil.getString(renderRequest, "keywords", StringPool.BLANK));
		renderRequest.setAttribute("countryKeyword",countryKeyword);
		
		return "ingram-user-management-portlet/view";
	}
	
	
	@RenderMapping(params = "viewName=editUser")
	public String editUser(RenderRequest renderRequest, RenderResponse renderResponse, Model model) throws PortalException, SystemException {
		long userId = ParamUtil.getLong(renderRequest, "userId", 0);
		renderRequest.setAttribute("backURL", ParamUtil.getString(renderRequest, "redirect"));
		String action=renderRequest.getParameter("action");
		LOGGER.info("Rendering user in edit mode " + userId);
		
		if(userId > 0){
			model.addAttribute("userDTO", getUserDetail(userId));
			
			List<Country> countries =  CountryServiceUtil.getCountries(true);
			model.addAttribute("countries",countries);
		}
		if(action.equalsIgnoreCase("edit"))
			return "ingram-user-management-portlet/editUser";
		else
			return "ingram-user-management-portlet/viewUser";
	}
	
	
	@ActionMapping(params = "viewName=deleteUser")
	public void editUser(ActionRequest req, ActionResponse res) throws PortalException, SystemException 
	{
		long userId = ParamUtil.getLong(req, "userId", 0);
		//req.setAttribute("backURL", ParamUtil.getString(req, "redirect"));
		System.out.println("User ID -----"+userId);
		LOGGER.info("Rendering user in delet mode " + userId);
		User user = UserLocalServiceUtil.deleteUser(userId);
		SessionMessages.add(req, "user-Delete");
		
		System.out.println("User Delete SuccessFully");
		
		
	}
	
	@ActionMapping(params = "imPersonate=impersonateUserURL")
	public void impersonateUserURL(ActionRequest req, ActionResponse res) throws PortalException, SystemException, EncryptorException, IOException 
	{
		long userId = ParamUtil.getLong(req, "userId", 0);
		//req.setAttribute("backURL", ParamUtil.getString(req, "redirect"));
		User user = UserLocalServiceUtil.getUser(userId);
		
		System.out.println("imparsunate userId========="+userId);
		
		String UserName = user.getFullName();
		
		User currentUser = PortalUtil.getUser(req);
		String currentUserName = currentUser.getFullName();
		
		/*--------Impersonate User--------*/
		ThemeDisplay themeDisplay = (ThemeDisplay)req.getAttribute(WebKeys.THEME_DISPLAY);

		Company company = themeDisplay.getCompany();

		String doAsURL = themeDisplay.getURLHome();

		String encDoAsUserId = Encryptor.encrypt(company.getKeyObj(),String.valueOf(userId));

		System.out.println("theme display========="+themeDisplay.getPathContext() + doAsURL);
		
		doAsURL = themeDisplay.getPathContext() + doAsURL+"/home-page" + "?" + "doAsUserId="+encDoAsUserId;

		System.out.println("doAsURL=========" + doAsURL);

		System.out.println("encDoAsUserId=========" + encDoAsUserId);

		/*--------Impersonate User--------*/

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();

		System.out.println("User ID -----" + userId);

		LOGGER.info("Impersonate user  " + currentUserName
				+ "  login with impersonate user " + UserName + "  user id "
				+ userId + " Time " + dateFormat.format(date));

		System.out.println("Impersonate user " + currentUserName
				+ " login with impersonate user " + UserName + " user id "
				+ userId + " Time " + dateFormat.format(date));

		// response.sendRedirect(redirectUrl);
		res.sendRedirect(doAsURL);
		
		
	}
	
	
	@ActionMapping(params = "viewName=editUserAction")
	public void saveUser(ActionRequest actionRequest, ActionResponse actionResponse) {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		LOGGER.info("[Admin Action] Updating user " + userId);
		
		if(userId > 0){
			try {
				updaeUser(actionRequest);

				SessionMessages.add(actionRequest, "user-update-sucess");

			} catch (PortalException e) {
				  PortalUtil.copyRequestParameters(actionRequest, actionResponse);
				  actionResponse.setRenderParameter("viewName","editUser");
				  SessionErrors.add(actionRequest, e.getClass(), e);
				  SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);		            
				  LOGGER.error("Error occured while updating user " + e.getMessage(), e);
				  
			} catch (SystemException e) {
				LOGGER.error("Error occured while updating user " + e.getMessage(), e);
			}
		}
	}


	/**
	 * @param actionRequest
	 * @throws PortalException
	 * @throws SystemException
	 * @throws SearchException
	 * @author INGAMS01
	 */
	private void updaeUser(ActionRequest actionRequest) throws PortalException, SystemException, SearchException {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String firstName = ParamUtil.getString(actionRequest,"firstName");
		String middleName = ParamUtil.getString(actionRequest,"middleName");
		String lastName = ParamUtil.getString(actionRequest,"lastName");
		String screenName = ParamUtil.getString(actionRequest,"screenName");
		String emailAddress = ParamUtil.getString(actionRequest,"emailAddress");
		
		String mobileNumber = ParamUtil.getString(actionRequest,"mobileNumber");
		String companyName = ParamUtil.getString(actionRequest,"companyName");
		String companyAddress = ParamUtil.getString(actionRequest,"companyAddress");
		String companyCountry = ParamUtil.getString(actionRequest,"companyCountry");
		String userCountry = ParamUtil.getString(actionRequest,"userCountry");
		String allowedPartnerIds = ParamUtil.getString(actionRequest,"allowedPartnerIds");
		String readCountry = ParamUtil.getString(actionRequest,"readCountry");
		User user = UserLocalServiceUtil.getUser(userId);
		user.setFirstName(firstName);
		user.setMiddleName(middleName);
		user.setLastName(lastName);
		user.setScreenName(screenName);
		user.setEmailAddress(emailAddress);
		user.setModifiedDate(new Date());
		if(Validator.isNull(userCountry)){
			userCountry="";
		}
		if(Validator.isNull(allowedPartnerIds)){
			allowedPartnerIds="";
		}
		if(Validator.isNull(readCountry)){
			readCountry="";
		}
		//Expando
		ExpandoBridge expandoBridge = user.getExpandoBridge();
		
		if (expandoBridge != null) {
			expandoBridge.setAttribute("contact-number-mobile", mobileNumber);
			expandoBridge.setAttribute("company-name", companyName);
			expandoBridge.setAttribute("company-address", companyAddress);
			expandoBridge.setAttribute("company-country", companyCountry);
		/*	if (expandoBridge.getAttribute("User Country") != null
					&& !expandoBridge.getAttribute("User Country").equals("")) {
				if (Validator.isNotNull(userCountry) && !userCountry.equals("")) {
					//userCountry += "," + expandoBridge.getAttribute("User Country");
				} else
					userCountry = (String) expandoBridge.getAttribute("User Country");
			}*/
			/*if (Validator.isNotNull(userCountry) && !userCountry.equals("")) {*/
				userCountry = removeDuplicateValues(userCountry);
				expandoBridge.setAttribute("User Country", userCountry);
		/*	}*/

			if (expandoBridge.getAttribute("Allowed Partner IDs") != null
					&& !expandoBridge.getAttribute("Allowed Partner IDs").equals("")) {
				if (Validator.isNotNull(allowedPartnerIds) && !allowedPartnerIds.equals("")) {
					allowedPartnerIds += "," + expandoBridge.getAttribute("Allowed Partner IDs");
				} else
					allowedPartnerIds = (String) expandoBridge.getAttribute("Allowed Partner IDs");
			}
			if (Validator.isNotNull(allowedPartnerIds) && !allowedPartnerIds.equals("")) {
				allowedPartnerIds = removeDuplicateValues(allowedPartnerIds);
				expandoBridge.setAttribute("Allowed Partner IDs", allowedPartnerIds);
			}
			if (expandoBridge.getAttribute("Read Country") != null
					&& !expandoBridge.getAttribute("Read Country").equals("")) {
				if (Validator.isNotNull(readCountry) && !readCountry.equals("")) {
					readCountry += "," + expandoBridge.getAttribute("Read Country");
				} else
					readCountry = (String) expandoBridge.getAttribute("Read Country");
			}
			if (Validator.isNotNull(readCountry) && !readCountry.equals("")) {
				readCountry = removeDuplicateValues(readCountry);
				expandoBridge.setAttribute("Read Country", readCountry);
			}
		}
		
		Contact contact = user.getContact();
		Calendar birthdayCal = CalendarFactoryUtil.getCalendar();
		birthdayCal.setTime(contact.getBirthday());

		int birthdayMonth = birthdayCal.get(Calendar.MONTH);
		int birthdayDay = birthdayCal.get(Calendar.DATE);
		int birthdayYear = birthdayCal.get(Calendar.YEAR);
		
		user = UserServiceUtil.updateUser(
				userId, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK,
				user.isPasswordReset(), user.getReminderQueryQuestion(),
				user.getReminderQueryAnswer(), screenName, emailAddress, user.getFacebookId(),
				user.getOpenId(), user.getLanguageId(), user.getTimeZoneId(), user.getGreeting(), user.getComments(),
				firstName, middleName, lastName, contact.getPrefixId(), contact.getSuffixId(),
				contact.isMale(), birthdayMonth, birthdayDay, birthdayYear, contact.getSmsSn(),
				contact.getFacebookSn(), contact.getJabberSn(),contact.getSkypeSn(),contact.getTwitterSn(),contact.getJobTitle(),null,
				null, null, null,null,null,null,null,null,null, ServiceContextFactory.getInstance(actionRequest));
		
		Indexer indexer = IndexerRegistryUtil.getIndexer(User.class);
		indexer.reindex(user.getUserId());
	}
	
	
	/**
	 * @param userId
	 * @return
	 * @throws PortalException
	 * @throws SystemException
	 * @author INGAMS01
	 */
	private UserDTO getUserDetail(long userId) throws PortalException, SystemException{
		UserDTO userDTO = new UserDTO();
		User user = UserLocalServiceUtil.getUser(userId);
		
		if(user != null){
			userDTO.setUserId(user.getUserId());
			userDTO.setFirstName(user.getFirstName());
			userDTO.setMiddleName(user.getMiddleName());
			userDTO.setLastName(user.getLastName());
			userDTO.setScreenName(user.getScreenName());
			userDTO.setEmailAddress(user.getEmailAddress());
			
			//Expando
			ExpandoBridge expandoBridge = user.getExpandoBridge();
			
			if(expandoBridge != null){
				userDTO.setMobileNumber(String.valueOf(expandoBridge.getAttribute("contact-number-mobile")));
				userDTO.setCompanyName(String.valueOf(expandoBridge.getAttribute("company-name")));
				userDTO.setCompanyAddress(String.valueOf(expandoBridge.getAttribute("company-address")));
				userDTO.setUserCountry(String.valueOf(expandoBridge.getAttribute("User Country")));
				userDTO.setReadCountry(String.valueOf(expandoBridge.getAttribute("Read Country")));
				userDTO.setAllowedPartnerIds(String.valueOf(expandoBridge.getAttribute("Allowed Partner IDs")));
				if(Validator.isNull(userDTO.getUserCountry())){
					userDTO.setUserCountry("");
				}
				if(Validator.isNull(userDTO.getReadCountry())){
					userDTO.setReadCountry("");
				}
				if(Validator.isNull(userDTO.getAllowedPartnerIds())){
					userDTO.setAllowedPartnerIds("");
				}
				Object ccValue = expandoBridge.getAttribute("company-country");
				Class<?> clazz = ccValue.getClass();
				
				if (clazz.isArray()) {
					String[] values = (String[]) ccValue;

					if (values.length != 0) {
						userDTO.setCompanyCountry(String.valueOf(values[0]));
					}
				}else{
					userDTO.setCompanyCountry(String.valueOf(ccValue));
				}
			}
		}
		return userDTO;
	}
	@ResourceMapping("getPartnerDetails")
	public void getPartnerDetails(ResourceRequest resourceRequest,
            ResourceResponse resourceResponse) throws IOException,
    PortletException {
		System.out.println("sss_"+resourceRequest.getParameter("countryParam"));
		String country = ParamUtil.getString(resourceRequest, "countryParam");
		String partnerType = ParamUtil.getString(resourceRequest, "partnerTypeParam");
		List<PartnerDTO> partnerList =userManagementService.getPartnerDetails(country,partnerType);
		Map<String, Object> hashMap = new HashMap<String, Object>();
		PrintWriter writer = resourceResponse.getWriter();
		ObjectMapper mapper = new ObjectMapper();
		hashMap.put("partnerList", partnerList);
		String entityString = mapper.writeValueAsString(hashMap);
		writer.write(entityString);
		writer.close();
		//sendResponse(resourceResponse, partnerList);
	}
	private void sendResponse(ResourceResponse resourceResponse, Object data) throws IOException {
		HttpServletResponse response = PortalUtil.getHttpServletResponse(resourceResponse);
		JSONSerializer jsonSerializer = JSONFactoryUtil.createJSONSerializer();
		ServletResponseUtil.write(response, jsonSerializer.serialize(data));
	}
	
	public String removeDuplicateValues(String s) {
	    return new LinkedHashSet<String>(Arrays.asList(s.split(","))).toString().replaceAll("(^\\[|\\]$)", "").replace(", ", ",");
	}
}