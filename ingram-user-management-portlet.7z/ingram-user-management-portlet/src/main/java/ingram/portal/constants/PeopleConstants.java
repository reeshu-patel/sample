package ingram.portal.constants;


public interface PeopleConstants {   
    
    String IM_GLOBAL_READONLY="IM_Global_ReadOnly";
    String IM_GLOBAL_EDIT="IM_Global_Edit";
    String IM_GLOBAL_ADMIN="IM_Global_Admin";
    
    String IM_COUNTRY_READONLY="IM_Country_ReadOnly";
    String IM_COUNTRY_EDIT="IM_Country_Edit";
    String IM_COUNTRY_ADMIN="IM_Country_Admin";
    String IM_PARTNER_READONLY="IM_Partner_ReadOnly";
    String IM_PARTNER_EDIT="IM_Partner_Edit";
    String IM_GUEST="IM_Guest";
    String ADMINISTRATOR="Administrator";
    String IM_FULL_ACCESS="IM_Full_Access";
    String IM_READ_ONLY="IM_Read_Only";
}
