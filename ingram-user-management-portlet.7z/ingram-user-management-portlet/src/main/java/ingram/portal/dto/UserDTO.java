package ingram.portal.dto;

/**
 * @author samir.gami (INGAMS01)
 *
 */
public class UserDTO {
	
	private long userId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String screenName;
	private String emailAddress;
	private String mobileNumber;
	private String companyName;
	private String companyAddress;
	private String companyCountry;
	private String userCountry;
	private String allowedPartnerIds;
	private String readCountry;
	
	
	public String getReadCountry() {
		return readCountry;
	}
	public void setReadCountry(String readCountry) {
		this.readCountry = readCountry;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public String getCompanyCountry() {
		return companyCountry;
	}
	public void setCompanyCountry(String companyCountry) {
		this.companyCountry = companyCountry;
	}
	public String getUserCountry() {
		return userCountry;
	}
	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}
	public String getAllowedPartnerIds() {
		return allowedPartnerIds;
	}
	public void setAllowedPartnerIds(String allowedPartnerIds) {
		this.allowedPartnerIds = allowedPartnerIds;
	}

}
