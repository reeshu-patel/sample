package ingram.portal.dto;

public class PartnerDTO {

	private String partnerName;
	private String partnerCid;
	private String centityclassref;
	
	
	public String getCentityclassref() {
		return centityclassref;
	}
	public void setCentityclassref(String centityclassref) {
		this.centityclassref = centityclassref;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getPartnerCid() {
		return partnerCid;
	}
	public void setPartnerCid(String partnerCid) {
		this.partnerCid = partnerCid;
	}
	
	
}
