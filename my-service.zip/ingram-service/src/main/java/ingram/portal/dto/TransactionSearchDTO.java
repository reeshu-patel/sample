/**
 * 
 */
package ingram.portal.dto;

/**
 * @author INGAMS01
 *
 */
public class TransactionSearchDTO {
	
	private String country;
	private String partnerId;
	private String partnerName;
	private String transactionProfileUserId;
	private String transactionType;
	private String status;
	private String direction;
	private String startDate;
	private String endDate;
	 
	private String documentNumber;
	private String partnerOrderNumber;
	private String ingramOrderNumber;
	private String deliveryNumber;
	private String shipmentNumber;
	private String invoiceNumber;
	private String rmaNumber;
	 
	private String sbTrackId;
	private String idocNumber;
	
	private String id;
	private String attachementId;
	
	private boolean isPartner;
	private String ingramPartnerIds;
	
	private String statusInfo;
	private String documentsType;
	private String initiatorFiletype;
	private String sapPartnerid;
	private String senderIds;
	private String receiverIds;
	private String partnerAgreement;
	private String forwardingFiletype;
	private String businessFunction;
	private String regionCountry;
	private String ingramOrdernumber;
	private String sapIDocsize;
	private String seeburgerTrackId;
	private String transactionCount;
	private String transactionId;
	private String sapTransactiontype;
	private String numberofSegments;
	private String tradingPartnername;
	
	private String groupId;
	private String partnerIasid;
	private String partnerGsid;
	private String sapIdocnumber;
	
	private String purchaseOrdernumber;
	
	
	
	
	
	
	public String getPartnerAgreement() {
		return partnerAgreement;
	}
	public void setPartnerAgreement(String partnerAgreement) {
		this.partnerAgreement = partnerAgreement;
	}
	public String getForwardingFiletype() {
		return forwardingFiletype;
	}
	public void setForwardingFiletype(String forwardingFiletype) {
		this.forwardingFiletype = forwardingFiletype;
	}
	public String getBusinessFunction() {
		return businessFunction;
	}
	public void setBusinessFunction(String businessFunction) {
		this.businessFunction = businessFunction;
	}
	public String getRegionCountry() {
		return regionCountry;
	}
	public void setRegionCountry(String regionCountry) {
		this.regionCountry = regionCountry;
	}
	public String getIngramOrdernumber() {
		return ingramOrdernumber;
	}
	public void setIngramOrdernumber(String ingramOrdernumber) {
		this.ingramOrdernumber = ingramOrdernumber;
	}
	public String getSapIDocsize() {
		return sapIDocsize;
	}
	public void setSapIDocsize(String sapIDocsize) {
		this.sapIDocsize = sapIDocsize;
	}
	public String getSeeburgerTrackId() {
		return seeburgerTrackId;
	}
	public void setSeeburgerTrackId(String seeburgerTrackId) {
		this.seeburgerTrackId = seeburgerTrackId;
	}
	public String getTransactionCount() {
		return transactionCount;
	}
	public void setTransactionCount(String transactionCount) {
		this.transactionCount = transactionCount;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getSapTransactiontype() {
		return sapTransactiontype;
	}
	public void setSapTransactiontype(String sapTransactiontype) {
		this.sapTransactiontype = sapTransactiontype;
	}
	public String getNumberofSegments() {
		return numberofSegments;
	}
	public void setNumberofSegments(String numberofSegments) {
		this.numberofSegments = numberofSegments;
	}
	public String getTradingPartnername() {
		return tradingPartnername;
	}
	public void setTradingPartnername(String tradingPartnername) {
		this.tradingPartnername = tradingPartnername;
	}
	public String getSapIdocnumber() {
		return sapIdocnumber;
	}
	public void setSapIdocnumber(String sapIdocnumber) {
		this.sapIdocnumber = sapIdocnumber;
	}
	public String getPartnerGsid() {
		return partnerGsid;
	}
	public void setPartnerGsid(String partnerGsid) {
		this.partnerGsid = partnerGsid;
	}
	public String getPartnerIasid() {
		return partnerIasid;
	}
	public void setPartnerIasid(String partnerIasid) {
		this.partnerIasid = partnerIasid;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getPurchaseOrdernumber() {
		return purchaseOrdernumber;
	}
	public void setPurchaseOrdernumber(String purchaseOrdernumber) {
		this.purchaseOrdernumber = purchaseOrdernumber;
	}

	
	public String getInitiatorFiletype() {
		return initiatorFiletype;
	}
	public void setInitiatorFiletype(String initiatorFiletype) {
		this.initiatorFiletype = initiatorFiletype;
	}
	public String getSapPartnerid() {
		return sapPartnerid;
	}
	public void setSapPartnerid(String sapPartnerid) {
		this.sapPartnerid = sapPartnerid;
	}
	public String getSenderIds() {
		return senderIds;
	}
	public void setSenderIds(String senderIds) {
		this.senderIds = senderIds;
	}
	public String getReceiverIds() {
		return receiverIds;
	}
	public void setReceiverIds(String receiverIds) {
		this.receiverIds = receiverIds;
	}
	public String getStatusInfo() {
		return statusInfo;
	}
	public void setStatusInfo(String statusInfo) {
		this.statusInfo = statusInfo;
	}
	public String getDocumentsType() {
		return documentsType;
	}
	public void setDocumentsType(String documentsType) {
		this.documentsType = documentsType;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getTransactionProfileUserId() {
		return transactionProfileUserId;
	}
	public void setTransactionProfileUserId(String transactionProfileUserId) {
		this.transactionProfileUserId = transactionProfileUserId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getPartnerOrderNumber() {
		return partnerOrderNumber;
	}
	public void setPartnerOrderNumber(String partnerOrderNumber) {
		this.partnerOrderNumber = partnerOrderNumber;
	}
	public String getIngramOrderNumber() {
		return ingramOrderNumber;
	}
	public void setIngramOrderNumber(String ingramOrderNumber) {
		this.ingramOrderNumber = ingramOrderNumber;
	}
	public String getDeliveryNumber() {
		return deliveryNumber;
	}
	public void setDeliveryNumber(String deliveryNumber) {
		this.deliveryNumber = deliveryNumber;
	}
	public String getShipmentNumber() {
		return shipmentNumber;
	}
	public void setShipmentNumber(String shipmentNumber) {
		this.shipmentNumber = shipmentNumber;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getRmaNumber() {
		return rmaNumber;
	}
	public void setRmaNumber(String rmaNumber) {
		this.rmaNumber = rmaNumber;
	}
	public String getSbTrackId() {
		return sbTrackId;
	}
	public void setSbTrackId(String sbTrackId) {
		this.sbTrackId = sbTrackId;
	}
	public String getIdocNumber() {
		return idocNumber;
	}
	public void setIdocNumber(String idocNumber) {
		this.idocNumber = idocNumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAttachementId() {
		return attachementId;
	}
	public void setAttachementId(String attachementId) {
		this.attachementId = attachementId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public boolean isPartner() {
		return isPartner;
	}
	public void setPartner(boolean isPartner) {
		this.isPartner = isPartner;
	}
	public String getIngramPartnerIds() {
		return ingramPartnerIds;
	}
	public void setIngramPartnerIds(String ingramPartnerIds) {
		this.ingramPartnerIds = ingramPartnerIds;
	}
	
}
