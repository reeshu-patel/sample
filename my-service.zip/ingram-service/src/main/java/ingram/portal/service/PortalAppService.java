package ingram.portal.service;

import org.springframework.stereotype.Service;

public interface PortalAppService {
   
	void getCountries();
}
