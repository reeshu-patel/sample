package ingram.portal.service;

import java.util.List;
import java.util.Map;

import ingram.portal.dto.SelectItem;
import ingram.portal.dto.TransactionSearchDTO;

public interface TransactionMonitoringService {
	
	List<TransactionSearchDTO> searchTransactions(TransactionSearchDTO searchParams);
	
	List<SelectItem> getTransactionTypeOptions();
	
	List<SelectItem> getStatusOptions();
	
	List<SelectItem> getDirectionOptions();
	
	Map<String,Object> getTransactionDetail(String transactionId);
	
	byte[] getAttachementDetail(String objectId, String requestType,String url);
	
}
