package ingram.portal.service;

import java.util.List;

import ingram.portal.dto.PartnerDTO;

public interface UserManagementService {
   
	List<PartnerDTO> getPartnerDetails(String country,String partnerType);
}
