/**
 * 
 */
package ingram.portal.service.impl;

import org.springframework.stereotype.Service;

import ingram.portal.service.PortalAppService;

/**
 * @author samir.gami (INGAMS01)
 */
@Service("portalAppService")
public class PortalAppServiceImpl implements PortalAppService {

	@Override
	public void getCountries() {
		System.out.println("in countries >>>>>>>>>>>>>>>");
		
	}

}
