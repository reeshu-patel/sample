/**
 * 
 */
package ingram.portal.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;

import ingram.portal.dto.SelectItem;
import ingram.portal.dto.TransactionSearchDTO;
import ingram.portal.service.TransactionMonitoringService;

/**
 * @author samir.gami(INGAMS01)
 *
 */
@Service
public class TransactionMonitoringServiceImpl implements TransactionMonitoringService {
	
	private static final Log LOGGER = LogFactoryUtil.getLog(TransactionMonitoringServiceImpl.class);


	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value(value="${app.db.transaction.schema.name:SBP1_BISRPT_1_1_RO}")
	private String schemaName;
	
	@Override
	public List<SelectItem> getTransactionTypeOptions() {
		
		/*String sqlQuery = "SELECT DISTINCT((SELECT cvalue FROM TENTITIESEXTENSIONS WHERE ctyperef LIKE '%Meta%' AND ckey = 'TRANSACTIONDIRECTION' AND CNODEREF = A.CNODEREF)|| ':' ||"
						+"(SELECT cvalue FROM [SCHEMA_NAME].TENTITIESEXTENSIONS WHERE ctyperef LIKE '%Meta%' AND ckey = 'TRANSACTIONNAME' AND CNODEREF = A.CNODEREF) || ':' ||"
						+"(SELECT cvalue FROM [SCHEMA_NAME].TENTITIESEXTENSIONS WHERE ctyperef LIKE '%Meta%' AND ckey = 'TRANSACTIONVERSION' AND CNODEREF = A.CNODEREF) || ':' ||"
						+"(SELECT cvalue FROM [SCHEMA_NAME].TENTITIESEXTENSIONS WHERE ctyperef LIKE '%Meta%' AND ckey = 'TRANSACTION' AND CNODEREF = A.CNODEREF) || ':' ||"
						+"(SELECT cvalue FROM [SCHEMA_NAME].TENTITIESEXTENSIONS WHERE ctyperef LIKE '%Meta%' AND ckey = 'TRANSACTIONMODE' AND CNODEREF = A.CNODEREF))"
						+"TRANSATION_TYPE FROM [SCHEMA_NAME].TENTITIESEXTENSIONS A WHERE A.ctyperef LIKE '%Meta%' GROUP BY A.CNODEREF ORDER BY TRANSATION_TYPE";*/
		String sqlQuery = "select distinct TRANSACTION_TYPE.cvalue from (select replace(cvalue,'\\_','_') as cvalue,cnoderef FROM [SCHEMA_NAME].TENTITIESEXTENSIONS "
				+ "WHERE ctypename ='IMXML-TransactionMetaDataType' AND ckey = 'TRANSACTIONNAME' and "
				+ "(upper(cvalue) !=upper('PNARequest') and upper(cvalue) !=upper('PriceAndAvailabilityRequest') and "
				+ "upper(cvalue) !=upper('PNA'))) TRANSACTION_TYPE, TENTITIESEXTENSIONS A WHERE "
				+ "A.ctypename ='IMXML-TransactionMetaDataType' and a.ckey = 'LATESTVERSION' and a.cvalue = '1' "
				+ "and a.cnoderef = TRANSACTION_TYPE.cnoderef ORDER BY TRANSACTION_TYPE.cvalue";
		return jdbcTemplate.query(sqlQuery.replace("[SCHEMA_NAME]", schemaName), new RowMapper<SelectItem>(){
			public SelectItem mapRow(ResultSet rs, int arg1) throws SQLException {
				SelectItem selectItem = new SelectItem();
				selectItem.setName(rs.getString("cvalue"));
				selectItem.setValue(selectItem.getName());
				return selectItem;
			}
		});
	}

	@Override
	public List<SelectItem> getStatusOptions() {
		return jdbcTemplate.query("SELECT DISTINCT(CSTATUS) FROM "+schemaName+".TBISMT_WORKFLOW", new RowMapper<SelectItem>(){
			public SelectItem mapRow(ResultSet rs, int arg1) throws SQLException {
				SelectItem selectItem = new SelectItem();
				selectItem.setName(rs.getString("CSTATUS"));
				selectItem.setValue(selectItem.getName());
				return selectItem;
			}
		});
	}

	@Override
	public List<SelectItem> getDirectionOptions() {
		return jdbcTemplate.query("SELECT DISTINCT(CDIRECTION) FROM "+schemaName+".TBISMT_WORKFLOW", new RowMapper<SelectItem>(){
			public SelectItem mapRow(ResultSet rs, int arg1) throws SQLException {
				SelectItem selectItem = new SelectItem();
				selectItem.setName(rs.getString("CDIRECTION"));
				selectItem.setValue(selectItem.getName());
				return selectItem;
			}
		});
	}
	
	public List<TransactionSearchDTO> searchTransactions(TransactionSearchDTO searchParams) {
		
		Date startTime = new Date();
		
		String sqlQuery = "SELECT workflow.CWFID as id, workflow.COBJECTID as attachementId, workflow.CPROCESSINGTIMESTART as startDate, workflow.CPROCESSINGTIMEEND as endDate, "
				+ "workflow.CSTATUS as status, workflow.CPARTNER as partnerName, workflow.CFREE5 as partnerId, documents.CFREE20 as documentNumber, documents.CDOCTYPE as documentsType, workflow.CFREEDECIMAL2 as sbTrackId, workflow.CFREE2 as transactionProfileUserId, "
				+ "workflow.CFREE1 as initiatorFiletype, workflow.CFREE6 as senderIds, workflow.CFREE7 as receiverIds, workflow.CFREE4 as statusInfo, "
				+ "workflow.CFREE8 as partnerAgreement, workflow.CFREE11 as forwardingFiletype, workflow.CFREE15 as businessFunction, workflow.CFREE17 as regionCountry, "
				+ "workflow.CFREEDECIMAL1 as transactionCount, workflow.CFREEDECIMAL2 as seeburgerTrackId, workflow.CFREEDECIMAL3 as sapIDocsize, documents.CFREE8 as ingramOrdernumber, "
				+ "documents.CDOCNUMBER as transactionId, documents.CNUMBEROFLINES as numberofSegments, documents.CFREETEXT as tradingPartnername, "
				+ "documents.CREFERENCES as groupId, documents.CFREE1 as direction, documents.CFREE2 as partnerIasid, documents.CFREE3 as partnerGsid, documents.CFREE6 as sapIdocnumber, "
				+ "documents.CFREE7 as purchaseOrdernumber "
				+ "FROM [SCHEMA_NAME].TBISMT_WORKFLOW workflow "
				+ "LEFT JOIN [SCHEMA_NAME].TBISMT_DOCUMENTS documents ON workflow.CWFID = documents.CWFID WHERE ";
		
		List<String> queryParams = new ArrayList<String>();
		
		if(Validator.isNotNull(searchParams.getCountry())){
			String countryQuery = "( ";
			String[] countryList = searchParams.getCountry().split(",");

			for (int i = 0; i < countryList.length; i++) {
				countryQuery +=  "workflow.CPARTNER LIKE '"+countryList[i]+"%'";
				
				if((i+1) != countryList.length){
					countryQuery += " OR ";
				}
			}
			
			countryQuery += " )";
			queryParams.add(countryQuery);
		}
		
		if(Validator.isNotNull(searchParams.getPartnerId())){
			queryParams.add("workflow.CFREE5='" + searchParams.getPartnerId() + "'");
		}
		
		if(Validator.isNotNull(searchParams.getPartnerName())){
			queryParams.add("upper(workflow.CPARTNER) like'%" + searchParams.getPartnerName().toUpperCase() + "%'");
		}
		
		if(Validator.isNotNull(searchParams.getTransactionProfileUserId())){
			queryParams.add("workflow.CFREE2 like'" + searchParams.getTransactionProfileUserId() + "%'");
		}
		
		if(Validator.isNotNull(searchParams.getTransactionType())){
			queryParams.add("workflow.CMESSAGETYPE='" + searchParams.getTransactionType() + "'");
		}
		
		if(Validator.isNotNull(searchParams.getStatus())){
			queryParams.add("workflow.CSTATUS='" + searchParams.getStatus() + "'");
		}
		
		if(Validator.isNotNull(searchParams.getDirection())){
			queryParams.add("workflow.CDIRECTION='" + searchParams.getDirection() + "'");
		}
		
		//Document Number: Table: TBISMT_DOCUMENTS, Field: CFREE20
		if(Validator.isNotNull(searchParams.getDocumentNumber())){
			queryParams.add("documents.CFREE20='" + searchParams.getDocumentNumber() + "'");
		}
		
		//Partner Order Number: Table: TBISMT_DOCUMENTS, Field: CFREE7
		if(Validator.isNotNull(searchParams.getPartnerOrderNumber())){
			queryParams.add("documents.CFREE7='" + searchParams.getPartnerOrderNumber() + "'");
		}
		
		//Ingram Order Number: Table: TBISMT_DOCUMENTS, Field: CFREE8
		if(Validator.isNotNull(searchParams.getIngramOrderNumber())){
			queryParams.add("documents.CFREE8='" + searchParams.getIngramOrderNumber() + "'");
		}
		
		//Delivery Number: Table: TBISMT_DOCUMENTS, Field: CFREE9
		if(Validator.isNotNull(searchParams.getDeliveryNumber())){
			queryParams.add("documents.CFREE9='" + searchParams.getDeliveryNumber() + "'");
		}
		
		//Shipment Number: Table: TBISMT_DOCUMENTS, Field: CFREE10
		if(Validator.isNotNull(searchParams.getShipmentNumber())){
			queryParams.add("documents.CFREE10='" + searchParams.getShipmentNumber() + "'");
		}
		
		//Invoice Number: Table: TBISMT_DOCUMENTS, Field: CFREE11
		if(Validator.isNotNull(searchParams.getInvoiceNumber())){
			queryParams.add("documents.CFREE11='" + searchParams.getInvoiceNumber() + "'");
		}
		
		//RMA Number: Table: TBISMT_DOCUMENTS, Field: CFREE12
		if(Validator.isNotNull(searchParams.getRmaNumber())){
			queryParams.add("documents.CFREE12='" + searchParams.getRmaNumber() + "'");
		}
		
		if(Validator.isNotNull(searchParams.getSbTrackId())){
			queryParams.add("workflow.CFREEDECIMAL2='" + searchParams.getSbTrackId() + "'");
		}
		
		if(Validator.isNotNull(searchParams.getIdocNumber())){
			queryParams.add("documents.CFREE6='" + searchParams.getIdocNumber() + "'");
		}
		
		if(Validator.isNotNull(searchParams.getStartDate()) && Validator.isNotNull(searchParams.getEndDate())){
			queryParams.add("( workflow.CPROCESSINGTIMESTART >= "+searchParams.getStartDate()+" AND workflow.CPROCESSINGTIMEEND <= " +searchParams.getEndDate()+" )");
		}
		
		if(searchParams.isPartner() && Validator.isNotNull(searchParams.getIngramPartnerIds())){
			String partnerQuery = "workflow.CPARTNER IN (SELECT CNAME FROM [SCHEMA_NAME].TENTITIES WHERE CID IN (SELECT CNODEREF FROM TENTITIESEXTENSIONS WHERE CVALUE IN ([PARTNER_IDS]) AND CKEY = 'ErpNumber-Primary'))";
			String[] partnerArray = StringUtils.commaDelimitedListToStringArray(searchParams.getIngramPartnerIds());
			String partnerIds = StringPool.BLANK;
			
			for (int i = 0; i < partnerArray.length; i++) {
				if(Validator.isNotNull(partnerArray[i])){
					partnerIds += "'" + partnerArray[i] +"'";
				}
				if((i+1) != partnerArray.length){
					partnerIds += ",";
				}
			}
			
			if(Validator.isNotNull(partnerIds)){
				queryParams.add(partnerQuery.replace("[PARTNER_IDS]", partnerIds));
			}
		}
		
		queryParams.add("ROWNUM < 1001 ORDER BY workflow.CPROCESSINGTIMESTART DESC");

		sqlQuery += StringUtils.collectionToDelimitedString(queryParams, " AND ");
		sqlQuery = sqlQuery.replace("[SCHEMA_NAME]", schemaName);
		
		
		
		LOGGER.info("Search Query >>>> " + sqlQuery);
		
		List<TransactionSearchDTO> searchResult = jdbcTemplate.query(sqlQuery, new BeanPropertyRowMapper<TransactionSearchDTO>(TransactionSearchDTO.class));
		
		Date endTime = new Date();
		
		LOGGER.info("Time taken for search Transaction : " + ((endTime.getTime() - startTime.getTime()) / 1000)+ " second");
		
		return searchResult;
		
	}

	@Override
	public Map<String, Object> getTransactionDetail(String transactionId) {
		
		String sqlQuery = "SELECT workflow.CMESSAGEID as \"Message\", workflow.CPARTNER as \"Partner Name\","+
			"workflow.CDIRECTION as \"Direction\", workflow.CMESSAGETYPE as \"Partner Transaction Type\","+
			"workflow.CMESSAGESIZE as \"EDI Message Size\", workflow.CMESSAGEDATETIME as \"Messsage/Doc Time\","+
			"workflow.CPROCESSINGTIMESTART as \"Process Start Time\", workflow.CPROCESSINGTIMEEND as \"Process End Time\","+
			"workflow.CSTATUS as \"Process Status\", workflow.CFREE1 as \"Initiator | Filetype\","+
			"workflow.CFREE4 as \"Status Info\", workflow.CFREE5 as \"SAP Partner ID\","+
			"workflow.CFREE6 as \"Sender IDs\", workflow.CFREE7 as \"Receiver Ids\","+
			"workflow.CFREE8 as \"Partner Agreement\", workflow.CFREE11 as \"Forwarding | Filetype\","+
			"workflow.CFREE15 as \"Business Function\", workflow.CFREE17 as \"Region | Country\","+
			"workflow.CFREEDECIMAL1 as \"Transaction Count\", workflow.CFREEDECIMAL2 as \"Seeburger Track ID\","+
			"workflow.CFREEDECIMAL3 as \"SAP/IDoc Size\", documents.CFREE8 as \"Ingram Order Number\","+
			"documents.CDOCNUMBER as \"Transaction Id\", documents.CDOCTYPE as \"SAP Transaction Type\","+
			"documents.CNUMBEROFLINES as \"Number of Segments\",documents.CFREETEXT as \"Trading Partner Name\","+
			"documents.CREFERENCES as \"Group Id\",documents.CFREE1 as \"Direction\","+
			"documents.CFREE2 as \"Partner ISA Id\",documents.CFREE3 as \"Partner GS Id\","+
			"documents.CFREE6 as \"SAP IDoc Number\",documents.CFREE7 as \"Purchase Order Number\""+
			"FROM [SCHEMA_NAME].TBISMT_WORKFLOW workflow LEFT JOIN [SCHEMA_NAME].TBISMT_DOCUMENTS documents ON workflow.CWFID = documents.CWFID "+
			"WHERE workflow.CWFID ='"+transactionId+"' AND ROWNUM < 2 ORDER BY workflow.CPROCESSINGTIMESTART DESC";

		return jdbcTemplate.queryForMap(sqlQuery.replace("[SCHEMA_NAME]", schemaName));
	}
	

	@Override
	public byte[] getAttachementDetail(String objectIds, String requestType,String url){
		byte[] response = new byte[0];

		if(Validator.isNull(objectIds) || Validator.isNull(requestType)){
			return response;
		}
		//Test URL
		//String url = "https://venus.corporate.ingrammicro.com:8447/SeeburgerHTTP/HTTPController?HTTPInterface=syncReply&amp;Sender=FileDownloadAPI";
		//String url = "http://sbprodcentral.corporate.ingrammicro.com:8448/SeeburgerHTTP/HTTPController?HTTPInterface=syncReply&amp;Sender=FileDownloadAPI";
		String request = getRequestBody(objectIds, requestType);
		LOGGER.info("Request >>>> "+request);
		
		try{
			//Prepare Post request
			PostMethod method = new PostMethod(url);
			HttpClient client = new HttpClient();
			method.setRequestEntity(new StringRequestEntity(request, "text/xml", "UTF-8"));
			
			// Execute the method.
			int statusCode = client.executeMethod(method);

			// Read the response body.
			if (statusCode != HttpStatus.SC_OK) {
				LOGGER.error("Attachement Post request failed: " + method.getStatusLine());
			}else{
				response = method.getResponseBody();
			}
		}catch(Exception e){
			LOGGER.error("Error Occurred while calling post api : " + e.getMessage());
		}
		
		return response;
	}

	/**
	 * @param objectIds
	 * @param requestType
	 * @return
	 */
	private String getRequestBody(String objectIds, String requestType) {
		StringBuilder request = new StringBuilder("<FileDownloadRequest>");
		request.append("<FileType>"+requestType+"</FileType>");
		request.append("<DownloadFilePaths>");
		String file = "<FilePath>$[FILE_ID]</FilePath>";
		
		for(String objectId : StringUtils.commaDelimitedListToStringArray(objectIds)){
			request.append(file.replace("$[FILE_ID]", objectId));
		}
		
		request.append("</DownloadFilePaths></FileDownloadRequest>");
		
		return request.toString();
	}
	
}
