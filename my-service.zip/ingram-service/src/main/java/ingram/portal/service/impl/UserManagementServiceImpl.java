/**
 * 
 */
package ingram.portal.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;

import ingram.portal.dto.PartnerDTO;
import ingram.portal.service.UserManagementService;

/**
 * @author samir.gami (INGAMS01)
 */
@Service
public class UserManagementServiceImpl implements UserManagementService {

	private static final Log LOGGER = LogFactoryUtil.getLog(UserManagementServiceImpl.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<PartnerDTO> getPartnerDetails(String country, String partnerType) {
		
		String sql = "select te. cname PartnerName, tee.cvalue partnerCid , te.centityclassref centityclassref from tentities te,"
				+ " tentitiesextensions tee where te.cid = tee.cnoderef and tee.ckey = 'ErpNumber-Primary' ";
		if(Validator.isNotNull(country))
		{
		if (!country.equals(""))
			sql += " and (";
		
		String[] countryList = country.split(",");

		for (int i = 0; i < countryList.length; i++) {
			sql +=  "te.cname like '" + countryList[i] + "%'";
			
			if((i+1) != countryList.length){
				sql += " or ";
			}
		}
		
		sql += ")";
		}
		System.out.println(sql);

		List<PartnerDTO> listOfCountry = jdbcTemplate.query(sql + " order by te.cname",
				new BeanPropertyRowMapper(PartnerDTO.class));

		return listOfCountry;
	}

}
